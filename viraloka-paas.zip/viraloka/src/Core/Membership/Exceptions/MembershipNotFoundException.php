<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Exceptions;

use Exception;

/**
 * Membership Not Found Exception
 * 
 * Thrown when a membership cannot be found.
 * Requirement 4.9
 */
class MembershipNotFoundException extends Exception
{
    public function __construct(string $identityId, string $workspaceId)
    {
        parent::__construct(
            "Membership not found for identity {$identityId} in workspace {$workspaceId}"
        );
    }
}
