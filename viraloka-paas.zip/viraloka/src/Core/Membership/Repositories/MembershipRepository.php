<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Repositories;

use Viraloka\Core\Membership\Membership;
use Viraloka\Core\Membership\Contracts\MembershipRepositoryInterface;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use DateTimeImmutable;

/**
 * Membership Repository
 * 
 * Handles persistence of Membership entities using StorageAdapter.
 * Implements listing by identity and workspace, and owner count validation.
 * 
 * Requirements: 3.7, 3.9, 3.10
 */
class MembershipRepository implements MembershipRepositoryInterface
{
    private const PREFIX_ID = 'membership:id:';
    private const PREFIX_IDENTITY_WORKSPACE = 'membership:identity_workspace:';
    private const INDEX_IDENTITY = 'membership:index:identity:';
    private const INDEX_WORKSPACE = 'membership:index:workspace:';

    public function __construct(
        private readonly StorageAdapterInterface $storageAdapter
    ) {}

    /**
     * Create a new membership
     * 
     * @param Membership $membership
     * @return Membership
     */
    public function create(Membership $membership): Membership
    {
        // Check if membership already exists
        $existing = $this->findByIdentityAndWorkspace(
            $membership->identityId,
            $membership->workspaceId
        );
        
        if ($existing !== null) {
            throw new \RuntimeException('Membership already exists');
        }

        // Serialize membership data
        $data = $this->serialize($membership);

        // Store by ID
        $idKey = self::PREFIX_ID . $membership->membershipId;
        if (!$this->storageAdapter->set($idKey, $data)) {
            throw new \RuntimeException('Failed to save membership');
        }

        // Store identity-workspace index
        $identityWorkspaceKey = $this->getIdentityWorkspaceKey(
            $membership->identityId,
            $membership->workspaceId
        );
        if (!$this->storageAdapter->set($identityWorkspaceKey, $membership->membershipId)) {
            // Rollback ID storage
            $this->storageAdapter->delete($idKey);
            throw new \RuntimeException('Failed to create membership index');
        }

        // Add to identity index
        $this->addToIdentityIndex($membership->identityId, $membership->membershipId);

        // Add to workspace index
        $this->addToWorkspaceIndex($membership->workspaceId, $membership->membershipId);

        return $membership;
    }

    /**
     * Update an existing membership
     * 
     * @param Membership $membership
     * @return Membership
     */
    public function update(Membership $membership): Membership
    {
        // Check if membership exists
        $existing = $this->findById($membership->membershipId);
        if ($existing === null) {
            throw new \RuntimeException('Membership not found');
        }

        // Serialize updated data
        $data = $this->serialize($membership);

        // Update by ID
        $idKey = self::PREFIX_ID . $membership->membershipId;
        if (!$this->storageAdapter->set($idKey, $data)) {
            throw new \RuntimeException('Failed to update membership');
        }

        return $membership;
    }

    /**
     * Delete a membership
     * 
     * @param string $membershipId UUID
     * @return bool
     */
    public function delete(string $membershipId): bool
    {
        // Get membership first to remove indexes
        $membership = $this->findById($membershipId);
        if ($membership === null) {
            return false;
        }

        // Delete by ID
        $idKey = self::PREFIX_ID . $membershipId;
        $this->storageAdapter->delete($idKey);

        // Delete identity-workspace index
        $identityWorkspaceKey = $this->getIdentityWorkspaceKey(
            $membership->identityId,
            $membership->workspaceId
        );
        $this->storageAdapter->delete($identityWorkspaceKey);

        // Remove from identity index
        $this->removeFromIdentityIndex($membership->identityId, $membershipId);

        // Remove from workspace index
        $this->removeFromWorkspaceIndex($membership->workspaceId, $membershipId);

        return true;
    }

    /**
     * Find membership by ID
     * 
     * @param string $membershipId UUID
     * @return Membership|null
     */
    public function findById(string $membershipId): ?Membership
    {
        $key = self::PREFIX_ID . $membershipId;
        $data = $this->storageAdapter->get($key);

        if ($data === null) {
            return null;
        }

        return $this->deserialize($data);
    }

    /**
     * Find membership by identity and workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership|null
     */
    public function findByIdentityAndWorkspace(string $identityId, string $workspaceId): ?Membership
    {
        // Get membership ID from identity-workspace index
        $identityWorkspaceKey = $this->getIdentityWorkspaceKey($identityId, $workspaceId);
        $membershipId = $this->storageAdapter->get($identityWorkspaceKey);

        if ($membershipId === null) {
            return null;
        }

        return $this->findById($membershipId);
    }

    /**
     * List all memberships for an identity
     * 
     * @param string $identityId UUID
     * @return Membership[]
     */
    public function findByIdentity(string $identityId): array
    {
        $indexKey = self::INDEX_IDENTITY . $identityId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);

        if (!is_array($membershipIds)) {
            return [];
        }

        $memberships = [];
        foreach ($membershipIds as $membershipId) {
            $membership = $this->findById($membershipId);
            if ($membership !== null) {
                $memberships[] = $membership;
            }
        }

        return $memberships;
    }

    /**
     * List all memberships for a workspace
     * 
     * @param string $workspaceId UUID
     * @return Membership[]
     */
    public function findByWorkspace(string $workspaceId): array
    {
        $indexKey = self::INDEX_WORKSPACE . $workspaceId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);

        if (!is_array($membershipIds)) {
            return [];
        }

        $memberships = [];
        foreach ($membershipIds as $membershipId) {
            $membership = $this->findById($membershipId);
            if ($membership !== null) {
                $memberships[] = $membership;
            }
        }

        return $memberships;
    }

    /**
     * Count owners for a workspace
     * 
     * @param string $workspaceId UUID
     * @return int
     */
    public function countOwnersByWorkspace(string $workspaceId): int
    {
        $memberships = $this->findByWorkspace($workspaceId);
        
        $ownerCount = 0;
        foreach ($memberships as $membership) {
            if ($membership->role === Membership::ROLE_OWNER && $membership->isActive()) {
                $ownerCount++;
            }
        }

        return $ownerCount;
    }

    /**
     * Get identity-workspace key
     * 
     * @param string $identityId
     * @param string $workspaceId
     * @return string
     */
    private function getIdentityWorkspaceKey(string $identityId, string $workspaceId): string
    {
        return self::PREFIX_IDENTITY_WORKSPACE . $identityId . ':' . $workspaceId;
    }

    /**
     * Serialize membership to array
     * 
     * @param Membership $membership
     * @return array
     */
    private function serialize(Membership $membership): array
    {
        return [
            'membership_id' => $membership->membershipId,
            'identity_id' => $membership->identityId,
            'workspace_id' => $membership->workspaceId,
            'role' => $membership->role,
            'status' => $membership->status,
            'created_at' => $membership->createdAt->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * Deserialize array to membership
     * 
     * @param array $data
     * @return Membership
     */
    private function deserialize(array $data): Membership
    {
        return new Membership(
            $data['membership_id'],
            $data['identity_id'],
            $data['workspace_id'],
            $data['role'],
            $data['status'],
            new DateTimeImmutable($data['created_at'])
        );
    }

    /**
     * Add membership to identity index
     * 
     * @param string $identityId
     * @param string $membershipId
     * @return void
     */
    private function addToIdentityIndex(string $identityId, string $membershipId): void
    {
        $indexKey = self::INDEX_IDENTITY . $identityId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);
        
        if (!is_array($membershipIds)) {
            $membershipIds = [];
        }

        if (!in_array($membershipId, $membershipIds, true)) {
            $membershipIds[] = $membershipId;
            $this->storageAdapter->set($indexKey, $membershipIds);
        }
    }

    /**
     * Remove membership from identity index
     * 
     * @param string $identityId
     * @param string $membershipId
     * @return void
     */
    private function removeFromIdentityIndex(string $identityId, string $membershipId): void
    {
        $indexKey = self::INDEX_IDENTITY . $identityId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);
        
        if (!is_array($membershipIds)) {
            return;
        }

        $membershipIds = array_values(array_filter($membershipIds, fn($id) => $id !== $membershipId));
        $this->storageAdapter->set($indexKey, $membershipIds);
    }

    /**
     * Add membership to workspace index
     * 
     * @param string $workspaceId
     * @param string $membershipId
     * @return void
     */
    private function addToWorkspaceIndex(string $workspaceId, string $membershipId): void
    {
        $indexKey = self::INDEX_WORKSPACE . $workspaceId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);
        
        if (!is_array($membershipIds)) {
            $membershipIds = [];
        }

        if (!in_array($membershipId, $membershipIds, true)) {
            $membershipIds[] = $membershipId;
            $this->storageAdapter->set($indexKey, $membershipIds);
        }
    }

    /**
     * Remove membership from workspace index
     * 
     * @param string $workspaceId
     * @param string $membershipId
     * @return void
     */
    private function removeFromWorkspaceIndex(string $workspaceId, string $membershipId): void
    {
        $indexKey = self::INDEX_WORKSPACE . $workspaceId;
        $membershipIds = $this->storageAdapter->get($indexKey, []);
        
        if (!is_array($membershipIds)) {
            return;
        }

        $membershipIds = array_values(array_filter($membershipIds, fn($id) => $id !== $membershipId));
        $this->storageAdapter->set($indexKey, $membershipIds);
    }
}
