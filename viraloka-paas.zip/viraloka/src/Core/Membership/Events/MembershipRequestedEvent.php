<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Events;

use DateTimeImmutable;

/**
 * Membership Requested Event
 * 
 * Emitted when an identity requests membership to a workspace (pending approval).
 * Requirement 4.6
 */
class MembershipRequestedEvent
{
    public function __construct(
        public readonly string $membershipId,
        public readonly string $identityId,
        public readonly string $workspaceId,
        public readonly DateTimeImmutable $requestedAt
    ) {}
}
