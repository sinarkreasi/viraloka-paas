<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Events;

use DateTimeImmutable;

/**
 * Membership Revoked Event
 * 
 * Emitted when a membership is revoked.
 * Requirement 4.8
 */
class MembershipRevokedEvent
{
    public function __construct(
        public readonly string $membershipId,
        public readonly string $identityId,
        public readonly string $workspaceId,
        public readonly DateTimeImmutable $revokedAt
    ) {}
}
