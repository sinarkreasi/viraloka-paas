<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership;

use DateTimeImmutable;

/**
 * Membership Entity
 * 
 * Represents the relationship between an Identity and a Workspace.
 * Defines access rights through role and status within a workspace.
 */
class Membership
{
    public readonly string $membershipId;    // UUID
    public readonly string $identityId;      // UUID
    public readonly string $workspaceId;     // UUID
    public string $role;                     // owner, admin, member, custom
    public string $status;                   // active, pending, revoked
    public readonly DateTimeImmutable $createdAt;
    
    public const STATUS_ACTIVE = 'active';
    public const STATUS_PENDING = 'pending';
    public const STATUS_REVOKED = 'revoked';
    
    public const ROLE_OWNER = 'owner';
    public const ROLE_ADMIN = 'admin';
    public const ROLE_MEMBER = 'member';
    
    public function __construct(
        string $membershipId,
        string $identityId,
        string $workspaceId,
        string $role,
        string $status = self::STATUS_ACTIVE,
        ?DateTimeImmutable $createdAt = null
    ) {
        $this->membershipId = $membershipId;
        $this->identityId = $identityId;
        $this->workspaceId = $workspaceId;
        $this->role = $role;
        $this->status = $status;
        $this->createdAt = $createdAt ?? new DateTimeImmutable();
    }
    
    /**
     * Check if membership is active
     */
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }
    
    /**
     * Check if membership is pending approval
     */
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }
    
    /**
     * Check if membership has owner role
     */
    public function isOwner(): bool
    {
        return $this->role === self::ROLE_OWNER;
    }
    
    /**
     * Approve pending membership and assign role
     */
    public function approve(string $role): void
    {
        $this->status = self::STATUS_ACTIVE;
        $this->role = $role;
    }
    
    /**
     * Revoke membership
     */
    public function revoke(): void
    {
        $this->status = self::STATUS_REVOKED;
    }
}
