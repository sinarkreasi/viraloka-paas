<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Contracts;

use Viraloka\Core\Membership\Membership;

/**
 * Membership Engine Interface
 * 
 * Defines the contract for managing workspace membership relations.
 * Handles membership lifecycle: attach, request, approve, revoke.
 */
interface MembershipEngineInterface
{
    /**
     * Attach identity to workspace with role (direct membership)
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $role owner|admin|member|custom
     * @return Membership
     * @throws \Viraloka\Core\Membership\Exceptions\MembershipExistsException
     */
    public function attach(string $identityId, string $workspaceId, string $role): Membership;
    
    /**
     * Request membership (pending approval)
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership
     */
    public function request(string $identityId, string $workspaceId): Membership;
    
    /**
     * Approve pending membership request
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $role Role to assign
     * @return Membership
     * @throws \Viraloka\Core\Membership\Exceptions\MembershipNotPendingException
     */
    public function approve(string $identityId, string $workspaceId, string $role): Membership;
    
    /**
     * Revoke membership
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return bool
     * @throws \Viraloka\Core\Membership\Exceptions\LastOwnerException
     */
    public function revoke(string $identityId, string $workspaceId): bool;
    
    /**
     * Get membership for identity in workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership|null
     */
    public function getMembership(string $identityId, string $workspaceId): ?Membership;
    
    /**
     * List all memberships for an identity
     * 
     * @param string $identityId UUID
     * @return Membership[]
     */
    public function getMembershipsForIdentity(string $identityId): array;
    
    /**
     * List all memberships for a workspace
     * 
     * @param string $workspaceId UUID
     * @return Membership[]
     */
    public function getMembershipsForWorkspace(string $workspaceId): array;
    
    /**
     * Check if identity has permission in workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $capability Capability to check
     * @return bool
     */
    public function hasPermission(string $identityId, string $workspaceId, string $capability): bool;
}
