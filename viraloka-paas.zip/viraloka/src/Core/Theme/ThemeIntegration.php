<?php

namespace Viraloka\Core\Theme;

use Viraloka\Core\Application;
use Viraloka\Core\Context\Contracts\ContextResolverContract;
use Viraloka\Core\Modules\Contracts\AdminMenuBuilderContract;
use Viraloka\Core\Modules\Contracts\ModuleRecommenderContract;

/**
 * Theme Integration
 * 
 * Allows themes to register context information, UI hints, and module recommendations
 * while preventing themes from modifying Core service behavior.
 * 
 * Implementation Details:
 * - Provides safe API for themes to register metadata
 * - Validates theme input before applying
 * - Prevents themes from modifying Core services
 * - Integrates with ContextResolver, AdminMenuBuilder, and ModuleRecommender
 */
class ThemeIntegration
{
    /**
     * Application container
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Event adapter instance
     * 
     * @var \Viraloka\Core\Adapter\Contracts\EventAdapterInterface
     */
    protected \Viraloka\Core\Adapter\Contracts\EventAdapterInterface $eventAdapter;
    
    /**
     * Valid context values
     * 
     * @var array
     */
    protected array $validContexts = [
        'default',
        'ecommerce',
        'blog',
        'portfolio',
        'business',
        'landing',
        'membership',
        'community',
    ];
    
    /**
     * Theme-registered UI hints
     * 
     * @var array
     */
    protected array $uiHints = [];
    
    /**
     * Theme-registered context
     * 
     * @var string|null
     */
    protected ?string $themeContext = null;
    
    /**
     * Theme-registered module recommendations
     * 
     * @var array
     */
    protected array $moduleRecommendations = [];
    
    /**
     * Create a new theme integration instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
        
        // Get EventAdapter from AdapterRegistry
        $adapterRegistry = $app->make(\Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface::class);
        $this->eventAdapter = $adapterRegistry->event();
    }
    
    /**
     * Register context metadata from theme
     * 
     * Validates the context before updating. Only valid contexts are accepted.
     * 
     * @param string $context
     * @return bool Returns true if context was registered, false if invalid
     */
    public function registerContext(string $context): bool
    {
        // Validate context
        if (!in_array($context, $this->validContexts)) {
            return false;
        }
        
        // Store theme context for context resolution
        $this->themeContext = $context;
        
        // Also store in UI hints for backward compatibility
        $this->uiHints['context'] = $context;
        
        return true;
    }
    
    /**
     * Get the registered theme context
     * 
     * @return string|null
     */
    public function getThemeContext(): ?string
    {
        return $this->themeContext;
    }
    
    /**
     * Register UI hints from theme
     * 
     * Stores UI hints that will be incorporated into admin menu rendering.
     * 
     * @param array $hints
     * @return void
     */
    public function registerUIHints(array $hints): void
    {
        // Validate and sanitize hints
        foreach ($hints as $key => $value) {
            // Only allow specific hint keys
            if (in_array($key, ['menu_title', 'icon', 'order', 'parent_slug'])) {
                $this->uiHints[$key] = $value;
            }
        }
    }
    
    /**
     * Get registered UI hints
     * 
     * @return array
     */
    public function getUIHints(): array
    {
        return $this->uiHints;
    }
    
    /**
     * Register module recommendations from theme
     * 
     * Stores module recommendations that will be included in suggestion lists.
     * 
     * @param array $recommendations Array of module IDs
     * @return void
     */
    public function registerModuleRecommendations(array $recommendations): void
    {
        // Validate that recommendations are strings (module IDs)
        foreach ($recommendations as $moduleId) {
            if (is_string($moduleId)) {
                $this->moduleRecommendations[] = $moduleId;
            }
        }
    }
    
    /**
     * Get registered module recommendations
     * 
     * @return array
     */
    public function getModuleRecommendations(): array
    {
        return $this->moduleRecommendations;
    }
    
    /**
     * Activate theme integration
     * 
     * Registers event hook for theme integration.
     * Themes can hook into 'viraloka_theme_integration' to register metadata.
     * 
     * @return void
     */
    public function activate(): void
    {
        // Register event hook using EventAdapter
        $this->eventAdapter->listen('viraloka_theme_integration', function () {
            // Pass this instance to the hook so themes can call methods
            $this->eventAdapter->dispatch('viraloka_theme_integration_ready', ['integration' => $this]);
        });
    }
    
    /**
     * Prevent themes from modifying Core services
     * 
     * This method checks if a theme is attempting to rebind or override
     * Core services in the container.
     * 
     * @param string $abstract
     * @return bool Returns true if modification is allowed, false if prevented
     */
    public function allowServiceModification(string $abstract): bool
    {
        // List of protected Core services that themes cannot modify
        $protectedServices = [
            'config',
            'logger',
            'events',
            Application::class,
            ContextResolverContract::class,
            AdminMenuBuilderContract::class,
            ModuleRecommenderContract::class,
            'viraloka.kernel',
            'viraloka.security',
            'viraloka.performance',
        ];
        
        // Check if the service is protected
        return !in_array($abstract, $protectedServices);
    }
}
