<?php

namespace Viraloka\Core\Subscription;

use Viraloka\Core\Application;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Subscription\Contracts\SubscriptionEngineContract;
use Viraloka\Core\Workspace\Workspace;

/**
 * SubscriptionEngine
 * 
 * Provides subscription management interface with tier-based limits and entitlements.
 * Tracks subscription status per workspace and handles subscription lifecycle
 * (active, expired, cancelled, trial).
 */
class SubscriptionEngine implements SubscriptionEngineContract
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Subscription tier definitions
     * 
     * Defines entitlements and limits for each tier.
     * 
     * @var array
     */
    protected array $tierDefinitions = [
        'free' => [
            'entitlements' => [
                'basic_features',
            ],
            'limits' => [
                'api_calls' => 1000,
                'storage' => 1048576, // 1 MB in bytes
                'users' => 1,
                'workspaces' => 1,
            ],
        ],
        'pro' => [
            'entitlements' => [
                'basic_features',
                'premium_features',
                'api_access',
                'analytics_access',
            ],
            'limits' => [
                'api_calls' => 10000,
                'storage' => 10485760, // 10 MB in bytes
                'users' => 10,
                'workspaces' => 5,
            ],
        ],
        'enterprise' => [
            'entitlements' => [
                'basic_features',
                'premium_features',
                'api_access',
                'analytics_access',
                'priority_support',
                'custom_integrations',
            ],
            'limits' => [
                'api_calls' => -1, // Unlimited
                'storage' => -1, // Unlimited
                'users' => -1, // Unlimited
                'workspaces' => -1, // Unlimited
            ],
        ],
    ];
    
    /**
     * Subscription cache
     * 
     * @var array
     */
    protected array $subscriptionCache = [];
    
    /**
     * Create a new SubscriptionEngine instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->logger = $app->make(Logger::class);
    }
    
    /**
     * Get subscription tier for a user in a workspace
     * 
     * Returns the subscription tier identifier (e.g., 'free', 'pro', 'enterprise').
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return string Subscription tier identifier
     */
    public function getTier(string $userId, Workspace $workspace): string
    {
        try {
            $subscription = $this->getSubscription($userId, $workspace);
            return $subscription['tier'] ?? 'free';
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get tier for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Get Tier Error'
            );
            
            // Default to free tier on error
            return 'free';
        }
    }
    
    /**
     * Check if a subscription tier has a specific entitlement
     * 
     * Verifies that a subscription tier includes the requested entitlement.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $entitlement Entitlement identifier
     * @return bool True if tier has the entitlement, false otherwise
     */
    public function hasEntitlement(string $tier, string $entitlement): bool
    {
        try {
            if (!isset($this->tierDefinitions[$tier])) {
                $this->logger->warning(
                    sprintf('Unknown subscription tier: %s', $tier),
                    'subscription-engine'
                );
                return false;
            }
            
            $entitlements = $this->tierDefinitions[$tier]['entitlements'] ?? [];
            return in_array($entitlement, $entitlements);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to check entitlement %s for tier %s: %s', 
                    $entitlement, $tier, $e->getMessage()),
                'subscription-engine',
                'Entitlement Check Error'
            );
            return false;
        }
    }
    
    /**
     * Check if a limit is within the subscription tier's allowance
     * 
     * Verifies that a requested amount is within the tier's limit for a specific resource.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $limitType Limit type (e.g., 'api_calls', 'storage', 'users')
     * @param int $amount Amount to check
     * @return bool True if within limit, false if exceeds limit
     */
    public function checkLimit(string $tier, string $limitType, int $amount): bool
    {
        try {
            $limit = $this->getLimit($tier, $limitType);
            
            // -1 means unlimited
            if ($limit === -1) {
                return true;
            }
            
            // Check if amount is within limit
            return $amount <= $limit;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to check limit %s for tier %s: %s', 
                    $limitType, $tier, $e->getMessage()),
                'subscription-engine',
                'Limit Check Error'
            );
            
            // Deny on error for security
            return false;
        }
    }
    
    /**
     * Check if a subscription is active
     * 
     * Verifies that the subscription is in an active state (not expired or cancelled).
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return bool True if subscription is active, false otherwise
     */
    public function isActive(string $userId, Workspace $workspace): bool
    {
        try {
            $status = $this->getStatus($userId, $workspace);
            return in_array($status, ['active', 'trial']);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to check subscription status for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Status Check Error'
            );
            
            // Default to inactive on error for security
            return false;
        }
    }
    
    /**
     * Get subscription status
     * 
     * Returns the current subscription status (active, expired, cancelled, trial).
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return string Subscription status
     */
    public function getStatus(string $userId, Workspace $workspace): string
    {
        try {
            $subscription = $this->getSubscription($userId, $workspace);
            $status = $subscription['status'] ?? 'active';
            
            // Check if subscription has expired
            if (isset($subscription['expires_at'])) {
                $expiresAt = $subscription['expires_at'];
                if (is_numeric($expiresAt) && $expiresAt < time()) {
                    return 'expired';
                }
            }
            
            return $status;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get subscription status for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Get Status Error'
            );
            
            // Default to active on error (graceful degradation)
            return 'active';
        }
    }
    
    /**
     * Get limit value for a subscription tier
     * 
     * Returns the numeric limit for a specific resource type in a tier.
     * Returns -1 for unlimited.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $limitType Limit type (e.g., 'api_calls', 'storage', 'users')
     * @return int Limit value, or -1 for unlimited
     */
    public function getLimit(string $tier, string $limitType): int
    {
        try {
            if (!isset($this->tierDefinitions[$tier])) {
                $this->logger->warning(
                    sprintf('Unknown subscription tier: %s', $tier),
                    'subscription-engine'
                );
                
                // Return free tier limit as fallback
                return $this->tierDefinitions['free']['limits'][$limitType] ?? 0;
            }
            
            $limits = $this->tierDefinitions[$tier]['limits'] ?? [];
            return $limits[$limitType] ?? 0;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get limit %s for tier %s: %s', 
                    $limitType, $tier, $e->getMessage()),
                'subscription-engine',
                'Get Limit Error'
            );
            return 0;
        }
    }
    
    /**
     * Get subscription data for a user in a workspace
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return array Subscription data
     */
    protected function getSubscription(string $userId, Workspace $workspace): array
    {
        // Check cache first
        $cacheKey = $this->getSubscriptionCacheKey($userId, $workspace);
        if (isset($this->subscriptionCache[$cacheKey])) {
            return $this->subscriptionCache[$cacheKey];
        }
        
        try {
            // In a real implementation, this would query a subscriptions table
            // For now, we'll use WordPress options as a simple implementation
            $optionKey = sprintf('viraloka_subscription_%s_%s', $workspace->id, $userId);
            $subscription = get_option($optionKey);
            
            if (!is_array($subscription)) {
                // Default subscription
                $subscription = [
                    'tier' => 'free',
                    'status' => 'active',
                    'created_at' => time(),
                ];
            }
            
            // Cache the result
            $this->subscriptionCache[$cacheKey] = $subscription;
            
            return $subscription;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get subscription for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Get Subscription Error'
            );
            
            // Return default subscription on error
            return [
                'tier' => 'free',
                'status' => 'active',
                'created_at' => time(),
            ];
        }
    }
    
    /**
     * Update subscription for a user in a workspace
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @param array $data Subscription data
     * @return bool True on success, false on failure
     */
    public function updateSubscription(string $userId, Workspace $workspace, array $data): bool
    {
        try {
            $optionKey = sprintf('viraloka_subscription_%s_%s', $workspace->id, $userId);
            
            // Get current subscription
            $subscription = $this->getSubscription($userId, $workspace);
            
            // Merge with new data
            $subscription = array_merge($subscription, $data);
            $subscription['updated_at'] = time();
            
            // Save subscription
            update_option($optionKey, $subscription);
            
            // Clear cache
            $cacheKey = $this->getSubscriptionCacheKey($userId, $workspace);
            unset($this->subscriptionCache[$cacheKey]);
            
            $this->logger->info(
                sprintf('Subscription updated for user %s in workspace %s', $userId, $workspace->id),
                'subscription-engine'
            );
            
            return true;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to update subscription for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Update Subscription Error'
            );
            return false;
        }
    }
    
    /**
     * Cancel subscription for a user in a workspace
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return bool True on success, false on failure
     */
    public function cancelSubscription(string $userId, Workspace $workspace): bool
    {
        try {
            return $this->updateSubscription($userId, $workspace, [
                'status' => 'cancelled',
                'cancelled_at' => time(),
            ]);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to cancel subscription for user %s in workspace %s: %s', 
                    $userId, $workspace->id, $e->getMessage()),
                'subscription-engine',
                'Cancel Subscription Error'
            );
            return false;
        }
    }
    
    /**
     * Get subscription cache key
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return string Cache key
     */
    protected function getSubscriptionCacheKey(string $userId, Workspace $workspace): string
    {
        return sprintf('%s:%s', $workspace->id, $userId);
    }
    
    /**
     * Get all available tiers
     * 
     * @return array Array of tier identifiers
     */
    public function getAvailableTiers(): array
    {
        return array_keys($this->tierDefinitions);
    }
    
    /**
     * Get tier definition
     * 
     * @param string $tier Tier identifier
     * @return array|null Tier definition or null if not found
     */
    public function getTierDefinition(string $tier): ?array
    {
        return $this->tierDefinitions[$tier] ?? null;
    }
}
