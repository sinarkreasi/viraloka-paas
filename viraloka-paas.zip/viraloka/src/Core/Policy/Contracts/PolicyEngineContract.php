<?php

namespace Viraloka\Core\Policy\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Policy Engine Contract
 * 
 * Defines the interface for access policy evaluation and enforcement.
 * The PolicyEngine evaluates access requests based on role, capability,
 * entitlement, and usage quotas within workspace boundaries.
 */
interface PolicyEngineContract
{
    /**
     * Evaluate an access request
     * 
     * Evaluates whether a user has access to a resource based on:
     * - User role
     * - User capabilities
     * - Subscription entitlements
     * - Usage quotas
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action being performed (e.g., 'read', 'write', 'delete')
     * @param Workspace $workspace Workspace context
     * @return bool True if access is granted, false otherwise
     */
    public function evaluate(string $userId, string $resource, string $action, Workspace $workspace): bool;
    
    /**
     * Check if a user has a specific entitlement
     * 
     * Verifies that the user's subscription tier includes the requested entitlement.
     * 
     * @param string $userId User ID
     * @param string $entitlement Entitlement identifier
     * @param Workspace $workspace Workspace context
     * @return bool True if user has the entitlement, false otherwise
     */
    public function checkEntitlement(string $userId, string $entitlement, Workspace $workspace): bool;
    
    /**
     * Enforce usage quota
     * 
     * Checks if the user has remaining quota for a specific resource type.
     * Returns true if quota is available, false if limit is reached.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage')
     * @param int $amount Amount to check against quota
     * @param Workspace $workspace Workspace context
     * @return bool True if quota is available, false if limit reached
     */
    public function enforceQuota(string $userId, string $resourceType, int $amount, Workspace $workspace): bool;
    
    /**
     * Log a policy violation
     * 
     * Records when access is denied due to policy violation.
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action attempted
     * @param string $reason Reason for denial
     * @param Workspace $workspace Workspace context
     * @return void
     */
    public function logViolation(string $userId, string $resource, string $action, string $reason, Workspace $workspace): void;
}
