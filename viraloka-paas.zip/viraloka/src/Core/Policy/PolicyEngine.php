<?php

namespace Viraloka\Core\Policy;

use Viraloka\Core\Application;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Policy\Contracts\PolicyEngineContract;
use Viraloka\Core\Workspace\Workspace;

/**
 * PolicyEngine
 * 
 * Evaluates and enforces access policies based on role, capability,
 * entitlement, and usage quotas. Provides workspace-scoped policy
 * evaluation and violation logging.
 */
class PolicyEngine implements PolicyEngineContract
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Policy violation log
     * 
     * @var array
     */
    protected array $violations = [];
    
    /**
     * Create a new PolicyEngine instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->logger = $app->make(Logger::class);
    }
    
    /**
     * Evaluate an access request
     * 
     * Evaluates whether a user has access to a resource based on:
     * - User role
     * - User capabilities
     * - Subscription entitlements
     * - Usage quotas
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action being performed (e.g., 'read', 'write', 'delete')
     * @param Workspace $workspace Workspace context
     * @return bool True if access is granted, false otherwise
     */
    public function evaluate(string $userId, string $resource, string $action, Workspace $workspace): bool
    {
        // Step 1: Check role-based access
        if (!$this->checkRole($userId, $resource, $action, $workspace)) {
            $this->logViolation($userId, $resource, $action, 'Insufficient role', $workspace);
            return false;
        }
        
        // Step 2: Check capability-based access
        if (!$this->checkCapability($userId, $resource, $action, $workspace)) {
            $this->logViolation($userId, $resource, $action, 'Missing capability', $workspace);
            return false;
        }
        
        // Step 3: Check entitlement-based access
        $requiredEntitlement = $this->getRequiredEntitlement($resource, $action);
        if ($requiredEntitlement && !$this->checkEntitlement($userId, $requiredEntitlement, $workspace)) {
            $this->logViolation($userId, $resource, $action, 'Missing entitlement: ' . $requiredEntitlement, $workspace);
            return false;
        }
        
        // Step 4: Check usage quota
        $resourceType = $this->getResourceType($resource);
        if ($resourceType && !$this->enforceQuota($userId, $resourceType, 1, $workspace)) {
            $this->logViolation($userId, $resource, $action, 'Quota exceeded', $workspace);
            return false;
        }
        
        // All checks passed
        return true;
    }
    
    /**
     * Check if a user has a specific entitlement
     * 
     * Verifies that the user's subscription tier includes the requested entitlement.
     * 
     * @param string $userId User ID
     * @param string $entitlement Entitlement identifier
     * @param Workspace $workspace Workspace context
     * @return bool True if user has the entitlement, false otherwise
     */
    public function checkEntitlement(string $userId, string $entitlement, Workspace $workspace): bool
    {
        // Check if SubscriptionEngine is available
        if (!$this->app->bound('Viraloka\Core\Subscription\Contracts\SubscriptionEngineContract')) {
            // If SubscriptionEngine not available, allow access (graceful degradation)
            return true;
        }
        
        try {
            $subscriptionEngine = $this->app->make('Viraloka\Core\Subscription\Contracts\SubscriptionEngineContract');
            
            // Get user's subscription tier
            $tier = $subscriptionEngine->getTier($userId, $workspace);
            
            // Check if tier includes the entitlement
            return $subscriptionEngine->hasEntitlement($tier, $entitlement);
        } catch (\Throwable $e) {
            $this->logger->error(
                "Failed to check entitlement: {$e->getMessage()}",
                'policy-engine',
                'Entitlement Check Error'
            );
            
            // On error, deny access for security
            return false;
        }
    }
    
    /**
     * Enforce usage quota
     * 
     * Checks if the user has remaining quota for a specific resource type.
     * Returns true if quota is available, false if limit is reached.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage')
     * @param int $amount Amount to check against quota
     * @param Workspace $workspace Workspace context
     * @return bool True if quota is available, false if limit reached
     */
    public function enforceQuota(string $userId, string $resourceType, int $amount, Workspace $workspace): bool
    {
        // Check if UsageEngine is available
        if (!$this->app->bound('Viraloka\Core\Usage\Contracts\UsageEngineContract')) {
            // If UsageEngine not available, allow access (graceful degradation)
            return true;
        }
        
        try {
            $usageEngine = $this->app->make('Viraloka\Core\Usage\Contracts\UsageEngineContract');
            
            // Check if user has available quota
            return $usageEngine->checkLimit($userId, $resourceType, $amount, $workspace);
        } catch (\Throwable $e) {
            $this->logger->error(
                "Failed to enforce quota: {$e->getMessage()}",
                'policy-engine',
                'Quota Enforcement Error'
            );
            
            // On error, deny access for security
            return false;
        }
    }
    
    /**
     * Log a policy violation
     * 
     * Records when access is denied due to policy violation.
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action attempted
     * @param string $reason Reason for denial
     * @param Workspace $workspace Workspace context
     * @return void
     */
    public function logViolation(string $userId, string $resource, string $action, string $reason, Workspace $workspace): void
    {
        $violation = [
            'timestamp' => time(),
            'user_id' => $userId,
            'workspace_id' => $workspace->id,
            'resource' => $resource,
            'action' => $action,
            'reason' => $reason,
        ];
        
        // Store violation in memory
        $this->violations[] = $violation;
        
        // Log violation
        $this->logger->warning(
            sprintf(
                "Policy violation: User %s attempted %s on %s in workspace %s - %s",
                $userId,
                $action,
                $resource,
                $workspace->id,
                $reason
            ),
            'policy-engine'
        );
    }
    
    /**
     * Check role-based access
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action being performed
     * @param Workspace $workspace Workspace context
     * @return bool
     */
    protected function checkRole(string $userId, string $resource, string $action, Workspace $workspace): bool
    {
        // Check if AccountEngine is available
        if (!$this->app->bound('Viraloka\Core\Account\Contracts\AccountEngineContract')) {
            // If AccountEngine not available, allow access (graceful degradation)
            return true;
        }
        
        try {
            $accountEngine = $this->app->make('Viraloka\Core\Account\Contracts\AccountEngineContract');
            
            // Get required role for this resource/action combination
            $requiredRole = $this->getRequiredRole($resource, $action);
            
            if (!$requiredRole) {
                // No specific role required
                return true;
            }
            
            // Check if user has the required role in this workspace
            return $accountEngine->hasRole($userId, $requiredRole, $workspace);
        } catch (\Throwable $e) {
            $this->logger->error(
                "Failed to check role: {$e->getMessage()}",
                'policy-engine',
                'Role Check Error'
            );
            
            // On error, deny access for security
            return false;
        }
    }
    
    /**
     * Check capability-based access
     * 
     * @param string $userId User ID
     * @param string $resource Resource identifier
     * @param string $action Action being performed
     * @param Workspace $workspace Workspace context
     * @return bool
     */
    protected function checkCapability(string $userId, string $resource, string $action, Workspace $workspace): bool
    {
        // Check if AccountEngine is available
        if (!$this->app->bound('Viraloka\Core\Account\Contracts\AccountEngineContract')) {
            // If AccountEngine not available, allow access (graceful degradation)
            return true;
        }
        
        try {
            $accountEngine = $this->app->make('Viraloka\Core\Account\Contracts\AccountEngineContract');
            
            // Get required capability for this resource/action combination
            $requiredCapability = $this->getRequiredCapability($resource, $action);
            
            if (!$requiredCapability) {
                // No specific capability required
                return true;
            }
            
            // Check if user has the required capability in this workspace
            return $accountEngine->hasCapability($userId, $requiredCapability, $workspace);
        } catch (\Throwable $e) {
            $this->logger->error(
                "Failed to check capability: {$e->getMessage()}",
                'policy-engine',
                'Capability Check Error'
            );
            
            // On error, deny access for security
            return false;
        }
    }
    
    /**
     * Get required role for a resource/action combination
     * 
     * @param string $resource Resource identifier
     * @param string $action Action being performed
     * @return string|null Required role, or null if no specific role required
     */
    protected function getRequiredRole(string $resource, string $action): ?string
    {
        // This would typically be configured via a policy configuration file
        // For now, we'll use a simple mapping
        $roleMap = [
            'modules:manage' => 'admin',
            'workspaces:manage' => 'admin',
            'users:manage' => 'admin',
            'settings:write' => 'admin',
        ];
        
        $key = $resource . ':' . $action;
        return $roleMap[$key] ?? null;
    }
    
    /**
     * Get required capability for a resource/action combination
     * 
     * @param string $resource Resource identifier
     * @param string $action Action being performed
     * @return string|null Required capability, or null if no specific capability required
     */
    protected function getRequiredCapability(string $resource, string $action): ?string
    {
        // This would typically be configured via a policy configuration file
        // For now, we'll use a simple mapping
        $capabilityMap = [
            'modules:install' => 'manage_viraloka_modules',
            'modules:uninstall' => 'manage_viraloka_modules',
            'workspaces:create' => 'manage_viraloka_workspaces',
            'workspaces:delete' => 'manage_viraloka_workspaces',
        ];
        
        $key = $resource . ':' . $action;
        return $capabilityMap[$key] ?? null;
    }
    
    /**
     * Get required entitlement for a resource/action combination
     * 
     * @param string $resource Resource identifier
     * @param string $action Action being performed
     * @return string|null Required entitlement, or null if no specific entitlement required
     */
    protected function getRequiredEntitlement(string $resource, string $action): ?string
    {
        // This would typically be configured via a policy configuration file
        // For now, we'll use a simple mapping
        $entitlementMap = [
            'api:access' => 'api_access',
            'advanced_features:use' => 'premium_features',
            'analytics:view' => 'analytics_access',
        ];
        
        $key = $resource . ':' . $action;
        return $entitlementMap[$key] ?? null;
    }
    
    /**
     * Get resource type for quota enforcement
     * 
     * @param string $resource Resource identifier
     * @return string|null Resource type, or null if no quota applies
     */
    protected function getResourceType(string $resource): ?string
    {
        // This would typically be configured via a policy configuration file
        // For now, we'll use a simple mapping
        $resourceTypeMap = [
            'api' => 'api_calls',
            'storage' => 'storage',
            'compute' => 'compute_time',
        ];
        
        return $resourceTypeMap[$resource] ?? null;
    }
    
    /**
     * Get all logged violations
     * 
     * @return array
     */
    public function getViolations(): array
    {
        return $this->violations;
    }
    
    /**
     * Clear violation log
     * 
     * @return void
     */
    public function clearViolations(): void
    {
        $this->violations = [];
    }
}
