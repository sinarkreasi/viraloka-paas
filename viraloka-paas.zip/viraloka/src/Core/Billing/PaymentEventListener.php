<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing;

use Viraloka\Core\Billing\Contracts\SubscriptionEngineInterface;
use Viraloka\Core\Billing\Events\PaymentSucceededEvent;
use Viraloka\Core\Billing\Events\PaymentFailedEvent;
use Viraloka\Core\Events\EventDispatcher;

/**
 * Payment Event Listener
 * 
 * Listens to payment events and updates subscription status accordingly.
 * 
 * Requirements: 8.4, 8.6, 8.7, 9.1, 9.3
 */
class PaymentEventListener
{
    private SubscriptionEngineInterface $subscriptionEngine;
    
    public function __construct(SubscriptionEngineInterface $subscriptionEngine)
    {
        $this->subscriptionEngine = $subscriptionEngine;
    }
    
    /**
     * Register payment event listeners
     * 
     * @param EventDispatcher $eventDispatcher
     * @return void
     */
    public function register(EventDispatcher $eventDispatcher): void
    {
        // Listen to payment.succeeded event (Requirement 8.6)
        $eventDispatcher->listen('payment.succeeded', function ($event) {
            $this->handlePaymentSucceeded($event);
        });
        
        // Listen to payment.failed event (Requirement 8.7)
        $eventDispatcher->listen('payment.failed', function ($event) {
            $this->handlePaymentFailed($event);
        });
    }
    
    /**
     * Handle payment.succeeded event
     * 
     * Updates subscription status to active when payment succeeds.
     * 
     * Requirements: 8.6, 9.1
     * 
     * @param PaymentSucceededEvent $event
     * @return void
     */
    public function handlePaymentSucceeded(PaymentSucceededEvent $event): void
    {
        try {
            // Get current subscription for workspace
            $subscription = $this->subscriptionEngine->current($event->workspaceId);
            
            // If no active subscription, check if there's a paused one
            if ($subscription === null) {
                // Try to resume paused subscription
                try {
                    $this->subscriptionEngine->resume($event->workspaceId);
                } catch (\Throwable $e) {
                    // No paused subscription to resume, that's okay
                }
                return;
            }
            
            // Ensure subscription is active (Requirement 9.1)
            if ($subscription->status !== Subscription::STATUS_ACTIVE) {
                // If subscription is paused, resume it
                if ($subscription->isPaused()) {
                    $this->subscriptionEngine->resume($event->workspaceId);
                }
            }
        } catch (\Throwable $e) {
            // Log error but don't throw - event listeners should not block
            if (function_exists('error_log')) {
                error_log(sprintf(
                    'Error handling payment.succeeded for workspace %s: %s',
                    $event->workspaceId,
                    $e->getMessage()
                ));
            }
        }
    }
    
    /**
     * Handle payment.failed event
     * 
     * Optionally pauses subscription when payment fails.
     * 
     * Requirements: 8.7, 9.3
     * 
     * @param PaymentFailedEvent $event
     * @return void
     */
    public function handlePaymentFailed(PaymentFailedEvent $event): void
    {
        try {
            // Get current subscription for workspace
            $subscription = $this->subscriptionEngine->current($event->workspaceId);
            
            if ($subscription === null) {
                // No active subscription, nothing to do
                return;
            }
            
            // Optionally pause subscription on payment failure (Requirement 9.3)
            // This is a business decision - for now we'll pause the subscription
            if ($subscription->isActive()) {
                $this->subscriptionEngine->pause($event->workspaceId);
            }
        } catch (\Throwable $e) {
            // Log error but don't throw - event listeners should not block
            if (function_exists('error_log')) {
                error_log(sprintf(
                    'Error handling payment.failed for workspace %s: %s',
                    $event->workspaceId,
                    $e->getMessage()
                ));
            }
        }
    }
}
