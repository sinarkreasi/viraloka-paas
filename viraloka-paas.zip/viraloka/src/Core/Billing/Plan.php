<?php

namespace Viraloka\Core\Billing;

use DateTimeImmutable;

/**
 * Plan Entity
 * 
 * Represents a predefined set of entitlements and pricing.
 */
class Plan
{
    public function __construct(
        public readonly string $planId,
        public string $name,
        public string $billingPeriod,
        public array $entitlements,
        public ?int $trialPeriodDays = null,
        public bool $isActive = true,
        public array $metadata = [],
        public readonly ?DateTimeImmutable $createdAt = null
    ) {
        $this->createdAt = $createdAt ?? new DateTimeImmutable();
    }
    
    public function getEntitlement(string $key): mixed
    {
        return $this->entitlements[$key] ?? null;
    }
    
    public function hasEntitlement(string $key): bool
    {
        return isset($this->entitlements[$key]);
    }
    
    public function archive(): void
    {
        $this->isActive = false;
    }
}
