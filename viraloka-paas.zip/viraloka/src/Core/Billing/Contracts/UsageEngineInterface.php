<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Contracts;

use DateTimeInterface;
use Viraloka\Core\Billing\UsageRecord;

/**
 * Usage Engine Interface
 * 
 * Defines the contract for tracking feature consumption and usage metrics.
 */
interface UsageEngineInterface
{
    /**
     * Record usage for a feature
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key (e.g., "shortlink.clicks")
     * @param int $amount Amount to record
     * @param array $metadata Optional metadata
     * @return UsageRecord
     * @throws \InvalidArgumentException If amount is negative or key format is invalid
     */
    public function record(string $workspaceId, string $key, int $amount, array $metadata = []): UsageRecord;
    
    /**
     * Get current billing period usage
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return int
     */
    public function current(string $workspaceId, string $key): int;
    
    /**
     * Get all-time total usage
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return int
     */
    public function total(string $workspaceId, string $key): int;
    
    /**
     * Get usage within time range
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @param DateTimeInterface $start Start date
     * @param DateTimeInterface $end End date
     * @return int
     * @throws \InvalidArgumentException If date range is invalid
     */
    public function range(string $workspaceId, string $key, DateTimeInterface $start, DateTimeInterface $end): int;
    
    /**
     * Get usage breakdown by key for workspace
     * 
     * @param string $workspaceId UUID
     * @param DateTimeInterface|null $start Optional start date
     * @param DateTimeInterface|null $end Optional end date
     * @return array<string, int> Key => usage amount
     */
    public function getUsageBreakdown(string $workspaceId, ?DateTimeInterface $start = null, ?DateTimeInterface $end = null): array;
    
    /**
     * Reset usage for billing period
     * 
     * @param string $workspaceId UUID
     * @return void
     */
    public function resetBillingPeriod(string $workspaceId): void;
}
