<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Entitlement Not Found Exception
 * 
 * Thrown when an entitlement cannot be found for a workspace and key.
 */
class EntitlementNotFoundException extends \RuntimeException
{
    public function __construct(string $workspaceId, string $key)
    {
        parent::__construct(
            "Entitlement not found for workspace '{$workspaceId}' with key '{$key}'"
        );
    }
}
