<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Invalid Date Range Exception
 * 
 * Thrown when a date range is invalid (e.g., end before start).
 */
class InvalidDateRangeException extends \RuntimeException
{
    public function __construct(string $message = "End date must be after start date")
    {
        parent::__construct($message);
    }
}
