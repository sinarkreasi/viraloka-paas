<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Adapter Not Found Exception
 * 
 * Thrown when a payment adapter is not registered.
 */
class AdapterNotFoundException extends \RuntimeException
{
    public function __construct(string $adapterName)
    {
        parent::__construct(
            "Payment adapter not found: {$adapterName}"
        );
    }
}
