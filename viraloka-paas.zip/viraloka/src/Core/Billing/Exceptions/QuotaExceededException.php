<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Quota Exceeded Exception
 * 
 * Thrown when attempting to consume more quota than available.
 */
class QuotaExceededException extends \RuntimeException
{
    public function __construct(string $key, int $currentUsage, int $limit, int $attemptedAmount)
    {
        parent::__construct(
            "Quota exceeded for '{$key}': current usage {$currentUsage}, limit {$limit}, attempted to consume {$attemptedAmount}"
        );
    }
}
