<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Invalid Key Format Exception
 * 
 * Thrown when a key does not follow the required dot notation format.
 */
class InvalidKeyFormatException extends \RuntimeException
{
    public function __construct(string $key)
    {
        parent::__construct(
            "Key must follow dot notation format (e.g., 'module.feature'): {$key}"
        );
    }
}
