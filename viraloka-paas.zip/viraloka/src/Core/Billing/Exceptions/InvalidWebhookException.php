<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Invalid Webhook Exception
 * 
 * Thrown when webhook signature validation fails.
 */
class InvalidWebhookException extends \RuntimeException
{
    public function __construct(string $message = "Webhook signature validation failed")
    {
        parent::__construct($message);
    }
}
