<?php

namespace Viraloka\Core\Billing\Exceptions;

use Exception;

/**
 * Payment Exception
 * 
 * Thrown when payment gateway operations fail.
 */
class PaymentException extends Exception
{
    public function __construct(
        string $message,
        public readonly array $context = [],
        int $code = 0,
        ?\Throwable $previous = null
    ) {
        parent::__construct($message, $code, $previous);
    }
}
