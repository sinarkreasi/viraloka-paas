<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing;

use DateTimeImmutable;
use Viraloka\Core\Billing\Contracts\SubscriptionEngineInterface;
use Viraloka\Core\Billing\Repositories\SubscriptionRepository;
use Viraloka\Core\Billing\Repositories\PlanRepository;
use Viraloka\Core\Billing\Exceptions\SubscriptionExistsException;
use Viraloka\Core\Billing\Exceptions\SubscriptionNotFoundException;
use Viraloka\Core\Billing\Exceptions\PlanNotFoundException;
use Viraloka\Core\Billing\Exceptions\InvalidStatusException;
use Viraloka\Core\Billing\Events\SubscriptionCreatedEvent;
use Viraloka\Core\Billing\Events\SubscriptionUpdatedEvent;
use Viraloka\Core\Billing\Events\SubscriptionPausedEvent;
use Viraloka\Core\Billing\Events\SubscriptionResumedEvent;
use Viraloka\Core\Billing\Events\SubscriptionCancelledEvent;
use Viraloka\Core\Billing\Events\SubscriptionExpiredEvent;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Workspace\WorkspaceResolver;
use Viraloka\Core\Workspace\Repositories\WorkspaceRepository;

/**
 * Subscription Engine
 * 
 * Manages workspace subscription lifecycle operations.
 * Integrates with EventDispatcher for lifecycle events and WorkspaceResolver for context.
 * Updates workspace metadata on subscription changes.
 * 
 * Requirements: 2.1-2.10, 9.1-9.8, 12.1, 12.4, 12.5
 */
class SubscriptionEngine implements SubscriptionEngineInterface
{
    private SubscriptionRepository $subscriptionRepository;
    private PlanRepository $planRepository;
    private EventDispatcher $eventDispatcher;
    private EntitlementEngineInterface $entitlementEngine;
    private ?WorkspaceResolver $workspaceResolver;
    private ?WorkspaceRepository $workspaceRepository;
    
    public function __construct(
        SubscriptionRepository $subscriptionRepository,
        PlanRepository $planRepository,
        EventDispatcher $eventDispatcher,
        EntitlementEngineInterface $entitlementEngine,
        ?WorkspaceResolver $workspaceResolver = null,
        ?WorkspaceRepository $workspaceRepository = null
    ) {
        $this->subscriptionRepository = $subscriptionRepository;
        $this->planRepository = $planRepository;
        $this->eventDispatcher = $eventDispatcher;
        $this->entitlementEngine = $entitlementEngine;
        $this->workspaceResolver = $workspaceResolver;
        $this->workspaceRepository = $workspaceRepository;
    }
    
    /**
     * Create a new subscription for workspace
     * 
     * Requirements: 2.1, 2.7, 9.1, 7.6
     * 
     * @param string $workspaceId UUID
     * @param string $planId Plan identifier
     * @return Subscription
     * @throws SubscriptionExistsException
     * @throws PlanNotFoundException
     */
    public function create(string $workspaceId, string $planId): Subscription
    {
        // Validate inputs (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        $this->validatePlanId($planId);
        
        // Check if workspace already has active subscription (Requirement 2.7)
        $existingSubscription = $this->current($workspaceId);
        if ($existingSubscription !== null) {
            throw new SubscriptionExistsException($workspaceId, $existingSubscription->subscriptionId);
        }
        
        // Validate plan exists
        $plan = $this->planRepository->findById($planId);
        if ($plan === null) {
            throw new PlanNotFoundException($planId);
        }
        
        // Determine initial status based on plan configuration (Requirement 1.4)
        $status = $plan->trialPeriodDays !== null && $plan->trialPeriodDays > 0
            ? Subscription::STATUS_TRIAL
            : Subscription::STATUS_ACTIVE;
        
        // Calculate ends_at for trial subscriptions
        $startedAt = new DateTimeImmutable();
        $endsAt = null;
        if ($status === Subscription::STATUS_TRIAL && $plan->trialPeriodDays !== null) {
            $endsAt = $startedAt->modify("+{$plan->trialPeriodDays} days");
        }
        
        // Create subscription
        $subscription = $this->subscriptionRepository->create(
            $workspaceId,
            $planId,
            $status,
            $plan->billingPeriod,
            $startedAt,
            $endsAt
        );
        
        // Grant plan entitlements (Requirement 7.6)
        $this->entitlementEngine->grantPlanEntitlements($workspaceId, $plan);
        
        // Update workspace metadata (Requirement 12.5)
        $this->updateWorkspaceMetadata($workspaceId, $subscription);
        
        // Emit subscription.created event (Requirement 9.1)
        $this->eventDispatcher->dispatch(
            'subscription.created',
            new SubscriptionCreatedEvent(
                $subscription->subscriptionId,
                $subscription->workspaceId,
                $subscription->planId,
                $subscription->status,
                $subscription->createdAt
            )
        );
        
        return $subscription;
    }
    
    /**
     * Change subscription plan
     * 
     * Requirements: 2.2, 2.8, 9.2, 7.7
     * 
     * @param string $workspaceId UUID
     * @param string $planId New plan identifier
     * @return Subscription
     * @throws SubscriptionNotFoundException
     * @throws PlanNotFoundException
     */
    public function changePlan(string $workspaceId, string $planId): Subscription
    {
        // Validate inputs (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        $this->validatePlanId($planId);
        
        // Get current subscription
        $subscription = $this->current($workspaceId);
        if ($subscription === null) {
            throw new SubscriptionNotFoundException($workspaceId);
        }
        
        // Validate new plan exists
        $newPlan = $this->planRepository->findById($planId);
        if ($newPlan === null) {
            throw new PlanNotFoundException($planId);
        }
        
        // Get old plan for entitlement management
        $oldPlan = $this->planRepository->findById($subscription->planId);
        
        // Store old plan ID for event
        $oldPlanId = $subscription->planId;
        
        // Update entitlements (Requirement 7.7)
        if ($oldPlan !== null) {
            // Get entitlements that are common to both plans
            $commonKeys = array_intersect_key($oldPlan->entitlements, $newPlan->entitlements);
            
            // Revoke entitlements that are only in old plan
            foreach ($oldPlan->entitlements as $key => $value) {
                if (!isset($commonKeys[$key])) {
                    $this->entitlementEngine->revoke($workspaceId, $key);
                }
            }
            
            // Grant/update all entitlements from new plan
            $this->entitlementEngine->grantPlanEntitlements($workspaceId, $newPlan);
        } else {
            // If old plan not found, just grant new plan entitlements
            $this->entitlementEngine->grantPlanEntitlements($workspaceId, $newPlan);
        }
        
        // Change plan (Requirement 2.8 - preserves subscription history)
        $subscription->changePlan($planId);
        $subscription->billingPeriod = $newPlan->billingPeriod;
        
        // Update subscription in repository
        $this->subscriptionRepository->update($subscription);
        
        // Update workspace metadata (Requirement 12.5)
        $this->updateWorkspaceMetadata($workspaceId, $subscription);
        
        // Emit subscription.updated event (Requirement 9.2)
        $this->eventDispatcher->dispatch(
            'subscription.updated',
            new SubscriptionUpdatedEvent(
                $subscription->subscriptionId,
                $subscription->workspaceId,
                $oldPlanId,
                $planId,
                new DateTimeImmutable()
            )
        );
        
        return $subscription;
    }
    
    /**
     * Pause active subscription
     * 
     * Requirements: 2.3, 2.9, 9.3
     * 
     * @param string $workspaceId UUID
     * @return bool
     * @throws SubscriptionNotFoundException
     * @throws InvalidStatusException
     */
    public function pause(string $workspaceId): bool
    {
        // Validate input (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        
        // Get current subscription
        $subscription = $this->current($workspaceId);
        if ($subscription === null) {
            throw new SubscriptionNotFoundException($workspaceId);
        }
        
        // Pause subscription (throws InvalidStatusException if not active)
        $subscription->pause();
        
        // Update subscription in repository
        $this->subscriptionRepository->update($subscription);
        
        // Update workspace metadata (Requirement 12.5)
        $this->updateWorkspaceMetadata($workspaceId, $subscription);
        
        // Emit subscription.paused event (Requirement 9.3)
        $this->eventDispatcher->dispatch(
            'subscription.paused',
            new SubscriptionPausedEvent(
                $subscription->subscriptionId,
                $subscription->workspaceId,
                new DateTimeImmutable()
            )
        );
        
        return true;
    }
    
    /**
     * Resume paused subscription
     * 
     * Requirements: 2.4, 2.9, 9.4
     * 
     * @param string $workspaceId UUID
     * @return bool
     * @throws SubscriptionNotFoundException
     * @throws InvalidStatusException
     */
    public function resume(string $workspaceId): bool
    {
        // Validate input (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        
        // Get current subscription
        $subscription = $this->current($workspaceId);
        if ($subscription === null) {
            throw new SubscriptionNotFoundException($workspaceId);
        }
        
        // Resume subscription (throws InvalidStatusException if not paused)
        $subscription->resume();
        
        // Update subscription in repository
        $this->subscriptionRepository->update($subscription);
        
        // Update workspace metadata (Requirement 12.5)
        $this->updateWorkspaceMetadata($workspaceId, $subscription);
        
        // Emit subscription.resumed event (Requirement 9.4)
        $this->eventDispatcher->dispatch(
            'subscription.resumed',
            new SubscriptionResumedEvent(
                $subscription->subscriptionId,
                $subscription->workspaceId,
                new DateTimeImmutable()
            )
        );
        
        return true;
    }
    
    /**
     * Cancel subscription
     * 
     * Requirements: 2.5, 2.10, 9.6
     * 
     * @param string $workspaceId UUID
     * @return bool
     * @throws SubscriptionNotFoundException
     */
    public function cancel(string $workspaceId): bool
    {
        // Validate input (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        
        // Get current subscription
        $subscription = $this->current($workspaceId);
        if ($subscription === null) {
            throw new SubscriptionNotFoundException($workspaceId);
        }
        
        // Cancel subscription (sets status to cancelled and ends_at to now)
        $subscription->cancel();
        
        // Update subscription in repository
        $this->subscriptionRepository->update($subscription);
        
        // Update workspace metadata (Requirement 12.5)
        $this->updateWorkspaceMetadata($workspaceId, $subscription);
        
        // Emit subscription.cancelled event (Requirement 9.6)
        $this->eventDispatcher->dispatch(
            'subscription.cancelled',
            new SubscriptionCancelledEvent(
                $subscription->subscriptionId,
                $subscription->workspaceId,
                new DateTimeImmutable()
            )
        );
        
        return true;
    }
    
    /**
     * Get current active subscription for workspace
     * 
     * Requirements: 2.6
     * 
     * @param string $workspaceId UUID
     * @return Subscription|null
     */
    public function current(string $workspaceId): ?Subscription
    {
        // Validate input (Requirement 1.2)
        $this->validateWorkspaceId($workspaceId);
        
        $subscription = $this->subscriptionRepository->findByWorkspace($workspaceId);
        
        // Return null if no subscription or if not active
        if ($subscription === null || !$subscription->isActive()) {
            return null;
        }
        
        return $subscription;
    }
    
    /**
     * Check if workspace has active subscription
     * 
     * @param string $workspaceId UUID
     * @return bool
     */
    public function hasActiveSubscription(string $workspaceId): bool
    {
        return $this->current($workspaceId) !== null;
    }
    
    /**
     * Process subscription expirations (called by scheduler)
     * 
     * Requirements: 1.9, 9.5, 3.9
     * 
     * @return int Number of subscriptions expired
     */
    public function processExpirations(): int
    {
        // Find all expired subscriptions
        $expiredSubscriptions = $this->subscriptionRepository->findExpired();
        
        $count = 0;
        foreach ($expiredSubscriptions as $subscription) {
            // Get plan for entitlement revocation
            $plan = $this->planRepository->findById($subscription->planId);
            
            // Revoke plan entitlements (Requirement 3.9)
            if ($plan !== null) {
                $this->entitlementEngine->revokePlanEntitlements($subscription->workspaceId, $plan);
            }
            
            // Update status to expired
            $subscription->status = Subscription::STATUS_EXPIRED;
            
            // Update subscription in repository
            $this->subscriptionRepository->update($subscription);
            
            // Update workspace metadata (Requirement 12.5)
            $this->updateWorkspaceMetadata($subscription->workspaceId, $subscription);
            
            // Emit subscription.expired event (Requirement 9.5)
            $this->eventDispatcher->dispatch(
                'subscription.expired',
                new SubscriptionExpiredEvent(
                    $subscription->subscriptionId,
                    $subscription->workspaceId,
                    new DateTimeImmutable()
                )
            );
            
            $count++;
        }
        
        return $count;
    }
    
    /**
     * Get current workspace ID from WorkspaceResolver
     * 
     * Requirements: 12.1, 12.4
     * 
     * @return string|null Workspace ID or null if resolver not available
     */
    private function getCurrentWorkspaceId(): ?string
    {
        if ($this->workspaceResolver === null) {
            return null;
        }
        
        $workspace = $this->workspaceResolver->resolve();
        return $workspace->workspaceId;
    }
    
    /**
     * Update workspace metadata with subscription status
     * 
     * Requirements: 12.5
     * 
     * @param string $workspaceId Workspace UUID
     * @param Subscription $subscription Subscription entity
     * @return void
     */
    private function updateWorkspaceMetadata(string $workspaceId, Subscription $subscription): void
    {
        // Only update if WorkspaceRepository is available
        if ($this->workspaceRepository === null) {
            return;
        }
        
        try {
            // Find workspace
            $workspace = $this->workspaceRepository->findById($workspaceId);
            
            if ($workspace === null) {
                return;
            }
            
            // Update workspace config with subscription metadata
            $workspace->config['subscription'] = [
                'subscription_id' => $subscription->subscriptionId,
                'plan_id' => $subscription->planId,
                'status' => $subscription->status,
                'billing_period' => $subscription->billingPeriod,
                'started_at' => $subscription->startedAt->format('Y-m-d H:i:s'),
                'ends_at' => $subscription->endsAt ? $subscription->endsAt->format('Y-m-d H:i:s') : null,
            ];
            
            // Update workspace in repository
            $this->workspaceRepository->update($workspace);
        } catch (\Exception $e) {
            // Log error but don't fail the subscription operation
            // In production, this should use a proper logger
            error_log("Failed to update workspace metadata: " . $e->getMessage());
        }
    }
    
    /**
     * Create subscription for current workspace (using WorkspaceResolver)
     * 
     * Requirements: 12.1, 12.4
     * 
     * @param string $planId Plan identifier
     * @return Subscription
     * @throws \RuntimeException If WorkspaceResolver not available
     * @throws SubscriptionExistsException
     * @throws PlanNotFoundException
     */
    public function createForCurrentWorkspace(string $planId): Subscription
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        if ($workspaceId === null) {
            throw new \RuntimeException('WorkspaceResolver not available');
        }
        
        return $this->create($workspaceId, $planId);
    }
    
    /**
     * Get current subscription for current workspace (using WorkspaceResolver)
     * 
     * Requirements: 12.1, 12.4
     * 
     * @return Subscription|null
     * @throws \RuntimeException If WorkspaceResolver not available
     */
    public function currentForCurrentWorkspace(): ?Subscription
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        if ($workspaceId === null) {
            throw new \RuntimeException('WorkspaceResolver not available');
        }
        
        return $this->current($workspaceId);
    }
    
    /**
     * Validate workspace ID format
     * 
     * Note: This validates the format only. For production use, consider adding
     * workspace existence validation by injecting WorkspaceRepositoryInterface
     * and checking if the workspace exists in the database (Requirement 13.5).
     * 
     * @param string $workspaceId
     * @return void
     * @throws \InvalidArgumentException
     */
    private function validateWorkspaceId(string $workspaceId): void
    {
        if (empty($workspaceId)) {
            throw new \InvalidArgumentException("Workspace ID cannot be empty");
        }
        
        // UUID format validation (optional but recommended)
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $workspaceId)) {
            throw new \InvalidArgumentException("Workspace ID must be a valid UUID: {$workspaceId}");
        }
    }
    
    /**
     * Validate plan ID format
     * 
     * @param string $planId
     * @return void
     * @throws \InvalidArgumentException
     */
    private function validatePlanId(string $planId): void
    {
        if (empty($planId)) {
            throw new \InvalidArgumentException("Plan ID cannot be empty");
        }
        
        // Plan ID should be alphanumeric with hyphens/underscores
        if (!preg_match('/^[a-zA-Z0-9_-]+$/', $planId)) {
            throw new \InvalidArgumentException("Plan ID must be alphanumeric with hyphens or underscores: {$planId}");
        }
    }
}

