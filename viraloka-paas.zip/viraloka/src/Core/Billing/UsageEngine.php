<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing;

use DateTimeImmutable;
use DateTimeInterface;
use Viraloka\Core\Billing\Repositories\UsageRepository;
use Viraloka\Core\Billing\Repositories\SubscriptionRepository;
use Viraloka\Core\Billing\UsageRecord;
use Viraloka\Core\Billing\Exceptions\InvalidAmountException;
use Viraloka\Core\Billing\Exceptions\InvalidKeyFormatException;
use Viraloka\Core\Billing\Exceptions\InvalidDateRangeException;
use Viraloka\Core\Billing\Contracts\UsageEngineInterface;
use Viraloka\Core\Workspace\WorkspaceResolver;

/**
 * Usage Engine
 * 
 * Tracks feature consumption and usage metrics for workspaces.
 * Usage data is input for metered billing but does not directly determine access.
 * Integrates with WorkspaceResolver for context.
 * 
 * Requirements: 6.1-6.8, 5.10, 12.1, 12.4
 */
class UsageEngine implements UsageEngineInterface
{
    private ?WorkspaceResolver $workspaceResolver;
    
    public function __construct(
        private UsageRepository $usageRepository,
        private SubscriptionRepository $subscriptionRepository,
        ?WorkspaceResolver $workspaceResolver = null
    ) {
        $this->workspaceResolver = $workspaceResolver;
    }
    
    /**
     * Record usage for a feature
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key (e.g., "shortlink.clicks")
     * @param int $amount Amount to record
     * @param array $metadata Optional metadata
     * @return UsageRecord
     * @throws \InvalidArgumentException If amount is negative or key format is invalid
     */
    public function record(string $workspaceId, string $key, int $amount, array $metadata = []): UsageRecord
    {
        // Validate workspace ID
        $this->validateWorkspaceId($workspaceId);
        
        // Validate amount (Requirement 6.5)
        if ($amount < 0) {
            throw new InvalidAmountException($amount);
        }
        
        // Validate key format (dot notation) (Requirement 5.5)
        if (!$this->isValidKey($key)) {
            throw new InvalidKeyFormatException($key);
        }
        
        // Record usage (Requirement 6.1)
        return $this->usageRepository->create($workspaceId, $key, $amount, $metadata);
    }
    
    /**
     * Get current billing period usage
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return int
     */
    public function current(string $workspaceId, string $key): int
    {
        // Validate inputs
        $this->validateWorkspaceId($workspaceId);
        
        if (!$this->isValidKey($key)) {
            throw new InvalidKeyFormatException($key);
        }
        
        // Get subscription to determine billing period (Requirement 6.2)
        $subscription = $this->subscriptionRepository->findByWorkspace($workspaceId);
        
        // If no active subscription, return zero (Requirement 6.7)
        if ($subscription === null || !$subscription->isActive()) {
            return 0;
        }
        
        // Calculate billing period start date
        $billingPeriodStart = $this->calculateBillingPeriodStart($subscription);
        $now = new DateTimeImmutable();
        
        // Aggregate usage within current billing period
        return $this->usageRepository->aggregateByTimeRange(
            $workspaceId,
            $key,
            $billingPeriodStart,
            $now
        );
    }
    
    /**
     * Get all-time total usage
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return int
     */
    public function total(string $workspaceId, string $key): int
    {
        // Validate inputs
        $this->validateWorkspaceId($workspaceId);
        
        if (!$this->isValidKey($key)) {
            throw new InvalidKeyFormatException($key);
        }
        
        // Aggregate all usage (Requirement 6.3)
        return $this->usageRepository->aggregateTotal($workspaceId, $key);
    }
    
    /**
     * Get usage within time range
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @param DateTimeInterface $start Start date
     * @param DateTimeInterface $end End date
     * @return int
     * @throws \InvalidArgumentException If date range is invalid
     */
    public function range(string $workspaceId, string $key, DateTimeInterface $start, DateTimeInterface $end): int
    {
        // Validate workspace ID
        $this->validateWorkspaceId($workspaceId);
        
        // Validate key format
        if (!$this->isValidKey($key)) {
            throw new InvalidKeyFormatException($key);
        }
        
        // Validate date range (Requirement 6.8)
        if ($end < $start) {
            throw new InvalidDateRangeException();
        }
        
        // Aggregate usage within time range (Requirement 6.4)
        return $this->usageRepository->aggregateByTimeRange($workspaceId, $key, $start, $end);
    }
    
    /**
     * Get usage breakdown by key for workspace
     * 
     * @param string $workspaceId UUID
     * @param DateTimeInterface|null $start Optional start date
     * @param DateTimeInterface|null $end Optional end date
     * @return array<string, int> Key => usage amount
     */
    public function getUsageBreakdown(string $workspaceId, ?DateTimeInterface $start = null, ?DateTimeInterface $end = null): array
    {
        // Validate workspace ID
        $this->validateWorkspaceId($workspaceId);
        
        // Validate date range if both provided
        if ($start !== null && $end !== null && $end < $start) {
            throw new InvalidDateRangeException();
        }
        
        return $this->usageRepository->getUsageBreakdown($workspaceId, $start, $end);
    }
    
    /**
     * Reset usage for billing period (called by scheduler)
     * 
     * Note: This method does NOT delete historical data. It simply marks the start
     * of a new billing period. Historical usage records are preserved.
     * 
     * @param string $workspaceId UUID
     * @return void
     */
    public function resetBillingPeriod(string $workspaceId): void
    {
        // Validate workspace ID
        $this->validateWorkspaceId($workspaceId);
        
        // This is a no-op in the current implementation because usage records
        // are never deleted (Requirement 5.10). The billing period is calculated
        // dynamically based on the subscription's started_at and billing_period.
        // 
        // Historical data is always preserved and can be queried using the range() method.
        // The current() method automatically calculates the current billing period
        // based on the subscription's billing_period setting.
    }
    
    /**
     * Validate key format (dot notation)
     * 
     * @param string $key
     * @return bool
     */
    private function isValidKey(string $key): bool
    {
        // Key must contain at least one dot
        return strpos($key, '.') !== false;
    }
    
    /**
     * Calculate billing period start date based on subscription
     * 
     * @param Subscription $subscription
     * @return DateTimeImmutable
     */
    private function calculateBillingPeriodStart(Subscription $subscription): DateTimeImmutable
    {
        $now = new DateTimeImmutable();
        $startedAt = $subscription->startedAt;
        
        switch ($subscription->billingPeriod) {
            case Subscription::PERIOD_MONTHLY:
                // Calculate the start of the current monthly billing period
                $monthsSinceStart = $this->getMonthsDifference($startedAt, $now);
                return $startedAt->modify("+{$monthsSinceStart} months");
                
            case Subscription::PERIOD_YEARLY:
                // Calculate the start of the current yearly billing period
                $yearsSinceStart = $this->getYearsDifference($startedAt, $now);
                return $startedAt->modify("+{$yearsSinceStart} years");
                
            case Subscription::PERIOD_CUSTOM:
            default:
                // For custom periods, use subscription start date
                return $startedAt;
        }
    }
    
    /**
     * Get number of complete months between two dates
     * 
     * @param DateTimeInterface $start
     * @param DateTimeInterface $end
     * @return int
     */
    private function getMonthsDifference(DateTimeInterface $start, DateTimeInterface $end): int
    {
        $startYear = (int) $start->format('Y');
        $startMonth = (int) $start->format('m');
        $endYear = (int) $end->format('Y');
        $endMonth = (int) $end->format('m');
        
        $months = ($endYear - $startYear) * 12 + ($endMonth - $startMonth);
        
        // If we haven't reached the day of the month yet, subtract one month
        if ((int) $end->format('d') < (int) $start->format('d')) {
            $months--;
        }
        
        return max(0, $months);
    }
    
    /**
     * Get number of complete years between two dates
     * 
     * @param DateTimeInterface $start
     * @param DateTimeInterface $end
     * @return int
     */
    private function getYearsDifference(DateTimeInterface $start, DateTimeInterface $end): int
    {
        $years = (int) $end->format('Y') - (int) $start->format('Y');
        
        // If we haven't reached the anniversary date yet, subtract one year
        if ($end->format('m-d') < $start->format('m-d')) {
            $years--;
        }
        
        return max(0, $years);
    }
    
    /**
     * Get current workspace ID from WorkspaceResolver
     * 
     * Requirements: 12.1, 12.4
     * 
     * @return string|null Workspace ID or null if resolver not available
     */
    private function getCurrentWorkspaceId(): ?string
    {
        if ($this->workspaceResolver === null) {
            return null;
        }
        
        $workspace = $this->workspaceResolver->resolve();
        return $workspace->workspaceId;
    }
    
    /**
     * Record usage for current workspace (using WorkspaceResolver)
     * 
     * Requirements: 12.1, 12.4
     * 
     * @param string $key Usage key
     * @param int $amount Amount to record
     * @param array $metadata Optional metadata
     * @return UsageRecord
     * @throws \RuntimeException If WorkspaceResolver not available
     */
    public function recordForCurrentWorkspace(string $key, int $amount, array $metadata = []): UsageRecord
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        if ($workspaceId === null) {
            throw new \RuntimeException('WorkspaceResolver not available');
        }
        
        return $this->record($workspaceId, $key, $amount, $metadata);
    }
    
    /**
     * Get current period usage for current workspace (using WorkspaceResolver)
     * 
     * Requirements: 12.1, 12.4
     * 
     * @param string $key Usage key
     * @return int
     * @throws \RuntimeException If WorkspaceResolver not available
     */
    public function currentForCurrentWorkspace(string $key): int
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        if ($workspaceId === null) {
            throw new \RuntimeException('WorkspaceResolver not available');
        }
        
        return $this->current($workspaceId, $key);
    }
    
    /**
     * Validate workspace ID format
     * 
     * Note: This validates the format only. For production use, consider adding
     * workspace existence validation by injecting WorkspaceRepositoryInterface
     * and checking if the workspace exists in the database.
     * 
     * @param string $workspaceId
     * @return void
     * @throws \InvalidArgumentException
     */
    private function validateWorkspaceId(string $workspaceId): void
    {
        if (empty($workspaceId)) {
            throw new \InvalidArgumentException("Workspace ID cannot be empty");
        }
        
        // UUID format validation (optional but recommended)
        if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $workspaceId)) {
            throw new \InvalidArgumentException("Workspace ID must be a valid UUID: {$workspaceId}");
        }
    }
}
