<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Repositories;

use Viraloka\Core\Billing\Subscription;
use DateTimeImmutable;

/**
 * Subscription Repository
 * 
 * Handles persistence of Subscription entities using WordPress wpdb.
 * Enforces workspace active subscription uniqueness constraint.
 * 
 * Requirements: 1.10, 2.7
 */
class SubscriptionRepository
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_subscriptions';
    }
    
    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * Create a new subscription
     * 
     * @param string $workspaceId UUID
     * @param string $planId Plan identifier
     * @param string $status Subscription status
     * @param string $billingPeriod Billing period
     * @param DateTimeImmutable $startedAt Start timestamp
     * @param DateTimeImmutable|null $endsAt End timestamp
     * @param array $metadata Optional metadata
     * @return Subscription
     * @throws \RuntimeException If workspace already has active subscription
     */
    public function create(
        string $workspaceId,
        string $planId,
        string $status,
        string $billingPeriod,
        DateTimeImmutable $startedAt,
        ?DateTimeImmutable $endsAt = null,
        array $metadata = []
    ): Subscription {
        // Check for existing active subscription (Requirement 1.10)
        if ($this->hasActiveSubscription($workspaceId)) {
            throw new \RuntimeException("Workspace already has an active subscription");
        }
        
        $subscriptionId = $this->generateUuid();
        $createdAt = new DateTimeImmutable();
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'subscription_id' => $subscriptionId,
                'workspace_id' => $workspaceId,
                'plan_id' => $planId,
                'status' => $status,
                'billing_period' => $billingPeriod,
                'started_at' => $startedAt->format('Y-m-d H:i:s'),
                'ends_at' => $endsAt ? $endsAt->format('Y-m-d H:i:s') : null,
                'metadata' => json_encode($metadata),
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create subscription: ' . $this->wpdb->last_error);
        }
        
        return new Subscription(
            $subscriptionId,
            $workspaceId,
            $planId,
            $status,
            $billingPeriod,
            $startedAt,
            $endsAt,
            $metadata,
            $createdAt
        );
    }

    
    /**
     * Find subscription by workspace ID
     * 
     * @param string $workspaceId UUID
     * @return Subscription|null
     */
    public function findByWorkspace(string $workspaceId): ?Subscription
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s ORDER BY created_at DESC LIMIT 1",
                $workspaceId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find subscription by ID
     * 
     * @param string $subscriptionId UUID
     * @return Subscription|null
     */
    public function findById(string $subscriptionId): ?Subscription
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE subscription_id = %s",
                $subscriptionId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Update an existing subscription
     * 
     * @param Subscription $subscription
     * @return bool
     */
    public function update(Subscription $subscription): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'plan_id' => $subscription->planId,
                'status' => $subscription->status,
                'billing_period' => $subscription->billingPeriod,
                'ends_at' => $subscription->endsAt ? $subscription->endsAt->format('Y-m-d H:i:s') : null,
                'metadata' => json_encode($subscription->metadata),
                'updated_at' => (new DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['subscription_id' => $subscription->subscriptionId],
            ['%s', '%s', '%s', '%s', '%s', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Delete a subscription
     * 
     * @param string $subscriptionId UUID
     * @return bool
     */
    public function delete(string $subscriptionId): bool
    {
        $result = $this->wpdb->delete(
            $this->tableName,
            ['subscription_id' => $subscriptionId],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Check if workspace has an active subscription
     * 
     * @param string $workspaceId UUID
     * @return bool
     */
    public function hasActiveSubscription(string $workspaceId): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tableName} WHERE workspace_id = %s AND status = %s",
                $workspaceId,
                Subscription::STATUS_ACTIVE
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Find all subscriptions that have expired (ends_at in the past but status not expired)
     * 
     * @return Subscription[]
     */
    public function findExpired(): array
    {
        $now = (new DateTimeImmutable())->format('Y-m-d H:i:s');
        
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} 
                WHERE ends_at IS NOT NULL 
                AND ends_at < %s 
                AND status != %s
                ORDER BY ends_at ASC",
                $now,
                Subscription::STATUS_EXPIRED
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Convert database row to Subscription entity
     * 
     * @param array $row Database row
     * @return Subscription
     */
    private function rowToEntity(array $row): Subscription
    {
        $metadata = !empty($row['metadata']) ? json_decode($row['metadata'], true) : [];
        
        return new Subscription(
            $row['subscription_id'],
            $row['workspace_id'],
            $row['plan_id'],
            $row['status'],
            $row['billing_period'],
            new DateTimeImmutable($row['started_at']),
            $row['ends_at'] ? new DateTimeImmutable($row['ends_at']) : null,
            $metadata,
            new DateTimeImmutable($row['created_at'])
        );
    }
}
