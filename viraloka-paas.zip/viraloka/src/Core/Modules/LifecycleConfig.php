<?php

namespace Viraloka\Core\Modules;

/**
 * Lifecycle Configuration
 * 
 * Value object for lifecycle-related manifest configuration.
 */
class LifecycleConfig
{
    public string $provider;
    public bool $boot;
    
    /**
     * Create a new lifecycle config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->provider = $data['provider'] ?? '';
        $this->boot = $data['boot'] ?? true;
    }
}
