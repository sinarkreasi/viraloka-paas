<?php

namespace Viraloka\Core\Modules;

/**
 * Validation Result
 * 
 * Result object from schema validation.
 */
class ValidationResult
{
    public bool $valid;
    public array $errors;
    public array $warnings;
    
    /**
     * Create a new validation result instance
     * 
     * @param bool $valid
     * @param array $errors
     * @param array $warnings
     */
    public function __construct(bool $valid, array $errors = [], array $warnings = [])
    {
        $this->valid = $valid;
        $this->errors = $errors;
        $this->warnings = $warnings;
    }
    
    /**
     * Check if validation passed
     * 
     * @return bool
     */
    public function isValid(): bool
    {
        return $this->valid;
    }
    
    /**
     * Get validation errors
     * 
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
    
    /**
     * Check if there are warnings
     * 
     * @return bool
     */
    public function hasWarnings(): bool
    {
        return !empty($this->warnings);
    }
}
