<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\AdminMenuBuilderContract;

/**
 * Admin Menu Builder
 * 
 * Builds WordPress admin menus from module UI hints.
 * Handles admin_menu flag to suppress menu creation.
 * Applies default values for incomplete UI hints.
 */
class AdminMenuBuilder implements AdminMenuBuilderContract
{
    /**
     * Build admin menu for a module
     * 
     * Reads UI hints from the module manifest and creates WordPress admin menu entries.
     * Respects the admin_menu flag - if false, no menu is created.
     * Applies sensible defaults for missing UI hint fields.
     * 
     * @param Module $module
     * @return void
     */
    public function buildMenu(Module $module): void
    {
        $manifest = $module->manifest;
        
        // If no UI config or admin_menu is false, skip menu creation
        if ($manifest->ui === null || !$manifest->ui->adminMenu) {
            return;
        }
        
        // Apply defaults for incomplete UI hints
        $menuTitle = $manifest->ui->menuTitle ?? $manifest->name;
        $icon = $manifest->ui->icon ?? 'dashicons-admin-generic';
        
        // Generate a unique menu slug from module ID
        $menuSlug = 'viraloka-' . $manifest->id;
        
        // Determine the callback to use
        // If the module provider has a renderAdminPage method, use it
        // Otherwise, use the default placeholder
        $callback = [$this, 'renderModulePage'];
        
        if ($module->provider && method_exists($module->provider, 'renderAdminPage')) {
            $callback = [$module->provider, 'renderAdminPage'];
        }
        
        // Create the admin submenu page under Viraloka Core
        add_submenu_page(
            'viraloka-core',          // Parent slug (Viraloka Core menu)
            $menuTitle,               // Page title
            $menuTitle,               // Menu title
            'manage_options',         // Capability
            $menuSlug,                // Menu slug
            $callback                 // Callback
        );
    }
    
    /**
     * Build admin menus for multiple modules
     * 
     * @param array $modules Array of Module instances
     * @return void
     */
    public function buildMenus(array $modules): void
    {
        foreach ($modules as $module) {
            $this->buildMenu($module);
        }
    }
    
    /**
     * Render module page (placeholder)
     * 
     * This is a placeholder callback for the admin menu page.
     * Individual modules should override this through their service providers.
     * 
     * @return void
     */
    public function renderModulePage(): void
    {
        echo '<div class="wrap">';
        echo '<h1>Module Page</h1>';
        echo '<p>This page should be rendered by the module\'s service provider.</p>';
        echo '</div>';
    }
}
