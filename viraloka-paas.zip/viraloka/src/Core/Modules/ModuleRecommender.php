<?php

namespace Viraloka\Core\Modules;

use Illuminate\Support\Collection;
use Viraloka\Core\Context\Contracts\ContextResolverContract;
use Viraloka\Core\Modules\Contracts\ModuleRecommenderContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;

/**
 * Module Recommender
 * 
 * Manages module recommendations and provides context-aware ranking.
 * 
 * Implementation Details:
 * - Stores recommendations from module manifests
 * - Ranks recommendations by context relevance and priority
 * - Integrates with ContextResolver for context matching
 * - Checks installation status of recommended modules
 */
class ModuleRecommender implements ModuleRecommenderContract
{
    /**
     * Context resolver for context matching
     * 
     * @var ContextResolverContract
     */
    protected ContextResolverContract $contextResolver;
    
    /**
     * Module registry for checking installation status
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $moduleRegistry;
    
    /**
     * Stored recommendations indexed by source module ID
     * 
     * Structure: [
     *   'source_module_id' => [
     *     'modules' => ['recommended_module_id_1', 'recommended_module_id_2'],
     *     'integrations' => ['integration_1', 'integration_2']
     *   ]
     * ]
     * 
     * @var array
     */
    protected array $recommendations = [];
    
    /**
     * Create a new module recommender instance
     * 
     * @param ContextResolverContract $contextResolver
     * @param ModuleRegistryContract $moduleRegistry
     */
    public function __construct(
        ContextResolverContract $contextResolver,
        ModuleRegistryContract $moduleRegistry
    ) {
        $this->contextResolver = $contextResolver;
        $this->moduleRegistry = $moduleRegistry;
    }
    
    /**
     * Store recommendations from a module's manifest
     * 
     * Extracts and stores module and integration recommendations.
     * 
     * @param Module $module
     * @return void
     */
    public function storeRecommendations(Module $module): void
    {
        $moduleId = $module->getId();
        $manifest = $module->manifest;
        
        // Skip if no recommendations declared
        if ($manifest->recommendations === null) {
            return;
        }
        
        $this->recommendations[$moduleId] = [
            'modules' => $manifest->recommendations->modules,
            'integrations' => $manifest->recommendations->integrations,
        ];
    }
    
    /**
     * Get recommended modules for a given context
     * 
     * Returns modules ranked by context relevance and priority.
     * Each recommendation includes:
     * - recommended_module_id: The ID of the recommended module
     * - source_module_id: The ID of the module making the recommendation
     * - source_module_name: The name of the module making the recommendation
     * - installed: Whether the recommended module is installed
     * - priority: The priority of the source module (for ranking)
     * - context_match: Whether the source module matches the given context
     * 
     * @param string $context
     * @return Collection<array>
     */
    public function getRecommendationsForContext(string $context): Collection
    {
        $recommendations = [];
        
        // Iterate through all stored recommendations
        foreach ($this->recommendations as $sourceModuleId => $recs) {
            $sourceModule = $this->moduleRegistry->get($sourceModuleId);
            
            // Skip if source module is not found
            if ($sourceModule === null) {
                continue;
            }
            
            $manifest = $sourceModule->manifest;
            
            // Check if source module supports the given context
            $contextMatch = $this->contextResolver->supportsContext($manifest, $context);
            
            // Get priority for ranking
            $priority = $this->getModulePriority($manifest, $context);
            
            // Add each recommended module
            foreach ($recs['modules'] as $recommendedModuleId) {
                $recommendations[] = [
                    'recommended_module_id' => $recommendedModuleId,
                    'source_module_id' => $sourceModuleId,
                    'source_module_name' => $manifest->name,
                    'installed' => $this->isModuleInstalled($recommendedModuleId),
                    'priority' => $priority,
                    'context_match' => $contextMatch,
                ];
            }
        }
        
        // Sort by context match (true first) and then by priority (higher first)
        usort($recommendations, function ($a, $b) {
            // First, prioritize context matches
            if ($a['context_match'] !== $b['context_match']) {
                return $b['context_match'] <=> $a['context_match'];
            }
            
            // Then sort by priority (higher first)
            return $b['priority'] <=> $a['priority'];
        });
        
        return new Collection($recommendations);
    }
    
    /**
     * Get all recommendations from a specific module
     * 
     * @param string $moduleId
     * @return array
     */
    public function getModuleRecommendations(string $moduleId): array
    {
        return $this->recommendations[$moduleId] ?? [
            'modules' => [],
            'integrations' => [],
        ];
    }
    
    /**
     * Check if a recommended module is installed
     * 
     * @param string $moduleId
     * @return bool
     */
    public function isModuleInstalled(string $moduleId): bool
    {
        return $this->moduleRegistry->has($moduleId);
    }
    
    /**
     * Get priority for a module in a given context
     * 
     * Returns the module's priority value, with a boost for primary context.
     * 
     * @param Manifest $manifest
     * @param string $context
     * @return int
     */
    protected function getModulePriority(Manifest $manifest, string $context): int
    {
        // Context-agnostic modules use default priority
        if ($manifest->contexts === null) {
            return 50; // Default priority
        }
        
        $basePriority = $manifest->contexts->priority;
        
        // Boost priority if this is the primary context
        if ($manifest->contexts->primary === $context) {
            return $basePriority + 10; // Primary context boost
        }
        
        return $basePriority;
    }
    
    /**
     * Get recommendations for physical marketplace use-case
     * 
     * Provides WooCommerce integration recommendation when physical marketplace
     * use-case is detected.
     * 
     * Validates: Requirements 13.3, 13.4
     * 
     * @return array
     */
    public function getPhysicalMarketplaceRecommendations(): array
    {
        // Check if physical marketplace use-case is detected
        $outOfScopeRecs = $this->contextResolver->getOutOfScopeRecommendations();
        
        if (!$outOfScopeRecs['detected'] || $outOfScopeRecs['use_case'] !== 'physical-marketplace') {
            return [];
        }
        
        return $outOfScopeRecs['recommendations'];
    }
    
    /**
     * Get all out-of-scope recommendations
     * 
     * Provides contextual recommendations for any detected out-of-scope use-cases.
     * 
     * Validates: Requirements 13.4
     * 
     * @return array
     */
    public function getOutOfScopeRecommendations(): array
    {
        return $this->contextResolver->getOutOfScopeRecommendations();
    }
}
