<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\Manifest;

/**
 * Manifest Cache Contract
 * 
 * Caches parsed manifests to improve performance.
 */
interface ManifestCacheContract
{
    /**
     * Get cached manifest
     * 
     * @param string $moduleId
     * @return Manifest|null
     */
    public function get(string $moduleId): ?Manifest;
    
    /**
     * Store manifest in cache
     * 
     * @param string $moduleId
     * @param Manifest $manifest
     * @return void
     */
    public function put(string $moduleId, Manifest $manifest): void;
    
    /**
     * Invalidate cache for module
     * 
     * @param string $moduleId
     * @return void
     */
    public function forget(string $moduleId): void;
    
    /**
     * Clear all cached manifests
     * 
     * @return void
     */
    public function flush(): void;
}
