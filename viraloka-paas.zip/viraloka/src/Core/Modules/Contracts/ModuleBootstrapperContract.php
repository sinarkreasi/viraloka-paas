<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Exceptions\BootstrapException;

/**
 * Module Bootstrapper Contract
 * 
 * Instantiates and initializes module service providers.
 */
interface ModuleBootstrapperContract
{
    /**
     * Bootstrap a module
     * 
     * @param Module $module
     * @return void
     * @throws BootstrapException
     */
    public function bootstrap(Module $module): void;
    
    /**
     * Check if module is bootstrapped
     * 
     * @param string $moduleId
     * @return bool
     */
    public function isBootstrapped(string $moduleId): bool;
}
