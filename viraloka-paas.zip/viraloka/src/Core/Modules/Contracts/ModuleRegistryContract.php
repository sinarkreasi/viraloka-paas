<?php

namespace Viraloka\Core\Modules\Contracts;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Exceptions\DuplicateModuleException;

/**
 * Module Registry Contract
 * 
 * Maintains the central registry of all loaded modules.
 */
interface ModuleRegistryContract
{
    /**
     * Register a module
     * 
     * @param Module $module
     * @return void
     * @throws DuplicateModuleException
     */
    public function register(Module $module): void;
    
    /**
     * Get module by ID
     * 
     * @param string $moduleId
     * @return Module|null
     */
    public function get(string $moduleId): ?Module;
    
    /**
     * Get all registered modules
     * 
     * @return Collection<Module>
     */
    public function all(): Collection;
    
    /**
     * Check if module is registered
     * 
     * @param string $moduleId
     * @return bool
     */
    public function has(string $moduleId): bool;
    
    /**
     * Get all public modules (visibility filtering)
     * 
     * @return Collection<Module>
     */
    public function getPublicModules(): Collection;
}
