<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ResolutionResult;

/**
 * Dependency Resolver Contract
 * 
 * Checks module dependencies and determines if they are satisfied.
 */
interface DependencyResolverContract
{
    /**
     * Resolve dependencies for a manifest
     * 
     * @param Manifest $manifest
     * @return ResolutionResult
     */
    public function resolve(Manifest $manifest): ResolutionResult;
    
    /**
     * Check if core version satisfies requirement
     * 
     * @param string $requirement
     * @return bool
     */
    public function checkCoreVersion(string $requirement): bool;
    
    /**
     * Check if module is available
     * 
     * @param string $moduleId
     * @return bool
     */
    public function checkModule(string $moduleId): bool;
    
    /**
     * Check if WordPress plugin is active
     * 
     * @param string $pluginSlug
     * @return bool
     */
    public function checkPlugin(string $pluginSlug): bool;
}
