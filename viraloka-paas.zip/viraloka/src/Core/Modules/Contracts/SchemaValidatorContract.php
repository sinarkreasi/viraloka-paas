<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\ValidationResult;

/**
 * Schema Validator Contract
 * 
 * Validates manifest data against the defined schema.
 */
interface SchemaValidatorContract
{
    /**
     * Validate manifest data against schema
     * 
     * @param array $data
     * @return ValidationResult
     */
    public function validate(array $data): ValidationResult;
    
    /**
     * Get schema definition
     * 
     * @return array
     */
    public function getSchema(): array;
}
