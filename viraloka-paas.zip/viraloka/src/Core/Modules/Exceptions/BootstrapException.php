<?php

namespace Viraloka\Core\Modules\Exceptions;

use Exception;

/**
 * Bootstrap Exception
 * 
 * Thrown when a module fails to bootstrap properly.
 */
class BootstrapException extends Exception
{
    /**
     * Create a new bootstrap exception
     * 
     * @param string $moduleId
     * @param string $message
     * @param \Throwable|null $previous
     */
    public function __construct(string $moduleId, string $message, ?\Throwable $previous = null)
    {
        parent::__construct(
            "Module '{$moduleId}' failed to bootstrap: {$message}",
            0,
            $previous
        );
    }
}
