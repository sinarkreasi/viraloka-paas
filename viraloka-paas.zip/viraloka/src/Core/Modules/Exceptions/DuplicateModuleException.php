<?php

namespace Viraloka\Core\Modules\Exceptions;

use Exception;

/**
 * Duplicate Module Exception
 * 
 * Thrown when attempting to register a module with an ID that already exists.
 */
class DuplicateModuleException extends Exception
{
    /**
     * Create a new duplicate module exception
     * 
     * @param string $moduleId
     */
    public function __construct(string $moduleId)
    {
        parent::__construct(
            "Module with ID '{$moduleId}' is already registered. Module IDs must be unique."
        );
    }
}
