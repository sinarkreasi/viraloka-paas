<?php

namespace Viraloka\Core\Modules;

/**
 * Logger
 * 
 * Wrapper for WordPress error logging system.
 * Provides structured logging for all module-related errors, warnings, and info messages.
 * Formats log messages with module ID and error details for easy debugging.
 * Supports persistent log file writing for bootstrap errors.
 */
class Logger
{
    /**
     * Log prefix for all Viraloka Core messages
     */
    private const LOG_PREFIX = '[Viraloka Core]';
    
    /**
     * Path to persistent log file
     * 
     * @var string|null
     */
    private ?string $logFile = null;
    
    /**
     * Debug mode flag
     * 
     * @var bool
     */
    private bool $debugMode = false;
    
    /**
     * Create a new Logger instance
     * 
     * @param string|null $logFile Optional path to persistent log file
     * @param bool $debugMode Whether to include detailed error traces
     */
    public function __construct(?string $logFile = null, bool $debugMode = false)
    {
        $this->logFile = $logFile;
        $this->debugMode = $debugMode;
    }
    
    /**
     * Log an error message
     * 
     * Errors indicate critical issues that prevent normal operation.
     * Format: [Viraloka Core] Module Error: {moduleId} - {errorType}: {message}
     * 
     * @param string $message Error message
     * @param string|null $moduleId Optional module ID for context
     * @param string|null $errorType Optional error type (e.g., "Parse Error", "Validation Error")
     * @return void
     */
    public function error(string $message, ?string $moduleId = null, ?string $errorType = null): void
    {
        $logMessage = $this->formatMessage('Module Error', $message, $moduleId, $errorType);
        $this->write($logMessage);
    }
    
    /**
     * Log a warning message
     * 
     * Warnings indicate potential issues that don't prevent operation.
     * Format: [Viraloka Core] Module Warning: {moduleId} - {message}
     * 
     * @param string $message Warning message
     * @param string|null $moduleId Optional module ID for context
     * @return void
     */
    public function warning(string $message, ?string $moduleId = null): void
    {
        $logMessage = $this->formatMessage('Module Warning', $message, $moduleId);
        $this->write($logMessage);
    }
    
    /**
     * Log an info message
     * 
     * Info messages provide general operational information.
     * Format: [Viraloka Core] Module Info: {message}
     * 
     * @param string $message Info message
     * @param string|null $moduleId Optional module ID for context
     * @return void
     */
    public function info(string $message, ?string $moduleId = null): void
    {
        $logMessage = $this->formatMessage('Module Info', $message, $moduleId);
        $this->write($logMessage);
    }
    
    /**
     * Log a parse error
     * 
     * Specialized method for manifest parsing errors.
     * 
     * @param string $filePath Path to the manifest file
     * @param string $error Error message
     * @param string|null $moduleId Optional module ID if known
     * @return void
     */
    public function parseError(string $filePath, string $error, ?string $moduleId = null): void
    {
        $message = "Parse error in {$filePath}: {$error}";
        $this->error($message, $moduleId, 'Parse Error');
    }
    
    /**
     * Log a validation error
     * 
     * Specialized method for schema validation errors.
     * 
     * @param array $errors Array of validation error messages
     * @param string|null $moduleId Optional module ID if known
     * @return void
     */
    public function validationError(array $errors, ?string $moduleId = null): void
    {
        $message = "Validation failed: " . implode(', ', $errors);
        $this->error($message, $moduleId, 'Validation Error');
    }
    
    /**
     * Log a dependency warning
     * 
     * Specialized method for missing optional dependencies.
     * 
     * @param string $moduleId Module ID
     * @param array $missingDependencies Array of missing dependency names
     * @param string $dependencyType Type of dependency (e.g., "modules", "plugins")
     * @return void
     */
    public function dependencyWarning(string $moduleId, array $missingDependencies, string $dependencyType): void
    {
        $missing = implode(', ', $missingDependencies);
        $message = "Optional {$dependencyType} dependencies not found: {$missing}";
        $this->warning($message, $moduleId);
    }
    
    /**
     * Log a bootstrap error
     * 
     * Specialized method for module bootstrap errors.
     * In debug mode, includes full stack trace.
     * 
     * @param string $moduleId Module ID
     * @param string $error Error message
     * @param \Throwable|null $exception Optional exception for stack trace
     * @return void
     */
    public function bootstrapError(string $moduleId, string $error, ?\Throwable $exception = null): void
    {
        $message = $error;
        
        // In debug mode, include full stack trace
        if ($this->debugMode && $exception) {
            $message .= "\nException: " . get_class($exception);
            $message .= "\nMessage: " . $exception->getMessage();
            $message .= "\nFile: " . $exception->getFile() . ':' . $exception->getLine();
            $message .= "\nStack trace:\n" . $exception->getTraceAsString();
        } elseif ($exception) {
            // In non-debug mode, just include basic exception info
            $message .= " (" . get_class($exception) . ": " . $exception->getMessage() . ")";
        }
        
        $this->error($message, $moduleId, 'Bootstrap Error');
    }
    
    /**
     * Log a conflict error
     * 
     * Specialized method for module ID conflicts.
     * 
     * @param string $moduleId Duplicate module ID
     * @return void
     */
    public function conflictError(string $moduleId): void
    {
        $message = "Duplicate module ID detected";
        $this->error($message, $moduleId, 'Conflict Error');
    }
    
    /**
     * Format a log message with consistent structure
     * 
     * @param string $level Log level (e.g., "Module Error", "Module Warning")
     * @param string $message Message content
     * @param string|null $moduleId Optional module ID
     * @param string|null $errorType Optional error type
     * @return string Formatted log message
     */
    private function formatMessage(
        string $level,
        string $message,
        ?string $moduleId = null,
        ?string $errorType = null
    ): string {
        $parts = [self::LOG_PREFIX, $level];
        
        if ($moduleId !== null) {
            $parts[] = $moduleId;
        }
        
        if ($errorType !== null) {
            $parts[] = $errorType;
        }
        
        $prefix = implode(': ', array_filter($parts));
        
        return "{$prefix}: {$message}";
    }
    
    /**
     * Write log message to error log and persistent file
     * 
     * Uses WordPress error_log function if available.
     * Also writes to persistent log file if configured.
     * 
     * @param string $message Formatted log message
     * @return void
     */
    private function write(string $message): void
    {
        // Write to WordPress error log
        if (function_exists('error_log')) {
            error_log($message);
        }
        
        // Write to persistent log file if configured
        if ($this->logFile !== null) {
            $this->writeToPersistentLog($message);
        }
    }
    
    /**
     * Write message to persistent log file
     * 
     * @param string $message Log message
     * @return void
     */
    private function writeToPersistentLog(string $message): void
    {
        $logEntry = sprintf(
            "[%s] %s\n",
            date('Y-m-d H:i:s'),
            $message
        );
        
        // Ensure log directory exists
        $logDir = dirname($this->logFile);
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        
        // Write to log file
        @file_put_contents($this->logFile, $logEntry, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Get the debug mode status
     * 
     * @return bool
     */
    public function isDebugMode(): bool
    {
        return $this->debugMode;
    }
    
    /**
     * Set the debug mode
     * 
     * @param bool $debugMode
     * @return void
     */
    public function setDebugMode(bool $debugMode): void
    {
        $this->debugMode = $debugMode;
    }
    
    /**
     * Set the log file path
     * 
     * @param string $logFile
     * @return void
     */
    public function setLogFile(string $logFile): void
    {
        $this->logFile = $logFile;
    }
}
