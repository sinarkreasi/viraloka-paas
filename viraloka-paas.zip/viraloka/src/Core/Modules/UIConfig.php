<?php

namespace Viraloka\Core\Modules;

/**
 * UI Configuration
 * 
 * Value object for UI-related manifest configuration.
 */
class UIConfig
{
    public bool $adminMenu;
    public ?string $menuTitle;
    public ?string $icon;
    public int $order;
    
    /**
     * Create a new UI config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->adminMenu = (bool)($data['admin_menu'] ?? false);
        $this->menuTitle = $data['menu_title'] ?? null;
        $this->icon = $data['icon'] ?? null;
        $this->order = (int)($data['order'] ?? 50);
    }
}
