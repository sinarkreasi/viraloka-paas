<?php

namespace Viraloka\Core\Modules;

/**
 * Dependency Configuration
 * 
 * Value object for dependency-related manifest configuration.
 */
class DependencyConfig
{
    public ?string $core;
    public array $modules;
    public array $plugins;
    
    /**
     * Create a new dependency config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->core = $data['core'] ?? null;
        $this->modules = $data['modules'] ?? [];
        $this->plugins = $data['plugins'] ?? [];
    }
}
