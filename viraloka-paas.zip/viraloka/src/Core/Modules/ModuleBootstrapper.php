<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Application;
use Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Viraloka\Core\Modules\Exceptions\BootstrapException;
use Viraloka\Core\Providers\ServiceProvider;

/**
 * Module Bootstrapper
 * 
 * Instantiates and initializes module service providers.
 * Validates provider classes, calls register() and conditionally boot() methods,
 * and handles bootstrap exceptions gracefully with logging.
 */
class ModuleBootstrapper implements ModuleBootstrapperContract
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * The module registry
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $registry;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Track bootstrapped modules
     * 
     * @var array<string, bool>
     */
    protected array $bootstrapped = [];
    
    /**
     * Track if boot phase is complete
     * 
     * @var bool
     */
    protected bool $bootPhaseComplete = false;
    
    /**
     * Create a new module bootstrapper instance
     * 
     * @param Application $app
     * @param ModuleRegistryContract $registry
     * @param Logger|null $logger
     */
    public function __construct(Application $app, ModuleRegistryContract $registry, ?Logger $logger = null)
    {
        $this->app = $app;
        $this->registry = $registry;
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Bootstrap a module
     * 
     * Instantiates the service provider, validates it extends base ServiceProvider,
     * calls register() method, and conditionally calls boot() method based on manifest.
     * Handles bootstrap exceptions gracefully with logging.
     * 
     * @param Module $module
     * @return void
     * @throws BootstrapException
     */
    public function bootstrap(Module $module): void
    {
        $moduleId = $module->getId();
        
        // Check if already bootstrapped
        if ($this->isBootstrapped($moduleId)) {
            return;
        }
        
        try {
            // Get provider class from manifest
            $providerClass = $module->manifest->getProviderClass();
            
            // Validate provider class is specified
            if (empty($providerClass)) {
                throw new BootstrapException(
                    $moduleId,
                    'No provider class specified in manifest'
                );
            }
            
            // Validate provider class exists
            if (!class_exists($providerClass)) {
                throw new BootstrapException(
                    $moduleId,
                    "Provider class '{$providerClass}' does not exist"
                );
            }
            
            // Validate provider extends base ServiceProvider
            if (!is_subclass_of($providerClass, ServiceProvider::class)) {
                throw new BootstrapException(
                    $moduleId,
                    "Provider class '{$providerClass}' must extend " . ServiceProvider::class
                );
            }
            
            // Instantiate the provider
            $provider = new $providerClass($this->app);
            
            // Store provider reference in module
            $module->provider = $provider;
            
            // Call register() method first
            $provider->register();
            
            // Then call boot() method (always call boot after register)
            if ($module->manifest->lifecycle && $module->manifest->lifecycle->boot) {
                $provider->boot();
            }
            
            // Mark module as bootstrapped
            $module->isBootstrapped = true;
            $this->bootstrapped[$moduleId] = true;
            
        } catch (BootstrapException $e) {
            // Re-throw bootstrap exceptions
            $this->logger->bootstrapError($moduleId, $e->getMessage());
            throw $e;
            
        } catch (\Throwable $e) {
            // Wrap other exceptions in BootstrapException
            $message = "Unexpected error during bootstrap: {$e->getMessage()}";
            $this->logger->bootstrapError($moduleId, $message, $e);
            throw new BootstrapException($moduleId, $message, $e);
        }
    }
    
    /**
     * Check if module is bootstrapped
     * 
     * @param string $moduleId
     * @return bool
     */
    public function isBootstrapped(string $moduleId): bool
    {
        return isset($this->bootstrapped[$moduleId]) && $this->bootstrapped[$moduleId];
    }
    
    /**
     * Bootstrap all active modules in dependency order
     * 
     * This method should be called during the ready phase.
     * It boots modules in dependency order, isolates failures,
     * and marks the boot phase as complete.
     * 
     * @return void
     */
    public function bootstrapAll(): void
    {
        // Get all modules from registry
        $modules = $this->registry->all();
        
        // Sort modules by dependency order
        $orderedModules = $this->sortByDependencies($modules);
        
        // Bootstrap each module with failure isolation
        foreach ($orderedModules as $module) {
            try {
                $this->bootstrap($module);
            } catch (\Throwable $e) {
                // Log error but continue with remaining modules
                $this->logger->bootstrapError(
                    $module->getId(),
                    "Module failed to bootstrap: {$e->getMessage()}",
                    $e
                );
                // Continue with next module
            }
        }
        
        // Mark boot phase as complete
        $this->bootPhaseComplete = true;
    }
    
    /**
     * Sort modules by dependency order
     * 
     * Uses topological sort to ensure modules are loaded after their dependencies.
     * 
     * @param array<Module> $modules
     * @return array<Module>
     */
    protected function sortByDependencies(array $modules): array
    {
        // Build dependency graph
        $graph = [];
        $moduleMap = [];
        
        foreach ($modules as $module) {
            $moduleId = $module->getId();
            $moduleMap[$moduleId] = $module;
            $graph[$moduleId] = [];
            
            // Add module dependencies to graph
            if ($module->manifest->dependencies !== null && !empty($module->manifest->dependencies->modules)) {
                foreach ($module->manifest->dependencies->modules as $dep) {
                    $depId = is_array($dep) ? ($dep['id'] ?? '') : $dep;
                    if (!empty($depId)) {
                        $graph[$moduleId][] = $depId;
                    }
                }
            }
        }
        
        // Perform topological sort
        $sorted = [];
        $visited = [];
        $visiting = [];
        
        foreach (array_keys($graph) as $moduleId) {
            if (!isset($visited[$moduleId])) {
                $this->topologicalSortVisit($moduleId, $graph, $visited, $visiting, $sorted);
            }
        }
        
        // Reverse to get correct order (dependencies first)
        $sorted = array_reverse($sorted);
        
        // Map back to Module objects
        $orderedModules = [];
        foreach ($sorted as $moduleId) {
            if (isset($moduleMap[$moduleId])) {
                $orderedModules[] = $moduleMap[$moduleId];
            }
        }
        
        return $orderedModules;
    }
    
    /**
     * Topological sort visit helper
     * 
     * @param string $moduleId
     * @param array $graph
     * @param array &$visited
     * @param array &$visiting
     * @param array &$sorted
     * @return void
     */
    protected function topologicalSortVisit(
        string $moduleId,
        array $graph,
        array &$visited,
        array &$visiting,
        array &$sorted
    ): void {
        // Mark as visiting to detect cycles
        $visiting[$moduleId] = true;
        
        // Visit dependencies
        if (isset($graph[$moduleId])) {
            foreach ($graph[$moduleId] as $depId) {
                if (isset($visiting[$depId])) {
                    // Cycle detected - skip this dependency
                    continue;
                }
                
                if (!isset($visited[$depId]) && isset($graph[$depId])) {
                    $this->topologicalSortVisit($depId, $graph, $visited, $visiting, $sorted);
                }
            }
        }
        
        // Mark as visited
        $visited[$moduleId] = true;
        unset($visiting[$moduleId]);
        
        // Add to sorted list
        $sorted[] = $moduleId;
    }
    
    /**
     * Check if boot phase is complete
     * 
     * @return bool
     */
    public function isBootPhaseComplete(): bool
    {
        return $this->bootPhaseComplete;
    }
}
