<?php

namespace Viraloka\Core\Modules;

/**
 * Recommendation Configuration
 * 
 * Value object for recommendation-related manifest configuration.
 */
class RecommendationConfig
{
    public array $modules;
    public array $integrations;
    
    /**
     * Create a new recommendation config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->modules = $data['modules'] ?? [];
        $this->integrations = $data['integrations'] ?? [];
    }
}
