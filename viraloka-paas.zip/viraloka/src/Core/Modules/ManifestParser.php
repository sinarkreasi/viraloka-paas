<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\ManifestParserContract;
use Viraloka\Core\Modules\Contracts\SchemaValidatorContract;

/**
 * Manifest Parser
 * 
 * Parses and validates module.json files into Manifest objects.
 */
class ManifestParser implements ManifestParserContract
{
    /**
     * Schema validator instance
     * 
     * @var SchemaValidatorContract
     */
    private SchemaValidatorContract $validator;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    private Logger $logger;
    
    /**
     * Create a new manifest parser instance
     * 
     * @param SchemaValidatorContract $validator
     * @param Logger|null $logger
     */
    public function __construct(SchemaValidatorContract $validator, ?Logger $logger = null)
    {
        $this->validator = $validator;
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Parse a manifest file
     * 
     * @param string $filePath
     * @return ParseResult
     */
    public function parse(string $filePath): ParseResult
    {
        // Check if file exists
        if (!file_exists($filePath)) {
            $error = "Manifest file not found: {$filePath}";
            $this->logger->parseError($filePath, 'File not found');
            return ParseResult::failure($error);
        }
        
        // Read file content
        $content = @file_get_contents($filePath);
        if ($content === false) {
            $error = "Failed to read manifest file: {$filePath}";
            $this->logger->parseError($filePath, 'Failed to read file');
            return ParseResult::failure($error);
        }
        
        // Validate UTF-8 encoding
        if (!mb_check_encoding($content, 'UTF-8')) {
            $error = "Manifest file is not valid UTF-8: {$filePath}";
            $this->logger->parseError($filePath, 'Invalid UTF-8 encoding');
            return ParseResult::failure($error);
        }
        
        // Decode JSON
        try {
            $data = json_decode($content, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            $error = "Invalid JSON in manifest file: {$e->getMessage()}";
            $this->logger->parseError($filePath, $e->getMessage());
            return ParseResult::failure($error);
        }
        
        // Ensure decoded data is an array
        if (!is_array($data)) {
            $error = "Manifest file must contain a JSON object";
            $this->logger->parseError($filePath, 'JSON must be an object');
            return ParseResult::failure($error);
        }
        
        // Validate against schema
        $validationResult = $this->validator->validate($data);
        
        if (!$validationResult->isValid()) {
            $errorMessage = "Manifest validation failed: " . implode(', ', $validationResult->getErrors());
            // Extract module ID if available for better logging
            $moduleId = $data['id'] ?? null;
            $this->logger->validationError($validationResult->getErrors(), $moduleId);
            return ParseResult::failure($errorMessage);
        }
        
        // Extract module path from file path
        $modulePath = dirname($filePath);
        
        // Create Manifest object
        try {
            $manifest = new Manifest($data, $modulePath);
        } catch (\Throwable $e) {
            $error = "Failed to create manifest object: {$e->getMessage()}";
            $moduleId = $data['id'] ?? null;
            $this->logger->error($error, $moduleId, 'Manifest Creation Error');
            return ParseResult::failure($error);
        }
        
        // Return success with any warnings
        return ParseResult::success($manifest, $validationResult->warnings);
    }
    
    /**
     * Validate manifest structure
     * 
     * @param array $data
     * @return ValidationResult
     */
    public function validate(array $data): ValidationResult
    {
        return $this->validator->validate($data);
    }
}
