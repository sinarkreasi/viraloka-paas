<?php

namespace Viraloka\Core\Modules;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Viraloka\Core\Modules\Exceptions\DuplicateModuleException;

/**
 * Module Registry
 * 
 * Maintains the central registry of all loaded modules.
 * Stores modules in an associative array keyed by module ID.
 * Enforces unique module IDs and maintains separate collections for valid and invalid modules.
 */
class ModuleRegistry implements ModuleRegistryContract
{
    /**
     * Valid modules indexed by module ID
     * 
     * @var array<string, Module>
     */
    protected array $modules = [];
    
    /**
     * Invalid modules collection
     * 
     * @var array<InvalidModule>
     */
    protected array $invalidModules = [];
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Module loader instance
     * 
     * @var \Viraloka\Core\Modules\Contracts\ModuleLoaderContract|null
     */
    protected $moduleLoader = null;
    
    /**
     * Workspace instance for filtering
     * 
     * @var \Viraloka\Core\Workspace\Workspace|null
     */
    protected $workspace = null;
    
    /**
     * Flag indicating if registry has been initialized
     * 
     * @var bool
     */
    protected bool $initialized = false;
    
    /**
     * Create a new module registry instance
     * 
     * @param Logger|null $logger
     */
    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Register a module
     * 
     * Enforces unique module IDs - throws exception on duplicate.
     * Provides fast O(1) lookup by ID.
     * 
     * @param Module $module
     * @return void
     * @throws DuplicateModuleException
     */
    public function register(Module $module): void
    {
        $moduleId = $module->getId();
        
        if ($this->has($moduleId)) {
            $this->logger->conflictError($moduleId);
            throw new DuplicateModuleException($moduleId);
        }
        
        $this->modules[$moduleId] = $module;
    }
    
    /**
     * Get module by ID
     * 
     * Provides fast O(1) lookup by ID.
     * Implements direct installation bypass (Requirement 9.4) - 
     * modules can be retrieved by ID regardless of visibility settings.
     * 
     * @param string $moduleId
     * @return Module|null
     */
    public function get(string $moduleId): ?Module
    {
        return $this->modules[$moduleId] ?? null;
    }
    
    /**
     * Get all registered modules
     * 
     * @return Collection<Module>
     */
    public function all(): Collection
    {
        return new Collection(array_values($this->modules));
    }
    
    /**
     * Get all public modules (visibility filtering)
     * 
     * Filters modules based on visibility.public setting.
     * Implements public listing filter (Requirement 9.1).
     * 
     * @return Collection<Module>
     */
    public function getPublicModules(): Collection
    {
        return $this->all()->filter(function (Module $module) {
            return $module->manifest->visibility->public;
        });
    }
    
    /**
     * Check if module is registered
     * 
     * @param string $moduleId
     * @return bool
     */
    public function has(string $moduleId): bool
    {
        return isset($this->modules[$moduleId]);
    }
    
    /**
     * Register an invalid module
     * 
     * Stores invalid modules in a separate collection.
     * 
     * @param InvalidModule $invalidModule
     * @return void
     */
    public function registerInvalid(InvalidModule $invalidModule): void
    {
        $this->invalidModules[] = $invalidModule;
    }
    
    /**
     * Get all invalid modules
     * 
     * @return Collection<InvalidModule>
     */
    public function getInvalidModules(): Collection
    {
        return new Collection($this->invalidModules);
    }
    
    /**
     * Initialize the module registry during boot phase
     * 
     * This method performs module discovery, validation, dependency resolution,
     * and workspace-based filtering. It does NOT execute any module code.
     * 
     * @param \Viraloka\Core\Modules\Contracts\ModuleLoaderContract $loader
     * @param \Viraloka\Core\Workspace\Workspace|null $workspace
     * @return void
     */
    public function initialize($loader, $workspace = null): void
    {
        if ($this->initialized) {
            $this->logger->warning('Module registry already initialized', null);
            return;
        }
        
        $this->moduleLoader = $loader;
        $this->workspace = $workspace;
        
        // Discover and load modules (validation and dependency resolution happen in loader)
        $this->discoverModules();
        
        // Filter modules by workspace if workspace is provided
        if ($workspace !== null) {
            $this->filterByWorkspace($workspace);
        }
        
        $this->initialized = true;
    }
    
    /**
     * Discover modules using the module loader
     * 
     * This triggers module discovery, manifest validation, and dependency resolution.
     * No module code is executed during this phase.
     * 
     * @return void
     */
    protected function discoverModules(): void
    {
        if ($this->moduleLoader === null) {
            $this->logger->error('Module loader not set', null, 'Registry Initialization');
            return;
        }
        
        // Load modules (this handles discovery, validation, and dependency resolution)
        $this->moduleLoader->loadModules();
        
        // Modules are automatically registered in the registry by the loader
    }
    
    /**
     * Filter modules by workspace enablement
     * 
     * Removes modules that are not enabled for the current workspace.
     * 
     * @param \Viraloka\Core\Workspace\Workspace $workspace
     * @return void
     */
    protected function filterByWorkspace($workspace): void
    {
        if (empty($workspace->enabledModules)) {
            // No filtering - all modules are enabled
            return;
        }
        
        // Filter out modules not enabled for this workspace
        $this->modules = array_filter($this->modules, function (Module $module) use ($workspace) {
            $isEnabled = in_array($module->getId(), $workspace->enabledModules, true);
            
            if (!$isEnabled) {
                $this->logger->info(
                    "Module '{$module->getId()}' not enabled for workspace '{$workspace->id}'",
                    $module->getId()
                );
            }
            
            return $isEnabled;
        });
    }
    
    /**
     * Check if registry has been initialized
     * 
     * @return bool
     */
    public function isInitialized(): bool
    {
        return $this->initialized;
    }
    
    /**
     * Get modules enabled for a specific workspace
     * 
     * @param \Viraloka\Core\Workspace\Workspace $workspace
     * @return Collection<Module>
     */
    public function getModulesForWorkspace($workspace): Collection
    {
        if (empty($workspace->enabledModules)) {
            // No filtering - return all modules
            return $this->all();
        }
        
        return $this->all()->filter(function (Module $module) use ($workspace) {
            return in_array($module->getId(), $workspace->enabledModules, true);
        });
    }
}
