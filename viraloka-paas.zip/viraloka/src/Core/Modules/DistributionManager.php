<?php

namespace Viraloka\Core\Modules;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Contracts\DistributionManagerContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;

/**
 * Distribution Manager
 * 
 * Manages module distribution and marketplace visibility.
 * Filters modules based on visibility settings for marketplace APIs.
 */
class DistributionManager implements DistributionManagerContract
{
    /**
     * Module registry instance
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $registry;
    
    /**
     * Create a new distribution manager instance
     * 
     * @param ModuleRegistryContract $registry
     */
    public function __construct(ModuleRegistryContract $registry)
    {
        $this->registry = $registry;
    }
    
    /**
     * Get modules available for marketplace distribution
     * 
     * Filters modules based on visibility.marketplace setting.
     * Implements marketplace API filtering (Requirement 9.2).
     * 
     * @return Collection
     */
    public function getMarketplaceModules(): Collection
    {
        return $this->registry->all()->filter(function (Module $module) {
            return $module->manifest->visibility->marketplace;
        });
    }
}
