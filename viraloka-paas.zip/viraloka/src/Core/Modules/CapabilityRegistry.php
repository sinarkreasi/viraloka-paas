<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\CapabilityRegistryContract;

/**
 * Capability Registry
 * 
 * Manages module-declared capabilities for the permission system.
 * Capabilities are namespaced with module IDs to prevent collisions
 * and stored in WordPress options per workspace.
 */
class CapabilityRegistry implements CapabilityRegistryContract
{
    /**
     * WordPress option key for storing capabilities
     */
    private const OPTION_KEY = 'viraloka_module_capabilities';
    
    /**
     * In-memory cache of capabilities
     * 
     * @var array
     */
    private array $capabilities = [];
    
    /**
     * Whether capabilities have been loaded from storage
     * 
     * @var bool
     */
    private bool $loaded = false;
    
    /**
     * Register capabilities from manifest
     * 
     * @param Manifest $manifest
     * @return void
     */
    public function registerCapabilities(Manifest $manifest): void
    {
        $this->ensureLoaded();
        
        $moduleId = $manifest->id;
        $capabilities = $manifest->capabilities;
        
        if (empty($capabilities)) {
            return;
        }
        
        // Namespace capabilities with module ID to prevent collisions
        $namespacedCapabilities = [];
        foreach ($capabilities as $capability) {
            $namespacedCapabilities[] = $this->namespaceCapability($moduleId, $capability);
        }
        
        // Store capabilities for this module
        $this->capabilities[$moduleId] = $namespacedCapabilities;
        
        // Persist to WordPress options
        $this->save();
    }
    
    /**
     * Get all capabilities for a module
     * 
     * @param string $moduleId
     * @return array
     */
    public function getModuleCapabilities(string $moduleId): array
    {
        $this->ensureLoaded();
        
        return $this->capabilities[$moduleId] ?? [];
    }
    
    /**
     * Remove capabilities when module is disabled
     * 
     * @param string $moduleId
     * @return void
     */
    public function unregisterCapabilities(string $moduleId): void
    {
        $this->ensureLoaded();
        
        if (isset($this->capabilities[$moduleId])) {
            unset($this->capabilities[$moduleId]);
            $this->save();
        }
    }
    
    /**
     * Namespace a capability with module ID
     * 
     * @param string $moduleId
     * @param string $capability
     * @return string
     */
    private function namespaceCapability(string $moduleId, string $capability): string
    {
        return "{$moduleId}:{$capability}";
    }
    
    /**
     * Ensure capabilities are loaded from storage
     * 
     * @return void
     */
    private function ensureLoaded(): void
    {
        if ($this->loaded) {
            return;
        }
        
        $this->load();
        $this->loaded = true;
    }
    
    /**
     * Load capabilities from WordPress options
     * 
     * @return void
     */
    private function load(): void
    {
        $stored = get_option(self::OPTION_KEY, []);
        
        if (is_array($stored)) {
            $this->capabilities = $stored;
        } else {
            $this->capabilities = [];
        }
    }
    
    /**
     * Save capabilities to WordPress options
     * 
     * @return void
     */
    private function save(): void
    {
        update_option(self::OPTION_KEY, $this->capabilities);
    }
}

