<?php

namespace Viraloka\Core\Modules;

/**
 * Invalid Module
 * 
 * Represents a module that failed validation with error details.
 */
class InvalidModule
{
    public string $path;
    public string $error;
    public ?string $moduleId;
    
    /**
     * Create a new invalid module instance
     * 
     * @param string $path
     * @param string $error
     * @param string|null $moduleId
     */
    public function __construct(string $path, string $error, ?string $moduleId = null)
    {
        $this->path = $path;
        $this->error = $error;
        $this->moduleId = $moduleId;
    }
}
