<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\ManifestCacheContract;

/**
 * Manifest Cache
 * 
 * Caches parsed manifests to improve performance.
 * 
 * Implementation Details:
 * - Uses WordPress transients API for storage
 * - Cache key format: viraloka_manifest_{moduleId}
 * - TTL: 24 hours (configurable via filter)
 * - Invalidates cache when module.json file is modified (via filemtime check)
 * - Falls back to object cache if available (Redis, Memcached)
 * - Serializes Manifest objects for storage
 */
class ManifestCache implements ManifestCacheContract
{
    /**
     * Cache key prefix
     * 
     * @var string
     */
    protected string $prefix = 'viraloka_manifest_';
    
    /**
     * Cache TTL in seconds (24 hours)
     * 
     * @var int
     */
    protected int $ttl = 86400;
    
    /**
     * Module file paths for filemtime checking
     * Key: moduleId, Value: file path
     * 
     * @var array<string, string>
     */
    protected array $filePaths = [];
    
    /**
     * Create a new manifest cache instance
     * 
     * @param int|null $ttl Optional TTL override in seconds
     */
    public function __construct(?int $ttl = null)
    {
        if ($ttl !== null) {
            $this->ttl = $ttl;
        }
    }
    
    /**
     * Get cached manifest
     * 
     * Retrieves manifest from cache and validates it hasn't been modified.
     * Returns null if cache miss or file has been modified.
     * 
     * @param string $moduleId
     * @return Manifest|null
     */
    public function get(string $moduleId): ?Manifest
    {
        $cacheKey = $this->getCacheKey($moduleId);
        
        // Try to get from transient
        $cached = $this->getTransient($cacheKey);
        
        if ($cached === false) {
            return null;
        }
        
        // Validate cache structure
        if (!is_array($cached) || !isset($cached['manifest']) || !isset($cached['mtime']) || !isset($cached['path'])) {
            $this->deleteTransient($cacheKey);
            return null;
        }
        
        // Check if file has been modified
        $filePath = $cached['path'];
        if (file_exists($filePath)) {
            $currentMtime = filemtime($filePath);
            if ($currentMtime !== $cached['mtime']) {
                // File modified, invalidate cache
                $this->deleteTransient($cacheKey);
                return null;
            }
        } else {
            // File no longer exists, invalidate cache
            $this->deleteTransient($cacheKey);
            return null;
        }
        
        // Deserialize manifest
        $manifest = $this->deserializeManifest($cached['manifest']);
        
        if ($manifest === null) {
            $this->deleteTransient($cacheKey);
            return null;
        }
        
        // Store file path for future invalidation
        $this->filePaths[$moduleId] = $filePath;
        
        return $manifest;
    }
    
    /**
     * Store manifest in cache
     * 
     * Serializes manifest and stores with file modification time.
     * 
     * @param string $moduleId
     * @param Manifest $manifest
     * @return void
     */
    public function put(string $moduleId, Manifest $manifest): void
    {
        $cacheKey = $this->getCacheKey($moduleId);
        $filePath = $manifest->getPath() . '/module.json';
        
        // Get file modification time
        $mtime = file_exists($filePath) ? filemtime($filePath) : time();
        
        // Serialize manifest
        $serialized = $this->serializeManifest($manifest);
        
        // Store in cache with metadata
        $cacheData = [
            'manifest' => $serialized,
            'mtime' => $mtime,
            'path' => $filePath
        ];
        
        $this->setTransient($cacheKey, $cacheData, $this->ttl);
        
        // Store file path for future invalidation
        $this->filePaths[$moduleId] = $filePath;
    }
    
    /**
     * Invalidate cache for module
     * 
     * @param string $moduleId
     * @return void
     */
    public function forget(string $moduleId): void
    {
        $cacheKey = $this->getCacheKey($moduleId);
        $this->deleteTransient($cacheKey);
        
        // Remove from file paths tracking
        unset($this->filePaths[$moduleId]);
    }
    
    /**
     * Clear all cached manifests
     * 
     * @return void
     */
    public function flush(): void
    {
        // WordPress doesn't provide a way to delete all transients by prefix
        // So we need to use direct database access or track all keys
        // For now, we'll use a simple approach with known module IDs
        
        global $wpdb;
        
        if ($wpdb) {
            // Delete all transients with our prefix
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                    $wpdb->esc_like('_transient_' . $this->prefix) . '%',
                    $wpdb->esc_like('_transient_timeout_' . $this->prefix) . '%'
                )
            );
        }
        
        // Clear file paths tracking
        $this->filePaths = [];
    }
    
    /**
     * Get cache key for module
     * 
     * @param string $moduleId
     * @return string
     */
    protected function getCacheKey(string $moduleId): string
    {
        return $this->prefix . $moduleId;
    }
    
    /**
     * Serialize manifest for storage
     * 
     * Converts Manifest object to array for serialization.
     * 
     * @param Manifest $manifest
     * @return array
     */
    protected function serializeManifest(Manifest $manifest): array
    {
        return [
            'id' => $manifest->id,
            'name' => $manifest->name,
            'description' => $manifest->description,
            'version' => $manifest->version,
            'author' => $manifest->author,
            'namespace' => $manifest->namespace,
            'path' => $manifest->getPath(),
            'contexts' => $manifest->contexts ? $this->serializeContextConfig($manifest->contexts) : null,
            'dependencies' => $manifest->dependencies ? $this->serializeDependencyConfig($manifest->dependencies) : null,
            'capabilities' => $manifest->capabilities,
            'ui' => $manifest->ui ? $this->serializeUIConfig($manifest->ui) : null,
            'lifecycle' => $manifest->lifecycle ? $this->serializeLifecycleConfig($manifest->lifecycle) : null,
            'recommendations' => $manifest->recommendations ? $this->serializeRecommendationConfig($manifest->recommendations) : null,
            'visibility' => $this->serializeVisibilityConfig($manifest->visibility),
        ];
    }
    
    /**
     * Deserialize manifest from storage
     * 
     * Converts array back to Manifest object.
     * 
     * @param array $data
     * @return Manifest|null
     */
    protected function deserializeManifest(array $data): ?Manifest
    {
        try {
            // Reconstruct the manifest data array
            $manifestData = [
                'id' => $data['id'],
                'name' => $data['name'],
                'description' => $data['description'],
                'version' => $data['version'],
                'author' => $data['author'],
                'namespace' => $data['namespace'],
            ];
            
            if ($data['contexts'] !== null) {
                $manifestData['contexts'] = $data['contexts'];
            }
            
            if ($data['dependencies'] !== null) {
                $manifestData['dependencies'] = $data['dependencies'];
            }
            
            if (!empty($data['capabilities'])) {
                $manifestData['capabilities'] = $data['capabilities'];
            }
            
            if ($data['ui'] !== null) {
                $manifestData['ui'] = $data['ui'];
            }
            
            if ($data['lifecycle'] !== null) {
                $manifestData['lifecycle'] = $data['lifecycle'];
            }
            
            if ($data['recommendations'] !== null) {
                $manifestData['recommendations'] = $data['recommendations'];
            }
            
            if ($data['visibility'] !== null) {
                $manifestData['visibility'] = $data['visibility'];
            }
            
            return new Manifest($manifestData, $data['path']);
        } catch (\Exception $e) {
            return null;
        }
    }
    
    /**
     * Serialize ContextConfig
     * 
     * @param ContextConfig $config
     * @return array
     */
    protected function serializeContextConfig(ContextConfig $config): array
    {
        return [
            'supported' => $config->supported,
            'primary' => $config->primary,
            'priority' => $config->priority,
        ];
    }
    
    /**
     * Serialize DependencyConfig
     * 
     * @param DependencyConfig $config
     * @return array
     */
    protected function serializeDependencyConfig(DependencyConfig $config): array
    {
        return [
            'core' => $config->core,
            'modules' => $config->modules,
            'plugins' => $config->plugins,
        ];
    }
    
    /**
     * Serialize UIConfig
     * 
     * @param UIConfig $config
     * @return array
     */
    protected function serializeUIConfig(UIConfig $config): array
    {
        return [
            'admin_menu' => $config->adminMenu,
            'menu_title' => $config->menuTitle,
            'icon' => $config->icon,
            'order' => $config->order,
        ];
    }
    
    /**
     * Serialize LifecycleConfig
     * 
     * @param LifecycleConfig $config
     * @return array
     */
    protected function serializeLifecycleConfig(LifecycleConfig $config): array
    {
        return [
            'provider' => $config->provider,
            'boot' => $config->boot,
        ];
    }
    
    /**
     * Serialize RecommendationConfig
     * 
     * @param RecommendationConfig $config
     * @return array
     */
    protected function serializeRecommendationConfig(RecommendationConfig $config): array
    {
        return [
            'modules' => $config->modules,
            'integrations' => $config->integrations,
        ];
    }
    
    /**
     * Serialize VisibilityConfig
     * 
     * @param VisibilityConfig $config
     * @return array
     */
    protected function serializeVisibilityConfig(VisibilityConfig $config): array
    {
        return [
            'public' => $config->public,
            'marketplace' => $config->marketplace,
        ];
    }
    
    /**
     * Get transient value
     * 
     * Wrapper for WordPress get_transient with fallback.
     * 
     * @param string $key
     * @return mixed
     */
    protected function getTransient(string $key)
    {
        if (function_exists('get_transient')) {
            return get_transient($key);
        }
        
        // Fallback for testing without WordPress
        return false;
    }
    
    /**
     * Set transient value
     * 
     * Wrapper for WordPress set_transient with fallback.
     * 
     * @param string $key
     * @param mixed $value
     * @param int $expiration
     * @return bool
     */
    protected function setTransient(string $key, $value, int $expiration): bool
    {
        if (function_exists('set_transient')) {
            return set_transient($key, $value, $expiration);
        }
        
        // Fallback for testing without WordPress
        return true;
    }
    
    /**
     * Delete transient value
     * 
     * Wrapper for WordPress delete_transient with fallback.
     * 
     * @param string $key
     * @return bool
     */
    protected function deleteTransient(string $key): bool
    {
        if (function_exists('delete_transient')) {
            return delete_transient($key);
        }
        
        // Fallback for testing without WordPress
        return true;
    }
}
