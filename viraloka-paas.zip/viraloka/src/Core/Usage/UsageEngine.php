<?php

namespace Viraloka\Core\Usage;

use Viraloka\Core\Application;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Usage\Contracts\UsageEngineContract;
use Viraloka\Core\Workspace\Workspace;

/**
 * UsageEngine
 * 
 * Provides credit-based usage metering with workspace-scoped tracking.
 * Records usage against workspaces, enforces limits based on subscription tiers,
 * and maintains usage history.
 */
class UsageEngine implements UsageEngineContract
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Usage cache
     * 
     * @var array
     */
    protected array $usageCache = [];
    
    /**
     * Create a new UsageEngine instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->logger = $app->make(Logger::class);
    }
    
    /**
     * Record usage for a user in a workspace
     * 
     * Records a usage event and deducts from available quota.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param int $amount Amount of usage to record
     * @param Workspace $workspace Workspace context
     * @param array $metadata Optional metadata about the usage event
     * @return bool True on success, false on failure
     */
    public function recordUsage(string $userId, string $resourceType, int $amount, Workspace $workspace, array $metadata = []): bool
    {
        try {
            // Check if recording this usage would exceed limits
            if (!$this->checkLimit($userId, $resourceType, $amount, $workspace)) {
                $this->logger->warning(
                    sprintf('Usage limit exceeded for user %s, resource %s in workspace %s', 
                        $userId, $resourceType, $workspace->id),
                    'usage-engine'
                );
                return false;
            }
            
            // Get current usage
            $currentUsage = $this->getUsage($userId, $resourceType, $workspace);
            
            // Calculate new usage
            $newUsage = $currentUsage + $amount;
            
            // Update usage counter
            $this->updateUsageCounter($userId, $resourceType, $newUsage, $workspace);
            
            // Record usage event in history
            $this->recordUsageEvent($userId, $resourceType, $amount, $workspace, $metadata);
            
            // Clear cache
            $this->clearUsageCache($userId, $resourceType, $workspace);
            
            $this->logger->info(
                sprintf('Usage recorded: user %s, resource %s, amount %d in workspace %s', 
                    $userId, $resourceType, $amount, $workspace->id),
                'usage-engine'
            );
            
            return true;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to record usage for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Record Usage Error'
            );
            return false;
        }
    }
    
    /**
     * Check if usage is within limit
     * 
     * Verifies that recording the specified amount would not exceed the subscription tier's limit.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param int $amount Amount to check
     * @param Workspace $workspace Workspace context
     * @return bool True if within limit, false if would exceed limit
     */
    public function checkLimit(string $userId, string $resourceType, int $amount, Workspace $workspace): bool
    {
        try {
            // Get remaining quota
            $remaining = $this->getRemainingQuota($userId, $resourceType, $workspace);
            
            // -1 means unlimited
            if ($remaining === -1) {
                return true;
            }
            
            // Check if amount is within remaining quota
            return $amount <= $remaining;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to check limit for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Check Limit Error'
            );
            
            // Deny on error for security
            return false;
        }
    }
    
    /**
     * Get current usage for a user in a workspace
     * 
     * Returns the current usage amount for a specific resource type.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return int Current usage amount
     */
    public function getUsage(string $userId, string $resourceType, Workspace $workspace): int
    {
        // Check cache first
        $cacheKey = $this->getUsageCacheKey($userId, $resourceType, $workspace);
        if (isset($this->usageCache[$cacheKey])) {
            return $this->usageCache[$cacheKey];
        }
        
        try {
            // In a real implementation, this would query a usage table
            // For now, we'll use WordPress options as a simple implementation
            $optionKey = $this->getUsageOptionKey($userId, $resourceType, $workspace);
            $usage = get_option($optionKey, 0);
            
            // Ensure it's an integer
            $usage = is_numeric($usage) ? (int) $usage : 0;
            
            // Cache the result
            $this->usageCache[$cacheKey] = $usage;
            
            return $usage;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get usage for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Get Usage Error'
            );
            return 0;
        }
    }
    
    /**
     * Get usage history for a user in a workspace
     * 
     * Returns historical usage records for a specific resource type.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @param int $limit Maximum number of records to return
     * @return array Array of usage records
     */
    public function getUsageHistory(string $userId, string $resourceType, Workspace $workspace, int $limit = 100): array
    {
        try {
            // In a real implementation, this would query a usage_history table
            // For now, we'll use WordPress options as a simple implementation
            $optionKey = $this->getUsageHistoryOptionKey($userId, $resourceType, $workspace);
            $history = get_option($optionKey, []);
            
            if (!is_array($history)) {
                return [];
            }
            
            // Sort by timestamp descending (most recent first)
            usort($history, function($a, $b) {
                return ($b['timestamp'] ?? 0) - ($a['timestamp'] ?? 0);
            });
            
            // Limit results
            return array_slice($history, 0, $limit);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get usage history for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Get Usage History Error'
            );
            return [];
        }
    }
    
    /**
     * Reset usage for a user in a workspace
     * 
     * Resets usage counters for a specific resource type (typically used for monthly resets).
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return bool True on success, false on failure
     */
    public function resetUsage(string $userId, string $resourceType, Workspace $workspace): bool
    {
        try {
            // Reset usage counter to 0
            $this->updateUsageCounter($userId, $resourceType, 0, $workspace);
            
            // Clear cache
            $this->clearUsageCache($userId, $resourceType, $workspace);
            
            $this->logger->info(
                sprintf('Usage reset for user %s, resource %s in workspace %s', 
                    $userId, $resourceType, $workspace->id),
                'usage-engine'
            );
            
            return true;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to reset usage for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Reset Usage Error'
            );
            return false;
        }
    }
    
    /**
     * Get remaining quota for a user in a workspace
     * 
     * Returns the remaining quota available for a specific resource type.
     * Returns -1 for unlimited.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return int Remaining quota, or -1 for unlimited
     */
    public function getRemainingQuota(string $userId, string $resourceType, Workspace $workspace): int
    {
        try {
            // Get subscription engine
            if (!$this->app->bound('Viraloka\Core\Subscription\Contracts\SubscriptionEngineContract')) {
                // If SubscriptionEngine not available, return unlimited
                return -1;
            }
            
            $subscriptionEngine = $this->app->make('Viraloka\Core\Subscription\Contracts\SubscriptionEngineContract');
            
            // Get user's subscription tier
            $tier = $subscriptionEngine->getTier($userId, $workspace);
            
            // Get tier limit
            $limit = $subscriptionEngine->getLimit($tier, $resourceType);
            
            // -1 means unlimited
            if ($limit === -1) {
                return -1;
            }
            
            // Get current usage
            $currentUsage = $this->getUsage($userId, $resourceType, $workspace);
            
            // Calculate remaining
            $remaining = $limit - $currentUsage;
            
            // Ensure non-negative
            return max(0, $remaining);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to get remaining quota for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Get Remaining Quota Error'
            );
            
            // Return 0 on error for security
            return 0;
        }
    }
    
    /**
     * Update usage counter
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param int $usage New usage value
     * @param Workspace $workspace Workspace context
     * @return void
     */
    protected function updateUsageCounter(string $userId, string $resourceType, int $usage, Workspace $workspace): void
    {
        $optionKey = $this->getUsageOptionKey($userId, $resourceType, $workspace);
        update_option($optionKey, $usage);
    }
    
    /**
     * Record usage event in history
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param int $amount Amount of usage
     * @param Workspace $workspace Workspace context
     * @param array $metadata Optional metadata
     * @return void
     */
    protected function recordUsageEvent(string $userId, string $resourceType, int $amount, Workspace $workspace, array $metadata = []): void
    {
        try {
            // Get current history
            $optionKey = $this->getUsageHistoryOptionKey($userId, $resourceType, $workspace);
            $history = get_option($optionKey, []);
            
            if (!is_array($history)) {
                $history = [];
            }
            
            // Add new event
            $event = [
                'timestamp' => time(),
                'amount' => $amount,
                'metadata' => $metadata,
            ];
            
            $history[] = $event;
            
            // Keep only last 1000 events to prevent unbounded growth
            if (count($history) > 1000) {
                // Sort by timestamp descending
                usort($history, function($a, $b) {
                    return ($b['timestamp'] ?? 0) - ($a['timestamp'] ?? 0);
                });
                
                // Keep only last 1000
                $history = array_slice($history, 0, 1000);
            }
            
            // Save history
            update_option($optionKey, $history);
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Failed to record usage event for user %s, resource %s in workspace %s: %s', 
                    $userId, $resourceType, $workspace->id, $e->getMessage()),
                'usage-engine',
                'Record Usage Event Error'
            );
        }
    }
    
    /**
     * Get usage option key
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param Workspace $workspace Workspace context
     * @return string Option key
     */
    protected function getUsageOptionKey(string $userId, string $resourceType, Workspace $workspace): string
    {
        return sprintf('viraloka_usage_%s_%s_%s', $workspace->id, $userId, $resourceType);
    }
    
    /**
     * Get usage history option key
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param Workspace $workspace Workspace context
     * @return string Option key
     */
    protected function getUsageHistoryOptionKey(string $userId, string $resourceType, Workspace $workspace): string
    {
        return sprintf('viraloka_usage_history_%s_%s_%s', $workspace->id, $userId, $resourceType);
    }
    
    /**
     * Get usage cache key
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param Workspace $workspace Workspace context
     * @return string Cache key
     */
    protected function getUsageCacheKey(string $userId, string $resourceType, Workspace $workspace): string
    {
        return sprintf('%s:%s:%s', $workspace->id, $userId, $resourceType);
    }
    
    /**
     * Clear usage cache
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type
     * @param Workspace $workspace Workspace context
     * @return void
     */
    protected function clearUsageCache(string $userId, string $resourceType, Workspace $workspace): void
    {
        $cacheKey = $this->getUsageCacheKey($userId, $resourceType, $workspace);
        unset($this->usageCache[$cacheKey]);
    }
}
