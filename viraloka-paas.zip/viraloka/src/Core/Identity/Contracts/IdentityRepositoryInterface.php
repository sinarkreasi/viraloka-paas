<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Contracts;

use Viraloka\Core\Identity\Identity;

/**
 * Identity Repository Interface
 * 
 * Defines the contract for identity persistence operations.
 */
interface IdentityRepositoryInterface
{
    /**
     * Save a new identity
     * 
     * @param Identity $identity
     * @return bool
     */
    public function save(Identity $identity): bool;

    /**
     * Find identity by ID
     * 
     * @param string $identityId UUID
     * @return Identity|null
     */
    public function findById(string $identityId): ?Identity;

    /**
     * Find identity by email
     * 
     * @param string $email Email address
     * @return Identity|null
     */
    public function findByEmail(string $email): ?Identity;

    /**
     * Update an existing identity
     * 
     * @param Identity $identity
     * @return bool
     */
    public function update(Identity $identity): bool;

    /**
     * Delete an identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function delete(string $identityId): bool;

    /**
     * Check if email exists
     * 
     * @param string $email Email address
     * @return bool
     */
    public function emailExists(string $email): bool;
}
