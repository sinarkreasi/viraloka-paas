<?php

namespace Viraloka\Core\Identity\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Identity Engine Contract
 * 
 * Defines the interface for user authentication and workspace membership resolution.
 * The IdentityEngine integrates with WordPress user system and resolves workspace
 * membership on authentication.
 */
interface IdentityEngineContract
{
    /**
     * Authenticate a user
     * 
     * Authenticates a user and resolves their workspace membership.
     * Integrates with WordPress authentication system.
     * 
     * @param string $username Username or email
     * @param string $password Password
     * @return array|false Authentication result with user data and workspaces, or false on failure
     */
    public function authenticate(string $username, string $password);
    
    /**
     * Resolve workspace membership for a user
     * 
     * Returns all workspaces the user is a member of.
     * Supports multi-workspace membership.
     * 
     * @param string $userId User ID
     * @return array Array of Workspace objects the user belongs to
     */
    public function resolveWorkspaceMembership(string $userId): array;
    
    /**
     * Get the current authenticated user
     * 
     * Returns the currently authenticated user data.
     * 
     * @return array|null User data array or null if not authenticated
     */
    public function getCurrentUser(): ?array;
    
    /**
     * Check if a user is authenticated
     * 
     * @return bool True if user is authenticated, false otherwise
     */
    public function isAuthenticated(): bool;
    
    /**
     * Get user by ID
     * 
     * @param string $userId User ID
     * @return array|null User data array or null if not found
     */
    public function getUserById(string $userId): ?array;
}
