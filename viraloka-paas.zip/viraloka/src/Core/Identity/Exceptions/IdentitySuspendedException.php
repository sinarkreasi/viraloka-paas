<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Exceptions;

use Exception;

/**
 * Identity Suspended Exception
 * 
 * Thrown when attempting to perform operations on a suspended identity.
 */
class IdentitySuspendedException extends Exception
{
    public function __construct(string $identityId, int $code = 0, ?\Throwable $previous = null)
    {
        $message = sprintf('Identity with ID "%s" is suspended', $identityId);
        parent::__construct($message, $code, $previous);
    }
}
