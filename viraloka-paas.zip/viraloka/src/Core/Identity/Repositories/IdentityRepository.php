<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Repositories;

use Viraloka\Core\Identity\Identity;
use Viraloka\Core\Identity\Contracts\IdentityRepositoryInterface;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use DateTimeImmutable;

/**
 * Identity Repository
 * 
 * Handles persistence of Identity entities using StorageAdapter.
 */
class IdentityRepository implements IdentityRepositoryInterface
{
    private const PREFIX_ID = 'identity:id:';
    private const PREFIX_EMAIL = 'identity:email:';
    private const INDEX_EMAILS = 'identity:index:emails';

    public function __construct(
        private readonly StorageAdapterInterface $storageAdapter
    ) {}

    /**
     * Save a new identity
     * 
     * @param Identity $identity
     * @return bool
     */
    public function save(Identity $identity): bool
    {
        // Check if email already exists
        if ($this->emailExists($identity->email)) {
            return false;
        }

        // Serialize identity data
        $data = $this->serialize($identity);

        // Store by ID
        $idKey = self::PREFIX_ID . $identity->identityId;
        if (!$this->storageAdapter->set($idKey, $data)) {
            return false;
        }

        // Store email index
        $emailKey = self::PREFIX_EMAIL . strtolower($identity->email);
        if (!$this->storageAdapter->set($emailKey, $identity->identityId)) {
            // Rollback ID storage
            $this->storageAdapter->delete($idKey);
            return false;
        }

        // Add to email index
        $this->addToEmailIndex($identity->email);

        return true;
    }

    /**
     * Find identity by ID
     * 
     * @param string $identityId UUID
     * @return Identity|null
     */
    public function findById(string $identityId): ?Identity
    {
        $key = self::PREFIX_ID . $identityId;
        $data = $this->storageAdapter->get($key);

        if ($data === null) {
            return null;
        }

        return $this->deserialize($data);
    }

    /**
     * Find identity by email
     * 
     * @param string $email Email address
     * @return Identity|null
     */
    public function findByEmail(string $email): ?Identity
    {
        // Get identity ID from email index
        $emailKey = self::PREFIX_EMAIL . strtolower($email);
        $identityId = $this->storageAdapter->get($emailKey);

        if ($identityId === null) {
            return null;
        }

        return $this->findById($identityId);
    }

    /**
     * Update an existing identity
     * 
     * @param Identity $identity
     * @return bool
     */
    public function update(Identity $identity): bool
    {
        // Check if identity exists
        $existing = $this->findById($identity->identityId);
        if ($existing === null) {
            return false;
        }

        // Serialize updated data
        $data = $this->serialize($identity);

        // Update by ID
        $idKey = self::PREFIX_ID . $identity->identityId;
        return $this->storageAdapter->set($idKey, $data);
    }

    /**
     * Delete an identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function delete(string $identityId): bool
    {
        // Get identity first to remove email index
        $identity = $this->findById($identityId);
        if ($identity === null) {
            return false;
        }

        // Delete by ID
        $idKey = self::PREFIX_ID . $identityId;
        $this->storageAdapter->delete($idKey);

        // Delete email index
        $emailKey = self::PREFIX_EMAIL . strtolower($identity->email);
        $this->storageAdapter->delete($emailKey);

        // Remove from email index
        $this->removeFromEmailIndex($identity->email);

        return true;
    }

    /**
     * Check if email exists
     * 
     * @param string $email Email address
     * @return bool
     */
    public function emailExists(string $email): bool
    {
        $emailKey = self::PREFIX_EMAIL . strtolower($email);
        return $this->storageAdapter->has($emailKey);
    }

    /**
     * Serialize identity to array
     * 
     * @param Identity $identity
     * @return array
     */
    private function serialize(Identity $identity): array
    {
        return [
            'identity_id' => $identity->identityId,
            'email' => $identity->email,
            'status' => $identity->status,
            'metadata' => $identity->metadata,
            'created_at' => $identity->createdAt->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * Deserialize array to identity
     * 
     * @param array $data
     * @return Identity
     */
    private function deserialize(array $data): Identity
    {
        return new Identity(
            $data['identity_id'],
            $data['email'],
            $data['status'],
            $data['metadata'] ?? [],
            new DateTimeImmutable($data['created_at'])
        );
    }

    /**
     * Add email to index
     * 
     * @param string $email
     * @return void
     */
    private function addToEmailIndex(string $email): void
    {
        $emails = $this->storageAdapter->get(self::INDEX_EMAILS, []);
        if (!is_array($emails)) {
            $emails = [];
        }

        $normalizedEmail = strtolower($email);
        if (!in_array($normalizedEmail, $emails, true)) {
            $emails[] = $normalizedEmail;
            $this->storageAdapter->set(self::INDEX_EMAILS, $emails);
        }
    }

    /**
     * Remove email from index
     * 
     * @param string $email
     * @return void
     */
    private function removeFromEmailIndex(string $email): void
    {
        $emails = $this->storageAdapter->get(self::INDEX_EMAILS, []);
        if (!is_array($emails)) {
            return;
        }

        $normalizedEmail = strtolower($email);
        $emails = array_values(array_filter($emails, fn($e) => $e !== $normalizedEmail));
        $this->storageAdapter->set(self::INDEX_EMAILS, $emails);
    }
}
