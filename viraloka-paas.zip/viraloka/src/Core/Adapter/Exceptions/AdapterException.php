<?php

namespace Viraloka\Core\Adapter\Exceptions;

/**
 * Base exception for all adapter-related errors.
 */
class AdapterException extends \RuntimeException
{
}
