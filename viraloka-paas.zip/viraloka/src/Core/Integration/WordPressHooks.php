<?php

namespace Viraloka\Core\Integration;

use Viraloka\Core\Application;
use Viraloka\Core\Identity\Contracts\IdentityEngineContract;
use Viraloka\Core\Usage\Contracts\UsageEngineContract;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;

/**
 * WordPressHooks
 * 
 * Integrates core engines with WordPress hooks and actions.
 * Provides seamless integration between WordPress events and SaaS platform functionality.
 * 
 * Refactored to use adapters for host environment isolation.
 */
class WordPressHooks
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Adapter registry for accessing host adapters
     * 
     * @var AdapterRegistryInterface
     */
    protected AdapterRegistryInterface $adapters;
    
    /**
     * Event adapter for hook registration
     * 
     * @var EventAdapterInterface
     */
    protected EventAdapterInterface $eventAdapter;
    
    /**
     * Auth adapter for user operations
     * 
     * @var AuthAdapterInterface
     */
    protected AuthAdapterInterface $authAdapter;
    
    /**
     * Storage adapter for cache operations
     * 
     * @var StorageAdapterInterface
     */
    protected StorageAdapterInterface $storageAdapter;
    
    /**
     * Indicates if hooks have been registered
     * 
     * @var bool
     */
    protected bool $registered = false;
    
    /**
     * Create a new WordPressHooks instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
        $this->logger = $app->make(Logger::class);
        $this->adapters = $app->make(AdapterRegistryInterface::class);
        $this->eventAdapter = $this->adapters->event();
        $this->authAdapter = $this->adapters->auth();
        $this->storageAdapter = $this->adapters->storage();
    }
    
    /**
     * Register all WordPress hooks
     * 
     * @return void
     */
    public function register(): void
    {
        if ($this->registered) {
            return;
        }
        
        // Register IdentityEngine hooks
        $this->registerIdentityHooks();
        
        // Register UsageEngine hooks
        $this->registerUsageHooks();
        
        $this->registered = true;
        
        // WordPress hooks registered successfully (info logging disabled for production)
    }
    
    /**
     * Register IdentityEngine hooks
     * 
     * Integrates IdentityEngine with WordPress authentication system.
     * Uses EventAdapter for hook registration and StorageAdapter for caching.
     * 
     * @return void
     */
    protected function registerIdentityHooks(): void
    {
        // Hook into wp_login to resolve workspace membership on authentication
        $this->eventAdapter->listen('wp_login', function ($user_login, $user) {
            try {
                if (!$this->app->bound(IdentityEngineContract::class)) {
                    return;
                }
                
                $identityEngine = $this->app->make(IdentityEngineContract::class);
                $userId = (string) $user->ID;
                
                // Resolve workspace membership
                $workspaces = $identityEngine->resolveWorkspaceMembership($userId);
                
                // Store workspace membership in cache for quick access using StorageAdapter
                $cacheKey = 'user_workspaces_' . $userId;
                $this->storageAdapter->set($cacheKey, $workspaces, 3600);
                
                $this->logger->info(
                    sprintf('Workspace membership resolved for user %s on login', $userId),
                    'wordpress-hooks'
                );
                
                // Fire action for extensions using EventAdapter
                $event = new class($userId, $workspaces) {
                    public function __construct(
                        public readonly string $userId,
                        public readonly array $workspaces
                    ) {}
                };
                $this->eventAdapter->dispatch($event);
            } catch (\Throwable $e) {
                $this->logger->error(
                    sprintf('Failed to resolve workspace membership on login: %s', $e->getMessage()),
                    'wordpress-hooks',
                    'Identity Hook Error'
                );
            }
        }, 10);
        
        // Hook into user_register to add new users to default workspace
        $this->eventAdapter->listen('user_register', function ($user_id) {
            try {
                if (!$this->app->bound(IdentityEngineContract::class)) {
                    return;
                }
                
                $identityEngine = $this->app->make(IdentityEngineContract::class);
                $userId = (string) $user_id;
                
                // Add user to default workspace
                $identityEngine->addUserToWorkspace($userId, 'default');
                
                $this->logger->info(
                    sprintf('New user %s added to default workspace', $userId),
                    'wordpress-hooks'
                );
                
                // Fire action for extensions using EventAdapter
                $event = new class($userId) {
                    public function __construct(
                        public readonly string $userId
                    ) {}
                };
                $this->eventAdapter->dispatch($event);
            } catch (\Throwable $e) {
                $this->logger->error(
                    sprintf('Failed to add new user to workspace: %s', $e->getMessage()),
                    'wordpress-hooks',
                    'Identity Hook Error'
                );
            }
        }, 10);
        
        // Hook into wp_logout to clear workspace cache
        $this->eventAdapter->listen('wp_logout', function ($user_id) {
            try {
                $userId = (string) $user_id;
                
                // Clear workspace cache using StorageAdapter
                $cacheKey = 'user_workspaces_' . $userId;
                $this->storageAdapter->delete($cacheKey);
                
                $this->logger->info(
                    sprintf('Workspace cache cleared for user %s on logout', $userId),
                    'wordpress-hooks'
                );
                
                // Fire action for extensions using EventAdapter
                $event = new class($userId) {
                    public function __construct(
                        public readonly string $userId
                    ) {}
                };
                $this->eventAdapter->dispatch($event);
            } catch (\Throwable $e) {
                $this->logger->error(
                    sprintf('Failed to clear workspace cache on logout: %s', $e->getMessage()),
                    'wordpress-hooks',
                    'Identity Hook Error'
                );
            }
        }, 10);
    }
    
    /**
     * Register UsageEngine hooks
     * 
     * Integrates UsageEngine with relevant WordPress actions for automatic usage tracking.
     * Uses EventAdapter for hook registration and AuthAdapter for user operations.
     * 
     * @return void
     */
    protected function registerUsageHooks(): void
    {
        // Hook into REST API requests to track API usage
        $this->eventAdapter->listen('rest_api_init', function () {
            $this->eventAdapter->listen('rest_pre_dispatch', function ($result, $server, $request) {
                try {
                    // Only track authenticated requests using AuthAdapter
                    if (!$this->authAdapter->isAuthenticated()) {
                        return $result;
                    }
                    
                    if (!$this->app->bound(UsageEngineContract::class)) {
                        return $result;
                    }
                    
                    $usageEngine = $this->app->make(UsageEngineContract::class);
                    
                    // Get current user using AuthAdapter
                    $user = $this->authAdapter->currentUser();
                    if ($user === null) {
                        return $result;
                    }
                    
                    $userId = $user->id;
                    
                    // Get workspace from container
                    if ($this->app->bound(\Viraloka\Core\Workspace\Workspace::class)) {
                        $workspace = $this->app->make(\Viraloka\Core\Workspace\Workspace::class);
                        
                        // Record API call usage
                        $usageEngine->recordUsage(
                            $userId,
                            'api_calls',
                            1,
                            $workspace,
                            [
                                'route' => $request->get_route(),
                                'method' => $request->get_method(),
                                'timestamp' => time(),
                            ]
                        );
                    }
                } catch (\Throwable $e) {
                    $this->logger->error(
                        sprintf('Failed to record API usage: %s', $e->getMessage()),
                        'wordpress-hooks',
                        'Usage Hook Error'
                    );
                }
                
                return $result;
            }, 10);
        });
        
        // Hook into post publish to track content creation usage
        $this->eventAdapter->listen('publish_post', function ($post_id, $post) {
            try {
                if (!$this->app->bound(UsageEngineContract::class)) {
                    return;
                }
                
                $usageEngine = $this->app->make(UsageEngineContract::class);
                $userId = (string) $post->post_author;
                
                // Get workspace from container
                if ($this->app->bound(\Viraloka\Core\Workspace\Workspace::class)) {
                    $workspace = $this->app->make(\Viraloka\Core\Workspace\Workspace::class);
                    
                    // Record content creation usage
                    $usageEngine->recordUsage(
                        $userId,
                        'content_items',
                        1,
                        $workspace,
                        [
                            'post_id' => $post_id,
                            'post_type' => $post->post_type,
                            'timestamp' => time(),
                        ]
                    );
                }
            } catch (\Throwable $e) {
                $this->logger->error(
                    sprintf('Failed to record content creation usage: %s', $e->getMessage()),
                    'wordpress-hooks',
                    'Usage Hook Error'
                );
            }
        }, 10);
        
        // Hook into media upload to track storage usage
        $this->eventAdapter->listen('add_attachment', function ($attachment_id) {
            try {
                if (!$this->app->bound(UsageEngineContract::class)) {
                    return;
                }
                
                $usageEngine = $this->app->make(UsageEngineContract::class);
                $attachment = get_post($attachment_id);
                $userId = (string) $attachment->post_author;
                
                // Get file size
                $file_path = get_attached_file($attachment_id);
                $file_size = file_exists($file_path) ? filesize($file_path) : 0;
                
                // Convert to MB
                $size_mb = ceil($file_size / (1024 * 1024));
                
                // Get workspace from container
                if ($this->app->bound(\Viraloka\Core\Workspace\Workspace::class)) {
                    $workspace = $this->app->make(\Viraloka\Core\Workspace\Workspace::class);
                    
                    // Record storage usage
                    $usageEngine->recordUsage(
                        $userId,
                        'storage_mb',
                        $size_mb,
                        $workspace,
                        [
                            'attachment_id' => $attachment_id,
                            'file_size' => $file_size,
                            'mime_type' => get_post_mime_type($attachment_id),
                            'timestamp' => time(),
                        ]
                    );
                }
            } catch (\Throwable $e) {
                $this->logger->error(
                    sprintf('Failed to record storage usage: %s', $e->getMessage()),
                    'wordpress-hooks',
                    'Usage Hook Error'
                );
            }
        }, 10);
        
        // Allow modules to register custom usage tracking hooks using EventAdapter
        $event = new class($this) {
            public function __construct(
                public readonly WordPressHooks $hooks
            ) {}
        };
        $this->eventAdapter->dispatch($event);
    }
    
    /**
     * Check if hooks have been registered
     * 
     * @return bool
     */
    public function isRegistered(): bool
    {
        return $this->registered;
    }
}

