<?php

namespace Viraloka\Core\Workspace\Repositories;

use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Workspace\Exceptions\WorkspaceNotFoundException;
use Viraloka\Core\Workspace\Exceptions\DuplicateSlugException;
use Viraloka\Core\Workspace\Exceptions\DuplicateDomainException;

/**
 * Workspace Repository
 * 
 * Implements data access operations for workspace entities.
 * Uses WordPress wpdb for database operations and UUID for primary keys.
 * Enforces slug and domain uniqueness constraints.
 */
class WorkspaceRepository implements WorkspaceRepositoryInterface
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_workspaces';
    }
    
    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * Create a new workspace
     * 
     * @param string $tenantId The tenant UUID that owns this workspace
     * @param string $name The workspace name
     * @param string $slug The unique workspace slug
     * @param string $context The active context for this workspace (default: 'default')
     * @return Workspace The created workspace with generated UUID
     * @throws DuplicateSlugException If slug already exists
     */
    public function create(string $tenantId, string $name, string $slug, string $context = 'default'): Workspace
    {
        // Check slug uniqueness
        if ($this->slugExists($slug)) {
            throw new DuplicateSlugException("Workspace slug '{$slug}' already exists");
        }
        
        $workspaceId = $this->generateUuid();
        $createdAt = new \DateTimeImmutable();
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'workspace_id' => $workspaceId,
                'tenant_id' => $tenantId,
                'name' => $name,
                'slug' => $slug,
                'status' => Workspace::STATUS_ACTIVE,
                'active_context' => $context,
                'is_default' => 0,
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create workspace: ' . $this->wpdb->last_error);
        }
        
        return new Workspace(
            $workspaceId,
            $tenantId,
            $name,
            $slug,
            Workspace::STATUS_ACTIVE,
            $context,
            $createdAt
        );
    }
    
    /**
     * Find a workspace by its UUID
     * 
     * @param string $workspaceId The workspace UUID
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findById(string $workspaceId): ?Workspace
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s",
                $workspaceId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find a workspace by its slug
     * 
     * @param string $slug The workspace slug
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findBySlug(string $slug): ?Workspace
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE slug = %s",
                $slug
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find a workspace by its custom domain
     * 
     * @param string $domain The custom domain (e.g., 'app.client.com')
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findByDomain(string $domain): ?Workspace
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE custom_domain = %s",
                $domain
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find a workspace by its subdomain
     * 
     * @param string $subdomain The subdomain (e.g., 'workspace' from 'workspace.viraloka.app')
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findBySubdomain(string $subdomain): ?Workspace
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE subdomain = %s",
                $subdomain
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find all workspaces belonging to a tenant
     * 
     * @param string $tenantId The tenant UUID
     * @return Workspace[] Array of workspaces owned by the tenant
     */
    public function findByTenant(string $tenantId): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE tenant_id = %s ORDER BY created_at DESC",
                $tenantId
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Update an existing workspace
     * 
     * @param Workspace $workspace The workspace entity with updated values
     * @return bool True if update was successful, false otherwise
     * @throws DuplicateSlugException If slug already exists for another workspace
     * @throws DuplicateDomainException If custom domain already exists for another workspace
     */
    public function update(Workspace $workspace): bool
    {
        // Check slug uniqueness (excluding current workspace)
        $existingSlug = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT workspace_id FROM {$this->tableName} WHERE slug = %s AND workspace_id != %s",
                $workspace->slug,
                $workspace->workspaceId
            )
        );
        
        if ($existingSlug !== null) {
            throw new DuplicateSlugException("Workspace slug '{$workspace->slug}' already exists");
        }
        
        // Check custom domain uniqueness (excluding current workspace)
        if ($workspace->customDomain !== null) {
            $existingDomain = $this->wpdb->get_var(
                $this->wpdb->prepare(
                    "SELECT workspace_id FROM {$this->tableName} WHERE custom_domain = %s AND workspace_id != %s",
                    $workspace->customDomain,
                    $workspace->workspaceId
                )
            );
            
            if ($existingDomain !== null) {
                throw new DuplicateDomainException("Custom domain '{$workspace->customDomain}' already exists");
            }
        }
        
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'name' => $workspace->name,
                'slug' => $workspace->slug,
                'status' => $workspace->status,
                'active_context' => $workspace->activeContext,
                'custom_domain' => $workspace->customDomain,
                'subdomain' => $workspace->subdomain,
                'is_default' => $workspace->isDefault ? 1 : 0,
                'updated_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['workspace_id' => $workspace->workspaceId],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Delete a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @return bool True if deletion was successful, false otherwise
     */
    public function delete(string $workspaceId): bool
    {
        $result = $this->wpdb->delete(
            $this->tableName,
            ['workspace_id' => $workspaceId],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Get the default workspace
     * 
     * @return Workspace|null The default workspace if exists, null otherwise
     */
    public function getDefault(): ?Workspace
    {
        $row = $this->wpdb->get_row(
            "SELECT * FROM {$this->tableName} WHERE is_default = 1 LIMIT 1",
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Check if a slug already exists
     * 
     * @param string $slug The slug to check
     * @return bool True if slug exists, false otherwise
     */
    public function slugExists(string $slug): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tableName} WHERE slug = %s",
                $slug
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Check if a custom domain already exists
     * 
     * @param string $domain The domain to check
     * @return bool True if domain exists, false otherwise
     */
    public function domainExists(string $domain): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tableName} WHERE custom_domain = %s",
                $domain
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Convert database row to Workspace entity
     * 
     * @param array $row Database row
     * @return Workspace
     */
    private function rowToEntity(array $row): Workspace
    {
        $workspace = new Workspace(
            $row['workspace_id'],
            $row['tenant_id'],
            $row['name'],
            $row['slug'],
            $row['status'],
            $row['active_context'],
            new \DateTimeImmutable($row['created_at'])
        );
        
        $workspace->customDomain = $row['custom_domain'];
        $workspace->subdomain = $row['subdomain'];
        $workspace->isDefault = (bool) $row['is_default'];
        
        return $workspace;
    }
}
