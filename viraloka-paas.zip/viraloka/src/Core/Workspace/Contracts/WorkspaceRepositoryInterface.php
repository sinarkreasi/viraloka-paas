<?php

namespace Viraloka\Core\Workspace\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Workspace Repository Contract
 * 
 * Defines the interface for workspace data access operations.
 * Implementations must handle UUID generation, CRUD operations,
 * domain/slug uniqueness validation, and workspace lookup by various methods.
 * 
 * @package Viraloka\Core\Workspace\Contracts
 */
interface WorkspaceRepositoryInterface
{
    /**
     * Create a new workspace
     * 
     * @param string $tenantId The tenant UUID that owns this workspace
     * @param string $name The workspace name
     * @param string $slug The unique workspace slug
     * @param string $context The active context for this workspace (default: 'default')
     * @return Workspace The created workspace with generated UUID
     */
    public function create(string $tenantId, string $name, string $slug, string $context = 'default'): Workspace;
    
    /**
     * Find a workspace by its UUID
     * 
     * @param string $workspaceId The workspace UUID
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findById(string $workspaceId): ?Workspace;
    
    /**
     * Find a workspace by its slug
     * 
     * @param string $slug The workspace slug
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findBySlug(string $slug): ?Workspace;
    
    /**
     * Find a workspace by its custom domain
     * 
     * @param string $domain The custom domain (e.g., 'app.client.com')
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findByDomain(string $domain): ?Workspace;
    
    /**
     * Find a workspace by its subdomain
     * 
     * @param string $subdomain The subdomain (e.g., 'workspace' from 'workspace.viraloka.app')
     * @return Workspace|null The workspace if found, null otherwise
     */
    public function findBySubdomain(string $subdomain): ?Workspace;
    
    /**
     * Find all workspaces belonging to a tenant
     * 
     * @param string $tenantId The tenant UUID
     * @return Workspace[] Array of workspaces owned by the tenant
     */
    public function findByTenant(string $tenantId): array;
    
    /**
     * Update an existing workspace
     * 
     * @param Workspace $workspace The workspace entity with updated values
     * @return bool True if update was successful, false otherwise
     */
    public function update(Workspace $workspace): bool;
    
    /**
     * Delete a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @return bool True if deletion was successful, false otherwise
     */
    public function delete(string $workspaceId): bool;
    
    /**
     * Get the default workspace
     * 
     * @return Workspace|null The default workspace if exists, null otherwise
     */
    public function getDefault(): ?Workspace;
    
    /**
     * Check if a slug already exists
     * 
     * @param string $slug The slug to check
     * @return bool True if slug exists, false otherwise
     */
    public function slugExists(string $slug): bool;
    
    /**
     * Check if a custom domain already exists
     * 
     * @param string $domain The domain to check
     * @return bool True if domain exists, false otherwise
     */
    public function domainExists(string $domain): bool;
}
