<?php

namespace Viraloka\Core\Workspace\Contracts;

/**
 * Permission Boundary Contract
 * 
 * Enforces workspace-level permission checks and role-based access control.
 * Prevents cross-workspace data access and ensures proper isolation.
 */
interface PermissionBoundaryInterface
{
    /**
     * Check if user has access to workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @return bool True if user has access, false otherwise
     */
    public function canAccess(int $userId, string $workspaceId): bool;
    
    /**
     * Check if user has specific role in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @param string $role The role to check (owner, admin, member, viewer)
     * @return bool True if user has the specified role, false otherwise
     */
    public function hasRole(int $userId, string $workspaceId, string $role): bool;
    
    /**
     * Check if user can perform action in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @param string $action The action to check (e.g., 'edit', 'delete', 'manage')
     * @return bool True if user can perform the action, false otherwise
     */
    public function canPerform(int $userId, string $workspaceId, string $action): bool;
    
    /**
     * Get user's role in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @return string|null The user's role if found, null otherwise
     */
    public function getUserRole(int $userId, string $workspaceId): ?string;
    
    /**
     * Validate workspace context for data access
     * 
     * Ensures that the current operation is within the correct workspace context.
     * 
     * @param string $workspaceId The workspace UUID to validate
     * @return bool True if workspace context is valid, false otherwise
     */
    public function validateWorkspaceContext(string $workspaceId): bool;
}
