<?php

namespace Viraloka\Core\Workspace;

use Viraloka\Core\Application;
use Viraloka\Core\Adapter\Contracts\RequestAdapterInterface;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use Viraloka\Container\Contracts\WorkspaceResolverInterface;

/**
 * Workspace Resolver
 * 
 * Determines the active tenant workspace based on domain, subdomain, or path.
 * Implements a fallback strategy to ensure a workspace is always resolved.
 * Uses RequestAdapter for host-agnostic request data access.
 */
class WorkspaceResolver implements WorkspaceResolverInterface
{
    protected Application $app;
    protected array $workspaceConfig = [];
    protected RequestAdapterInterface $requestAdapter;

    public function __construct(Application $app)
    {
        $this->app = $app;
        
        // Get RequestAdapter from registry
        $registry = $app->make(AdapterRegistryInterface::class);
        $this->requestAdapter = $registry->request();
        
        $this->loadWorkspaceConfig();
    }

    /**
     * Resolve the active workspace using multiple strategies
     */
    public function resolve(): Workspace
    {
        // Try domain-based resolution first
        $workspace = $this->resolveByDomain();
        if ($workspace !== null) {
            return $workspace;
        }

        // Try subdomain-based resolution
        $workspace = $this->resolveBySubdomain();
        if ($workspace !== null) {
            return $workspace;
        }

        // Try path-based resolution
        $workspace = $this->resolveByPath();
        if ($workspace !== null) {
            return $workspace;
        }

        // Fallback to default workspace
        return $this->getDefaultWorkspace();
    }

    /**
     * Resolve workspace by full domain match
     */
    protected function resolveByDomain(): ?Workspace
    {
        $domain = $this->getCurrentDomain();
        
        if (empty($domain)) {
            return null;
        }

        foreach ($this->workspaceConfig as $config) {
            if (isset($config['domain']) && $config['domain'] === $domain) {
                return $this->createWorkspaceFromConfig($config);
            }
        }

        return null;
    }

    /**
     * Resolve workspace by subdomain extraction
     */
    protected function resolveBySubdomain(): ?Workspace
    {
        $domain = $this->getCurrentDomain();
        
        if (empty($domain)) {
            return null;
        }

        // Extract subdomain (e.g., "tenant" from "tenant.example.com")
        $parts = explode('.', $domain);
        
        if (count($parts) < 3) {
            return null; // No subdomain present
        }

        $subdomain = $parts[0];

        foreach ($this->workspaceConfig as $config) {
            if (isset($config['subdomain']) && $config['subdomain'] === $subdomain) {
                return $this->createWorkspaceFromConfig($config);
            }
        }

        return null;
    }

    /**
     * Resolve workspace by URL path
     */
    protected function resolveByPath(): ?Workspace
    {
        $path = $this->getCurrentPath();
        
        if (empty($path)) {
            return null;
        }

        // Extract first path segment (e.g., "tenant" from "/tenant/page")
        $segments = explode('/', trim($path, '/'));
        
        if (empty($segments[0])) {
            return null;
        }

        $pathSegment = $segments[0];

        foreach ($this->workspaceConfig as $config) {
            if (isset($config['path']) && $config['path'] === $pathSegment) {
                return $this->createWorkspaceFromConfig($config);
            }
        }

        return null;
    }

    /**
     * Get the default workspace
     */
    protected function getDefaultWorkspace(): Workspace
    {
        // Check if default workspace is configured
        foreach ($this->workspaceConfig as $config) {
            if (isset($config['is_default']) && $config['is_default'] === true) {
                return $this->createWorkspaceFromConfig($config);
            }
        }

        // Return hardcoded default if no configured default exists
        return new Workspace(
            workspaceId: 'default',
            tenantId: 'system',
            name: 'Default Workspace',
            slug: 'default',
            status: Workspace::STATUS_ACTIVE,
            activeContext: 'default'
        );
    }

    /**
     * Get the current domain from the request
     */
    protected function getCurrentDomain(): string
    {
        // Use RequestAdapter to get Host header
        $host = $this->requestAdapter->getHeader('Host');
        
        if ($host) {
            return strtolower($host);
        }

        return '';
    }

    /**
     * Get the current path from the request
     */
    protected function getCurrentPath(): string
    {
        // Use RequestAdapter to get path
        return $this->requestAdapter->getPath();
    }

    /**
     * Load workspace configuration
     */
    protected function loadWorkspaceConfig(): void
    {
        // In a real implementation, this would load from a config file or database
        // For now, we'll use an empty array and allow it to be set via setWorkspaceConfig
        $this->workspaceConfig = [];
    }

    /**
     * Set workspace configuration (for testing and runtime configuration)
     */
    public function setWorkspaceConfig(array $config): void
    {
        $this->workspaceConfig = $config;
    }

    /**
     * Create a Workspace instance from configuration array
     */
    protected function createWorkspaceFromConfig(array $config): Workspace
    {
        return new Workspace(
            workspaceId: $config['id'] ?? 'unknown',
            tenantId: $config['tenant_id'] ?? 'default-tenant',
            name: $config['name'] ?? 'Unknown Workspace',
            slug: $config['slug'] ?? 'unknown',
            status: $config['status'] ?? Workspace::STATUS_ACTIVE,
            activeContext: $config['context'] ?? 'default'
        );
    }
}
