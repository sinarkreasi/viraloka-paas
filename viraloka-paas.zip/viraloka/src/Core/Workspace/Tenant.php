<?php

namespace Viraloka\Core\Workspace;

/**
 * Tenant Entity
 * 
 * Represents an ownership entity in the multi-tenant system.
 * A tenant can be an individual, team, company, or organization.
 */
class Tenant
{
    public readonly string $tenantId;
    public string $name;
    public readonly int $ownerUserId;
    public string $status;
    public readonly \DateTimeImmutable $createdAt;
    
    public const STATUS_ACTIVE = 'active';
    public const STATUS_SUSPENDED = 'suspended';
    
    public function __construct(
        string $tenantId,
        string $name,
        int $ownerUserId,
        string $status = self::STATUS_ACTIVE,
        ?\DateTimeImmutable $createdAt = null
    ) {
        $this->tenantId = $tenantId;
        $this->name = $name;
        $this->ownerUserId = $ownerUserId;
        $this->status = $status;
        $this->createdAt = $createdAt ?? new \DateTimeImmutable();
    }
    
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }
    
    public function suspend(): void
    {
        $this->status = self::STATUS_SUSPENDED;
    }
    
    public function activate(): void
    {
        $this->status = self::STATUS_ACTIVE;
    }
}
