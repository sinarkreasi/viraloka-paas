<?php

namespace Viraloka\Core\Workspace;

use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Modules\Logger;

/**
 * WorkspaceHooks
 * 
 * Provides extensible hook points for workspace-related resource limits,
 * feature limits, and billing integration. This class does NOT implement
 * the actual business logic - it provides extension points for external
 * handlers to implement these features.
 * 
 * Hook Points:
 * - viraloka_workspace_check_usage_limit: Check if workspace has exceeded usage limits
 * - viraloka_workspace_check_feature_limit: Check if workspace has access to a feature
 * - viraloka_workspace_record_usage: Record usage for billing/metering
 * - viraloka_workspace_billing_event: Notify billing system of workspace events
 */
class WorkspaceHooks
{
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Indicates if hooks have been registered
     * 
     * @var bool
     */
    protected bool $registered = false;
    
    /**
     * Registered hook handlers
     * 
     * @var array<string, array<callable>>
     */
    protected array $handlers = [];
    
    /**
     * Create a new WorkspaceHooks instance
     * 
     * @param Logger|null $logger
     */
    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Register all workspace hooks
     * 
     * This method sets up the hook points but does not implement any logic.
     * External modules can attach handlers to these hooks.
     * 
     * @return void
     */
    public function register(): void
    {
        if ($this->registered) {
            return;
        }
        
        // Initialize hook handler arrays
        $this->handlers['usage_limit'] = [];
        $this->handlers['feature_limit'] = [];
        $this->handlers['record_usage'] = [];
        $this->handlers['billing_event'] = [];
        
        $this->registered = true;
        
        $this->logger->info(
            'Workspace hooks registered successfully',
            'workspace-hooks'
        );
    }
    
    /**
     * Register a usage limit handler
     * 
     * Handler signature: function(Workspace $workspace, string $resourceType, float $currentUsage): bool
     * Should return true if limit is exceeded, false otherwise
     * 
     * @param callable $handler
     * @return void
     */
    public function onUsageLimitCheck(callable $handler): void
    {
        $this->handlers['usage_limit'][] = $handler;
    }
    
    /**
     * Register a feature limit handler
     * 
     * Handler signature: function(Workspace $workspace, string $featureName): bool
     * Should return true if feature is available, false otherwise
     * 
     * @param callable $handler
     * @return void
     */
    public function onFeatureLimitCheck(callable $handler): void
    {
        $this->handlers['feature_limit'][] = $handler;
    }
    
    /**
     * Register a usage recording handler
     * 
     * Handler signature: function(Workspace $workspace, string $resourceType, float $amount, array $metadata): void
     * 
     * @param callable $handler
     * @return void
     */
    public function onRecordUsage(callable $handler): void
    {
        $this->handlers['record_usage'][] = $handler;
    }
    
    /**
     * Register a billing event handler
     * 
     * Handler signature: function(Workspace $workspace, string $eventType, array $eventData): void
     * 
     * @param callable $handler
     * @return void
     */
    public function onBillingEvent(callable $handler): void
    {
        $this->handlers['billing_event'][] = $handler;
    }
    
    /**
     * Check if workspace has exceeded usage limit for a resource
     * 
     * @param Workspace $workspace
     * @param string $resourceType (e.g., 'api_calls', 'storage_mb', 'users')
     * @param float $currentUsage
     * @return bool True if limit is exceeded, false otherwise
     */
    public function checkUsageLimit(Workspace $workspace, string $resourceType, float $currentUsage): bool
    {
        if (!$this->registered) {
            $this->register();
        }
        
        // If no handlers registered, allow unlimited usage (default behavior)
        if (empty($this->handlers['usage_limit'])) {
            return false;
        }
        
        try {
            // Execute all registered handlers
            foreach ($this->handlers['usage_limit'] as $handler) {
                $result = $handler($workspace, $resourceType, $currentUsage);
                
                // If any handler returns true, limit is exceeded
                if ($result === true) {
                    $this->logger->warning(
                        sprintf(
                            'Usage limit exceeded for workspace %s: %s = %.2f',
                            $workspace->workspaceId,
                            $resourceType,
                            $currentUsage
                        ),
                        'workspace-hooks'
                    );
                    return true;
                }
            }
            
            return false;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Error checking usage limit: %s', $e->getMessage()),
                'workspace-hooks',
                'Usage Limit Check Error'
            );
            
            // On error, allow the operation (fail open)
            return false;
        }
    }
    
    /**
     * Check if workspace has access to a feature
     * 
     * @param Workspace $workspace
     * @param string $featureName (e.g., 'custom_domain', 'api_access', 'advanced_analytics')
     * @return bool True if feature is available, false otherwise
     */
    public function checkFeatureLimit(Workspace $workspace, string $featureName): bool
    {
        if (!$this->registered) {
            $this->register();
        }
        
        // If no handlers registered, allow all features (default behavior)
        if (empty($this->handlers['feature_limit'])) {
            return true;
        }
        
        try {
            // Execute all registered handlers
            foreach ($this->handlers['feature_limit'] as $handler) {
                $result = $handler($workspace, $featureName);
                
                // If any handler returns false, feature is not available
                if ($result === false) {
                    $this->logger->info(
                        sprintf(
                            'Feature not available for workspace %s: %s',
                            $workspace->workspaceId,
                            $featureName
                        ),
                        'workspace-hooks'
                    );
                    return false;
                }
            }
            
            return true;
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Error checking feature limit: %s', $e->getMessage()),
                'workspace-hooks',
                'Feature Limit Check Error'
            );
            
            // On error, allow the feature (fail open)
            return true;
        }
    }
    
    /**
     * Record usage for billing/metering purposes
     * 
     * @param Workspace $workspace
     * @param string $resourceType (e.g., 'api_calls', 'storage_mb', 'users')
     * @param float $amount
     * @param array<string, mixed> $metadata Additional context about the usage
     * @return void
     */
    public function recordUsage(Workspace $workspace, string $resourceType, float $amount, array $metadata = []): void
    {
        if (!$this->registered) {
            $this->register();
        }
        
        // If no handlers registered, just log
        if (empty($this->handlers['record_usage'])) {
            $this->logger->debug(
                sprintf(
                    'Usage recorded for workspace %s: %s = %.2f (no handlers)',
                    $workspace->workspaceId,
                    $resourceType,
                    $amount
                ),
                'workspace-hooks'
            );
            return;
        }
        
        try {
            // Add workspace context to metadata
            $enrichedMetadata = array_merge($metadata, [
                'workspace_id' => $workspace->workspaceId,
                'tenant_id' => $workspace->tenantId,
                'workspace_name' => $workspace->name,
                'timestamp' => time(),
            ]);
            
            // Execute all registered handlers
            foreach ($this->handlers['record_usage'] as $handler) {
                $handler($workspace, $resourceType, $amount, $enrichedMetadata);
            }
            
            $this->logger->debug(
                sprintf(
                    'Usage recorded for workspace %s: %s = %.2f',
                    $workspace->workspaceId,
                    $resourceType,
                    $amount
                ),
                'workspace-hooks'
            );
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Error recording usage: %s', $e->getMessage()),
                'workspace-hooks',
                'Usage Recording Error'
            );
        }
    }
    
    /**
     * Trigger a billing event
     * 
     * @param Workspace $workspace
     * @param string $eventType (e.g., 'workspace_created', 'workspace_suspended', 'plan_upgraded')
     * @param array<string, mixed> $eventData Additional event data
     * @return void
     */
    public function triggerBillingEvent(Workspace $workspace, string $eventType, array $eventData = []): void
    {
        if (!$this->registered) {
            $this->register();
        }
        
        // If no handlers registered, just log
        if (empty($this->handlers['billing_event'])) {
            $this->logger->debug(
                sprintf(
                    'Billing event triggered for workspace %s: %s (no handlers)',
                    $workspace->workspaceId,
                    $eventType
                ),
                'workspace-hooks'
            );
            return;
        }
        
        try {
            // Add workspace context to event data
            $enrichedEventData = array_merge($eventData, [
                'workspace_id' => $workspace->workspaceId,
                'tenant_id' => $workspace->tenantId,
                'workspace_name' => $workspace->name,
                'workspace_status' => $workspace->status,
                'timestamp' => time(),
            ]);
            
            // Execute all registered handlers
            foreach ($this->handlers['billing_event'] as $handler) {
                $handler($workspace, $eventType, $enrichedEventData);
            }
            
            $this->logger->info(
                sprintf(
                    'Billing event triggered for workspace %s: %s',
                    $workspace->workspaceId,
                    $eventType
                ),
                'workspace-hooks'
            );
        } catch (\Throwable $e) {
            $this->logger->error(
                sprintf('Error triggering billing event: %s', $e->getMessage()),
                'workspace-hooks',
                'Billing Event Error'
            );
        }
    }
    
    /**
     * Check if hooks have been registered
     * 
     * @return bool
     */
    public function isRegistered(): bool
    {
        return $this->registered;
    }
    
    /**
     * Get the number of registered handlers for a hook type
     * 
     * @param string $hookType ('usage_limit', 'feature_limit', 'record_usage', 'billing_event')
     * @return int
     */
    public function getHandlerCount(string $hookType): int
    {
        return count($this->handlers[$hookType] ?? []);
    }
    
    /**
     * Clear all registered handlers (useful for testing)
     * 
     * @return void
     */
    public function clearHandlers(): void
    {
        $this->handlers = [
            'usage_limit' => [],
            'feature_limit' => [],
            'record_usage' => [],
            'billing_event' => [],
        ];
    }
}
