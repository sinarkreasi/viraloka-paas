<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Base exception for all workspace-related errors
 */
class WorkspaceException extends \Exception
{
}
