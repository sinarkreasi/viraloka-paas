<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when permission is denied for a workspace operation
 */
class PermissionDeniedException extends WorkspaceException
{
}
