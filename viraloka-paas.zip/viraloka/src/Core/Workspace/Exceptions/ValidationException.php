<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when validation fails for workspace-related data
 */
class ValidationException extends WorkspaceException
{
}
