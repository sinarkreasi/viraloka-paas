<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when attempting to assign a duplicate custom domain
 */
class DuplicateDomainException extends WorkspaceException
{
}
