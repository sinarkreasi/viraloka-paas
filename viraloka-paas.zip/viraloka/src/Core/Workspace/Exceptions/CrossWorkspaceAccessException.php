<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when cross-workspace access is attempted
 */
class CrossWorkspaceAccessException extends PermissionDeniedException
{
}
