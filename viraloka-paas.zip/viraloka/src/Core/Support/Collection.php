<?php

namespace Illuminate\Support;

/**
 * Collection
 * 
 * Simple collection implementation for managing arrays of items.
 * This is a minimal implementation - in production, use Laravel's Collection.
 */
class Collection implements \ArrayAccess, \Countable, \IteratorAggregate
{
    /**
     * The items contained in the collection
     * 
     * @var array
     */
    protected array $items;
    
    /**
     * Create a new collection instance
     * 
     * @param array $items
     */
    public function __construct(array $items = [])
    {
        $this->items = $items;
    }
    
    /**
     * Get all items in the collection
     * 
     * @return array
     */
    public function all(): array
    {
        return $this->items;
    }
    
    /**
     * Get the first item from the collection
     * 
     * @return mixed
     */
    public function first()
    {
        return reset($this->items) ?: null;
    }
    
    /**
     * Filter the collection using a callback
     * 
     * @param callable $callback
     * @return static
     */
    public function filter(callable $callback): self
    {
        return new static(array_filter($this->items, $callback, ARRAY_FILTER_USE_BOTH));
    }
    
    /**
     * Map over the collection
     * 
     * @param callable $callback
     * @return static
     */
    public function map(callable $callback): self
    {
        return new static(array_map($callback, $this->items));
    }
    
    /**
     * Check if the collection is empty
     * 
     * @return bool
     */
    public function isEmpty(): bool
    {
        return empty($this->items);
    }
    
    /**
     * Count the items in the collection
     * 
     * @return int
     */
    public function count(): int
    {
        return count($this->items);
    }
    
    /**
     * Get an iterator for the items
     * 
     * @return \ArrayIterator
     */
    public function getIterator(): \ArrayIterator
    {
        return new \ArrayIterator($this->items);
    }
    
    /**
     * Determine if an item exists at an offset
     * 
     * @param mixed $offset
     * @return bool
     */
    public function offsetExists($offset): bool
    {
        return isset($this->items[$offset]);
    }
    
    /**
     * Get an item at a given offset
     * 
     * @param mixed $offset
     * @return mixed
     */
    public function offsetGet($offset): mixed
    {
        return $this->items[$offset] ?? null;
    }
    
    /**
     * Set the item at a given offset
     * 
     * @param mixed $offset
     * @param mixed $value
     * @return void
     */
    public function offsetSet($offset, $value): void
    {
        if (is_null($offset)) {
            $this->items[] = $value;
        } else {
            $this->items[$offset] = $value;
        }
    }
    
    /**
     * Unset the item at a given offset
     * 
     * @param mixed $offset
     * @return void
     */
    public function offsetUnset($offset): void
    {
        unset($this->items[$offset]);
    }
}
