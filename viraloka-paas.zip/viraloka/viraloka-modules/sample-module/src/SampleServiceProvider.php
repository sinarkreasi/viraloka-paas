<?php

namespace Viraloka\Modules\Sample;

use Viraloka\Core\Providers\ServiceProvider;

/**
 * Sample Module Service Provider
 * 
 * Demonstrates the basic structure of a module service provider.
 * This is a minimal example that can be extended with actual functionality.
 */
class SampleServiceProvider extends ServiceProvider
{
    /**
     * Register services
     * 
     * This method is called during the register phase of the bootstrap lifecycle.
     * Use it to bind services into the container.
     * 
     * @return void
     */
    public function register(): void
    {
        // Register any services this module provides
        // Example: $this->app->singleton(SampleService::class, function($app) {
        //     return new SampleService();
        // });
    }
    
    /**
     * Boot services
     * 
     * This method is called during the boot phase of the bootstrap lifecycle.
     * Use it to perform actions that depend on other services being registered.
     * 
     * @return void
     */
    public function boot(): void
    {
        // Perform any bootstrapping actions
        // Example: Register WordPress hooks, load assets, etc.
        
        // Register admin menu if in admin context
        if (is_admin()) {
            add_action('admin_menu', [$this, 'registerAdminMenu']);
        }
    }
    
    /**
     * Register admin menu
     * 
     * @return void
     */
    public function registerAdminMenu(): void
    {
        // This will be handled by the AdminMenuBuilder automatically
        // based on the module manifest, but you can add custom menu items here
    }
}
