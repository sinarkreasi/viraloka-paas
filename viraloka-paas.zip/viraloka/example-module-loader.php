<?php
/**
 * Example: Module Loader Demonstration
 * 
 * This script demonstrates how the ModuleLoader discovers and loads modules.
 * 
 * Usage: php example-module-loader.php
 */

require_once __DIR__ . '/vendor/autoload.php';

use Viraloka\Core\Modules\ModuleLoader;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\DependencyResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Context\ContextResolver;

// Set up the module system
$validator = new SchemaValidator();
$parser = new ManifestParser($validator);
$registry = new ModuleRegistry();
$dependencyResolver = new DependencyResolver($registry);
$contextResolver = new ContextResolver($registry);

// Create the module loader
$modulesPath = __DIR__ . '/viraloka-modules';
$loader = new ModuleLoader(
    $parser,
    $dependencyResolver,
    $registry,
    $contextResolver,
    $modulesPath
);

echo "=== Viraloka Module Loader Demo ===\n\n";
echo "Scanning modules directory: {$modulesPath}\n\n";

// Load all modules
$modules = $loader->loadModules();

echo "Found " . $modules->count() . " valid module(s):\n";
foreach ($modules as $module) {
    echo "  - {$module->manifest->id}: {$module->manifest->name} (v{$module->manifest->version})\n";
    echo "    Author: {$module->manifest->author}\n";
    echo "    Description: {$module->manifest->description}\n";
    
    if ($module->manifest->contexts !== null) {
        echo "    Contexts: " . implode(', ', $module->manifest->contexts->supported) . "\n";
        echo "    Primary Context: {$module->manifest->contexts->primary}\n";
    }
    
    if (!empty($module->manifest->capabilities)) {
        echo "    Capabilities: " . implode(', ', $module->manifest->capabilities) . "\n";
    }
    
    echo "\n";
}

// Check for invalid modules
$invalidModules = $loader->getInvalidModules();
if ($invalidModules->count() > 0) {
    echo "\nFound " . $invalidModules->count() . " invalid module(s):\n";
    foreach ($invalidModules as $invalid) {
        echo "  - Path: {$invalid->path}\n";
        echo "    Error: {$invalid->error}\n";
        if ($invalid->moduleId) {
            echo "    Module ID: {$invalid->moduleId}\n";
        }
        echo "\n";
    }
}

echo "=== Demo Complete ===\n";
