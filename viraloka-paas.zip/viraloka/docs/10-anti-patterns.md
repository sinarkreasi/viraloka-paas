# 10. Anti-Patterns & Common Mistakes

This document outlines common mistakes developers make when building with Viraloka and how to avoid them.

## Putting Logic in Adapter

### The Problem

Adapters should only translate between core contracts and host APIs. Business logic belongs in the core or modules.

### Anti-Pattern Example

```php
// ❌ BAD: Business logic in adapter
class WordPressAuthAdapter implements AuthAdapterInterface
{
    public function currentUser(): ?User
    {
        $wpUser = wp_get_current_user();
        
        // ❌ Business logic in adapter
        if ($wpUser->ID === 0) {
            return null;
        }
        
        // ❌ Business rules in adapter
        if (!$this->hasActiveSubscription($wpUser->ID)) {
            throw new SubscriptionRequiredException();
        }
        
        // ❌ Data transformation logic
        $user = new User($wpUser->ID, $wpUser->user_email);
        $user->setPermissions($this->calculatePermissions($wpUser));
        
        return $user;
    }
    
    // ❌ Business logic method in adapter
    private function hasActiveSubscription(int $userId): bool
    {
        // Complex subscription checking logic
        $subscription = get_user_meta($userId, 'subscription', true);
        return $subscription['status'] === 'active' 
            && strtotime($subscription['expires_at']) > time();
    }
}
```

### Correct Pattern

```php
// ✅ GOOD: Adapter only translates
class WordPressAuthAdapter implements AuthAdapterInterface
{
    public function currentUser(): ?User
    {
        $wpUser = wp_get_current_user();
        
        if ($wpUser->ID === 0) {
            return null;
        }
        
        // Simple mapping only
        return new User(
            id: $wpUser->ID,
            email: $wpUser->user_email,
            name: $wpUser->display_name
        );
    }
}

// ✅ GOOD: Business logic in service
class UserService
{
    public function __construct(
        private AuthAdapterInterface $auth,
        private SubscriptionService $subscriptions
    ) {}
    
    public function getCurrentUser(): ?User
    {
        $user = $this->auth->currentUser();
        
        if (!$user) {
            return null;
        }
        
        // Business logic in service layer
        if (!$this->subscriptions->hasActiveSubscription($user->id)) {
            throw new SubscriptionRequiredException();
        }
        
        return $user;
    }
}
```

### Why It Matters

- **Portability:** Business logic in adapters makes migration harder
- **Testing:** Can't test business logic without WordPress
- **Maintainability:** Logic scattered across adapters and core
- **Reusability:** Can't reuse logic with different adapters

## Tight Coupling Modules

### The Problem

Modules should communicate through events and contracts, not direct dependencies.

### Anti-Pattern Example

```php
// ❌ BAD: Module A directly uses Module B's classes
namespace ProductCatalog\Services;

use ShoppingCart\Services\CartService; // Direct dependency
use ShoppingCart\Models\Cart; // Direct dependency

class ProductService
{
    public function __construct(
        private CartService $cartService // Tight coupling
    ) {}
    
    public function addToCart(int $productId): void
    {
        $product = $this->findProduct($productId);
        
        // ❌ Directly calling another module's service
        $this->cartService->addItem($product);
    }
}
```

**Problems:**
- Product module can't work without Cart module
- Can't swap Cart implementation
- Circular dependency risk
- Hard to test in isolation

### Correct Pattern

```php
// ✅ GOOD: Module A dispatches events
namespace ProductCatalog\Services;

use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;

class ProductService
{
    public function __construct(
        private EventAdapterInterface $events
    ) {}
    
    public function addToCart(int $productId): void
    {
        $product = $this->findProduct($productId);
        
        // ✅ Dispatch event instead of direct call
        $this->events->dispatch('product.add_to_cart', [
            'product' => $product
        ]);
    }
}

// ✅ GOOD: Module B listens to events
namespace ShoppingCart\Services;

class CartService
{
    public function boot(): void
    {
        // ✅ Listen to events from other modules
        $this->events->listen('product.add_to_cart', function($data) {
            $this->addItem($data['product']);
        });
    }
}
```

### Alternative: Optional Dependencies

```php
// ✅ GOOD: Optional dependency with interface
namespace ProductCatalog\Services;

interface CartServiceInterface
{
    public function addItem(Product $product): void;
}

class ProductService
{
    public function __construct(
        private ?CartServiceInterface $cart = null // Optional
    ) {}
    
    public function addToCart(int $productId): void
    {
        $product = $this->findProduct($productId);
        
        if ($this->cart) {
            // Use cart if available
            $this->cart->addItem($product);
        } else {
            // Fallback behavior
            $this->events->dispatch('product.add_to_cart', [
                'product' => $product
            ]);
        }
    }
}
```

## Context Abuse

### The Problem

Context should determine which modules load, not control business logic.

### Anti-Pattern Example

```php
// ❌ BAD: Business logic based on context
class PricingService
{
    public function calculatePrice(Product $product): Money
    {
        $context = $this->getContext();
        
        // ❌ Business rules based on context
        if (in_array('b2b', $context)) {
            return $product->getPrice()->multiply(0.9); // 10% discount
        }
        
        if (in_array('wholesale', $context)) {
            return $product->getPrice()->multiply(0.7); // 30% discount
        }
        
        if (in_array('retail', $context)) {
            return $product->getPrice(); // Full price
        }
        
        return $product->getPrice();
    }
}
```

**Problems:**
- Business logic scattered in context checks
- Hard to test all scenarios
- Context becomes business logic container
- Difficult to add new pricing rules

### Correct Pattern

```php
// ✅ GOOD: Business logic in domain layer
interface PricingStrategyInterface
{
    public function calculatePrice(Product $product, Customer $customer): Money;
}

class B2BPricingStrategy implements PricingStrategyInterface
{
    public function calculatePrice(Product $product, Customer $customer): Money
    {
        return $product->getPrice()->multiply(0.9);
    }
}

class RetailPricingStrategy implements PricingStrategyInterface
{
    public function calculatePrice(Product $product, Customer $customer): Money
    {
        return $product->getPrice();
    }
}

// ✅ Context determines which strategy to use
class PricingService
{
    private PricingStrategyInterface $strategy;
    
    public function __construct(ContainerInterface $container)
    {
        $context = $container->make('current.context');
        
        // Context selects strategy, not business logic
        $this->strategy = in_array('b2b', $context)
            ? $container->make(B2BPricingStrategy::class)
            : $container->make(RetailPricingStrategy::class);
    }
    
    public function calculatePrice(Product $product, Customer $customer): Money
    {
        return $this->strategy->calculatePrice($product, $customer);
    }
}
```

### When Context Is Appropriate

```php
// ✅ GOOD: Context for feature toggling
class DashboardController
{
    public function render(): string
    {
        $context = $this->getContext();
        $widgets = [];
        
        // ✅ Context determines which features are available
        if (in_array('ecommerce', $context)) {
            $widgets[] = $this->renderSalesWidget();
        }
        
        if (in_array('blog', $context)) {
            $widgets[] = $this->renderPostsWidget();
        }
        
        return $this->view->render('dashboard', [
            'widgets' => $widgets
        ]);
    }
}
```

## WP Convenience Leaks

### The Problem

Using WordPress convenience functions in core code creates tight coupling.

### Anti-Pattern Example

```php
// ❌ BAD: WordPress functions in core
namespace Viraloka\Core\Services;

class UserService
{
    public function getCurrentUser(): ?User
    {
        // ❌ WordPress function in core
        $wpUser = wp_get_current_user();
        
        if ($wpUser->ID === 0) {
            return null;
        }
        
        return new User($wpUser->ID, $wpUser->user_email);
    }
    
    public function updateUser(int $userId, array $data): void
    {
        // ❌ WordPress function in core
        wp_update_user([
            'ID' => $userId,
            'user_email' => $data['email']
        ]);
    }
    
    public function sendNotification(User $user, string $message): void
    {
        // ❌ WordPress function in core
        wp_mail(
            $user->email,
            'Notification',
            $message
        );
    }
}
```

### Correct Pattern

```php
// ✅ GOOD: Use adapters in core
namespace Viraloka\Core\Services;

use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use Viraloka\Core\Adapter\Contracts\NotificationAdapterInterface;

class UserService
{
    public function __construct(
        private AuthAdapterInterface $auth,
        private StorageAdapterInterface $storage,
        private NotificationAdapterInterface $notifications
    ) {}
    
    public function getCurrentUser(): ?User
    {
        // ✅ Use adapter
        return $this->auth->currentUser();
    }
    
    public function updateUser(int $userId, array $data): void
    {
        // ✅ Use adapter
        $this->storage->update('users', $userId, $data);
    }
    
    public function sendNotification(User $user, string $message): void
    {
        // ✅ Use adapter
        $this->notifications->send($user->email, 'Notification', $message);
    }
}
```

### Common WordPress Leaks to Avoid

```php
// ❌ BAD: Direct WordPress usage in core
wp_get_current_user()
get_option()
update_option()
add_action()
do_action()
wp_mail()
wp_redirect()
wp_die()
esc_html()
esc_url()
sanitize_text_field()
$wpdb->query()
global $wpdb
$_SERVER
$_POST
$_GET

// ✅ GOOD: Use adapters
$this->auth->currentUser()
$this->storage->get()
$this->storage->set()
$this->events->listen()
$this->events->dispatch()
$this->notifications->send()
$this->response->redirect()
$this->response->error()
$this->response->sanitizeHtml()
$this->response->sanitizeUrl()
$this->request->input()
$this->storage->query()
$this->storage (injected)
$this->request->getHeader()
$this->request->getBody()
$this->request->getQuery()
```

## Additional Anti-Patterns

### Modifying Core Container Bindings

```php
// ❌ BAD: Module overrides core service
class MyModuleServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // ❌ Don't override core services
        $container->singleton(
            ContextResolverInterface::class,
            MyCustomContextResolver::class
        );
    }
}

// ✅ GOOD: Extend or decorate instead
class MyModuleServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // ✅ Register your own service
        $container->singleton(
            MyContextEnhancerInterface::class,
            MyContextEnhancer::class
        );
    }
    
    public function boot(ContainerInterface $container): void
    {
        // ✅ Enhance core behavior via events
        $events = $container->make(EventAdapterInterface::class);
        $events->listen('context.resolved', function($context) {
            // Enhance context
        });
    }
}
```

### Storing State in Static Properties

```php
// ❌ BAD: Static state
class ProductCache
{
    private static array $products = [];
    
    public static function get(int $id): ?Product
    {
        return self::$products[$id] ?? null;
    }
    
    public static function set(int $id, Product $product): void
    {
        self::$products[$id] = $product;
    }
}

// ✅ GOOD: Instance state with container
class ProductCache
{
    private array $products = [];
    
    public function get(int $id): ?Product
    {
        return $this->products[$id] ?? null;
    }
    
    public function set(int $id, Product $product): void
    {
        $this->products[$id] = $product;
    }
}

// Register as singleton
$container->singleton(ProductCache::class);
```

### Ignoring Workspace Context

```php
// ❌ BAD: Query without workspace filter
class ProductRepository
{
    public function findAll(): array
    {
        // ❌ Returns products from ALL workspaces
        return $this->storage->query('products', []);
    }
}

// ✅ GOOD: Always filter by workspace
class ProductRepository
{
    public function __construct(
        private StorageAdapterInterface $storage,
        private WorkspaceResolverInterface $workspaceResolver
    ) {}
    
    public function findAll(): array
    {
        $workspace = $this->workspaceResolver->resolve();
        
        // ✅ Only returns products from current workspace
        return $this->storage->query('products', [
            'workspace_id' => $workspace->getId()
        ]);
    }
}
```

### Creating Too Many Contexts

```php
// ❌ BAD: Too granular
{
  "context": {
    "provides": [
      "ecommerce",
      "shop",
      "products",
      "catalog",
      "inventory",
      "pricing",
      "discounts",
      "coupons",
      "sales"
    ]
  }
}

// ✅ GOOD: High-level contexts
{
  "context": {
    "provides": [
      "ecommerce",
      "shop"
    ]
  }
}
```

### Hardcoding Configuration

```php
// ❌ BAD: Hardcoded values
class PaymentService
{
    public function process(Order $order): void
    {
        $apiKey = 'sk_live_abc123'; // ❌ Hardcoded
        $apiUrl = 'https://api.payment.com'; // ❌ Hardcoded
        
        // Process payment
    }
}

// ✅ GOOD: Configuration from storage
class PaymentService
{
    public function __construct(
        private StorageAdapterInterface $storage,
        private WorkspaceResolverInterface $workspaceResolver
    ) {}
    
    public function process(Order $order): void
    {
        $workspace = $this->workspaceResolver->resolve();
        $settings = $workspace->getSettings()['payment'] ?? [];
        
        $apiKey = $settings['api_key'] ?? throw new ConfigurationException();
        $apiUrl = $settings['api_url'] ?? 'https://api.payment.com';
        
        // Process payment
    }
}
```

---

## Summary

**Key Principles:**

1. **Adapters translate, don't decide** - Keep business logic out of adapters
2. **Modules communicate via events** - Avoid direct dependencies between modules
3. **Context selects features, not logic** - Use context for feature toggling, not business rules
4. **Core stays pure** - No WordPress functions in core code
5. **Always filter by workspace** - Never query without workspace context
6. **Use container for state** - Avoid static properties and global variables
7. **Configuration over hardcoding** - Store settings in workspace configuration

---

## Next Steps

Learn about migration strategies:

→ [Migration & Portability](11-migration-portability.md)

Or explore AI integration:

→ [AI & Automation](12-ai-automation.md)
