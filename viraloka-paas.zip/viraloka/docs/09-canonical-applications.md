# 9. Canonical Applications

## 9.1 Purpose of Canonical Apps

Canonical applications serve as reference implementations that validate Viraloka's architecture and demonstrate best practices.

### Validation

**Architecture Validation:**
- Proves the platform can support real applications
- Tests module system under realistic conditions
- Validates context resolution in practice
- Confirms adapter pattern works across use cases

**API Validation:**
- Ensures core APIs are sufficient
- Identifies missing functionality
- Tests developer experience
- Validates documentation accuracy

**Performance Validation:**
- Tests platform overhead
- Measures module loading time
- Validates lazy loading effectiveness
- Identifies bottlenecks

### Reference

**Learning Resource:**
- Shows proper module structure
- Demonstrates best practices
- Provides working examples
- Serves as starting point for new modules

**Quality Benchmark:**
- Sets standards for module quality
- Demonstrates proper testing
- Shows documentation standards
- Establishes code style

**Integration Examples:**
- Shows how modules communicate
- Demonstrates context usage
- Illustrates service injection
- Provides event handling patterns

## 9.2 Example Apps

### Link-in-Bio

**Overview:**
A simple application that allows users to create a personalized landing page with multiple links.

**Purpose:**
- Validate single-app SaaS pattern
- Test basic CRUD operations
- Demonstrate simple module structure
- Prove user isolation works

**Features:**
- User profile management
- Link management (add, edit, delete, reorder)
- Public profile page
- Analytics (link clicks)
- Theme customization

**Module Structure:**

```
viraloka-modules/linkinbio/
├── module.json
├── README.md
├── src/
│   ├── LinkInBioServiceProvider.php
│   ├── Controllers/
│   │   ├── ProfileController.php
│   │   └── LinkController.php
│   ├── Models/
│   │   ├── Profile.php
│   │   └── Link.php
│   ├── Repositories/
│   │   ├── ProfileRepository.php
│   │   └── LinkRepository.php
│   └── Services/
│       ├── ProfileService.php
│       └── AnalyticsService.php
├── resources/
│   ├── views/
│   │   ├── admin/
│   │   │   ├── dashboard.php
│   │   │   └── edit-profile.php
│   │   └── public/
│   │       └── profile.php
│   └── assets/
│       ├── css/
│       └── js/
└── database/
    └── migrations/
        ├── 001_create_profiles_table.php
        └── 002_create_links_table.php
```

**Key Implementation Details:**

**module.json:**
```json
{
  "id": "linkinbio",
  "name": "Link in Bio",
  "version": "1.0.0",
  "type": "application",
  "description": "Create personalized landing pages with multiple links",
  
  "bootstrap": {
    "provider": "LinkInBio\\LinkInBioServiceProvider"
  },
  
  "context": {
    "provides": ["linkinbio", "profile"]
  },
  
  "ui": {
    "menu": {
      "title": "Link in Bio",
      "icon": "dashicons-admin-links",
      "position": 25,
      "capability": "edit_profile"
    },
    "submenu": [
      {
        "title": "My Profile",
        "slug": "linkinbio-profile",
        "capability": "edit_profile"
      },
      {
        "title": "Analytics",
        "slug": "linkinbio-analytics",
        "capability": "view_analytics"
      }
    ]
  },
  
  "capabilities": [
    "edit_profile",
    "view_analytics"
  ]
}
```

**Service Provider:**
```php
namespace LinkInBio;

use Viraloka\Container\Contracts\ServiceProviderInterface;
use Viraloka\Container\Contracts\ContainerInterface;

class LinkInBioServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // Register repositories
        $container->singleton(
            Repositories\ProfileRepositoryInterface::class,
            Repositories\ProfileRepository::class
        );
        
        $container->singleton(
            Repositories\LinkRepositoryInterface::class,
            Repositories\LinkRepository::class
        );
        
        // Register services
        $container->singleton(
            Services\ProfileService::class
        );
        
        $container->singleton(
            Services\AnalyticsService::class
        );
    }
    
    public function boot(ContainerInterface $container): void
    {
        // Register routes
        $this->registerRoutes($container);
        
        // Register public profile endpoint
        $this->registerPublicRoutes($container);
        
        // Register analytics tracking
        $this->registerAnalytics($container);
    }
    
    private function registerRoutes(ContainerInterface $container): void
    {
        $eventAdapter = $container->make(EventAdapterInterface::class);
        
        $eventAdapter->listen('viraloka.routes.register', function() use ($container) {
            $router = $container->make(RouterInterface::class);
            
            $router->get('/profile', [Controllers\ProfileController::class, 'show']);
            $router->post('/profile', [Controllers\ProfileController::class, 'update']);
            $router->post('/links', [Controllers\LinkController::class, 'create']);
            $router->put('/links/{id}', [Controllers\LinkController::class, 'update']);
            $router->delete('/links/{id}', [Controllers\LinkController::class, 'delete']);
        });
    }
}
```

**What It Validates:**
- ✅ Module manifest system
- ✅ Service provider pattern
- ✅ Repository pattern
- ✅ User-level data isolation
- ✅ Admin UI integration
- ✅ Public-facing pages
- ✅ Basic CRUD operations
- ✅ Event system

### Simple AI Tool

**Overview:**
A workspace-aware AI assistant that helps users with various tasks.

**Purpose:**
- Validate multi-tenant pattern
- Test workspace isolation
- Demonstrate API integration
- Prove context-aware behavior

**Features:**
- AI chat interface
- Conversation history (per workspace)
- Custom AI prompts (per workspace)
- Usage tracking and limits
- API key management

**Module Structure:**

```
viraloka-modules/ai-assistant/
├── module.json
├── README.md
├── src/
│   ├── AIAssistantServiceProvider.php
│   ├── Controllers/
│   │   ├── ChatController.php
│   │   └── SettingsController.php
│   ├── Models/
│   │   ├── Conversation.php
│   │   └── Message.php
│   ├── Repositories/
│   │   ├── ConversationRepository.php
│   │   └── MessageRepository.php
│   ├── Services/
│   │   ├── AIService.php
│   │   ├── UsageTracker.php
│   │   └── PromptManager.php
│   └── Integrations/
│       ├── OpenAIAdapter.php
│       └── AnthropicAdapter.php
├── resources/
│   ├── views/
│   │   ├── chat.php
│   │   └── settings.php
│   └── assets/
│       ├── css/
│       └── js/
└── database/
    └── migrations/
        ├── 001_create_conversations_table.php
        └── 002_create_messages_table.php
```

**Key Implementation Details:**

**module.json:**
```json
{
  "id": "ai-assistant",
  "name": "AI Assistant",
  "version": "1.0.0",
  "type": "application",
  "description": "Workspace-aware AI assistant",
  
  "bootstrap": {
    "provider": "AIAssistant\\AIAssistantServiceProvider"
  },
  
  "context": {
    "provides": ["ai", "assistant"],
    "requires": ["workspace"]
  },
  
  "dependencies": {
    "requires": {
      "viraloka-core": "^1.0"
    }
  },
  
  "ui": {
    "menu": {
      "title": "AI Assistant",
      "icon": "dashicons-admin-comments",
      "position": 30,
      "capability": "use_ai_assistant"
    },
    "submenu": [
      {
        "title": "Chat",
        "slug": "ai-chat",
        "capability": "use_ai_assistant"
      },
      {
        "title": "Settings",
        "slug": "ai-settings",
        "capability": "manage_ai_settings"
      }
    ]
  },
  
  "capabilities": [
    "use_ai_assistant",
    "manage_ai_settings",
    "view_ai_usage"
  ]
}
```

**Workspace-Aware Repository:**
```php
namespace AIAssistant\Repositories;

use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use Viraloka\Core\Workspace\WorkspaceResolver;

class ConversationRepository
{
    public function __construct(
        private StorageAdapterInterface $storage,
        private WorkspaceResolver $workspaceResolver
    ) {}
    
    public function findAll(): array
    {
        $workspace = $this->workspaceResolver->resolve();
        
        return $this->storage->query('ai_conversations', [
            'workspace_id' => $workspace->getId()
        ]);
    }
    
    public function create(array $data): Conversation
    {
        $workspace = $this->workspaceResolver->resolve();
        
        $data['workspace_id'] = $workspace->getId();
        $data['created_at'] = date('Y-m-d H:i:s');
        
        $id = $this->storage->insert('ai_conversations', $data);
        
        return $this->find($id);
    }
}
```

**Usage Tracking:**
```php
namespace AIAssistant\Services;

class UsageTracker
{
    public function trackUsage(int $workspaceId, int $tokens): void
    {
        $currentUsage = $this->getCurrentUsage($workspaceId);
        $limit = $this->getUsageLimit($workspaceId);
        
        if ($currentUsage + $tokens > $limit) {
            throw new UsageLimitExceededException(
                "Workspace has exceeded AI usage limit"
            );
        }
        
        $this->storage->increment(
            "workspace_{$workspaceId}_ai_usage",
            $tokens
        );
    }
    
    public function getCurrentUsage(int $workspaceId): int
    {
        return $this->storage->get("workspace_{$workspaceId}_ai_usage") ?? 0;
    }
    
    public function getUsageLimit(int $workspaceId): int
    {
        $workspace = $this->workspaceRepo->find($workspaceId);
        return $workspace->getSettings()['ai_usage_limit'] ?? 100000;
    }
}
```

**What It Validates:**
- ✅ Workspace-aware data access
- ✅ Multi-tenant isolation
- ✅ External API integration
- ✅ Usage tracking and limits
- ✅ Workspace-specific settings
- ✅ Context-aware features
- ✅ Permission boundaries

## 9.3 Lessons Learned

### What Worked

**1. Manifest-Driven Architecture**

**Success:**
- Modules are discoverable without execution
- Dependencies are clear and validated
- Context requirements are explicit
- UI registration is declarative

**Example:**
```json
{
  "context": {
    "requires": ["workspace"]
  }
}
```
Platform automatically ensures workspace context exists before loading module.

**2. Adapter Pattern**

**Success:**
- Core logic is completely portable
- Testing is straightforward (mock adapters)
- WordPress dependencies are isolated
- Future migration path is clear

**Example:**
```php
// Core code works with any adapter
$user = $this->authAdapter->currentUser();

// WordPress adapter
class WordPressAuthAdapter implements AuthAdapterInterface
{
    public function currentUser(): ?User
    {
        $wpUser = wp_get_current_user();
        return $this->mapToUser($wpUser);
    }
}
```

**3. Context System**

**Success:**
- Modules coordinate automatically
- Features activate based on context
- No manual module management needed
- Workspace-specific behavior works

**Example:**
```php
// Workspace declares 'ecommerce' context
// Product, cart, checkout modules automatically load
// Blog modules don't load
```

**4. Repository Pattern**

**Success:**
- Data access is abstracted
- Business logic is clean
- Testing is easy
- Storage can be swapped

**Example:**
```php
// Business logic doesn't know about database
$products = $this->productRepo->findAll();

// Repository handles storage details
public function findAll(): array
{
    return $this->storage->query('products', [
        'workspace_id' => $this->getCurrentWorkspaceId()
    ]);
}
```

### What Changed in Core

**1. Added Storage Adapter Methods**

**Before:**
```php
interface StorageAdapterInterface
{
    public function get(string $key): mixed;
    public function set(string $key, mixed $value): bool;
}
```

**After:**
```php
interface StorageAdapterInterface
{
    public function get(string $key): mixed;
    public function set(string $key, mixed $value): bool;
    
    // Added for canonical apps
    public function query(string $table, array $conditions): array;
    public function insert(string $table, array $data): int;
    public function update(string $table, int $id, array $data): bool;
    public function delete(string $table, int $id): bool;
}
```

**Reason:** Canonical apps needed structured data access, not just key-value storage.

**2. Enhanced Context Resolution**

**Before:**
```php
// Simple context array
$context = ['public', 'system'];
```

**After:**
```php
// Context stack with priorities
$context = $contextResolver->resolve();
// ['ecommerce', 'shop', 'public', 'system']
// Merged from workspace, theme, modules, defaults
```

**Reason:** Canonical apps showed need for layered context resolution.

**3. Added Workspace-Scoped Services**

**Before:**
```php
// Global services only
$container->singleton(ServiceInterface::class, Service::class);
```

**After:**
```php
// Workspace-scoped services
$container->scoped(
    ServiceInterface::class,
    Service::class,
    'workspace'
);
```

**Reason:** AI Assistant needed per-workspace service instances.

**4. Improved Event System**

**Before:**
```php
// Simple event dispatch
$this->events->dispatch($event);
```

**After:**
```php
// Event dispatch with data
$this->events->dispatch('product.created', [
    'product' => $product,
    'workspace_id' => $workspaceId
]);

// Priority-based listeners
$this->events->listen('product.created', $callback, $priority);
```

**Reason:** Modules needed to communicate with rich event data.

**5. Added Module Lifecycle Hooks**

**Before:**
```php
// Only bootstrap hook
{
  "bootstrap": {
    "provider": "MyServiceProvider"
  }
}
```

**After:**
```php
// Full lifecycle
{
  "lifecycle": {
    "install": "Installer::install",
    "activate": "Installer::activate",
    "deactivate": "Installer::deactivate",
    "uninstall": "Installer::uninstall"
  }
}
```

**Reason:** Canonical apps needed database setup and cleanup.

---

## Next Steps

Learn about common mistakes:

→ [Anti-Patterns & Common Mistakes](10-anti-patterns.md)

Or explore migration strategies:

→ [Migration & Portability](11-migration-portability.md)
