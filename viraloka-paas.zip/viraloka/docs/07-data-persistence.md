# 7. Data & Persistence

## 7.1 Domain vs Infrastructure Data

Viraloka separates domain logic from infrastructure concerns using clean architecture principles.

### Entities

**Entities** represent core business objects with identity and lifecycle.

**Characteristics:**
- Have unique identity (ID)
- Contain business logic
- Independent of storage mechanism
- Mutable state

**Example: Product Entity**

```php
namespace MyModule\Domain\Entities;

class Product
{
    private int $id;
    private string $name;
    private float $price;
    private int $stock;
    private \DateTime $createdAt;
    
    public function __construct(
        int $id,
        string $name,
        float $price,
        int $stock
    ) {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->stock = $stock;
        $this->createdAt = new \DateTime();
    }
    
    // Business logic
    public function reduceStock(int $quantity): void
    {
        if ($quantity > $this->stock) {
            throw new InsufficientStockException();
        }
        
        $this->stock -= $quantity;
    }
    
    public function isAvailable(): bool
    {
        return $this->stock > 0;
    }
    
    public function applyDiscount(float $percentage): void
    {
        if ($percentage < 0 || $percentage > 100) {
            throw new InvalidDiscountException();
        }
        
        $this->price = $this->price * (1 - $percentage / 100);
    }
    
    // Getters
    public function getId(): int { return $this->id; }
    public function getName(): string { return $this->name; }
    public function getPrice(): float { return $this->price; }
    public function getStock(): int { return $this->stock; }
}
```

**Key Points:**
- No database logic in entity
- Business rules encapsulated
- Validation in methods
- Pure PHP objects

### Value Objects

**Value Objects** represent descriptive aspects without identity.

**Characteristics:**
- No unique identity
- Immutable
- Equality based on value
- Replaceable

**Example: Money Value Object**

```php
namespace MyModule\Domain\ValueObjects;

class Money
{
    private float $amount;
    private string $currency;
    
    public function __construct(float $amount, string $currency = 'USD')
    {
        if ($amount < 0) {
            throw new InvalidAmountException();
        }
        
        $this->amount = $amount;
        $this->currency = strtoupper($currency);
    }
    
    public function add(Money $other): Money
    {
        if ($this->currency !== $other->currency) {
            throw new CurrencyMismatchException();
        }
        
        return new Money($this->amount + $other->amount, $this->currency);
    }
    
    public function multiply(float $factor): Money
    {
        return new Money($this->amount * $factor, $this->currency);
    }
    
    public function equals(Money $other): bool
    {
        return $this->amount === $other->amount 
            && $this->currency === $other->currency;
    }
    
    public function getAmount(): float { return $this->amount; }
    public function getCurrency(): string { return $this->currency; }
    
    public function format(): string
    {
        return sprintf('%s %.2f', $this->currency, $this->amount);
    }
}
```

**Example: Email Value Object**

```php
namespace MyModule\Domain\ValueObjects;

class Email
{
    private string $value;
    
    public function __construct(string $email)
    {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new InvalidEmailException();
        }
        
        $this->value = strtolower($email);
    }
    
    public function getValue(): string
    {
        return $this->value;
    }
    
    public function getDomain(): string
    {
        return substr($this->value, strpos($this->value, '@') + 1);
    }
    
    public function equals(Email $other): bool
    {
        return $this->value === $other->value;
    }
    
    public function __toString(): string
    {
        return $this->value;
    }
}
```

### Repositories

**Repositories** abstract data access and provide collection-like interface.

**Characteristics:**
- Interface in domain layer
- Implementation in infrastructure layer
- Collection-like API
- Hide storage details

**Repository Interface:**

```php
namespace MyModule\Domain\Repositories;

use MyModule\Domain\Entities\Product;

interface ProductRepositoryInterface
{
    public function find(int $id): ?Product;
    public function findAll(): array;
    public function findByCategory(int $categoryId): array;
    public function save(Product $product): void;
    public function delete(Product $product): void;
    public function nextId(): int;
}
```

**Repository Implementation:**

```php
namespace MyModule\Infrastructure\Repositories;

use MyModule\Domain\Entities\Product;
use MyModule\Domain\Repositories\ProductRepositoryInterface;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;

class ProductRepository implements ProductRepositoryInterface
{
    public function __construct(
        private StorageAdapterInterface $storage
    ) {}
    
    public function find(int $id): ?Product
    {
        $data = $this->storage->query('products', [
            'id' => $id
        ]);
        
        if (empty($data)) {
            return null;
        }
        
        return $this->hydrate($data[0]);
    }
    
    public function findAll(): array
    {
        $data = $this->storage->query('products', []);
        
        return array_map(
            fn($row) => $this->hydrate($row),
            $data
        );
    }
    
    public function findByCategory(int $categoryId): array
    {
        $data = $this->storage->query('products', [
            'category_id' => $categoryId
        ]);
        
        return array_map(
            fn($row) => $this->hydrate($row),
            $data
        );
    }
    
    public function save(Product $product): void
    {
        $data = [
            'name' => $product->getName(),
            'price' => $product->getPrice(),
            'stock' => $product->getStock(),
        ];
        
        if ($product->getId()) {
            // Update existing
            $this->storage->update('products', $product->getId(), $data);
        } else {
            // Insert new
            $id = $this->storage->insert('products', $data);
            // Set ID on entity (reflection or setter)
        }
    }
    
    public function delete(Product $product): void
    {
        $this->storage->delete('products', $product->getId());
    }
    
    public function nextId(): int
    {
        return $this->storage->nextId('products');
    }
    
    private function hydrate(array $data): Product
    {
        return new Product(
            id: $data['id'],
            name: $data['name'],
            price: $data['price'],
            stock: $data['stock']
        );
    }
}
```

## 7.2 Storage Adapter

The Storage Adapter abstracts database operations from the host implementation.

### Interface

```php
namespace Viraloka\Core\Adapter\Contracts;

interface StorageAdapterInterface
{
    // Basic CRUD
    public function get(string $key): mixed;
    public function set(string $key, mixed $value): bool;
    public function delete(string $key): bool;
    public function has(string $key): bool;
    
    // Query operations
    public function query(string $table, array $conditions): array;
    public function insert(string $table, array $data): int;
    public function update(string $table, int $id, array $data): bool;
    
    // Transactions
    public function beginTransaction(): void;
    public function commit(): void;
    public function rollback(): void;
    
    // Utilities
    public function execute(string $sql, array $params = []): bool;
    public function nextId(string $table): int;
    public function getCapabilities(): array;
}
```

### WordPress Implementation

```php
namespace Viraloka\Adapter\WordPress;

use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;

class WordPressStorageAdapter implements StorageAdapterInterface
{
    private \wpdb $wpdb;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    public function get(string $key): mixed
    {
        return get_option("viraloka_{$key}");
    }
    
    public function set(string $key, mixed $value): bool
    {
        return update_option("viraloka_{$key}", $value);
    }
    
    public function delete(string $key): bool
    {
        return delete_option("viraloka_{$key}");
    }
    
    public function has(string $key): bool
    {
        return get_option("viraloka_{$key}") !== false;
    }
    
    public function query(string $table, array $conditions): array
    {
        $table = $this->wpdb->prefix . $table;
        $where = $this->buildWhere($conditions);
        
        $sql = "SELECT * FROM {$table}";
        if (!empty($where)) {
            $sql .= " WHERE {$where}";
        }
        
        return $this->wpdb->get_results($sql, ARRAY_A);
    }
    
    public function insert(string $table, array $data): int
    {
        $table = $this->wpdb->prefix . $table;
        $this->wpdb->insert($table, $data);
        return $this->wpdb->insert_id;
    }
    
    public function update(string $table, int $id, array $data): bool
    {
        $table = $this->wpdb->prefix . $table;
        return $this->wpdb->update($table, $data, ['id' => $id]) !== false;
    }
    
    public function beginTransaction(): void
    {
        $this->wpdb->query('START TRANSACTION');
    }
    
    public function commit(): void
    {
        $this->wpdb->query('COMMIT');
    }
    
    public function rollback(): void
    {
        $this->wpdb->query('ROLLBACK');
    }
    
    public function execute(string $sql, array $params = []): bool
    {
        if (!empty($params)) {
            $sql = $this->wpdb->prepare($sql, $params);
        }
        return $this->wpdb->query($sql) !== false;
    }
    
    public function nextId(string $table): int
    {
        $table = $this->wpdb->prefix . $table;
        $result = $this->wpdb->get_var("SELECT MAX(id) FROM {$table}");
        return ($result ?? 0) + 1;
    }
    
    public function getCapabilities(): array
    {
        return [
            'transactions' => true,
            'foreign_keys' => true,
            'full_text_search' => true,
        ];
    }
    
    private function buildWhere(array $conditions): string
    {
        if (empty($conditions)) {
            return '';
        }
        
        $parts = [];
        foreach ($conditions as $key => $value) {
            if (is_null($value)) {
                $parts[] = "{$key} IS NULL";
            } else {
                $parts[] = $this->wpdb->prepare("{$key} = %s", $value);
            }
        }
        
        return implode(' AND ', $parts);
    }
}
```

## 7.3 Multi-Tenant Data Rules

### Isolation

**Workspace-Level Isolation:**

Every data access must be scoped to the current workspace.

**Automatic Scoping:**

```php
class WorkspaceAwareRepository
{
    public function __construct(
        private StorageAdapterInterface $storage,
        private WorkspaceResolverInterface $workspaceResolver
    ) {}
    
    protected function getCurrentWorkspaceId(): int
    {
        $workspace = $this->workspaceResolver->resolve();
        return $workspace->getId();
    }
    
    public function findAll(): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        return $this->storage->query('products', [
            'workspace_id' => $workspaceId
        ]);
    }
    
    public function save(Product $product): void
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = [
            'workspace_id' => $workspaceId,
            'name' => $product->getName(),
            'price' => $product->getPrice(),
        ];
        
        $this->storage->insert('products', $data);
    }
}
```

**Tenant-Level Isolation:**

```php
class TenantAwareRepository extends WorkspaceAwareRepository
{
    public function __construct(
        StorageAdapterInterface $storage,
        WorkspaceResolverInterface $workspaceResolver,
        private TenantResolverInterface $tenantResolver
    ) {
        parent::__construct($storage, $workspaceResolver);
    }
    
    protected function getCurrentTenantId(): ?int
    {
        $tenant = $this->tenantResolver->resolve();
        return $tenant?->getId();
    }
    
    public function findAll(): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        $tenantId = $this->getCurrentTenantId();
        
        $conditions = ['workspace_id' => $workspaceId];
        
        if ($tenantId) {
            $conditions['tenant_id'] = $tenantId;
        }
        
        return $this->storage->query('products', $conditions);
    }
}
```

**Database Schema with Isolation:**

```sql
CREATE TABLE wp_viraloka_products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT UNSIGNED NOT NULL,
    tenant_id BIGINT UNSIGNED NULL,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    
    -- Isolation constraints
    INDEX idx_workspace (workspace_id),
    INDEX idx_tenant (tenant_id),
    INDEX idx_workspace_tenant (workspace_id, tenant_id),
    
    FOREIGN KEY (workspace_id) 
        REFERENCES wp_viraloka_workspaces(id) 
        ON DELETE CASCADE,
    
    FOREIGN KEY (tenant_id) 
        REFERENCES wp_viraloka_tenants(id) 
        ON DELETE CASCADE
);
```

### Shared Resources

Some resources can be shared across workspaces or tenants.

**Global Resources:**

```php
// System-wide settings (no workspace_id)
CREATE TABLE wp_viraloka_system_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key VARCHAR(255) NOT NULL UNIQUE,
    value TEXT,
    created_at DATETIME
);
```

**Workspace-Shared Resources:**

```php
// Shared within workspace, across tenants
CREATE TABLE wp_viraloka_workspace_templates (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    content TEXT,
    
    -- Shared by all tenants in workspace
    INDEX idx_workspace (workspace_id),
    FOREIGN KEY (workspace_id) 
        REFERENCES wp_viraloka_workspaces(id)
);
```

**Access Control:**

```php
class SharedResourceRepository
{
    public function findSharedTemplates(): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        // Returns templates shared across all tenants
        return $this->storage->query('workspace_templates', [
            'workspace_id' => $workspaceId
        ]);
    }
    
    public function canAccessTemplate(int $templateId): bool
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $template = $this->storage->query('workspace_templates', [
            'id' => $templateId
        ]);
        
        if (empty($template)) {
            return false;
        }
        
        // Check if template belongs to current workspace
        return $template[0]['workspace_id'] === $workspaceId;
    }
}
```

**Best Practices:**

✅ **DO:**
- Always include `workspace_id` in multi-tenant tables
- Use foreign keys for referential integrity
- Add indexes on `workspace_id` and `tenant_id`
- Validate workspace access before queries
- Use transactions for multi-table operations

❌ **DON'T:**
- Query without workspace filtering
- Share data between workspaces without explicit permission
- Store workspace-specific data in global tables
- Bypass isolation checks
- Use direct SQL without workspace context

**Example: Safe Query Pattern**

```php
// ✅ Good: Workspace-scoped query
public function findProducts(): array
{
    $workspaceId = $this->getCurrentWorkspaceId();
    
    return $this->storage->query('products', [
        'workspace_id' => $workspaceId
    ]);
}

// ❌ Bad: Unscoped query
public function findProducts(): array
{
    return $this->storage->query('products', []);
    // Returns products from ALL workspaces!
}
```

---

## Next Steps

Learn about security and performance:

→ [Security & Performance](08-security-performance.md)

Or explore canonical applications:

→ [Canonical Applications](09-canonical-applications.md)
