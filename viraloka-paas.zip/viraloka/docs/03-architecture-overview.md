# 3. Architecture Overview

## 3.1 High-Level Architecture

Viraloka dibangun dengan arsitektur berlapis yang memisahkan concerns dengan jelas:

```
┌─────────────────────────────────────────────┐
│           Application Layer                 │
│  (Modules, Business Logic, UI)              │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│            Core Platform Layer              │
│  (Container, Context, Module System)        │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│           Adapter Layer                     │
│  (Host Integration, Contracts)              │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│            Host Layer                       │
│  (WordPress, Laravel, Symfony)              │
└─────────────────────────────────────────────┘
```

### Core Kernel

**Responsibility:**
- Bootstrap platform
- Initialize services
- Coordinate lifecycle
- Enforce security

**Key Components:**
```php
Kernel
├── boot()           // Initialize platform
├── shutdown()       // Cleanup resources
├── getContainer()   // Access DI container
└── getAdapters()    // Access adapter registry
```

**Location:** `src/Core/Bootstrap/Kernel.php`

### Service Container

**Responsibility:**
- Dependency injection
- Service lifecycle management
- Lazy loading
- Scoped bindings

**Key Features:**
- Auto-wiring
- Singleton services
- Factory bindings
- Context-aware resolution

**Example:**
```php
// Register service
$container->singleton(
    ModuleRegistryInterface::class,
    ModuleRegistry::class
);

// Resolve service
$registry = $container->make(ModuleRegistryInterface::class);
```

**Location:** `src/Container/Container.php`

### Context Resolver

**Responsibility:**
- Detect current context
- Resolve context stack
- Filter modules by context
- Handle context fallback

**Context Sources (Priority Order):**
1. Workspace configuration (highest)
2. Theme declaration
3. Module recommendations
4. System defaults (lowest)

**Example:**
```php
$contextResolver = $container->make(ContextResolverInterface::class);
$context = $contextResolver->resolve();

// Result:
// ['ecommerce', 'blog', 'system']
```

**Location:** `src/Core/Context/ContextResolver.php`

### Module System

**Responsibility:**
- Module discovery
- Manifest parsing
- Dependency resolution
- Lifecycle management

**Components:**
```php
Module System
├── ModuleLoader      // Discover modules
├── ModuleRegistry    // Track modules
├── ModuleBootstrapper // Initialize modules
├── DependencyResolver // Resolve deps
└── ManifestParser    // Parse manifests
```

**Location:** `src/Core/Modules/`

### Host Adapter

**Responsibility:**
- Abstract host-specific code
- Implement platform contracts
- Provide host integration
- Enable portability

**Adapter Types:**
```php
Adapters
├── AuthAdapter       // Authentication
├── StorageAdapter    // Data persistence
├── EventAdapter      // Event system
├── RequestAdapter    // HTTP requests
├── ResponseAdapter   // HTTP responses
└── RuntimeAdapter    // Environment info
```

**Location:** `src/Adapter/`

## 3.2 Execution Flow

### Request → Context → Module → Response

**Complete Request Flow:**

```
1. HTTP Request
   ↓
2. WordPress/Host receives request
   ↓
3. Viraloka Kernel boots
   ↓
4. Resolve Workspace
   │  - Check domain/subdomain
   │  - Check path prefix
   │  - Fallback to default
   ↓
5. Resolve Context
   │  - Load workspace config
   │  - Check theme context
   │  - Apply module recommendations
   │  - Build context stack
   ↓
6. Filter Modules
   │  - Match context requirements
   │  - Check dependencies
   │  - Resolve load order
   ↓
7. Bootstrap Modules
   │  - Initialize services
   │  - Register routes
   │  - Register UI components
   ↓
8. Handle Request
   │  - Route to module
   │  - Execute business logic
   │  - Generate response
   ↓
9. Send Response
   │  - Apply filters
   │  - Render output
   │  - Return to client
```

### Detailed Example: E-commerce Request

**Request:** `GET /shop/products`

**Step 1: Workspace Resolution**
```php
// Domain: shop.example.com
$workspace = $workspaceResolver->resolveByDomain('shop.example.com');
// Result: Workspace ID = 5
```

**Step 2: Context Resolution**
```php
$contextStack = $contextResolver->resolve($workspace);
// Result: ['ecommerce', 'shop', 'public', 'system']
```

**Step 3: Module Filtering**
```php
$modules = $moduleRegistry->getByContext('ecommerce');
// Result: ['product', 'cart', 'checkout', 'payment']
```

**Step 4: Module Bootstrap**
```php
foreach ($modules as $module) {
    $bootstrapper->bootstrap($module);
}
// Services registered, routes registered
```

**Step 5: Request Handling**
```php
$router->dispatch('/shop/products');
// Routes to ProductController::index()
```

**Step 6: Response**
```php
return $responseAdapter->render('products.list', $products);
```

### Admin Request Flow

**Request:** `GET /wp-admin/admin.php?page=viraloka`

**Differences:**
- Context: `['admin', 'system']`
- Modules: Admin-specific modules only
- UI: Admin interface components
- Permissions: Checked via `AuthAdapter`

## 3.3 Boundaries & Contracts

### What Lives in Core

**Allowed in `src/Core/`:**

✅ **Business Logic**
- Domain entities
- Value objects
- Business rules
- Workflows

✅ **Contracts (Interfaces)**
- Service contracts
- Adapter contracts
- Repository contracts

✅ **Core Services**
- Container
- Context resolver
- Module system
- Event dispatcher

✅ **Abstractions**
- Base classes
- Traits
- Helpers (pure PHP)

**Forbidden in `src/Core/`:**

❌ **Host-Specific Code**
- WordPress functions (`wp_*`, `get_*`, `add_*`)
- Global variables (`$wpdb`, `$_SERVER`, `$_POST`)
- Host constants (`WP_DEBUG`, `ABSPATH`)

❌ **Direct I/O**
- Database queries (use `StorageAdapter`)
- File system access (use `RuntimeAdapter`)
- HTTP calls (use `RequestAdapter`)

❌ **UI Rendering**
- HTML generation (use `ResponseAdapter`)
- Asset loading (use `EventAdapter`)
- Template rendering (delegate to modules)

### What Lives in Modules

**Allowed in `viraloka-modules/`:**

✅ **Application Logic**
- Feature implementation
- UI components
- Routes
- Controllers

✅ **Module-Specific Services**
- Service providers
- Repositories
- Factories

✅ **Assets**
- CSS, JavaScript
- Images, fonts
- Templates

✅ **Configuration**
- Module manifest
- Default settings
- Migrations

**Forbidden in Modules:**

❌ **Core Modifications**
- Extending core classes
- Overriding core services
- Modifying container bindings

❌ **Direct Host Access**
- Should use adapters
- Should use core services
- Should respect contracts

### What Lives in Adapters

**Allowed in `src/Adapter/`:**

✅ **Host Integration**
- WordPress function calls
- Host-specific APIs
- Platform hooks

✅ **Contract Implementation**
- Implement adapter interfaces
- Translate between core and host
- Handle host quirks

✅ **Host-Specific Logic**
- WordPress database queries
- WordPress user management
- WordPress hooks/filters

**Forbidden in Adapters:**

❌ **Business Logic**
- Domain rules
- Workflows
- Business decisions

❌ **UI Components**
- Templates
- Views
- Frontend logic

### Contract Examples

**Good Contract Design:**

```php
// ✅ Good: Abstract, testable, portable
interface StorageAdapterInterface
{
    public function get(string $key): mixed;
    public function set(string $key, mixed $value): bool;
    public function delete(string $key): bool;
    public function has(string $key): bool;
}
```

**Bad Contract Design:**

```php
// ❌ Bad: WordPress-specific, not portable
interface StorageAdapterInterface
{
    public function getOption(string $key): mixed;
    public function updateOption(string $key, mixed $value): bool;
    public function deleteOption(string $key): bool;
}
```

### Dependency Rules

**The Dependency Rule:**
```
Modules → Core → Adapters → Host
   ↓       ↓        ↓         ↓
  Can    Cannot   Cannot   Cannot
 depend  depend   depend   depend
   on      on       on       on
  Core   Modules   Core    Anything
```

**Allowed Dependencies:**
- Modules can depend on Core contracts
- Core can depend on Adapter contracts
- Adapters can depend on Host
- Nobody can depend on Modules

**Forbidden Dependencies:**
- Core cannot depend on Modules
- Core cannot depend on Host
- Adapters cannot depend on Core implementations
- Modules cannot depend on other Modules directly

### Verification

**Check Core Isolation:**
```bash
# No WordPress functions in Core
grep -r "wp_\|get_\|add_\|do_" src/Core/

# Should return: (empty)
```

**Check Adapter Usage:**
```bash
# Core should only use adapter interfaces
grep -r "WordPressAuthAdapter\|WordPressStorageAdapter" src/Core/

# Should return: (empty)
```

**Check Module Boundaries:**
```bash
# Modules should not extend Core classes
grep -r "extends.*Core\\" viraloka-modules/

# Should return: (empty or only allowed base classes)
```

---

## Next Steps

Understand the core concepts in detail:

→ [Core Concepts](04-core-concepts.md)

Or start building modules:

→ [Building Modules](05-building-modules.md)
