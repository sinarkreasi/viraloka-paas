# 5. Building Modules

## 5.1 What is a Module?

### Definition

**Module** adalah unit fungsional independen yang menyediakan fitur spesifik dalam Viraloka platform.

**Characteristics:**
- Self-contained (semua dependencies declared)
- Manifest-driven (behavior declared in `module.json`)
- Context-aware (can require/provide context)
- Lifecycle-managed (platform controls load/unload)

### Lifecycle

**Module States:**

```
Discovered → Validated → Registered → Bootstrapped → Active
    ↓           ↓            ↓             ↓            ↓
  Scan      Validate     Store in      Initialize   Serving
 manifest    schema      registry      services    requests
```

**State Transitions:**

**1. Discovery**
```php
$loader = $container->make(ModuleLoaderInterface::class);
$loader->discover('viraloka-modules/');
// Scans directory, finds module.json files
```

**2. Validation**
```php
$validator = $container->make(SchemaValidatorInterface::class);
$result = $validator->validate($manifest);
// Validates against schema, checks dependencies
```

**3. Registration**
```php
$registry = $container->make(ModuleRegistryInterface::class);
$registry->register($module);
// Stores module in registry
```

**4. Bootstrap**
```php
$bootstrapper = $container->make(ModuleBootstrapperInterface::class);
$bootstrapper->bootstrap($module);
// Initializes services, registers routes
```

**5. Active**
```php
// Module is now serving requests
// Services available in container
// Routes registered
// UI components registered
```

### Module vs App

**Module:**
- Provides specific functionality
- Can be combined with other modules
- Reusable across projects
- Examples: `product-catalog`, `user-auth`, `payment`

**App:**
- Complete application
- Combines multiple modules
- Project-specific
- Examples: `ecommerce-platform`, `agency-dashboard`

**Relationship:**
```
App: E-commerce Platform
├── Module: Product Catalog
├── Module: Shopping Cart
├── Module: Checkout
├── Module: Payment Gateway
└── Module: Order Management
```

## 5.2 Module Manifest Schema

### Required Fields

**Minimal `module.json`:**

```json
{
  "id": "my-module",
  "name": "My Module",
  "version": "1.0.0",
  "type": "feature",
  "bootstrap": {
    "provider": "MyModule\\MyServiceProvider"
  }
}
```

**Field Descriptions:**

**`id`** (string, required)
- Unique identifier
- Kebab-case format
- Used for dependency references
- Example: `product-catalog`, `user-auth`

**`name`** (string, required)
- Human-readable name
- Displayed in admin UI
- Example: "Product Catalog", "User Authentication"

**`version`** (string, required)
- Semantic versioning (semver)
- Format: `MAJOR.MINOR.PATCH`
- Example: `1.0.0`, `2.1.3`

**`type`** (string, required)
- Module type classification
- Values: `feature`, `application`, `integration`, `internal`
- Affects loading behavior

**`bootstrap.provider`** (string, required)
- Fully-qualified class name
- Must implement `ServiceProviderInterface`
- Entry point for module initialization

### Optional Fields

**Complete `module.json` with all options:**

```json
{
  "id": "product-catalog",
  "name": "Product Catalog",
  "description": "Manage products, categories, and inventory",
  "version": "1.2.0",
  "type": "feature",
  "author": "Your Name",
  "license": "MIT",
  
  "dependencies": {
    "requires": {
      "viraloka-core": "^1.0",
      "user-auth": "^2.0"
    },
    "conflicts": {
      "old-product-plugin": "*"
    },
    "recommends": {
      "payment-gateway": "^1.0"
    }
  },
  
  "context": {
    "provides": ["ecommerce", "catalog"],
    "requires": ["public"],
    "recommends": ["shop"]
  },
  
  "bootstrap": {
    "provider": "ProductCatalog\\ProductServiceProvider",
    "priority": 10
  },
  
  "lifecycle": {
    "install": "ProductCatalog\\Installer::install",
    "uninstall": "ProductCatalog\\Installer::uninstall",
    "activate": "ProductCatalog\\Installer::activate",
    "deactivate": "ProductCatalog\\Installer::deactivate"
  },
  
  "ui": {
    "menu": {
      "title": "Products",
      "icon": "dashicons-products",
      "position": 20,
      "capability": "manage_products"
    },
    "submenu": [
      {
        "title": "All Products",
        "slug": "products",
        "capability": "edit_products"
      },
      {
        "title": "Categories",
        "slug": "product-categories",
        "capability": "manage_categories"
      }
    ]
  },
  
  "capabilities": [
    "manage_products",
    "edit_products",
    "delete_products",
    "manage_categories"
  ],
  
  "visibility": {
    "admin": true,
    "public": true,
    "contexts": ["ecommerce"]
  }
}
```

**Field Descriptions:**

**`dependencies.requires`** (object, optional)
- Modules that must be present
- Key: module ID, Value: version constraint
- Module won't load if dependencies missing

**`dependencies.conflicts`** (object, optional)
- Modules that cannot coexist
- Prevents loading if conflict detected

**`dependencies.recommends`** (object, optional)
- Suggested modules
- Not enforced, just recommendations

**`context.provides`** (array, optional)
- Contexts this module provides
- Other modules can require these contexts

**`context.requires`** (array, optional)
- Contexts required for this module
- Module only loads if contexts present

**`context.recommends`** (array, optional)
- Contexts that enhance this module
- Not required, but beneficial

**`lifecycle.*`** (string, optional)
- Callbacks for lifecycle events
- Format: `ClassName::methodName`

**`ui.menu`** (object, optional)
- Admin menu registration
- Automatically registered by platform

**`capabilities`** (array, optional)
- Custom capabilities for this module
- Automatically registered on activation

**`visibility`** (object, optional)
- Where module is visible
- Controls admin/public availability

## 5.3 Module Structure

### Folder Layout

**Recommended Structure:**

```
viraloka-modules/
└── my-module/
    ├── module.json              # Manifest (required)
    ├── README.md                # Documentation
    ├── composer.json            # PHP dependencies
    ├── src/                     # Source code
    │   ├── MyServiceProvider.php
    │   ├── Controllers/
    │   │   └── ProductController.php
    │   ├── Models/
    │   │   └── Product.php
    │   ├── Repositories/
    │   │   └── ProductRepository.php
    │   └── Services/
    │       └── ProductService.php
    ├── resources/               # Assets & templates
    │   ├── views/
    │   │   └── products/
    │   │       ├── index.php
    │   │       └── show.php
    │   ├── css/
    │   │   └── products.css
    │   └── js/
    │       └── products.js
    ├── database/                # Migrations
    │   └── migrations/
    │       └── 001_create_products_table.php
    ├── tests/                   # Tests
    │   ├── Unit/
    │   └── Integration/
    └── config/                  # Configuration
        └── products.php
```

### PSR-4 Namespace Rules

**Namespace Mapping:**

```json
// composer.json
{
  "autoload": {
    "psr-4": {
      "MyModule\\": "src/"
    }
  }
}
```

**File to Namespace Mapping:**

```
src/MyServiceProvider.php
→ MyModule\MyServiceProvider

src/Controllers/ProductController.php
→ MyModule\Controllers\ProductController

src/Models/Product.php
→ MyModule\Models\Product
```

**Example Class:**

```php
<?php
// File: src/Controllers/ProductController.php

namespace MyModule\Controllers;

use Viraloka\Core\Adapter\Contracts\RequestAdapterInterface;
use Viraloka\Core\Adapter\Contracts\ResponseAdapterInterface;
use MyModule\Services\ProductService;

class ProductController
{
    public function __construct(
        private RequestAdapterInterface $request,
        private ResponseAdapterInterface $response,
        private ProductService $productService
    ) {}
    
    public function index(): string
    {
        $products = $this->productService->getAll();
        return $this->response->render('products.index', [
            'products' => $products
        ]);
    }
}
```

## 5.4 Module Lifecycle

### Install

**Triggered:** First time module is added to system

**Purpose:**
- Create database tables
- Setup default data
- Register capabilities

**Example:**

```php
// src/Installer.php
namespace MyModule;

use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;

class Installer
{
    public static function install(StorageAdapterInterface $storage): void
    {
        // Create tables
        $storage->execute("
            CREATE TABLE IF NOT EXISTS products (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                price DECIMAL(10,2) NOT NULL,
                created_at DATETIME
            )
        ");
        
        // Insert default data
        $storage->set('products_version', '1.0.0');
        
        // Register capabilities
        // (handled by platform via manifest)
    }
}
```

### Enable

**Triggered:** Module is enabled (can be disabled/enabled multiple times)

**Purpose:**
- Activate features
- Register hooks
- Initialize services

**Example:**

```php
public static function activate(): void
{
    // Flush rewrite rules
    // Clear caches
    // Enable scheduled tasks
}
```

### Disable

**Triggered:** Module is disabled (but not uninstalled)

**Purpose:**
- Deactivate features
- Unregister hooks
- Cleanup temporary data

**Example:**

```php
public static function deactivate(): void
{
    // Clear scheduled tasks
    // Flush caches
    // Keep data intact
}
```

### Uninstall

**Triggered:** Module is permanently removed

**Purpose:**
- Drop database tables
- Delete all data
- Remove capabilities

**Example:**

```php
public static function uninstall(StorageAdapterInterface $storage): void
{
    // Drop tables
    $storage->execute("DROP TABLE IF EXISTS products");
    
    // Delete options
    $storage->delete('products_version');
    
    // Remove capabilities
    // (handled by platform)
}
```

## 5.5 Module Communication

### Events

**Dispatching Events:**

```php
// In your module
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;

class ProductService
{
    public function __construct(
        private EventAdapterInterface $events
    ) {}
    
    public function createProduct(array $data): Product
    {
        $product = new Product($data);
        $product->save();
        
        // Dispatch event
        $this->events->dispatch('product.created', [
            'product' => $product
        ]);
        
        return $product;
    }
}
```

**Listening to Events:**

```php
// In your service provider
public function boot(): void
{
    $this->events->listen('product.created', function($data) {
        // Handle product creation
        $product = $data['product'];
        
        // Send notification
        // Update inventory
        // Log activity
    });
}
```

**Standard Events:**

```
module.loaded          // Module finished loading
module.bootstrapped    // Module finished bootstrapping
context.resolved       // Context resolution complete
workspace.changed      // Workspace switched
tenant.changed         // Tenant switched
```

### Context Sharing

**Reading Context:**

```php
use Viraloka\Container\Contracts\ContainerInterface;

class MyService
{
    public function __construct(
        private ContainerInterface $container
    ) {}
    
    public function execute(): void
    {
        // Get current context
        $context = $this->container->make('current.context');
        
        if (in_array('ecommerce', $context)) {
            // E-commerce specific logic
        }
    }
}
```

**Providing Context:**

```php
// In module.json
{
    "context": {
        "provides": ["ecommerce", "catalog"]
    }
}

// Context automatically available to other modules
```

### Service Injection

**Registering Services:**

```php
// src/MyServiceProvider.php
namespace MyModule;

use Viraloka\Container\Contracts\ServiceProviderInterface;
use Viraloka\Container\Contracts\ContainerInterface;

class MyServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // Register services
        $container->singleton(
            ProductRepositoryInterface::class,
            ProductRepository::class
        );
        
        $container->singleton(
            ProductService::class,
            ProductService::class
        );
    }
    
    public function boot(ContainerInterface $container): void
    {
        // Bootstrap logic
        // Register routes, events, etc.
    }
}
```

**Consuming Services from Other Modules:**

```php
// Your module can inject services from other modules
class MyController
{
    public function __construct(
        // From core
        private RequestAdapterInterface $request,
        
        // From another module (if available)
        private ?PaymentGatewayInterface $payment = null
    ) {}
    
    public function checkout(): void
    {
        if ($this->payment) {
            // Use payment service
            $this->payment->processPayment($amount);
        } else {
            // Fallback behavior
        }
    }
}
```

**Dependency Declaration:**

```json
// module.json
{
    "dependencies": {
        "requires": {
            "payment-gateway": "^1.0"
        }
    }
}
```

---

## Example: Complete Module

**Link-in-Bio Module:**

```
viraloka-modules/linkinbio/
├── module.json
├── src/
│   ├── LinkInBioServiceProvider.php
│   ├── Controllers/
│   │   └── ProfileController.php
│   ├── Models/
│   │   └── Profile.php
│   └── Repositories/
│       └── ProfileRepository.php
└── resources/
    └── views/
        └── profile.php
```

**module.json:**
```json
{
  "id": "linkinbio",
  "name": "Link in Bio",
  "version": "1.0.0",
  "type": "application",
  "bootstrap": {
    "provider": "LinkInBio\\LinkInBioServiceProvider"
  },
  "context": {
    "provides": ["linkinbio"]
  },
  "ui": {
    "menu": {
      "title": "Link in Bio",
      "icon": "dashicons-admin-links",
      "capability": "edit_profile"
    }
  }
}
```

**LinkInBioServiceProvider.php:**
```php
<?php

namespace LinkInBio;

use Viraloka\Container\Contracts\ServiceProviderInterface;
use Viraloka\Container\Contracts\ContainerInterface;

class LinkInBioServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        $container->singleton(ProfileRepository::class);
    }
    
    public function boot(ContainerInterface $container): void
    {
        // Register routes, hooks, etc.
    }
}
```

---

## Next Steps

Learn about context-driven development:

→ [Context-Driven Development](06-context-driven-development.md)

Or explore data persistence:

→ [Data & Persistence](07-data-persistence.md)
