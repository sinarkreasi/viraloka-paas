# 12. AI & Automation

## 12.1 Using Docs as AI Prompt

Viraloka documentation is designed to be consumed by both humans and AI agents, enabling AI-assisted development.

### Agent Roles

**Module Generator Agent:**

```
Role: Generate Viraloka modules from natural language descriptions

Context:
- Viraloka module structure (from docs/05-building-modules.md)
- Module manifest schema
- Service provider pattern
- Repository pattern

Input: "Create a blog module with posts, categories, and comments"

Output:
- module.json with proper schema
- Service provider implementation
- Repository interfaces and implementations
- Controller stubs
- Migration files
```

**Example Prompt:**

```markdown
You are a Viraloka module generator. Given a feature description, generate a complete module following Viraloka conventions.

# Context
Read the following documentation:
- docs/05-building-modules.md
- docs/04-core-concepts.md
- docs/07-data-persistence.md

# Requirements
1. Generate module.json with all required fields
2. Create service provider implementing ServiceProviderInterface
3. Create repository interfaces and implementations
4. Follow PSR-4 namespace conventions
5. Include database migrations
6. Add proper capability declarations

# Input
Feature: Blog management system with posts, categories, tags, and comments

# Output
Generate complete module structure with all files.
```

**Adapter Implementation Agent:**

```
Role: Implement Viraloka adapters for new host frameworks

Context:
- Adapter contract definitions (from docs/04-core-concepts.md)
- Host framework documentation
- Existing adapter implementations as reference

Input: "Implement Viraloka adapters for Symfony"

Output:
- SymfonyAuthAdapter
- SymfonyStorageAdapter
- SymfonyEventAdapter
- SymfonyRequestAdapter
- SymfonyResponseAdapter
- SymfonyRuntimeAdapter
- Compliance tests
```

**Code Review Agent:**

```
Role: Review Viraloka code for anti-patterns and violations

Context:
- Anti-patterns documentation (from docs/10-anti-patterns.md)
- Core contracts (from docs/04-core-concepts.md)
- Architecture boundaries (from docs/03-architecture-overview.md)

Input: Module source code

Output:
- List of violations
- Suggested fixes
- Compliance score
```

**Migration Assistant Agent:**

```
Role: Assist in migrating from WordPress to other frameworks

Context:
- Migration strategy (from docs/11-migration-portability.md)
- Adapter patterns
- Portability guidelines

Input: WordPress-based module code

Output:
- Portability analysis
- Required changes
- Migration steps
- Risk assessment
```

### Prompt Boundaries

**What AI Can Do:**

✅ **Generate Module Scaffolding:**
```
Input: "Create an e-commerce product catalog module"
Output: Complete module structure with manifest, service provider, repositories
```

✅ **Implement Adapters:**
```
Input: "Implement storage adapter for PostgreSQL"
Output: PostgreSQL storage adapter implementing StorageAdapterInterface
```

✅ **Write Tests:**
```
Input: "Generate tests for ProductRepository"
Output: PHPUnit tests covering all repository methods
```

✅ **Refactor for Compliance:**
```
Input: "Remove WordPress dependencies from this service"
Output: Refactored code using adapters instead of WordPress functions
```

✅ **Generate Documentation:**
```
Input: "Document this module's API"
Output: API documentation in markdown format
```

**What AI Should Not Do:**

❌ **Make Architectural Decisions:**
```
Bad: "Should I use event-driven or direct coupling?"
Good: "Implement event-driven communication as per docs/05-building-modules.md"
```

❌ **Override Core Contracts:**
```
Bad: "Modify AuthAdapterInterface to add new method"
Good: "Create new interface extending AuthAdapterInterface"
```

❌ **Ignore Isolation Rules:**
```
Bad: "Access other module's database tables directly"
Good: "Use events to communicate with other modules"
```

❌ **Bypass Security:**
```
Bad: "Skip permission checks for admin users"
Good: "Implement proper capability checks using AuthAdapter"
```

## 12.2 AI-Assisted Module Generation

### Manifest Generation

**AI Prompt Template:**

```markdown
Generate a Viraloka module manifest for the following feature:

Feature Name: {feature_name}
Description: {description}
Type: {application|feature|integration|internal}
Context Provides: {contexts}
Context Requires: {contexts}
Dependencies: {module_ids}
Capabilities: {capabilities}

Requirements:
1. Follow manifest schema from docs/05-building-modules.md
2. Use semantic versioning (1.0.0)
3. Include UI menu configuration if applicable
4. Declare all capabilities
5. Set appropriate visibility rules

Output: Complete module.json file
```

**Example:**

```markdown
Generate a Viraloka module manifest for the following feature:

Feature Name: Invoice Management
Description: Create, manage, and send invoices to clients
Type: feature
Context Provides: invoicing, billing
Context Requires: workspace, client-management
Dependencies: client-portal
Capabilities: manage_invoices, send_invoices, view_invoices

Output:
```

```json
{
  "id": "invoice-management",
  "name": "Invoice Management",
  "description": "Create, manage, and send invoices to clients",
  "version": "1.0.0",
  "type": "feature",
  "author": "Your Name",
  "license": "MIT",
  
  "dependencies": {
    "requires": {
      "viraloka-core": "^1.0",
      "client-portal": "^1.0"
    }
  },
  
  "context": {
    "provides": ["invoicing", "billing"],
    "requires": ["workspace", "client-management"]
  },
  
  "bootstrap": {
    "provider": "InvoiceManagement\\InvoiceServiceProvider",
    "priority": 10
  },
  
  "lifecycle": {
    "install": "InvoiceManagement\\Installer::install",
    "uninstall": "InvoiceManagement\\Installer::uninstall"
  },
  
  "ui": {
    "menu": {
      "title": "Invoices",
      "icon": "dashicons-media-spreadsheet",
      "position": 25,
      "capability": "manage_invoices"
    },
    "submenu": [
      {
        "title": "All Invoices",
        "slug": "invoices",
        "capability": "view_invoices"
      },
      {
        "title": "Create Invoice",
        "slug": "create-invoice",
        "capability": "manage_invoices"
      },
      {
        "title": "Settings",
        "slug": "invoice-settings",
        "capability": "manage_invoices"
      }
    ]
  },
  
  "capabilities": [
    "manage_invoices",
    "send_invoices",
    "view_invoices"
  ],
  
  "visibility": {
    "admin": true,
    "public": false,
    "contexts": ["invoicing", "billing"]
  }
}
```

### Boilerplate Generation

**Service Provider Template:**

```markdown
Generate a Viraloka service provider for module: {module_id}

Requirements:
1. Implement ServiceProviderInterface
2. Register repositories in register() method
3. Register services in register() method
4. Register routes in boot() method
5. Register event listeners in boot() method
6. Use proper namespace: {ModuleName}

Repositories to register:
- {RepositoryInterface} -> {RepositoryImplementation}

Services to register:
- {ServiceClass}

Routes:
- GET /path -> Controller@method
- POST /path -> Controller@method

Events to listen:
- event.name -> callback

Output: Complete service provider class
```

**Generated Output:**

```php
<?php

namespace InvoiceManagement;

use Viraloka\Container\Contracts\ServiceProviderInterface;
use Viraloka\Container\Contracts\ContainerInterface;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use InvoiceManagement\Repositories\InvoiceRepositoryInterface;
use InvoiceManagement\Repositories\InvoiceRepository;
use InvoiceManagement\Services\InvoiceService;
use InvoiceManagement\Services\PDFGenerator;
use InvoiceManagement\Controllers\InvoiceController;

class InvoiceServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // Register repositories
        $container->singleton(
            InvoiceRepositoryInterface::class,
            InvoiceRepository::class
        );
        
        // Register services
        $container->singleton(InvoiceService::class);
        $container->singleton(PDFGenerator::class);
        
        // Register controllers
        $container->singleton(InvoiceController::class);
    }
    
    public function boot(ContainerInterface $container): void
    {
        $this->registerRoutes($container);
        $this->registerEventListeners($container);
    }
    
    private function registerRoutes(ContainerInterface $container): void
    {
        $events = $container->make(EventAdapterInterface::class);
        
        $events->listen('viraloka.routes.register', function() use ($container) {
            $router = $container->make(RouterInterface::class);
            
            // Invoice routes
            $router->get('/invoices', [InvoiceController::class, 'index']);
            $router->get('/invoices/{id}', [InvoiceController::class, 'show']);
            $router->post('/invoices', [InvoiceController::class, 'create']);
            $router->put('/invoices/{id}', [InvoiceController::class, 'update']);
            $router->delete('/invoices/{id}', [InvoiceController::class, 'delete']);
            $router->post('/invoices/{id}/send', [InvoiceController::class, 'send']);
        });
    }
    
    private function registerEventListeners(ContainerInterface $container): void
    {
        $events = $container->make(EventAdapterInterface::class);
        
        // Listen to client events
        $events->listen('client.created', function($data) use ($container) {
            // Initialize invoice settings for new client
            $invoiceService = $container->make(InvoiceService::class);
            $invoiceService->initializeClientSettings($data['client']);
        });
        
        // Listen to payment events
        $events->listen('payment.received', function($data) use ($container) {
            // Mark invoice as paid
            $invoiceService = $container->make(InvoiceService::class);
            $invoiceService->markAsPaid($data['invoice_id']);
        });
    }
}
```

**Repository Template:**

```markdown
Generate a Viraloka repository for entity: {EntityName}

Requirements:
1. Create interface extending base repository interface
2. Create implementation using StorageAdapter
3. Include workspace filtering
4. Implement CRUD methods
5. Use proper namespace

Entity properties:
- {property}: {type}

Output: Interface and implementation files
```

**Generated Interface:**

```php
<?php

namespace InvoiceManagement\Repositories;

use InvoiceManagement\Entities\Invoice;

interface InvoiceRepositoryInterface
{
    public function find(int $id): ?Invoice;
    public function findAll(): array;
    public function findByClient(int $clientId): array;
    public function findByStatus(string $status): array;
    public function save(Invoice $invoice): void;
    public function delete(Invoice $invoice): void;
    public function nextInvoiceNumber(): string;
}
```

**Generated Implementation:**

```php
<?php

namespace InvoiceManagement\Repositories;

use InvoiceManagement\Entities\Invoice;
use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use Viraloka\Core\Workspace\WorkspaceResolver;

class InvoiceRepository implements InvoiceRepositoryInterface
{
    public function __construct(
        private StorageAdapterInterface $storage,
        private WorkspaceResolver $workspaceResolver
    ) {}
    
    public function find(int $id): ?Invoice
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = $this->storage->query('invoices', [
            'id' => $id,
            'workspace_id' => $workspaceId
        ]);
        
        if (empty($data)) {
            return null;
        }
        
        return $this->hydrate($data[0]);
    }
    
    public function findAll(): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = $this->storage->query('invoices', [
            'workspace_id' => $workspaceId
        ]);
        
        return array_map(
            fn($row) => $this->hydrate($row),
            $data
        );
    }
    
    public function findByClient(int $clientId): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = $this->storage->query('invoices', [
            'workspace_id' => $workspaceId,
            'client_id' => $clientId
        ]);
        
        return array_map(
            fn($row) => $this->hydrate($row),
            $data
        );
    }
    
    public function findByStatus(string $status): array
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = $this->storage->query('invoices', [
            'workspace_id' => $workspaceId,
            'status' => $status
        ]);
        
        return array_map(
            fn($row) => $this->hydrate($row),
            $data
        );
    }
    
    public function save(Invoice $invoice): void
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        
        $data = [
            'workspace_id' => $workspaceId,
            'client_id' => $invoice->getClientId(),
            'invoice_number' => $invoice->getInvoiceNumber(),
            'amount' => $invoice->getAmount(),
            'status' => $invoice->getStatus(),
            'due_date' => $invoice->getDueDate()->format('Y-m-d'),
            'created_at' => $invoice->getCreatedAt()->format('Y-m-d H:i:s'),
        ];
        
        if ($invoice->getId()) {
            $this->storage->update('invoices', $invoice->getId(), $data);
        } else {
            $id = $this->storage->insert('invoices', $data);
            // Set ID on entity (using reflection or setter)
        }
    }
    
    public function delete(Invoice $invoice): void
    {
        $this->storage->delete('invoices', $invoice->getId());
    }
    
    public function nextInvoiceNumber(): string
    {
        $workspaceId = $this->getCurrentWorkspaceId();
        $year = date('Y');
        
        $lastInvoice = $this->storage->query('invoices', [
            'workspace_id' => $workspaceId
        ], [
            'order_by' => 'id DESC',
            'limit' => 1
        ]);
        
        $nextNumber = empty($lastInvoice) ? 1 : $lastInvoice[0]['id'] + 1;
        
        return sprintf('INV-%s-%04d', $year, $nextNumber);
    }
    
    private function getCurrentWorkspaceId(): int
    {
        $workspace = $this->workspaceResolver->resolve();
        return $workspace->getId();
    }
    
    private function hydrate(array $data): Invoice
    {
        return new Invoice(
            id: $data['id'],
            clientId: $data['client_id'],
            invoiceNumber: $data['invoice_number'],
            amount: $data['amount'],
            status: $data['status'],
            dueDate: new \DateTime($data['due_date']),
            createdAt: new \DateTime($data['created_at'])
        );
    }
}
```

### AI Development Workflow

**1. Feature Request → Module Scaffold**

```
Human: "I need a task management module with projects, tasks, and time tracking"

AI: Generates:
- module.json
- Service provider
- Repository interfaces
- Entity classes
- Migration files
- Controller stubs
```

**2. Code Review → Compliance Check**

```
Human: Submits module code for review

AI: Analyzes:
- WordPress dependencies in core
- Missing workspace filtering
- Capability checks
- Event usage
- Provides fix suggestions
```

**3. Migration Request → Adapter Implementation**

```
Human: "Implement Viraloka adapters for Symfony"

AI: Generates:
- All 6 adapter implementations
- Compliance tests
- Service provider configuration
- Migration guide
```

**4. Documentation → API Reference**

```
Human: "Document the Invoice module API"

AI: Generates:
- API endpoint documentation
- Request/response examples
- Authentication requirements
- Error codes
- Usage examples
```

---

## Next Steps

Learn about contribution guidelines:

→ [Contribution & Governance](13-contribution-governance.md)

Or explore the roadmap:

→ [Roadmap & Evolution](14-roadmap-evolution.md)
