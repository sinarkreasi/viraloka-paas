# 1. Introduction

## 1.1 What is Viraloka?

### Viraloka as a WordPress-based PaaS

Viraloka adalah **Platform as a Service (PaaS)** yang dibangun di atas WordPress, dirancang untuk memungkinkan developer membangun aplikasi SaaS multi-tenant dengan cepat dan terstruktur.

**Viraloka bukan:**
- ❌ Plugin WordPress biasa
- ❌ Theme WordPress
- ❌ Page builder
- ❌ SaaS application (Viraloka adalah platform untuk membangun SaaS)

**Viraloka adalah:**
- ✅ Platform development framework
- ✅ Modular application architecture
- ✅ Context-aware system
- ✅ Multi-tenant infrastructure
- ✅ Engine-agnostic core (portable ke framework lain)

### Masalah yang Diselesaikan

**Problem 1: WordPress Plugin Chaos**
- Plugin stack yang tidak terstruktur
- Konflik antar plugin
- Tidak ada isolation
- Sulit maintain dan scale

**Solution: Modular Architecture**
- Module system dengan manifest
- Clear boundaries dan contracts
- Dependency resolution
- Isolated execution

**Problem 2: Multi-Tenant Complexity**
- Sulit implement multi-tenancy di WordPress
- Data isolation challenges
- Permission management
- Workspace separation

**Solution: Built-in Multi-Tenancy**
- Workspace & Tenant system
- Context-aware resolution
- Permission boundaries
- Data isolation

**Problem 3: Vendor Lock-in**
- Terikat ke WordPress
- Sulit migrate ke framework lain
- Business logic tercampur dengan WordPress code

**Solution: Host Adapter Pattern**
- Core logic independent dari WordPress
- Adapter layer untuk host integration
- Portable ke Laravel, Symfony, dll
- Clean separation of concerns

## 1.2 Core Philosophy

### Platform over Plugins

Viraloka mengubah paradigma dari "kumpulan plugin" menjadi "platform terpadu":

```
Traditional WordPress:
Plugin A + Plugin B + Plugin C = Chaos

Viraloka:
Core Platform + Module A + Module B + Module C = Harmony
```

**Principles:**
- Modules bukan plugins (managed lifecycle)
- Centralized service container
- Unified context system
- Coordinated execution

### Contract-First Design

Semua interaksi melalui contracts (interfaces):

```php
// ❌ Bad: Direct WordPress dependency
function my_function() {
    $user = wp_get_current_user();
    update_user_meta($user->ID, 'key', 'value');
}

// ✅ Good: Contract-based
class MyService {
    public function __construct(
        private AuthAdapterInterface $auth,
        private StorageAdapterInterface $storage
    ) {}
    
    public function execute() {
        $user = $this->auth->currentUser();
        $this->storage->set("user_{$user->id}_key", 'value');
    }
}
```

**Benefits:**
- Testable (mock contracts)
- Portable (swap implementations)
- Maintainable (clear dependencies)
- Predictable (type-safe)

### Context-Driven System

Aplikasi berperilaku berbeda berdasarkan context:

```
Context: ecommerce
→ Modules: product, cart, checkout
→ UI: product-focused

Context: blog
→ Modules: post, comment, author
→ UI: content-focused
```

**Context Sources:**
1. Workspace configuration
2. Theme declaration
3. Module recommendations
4. System defaults

### Engine-Agnostic Mindset

Core logic tidak terikat ke WordPress:

```
Core (Pure PHP)
    ↓
Adapter Layer
    ↓
Host (WordPress / Laravel / Symfony)
```

**Portability:**
- Core: 100% portable
- Modules: 95% portable (UI mungkin perlu adjust)
- Adapters: Host-specific

## 1.3 Mental Model

### Viraloka vs Plugin Stack

**Traditional WordPress Plugin Stack:**
```
WordPress Core
├── Plugin A (isolated)
├── Plugin B (isolated)
├── Plugin C (isolated)
└── Theme (isolated)

Problems:
- No coordination
- Duplicate services
- Conflict prone
- No shared context
```

**Viraloka Platform:**
```
WordPress Core
└── Viraloka Core
    ├── Service Container (shared)
    ├── Context Resolver (coordinated)
    ├── Module Registry (managed)
    ├── Module A (integrated)
    ├── Module B (integrated)
    └── Module C (integrated)

Benefits:
- Coordinated execution
- Shared services
- Context-aware
- Managed lifecycle
```

### Viraloka vs Laravel SaaS

**Laravel SaaS:**
```
Laravel Framework
├── App Code (monolithic)
├── Packages (composer)
└── Service Providers

Characteristics:
- Code-first
- Monolithic app
- Package ecosystem
- Framework-specific
```

**Viraloka:**
```
WordPress/Laravel/Symfony
└── Viraloka Core
    ├── Modules (manifest-driven)
    ├── Context System
    └── Adapters

Characteristics:
- Manifest-first
- Modular apps
- Module ecosystem
- Framework-agnostic
```

### Viraloka Lifecycle Overview

**1. Bootstrap Phase**
```
Kernel Boot
→ Register Services
→ Detect Host Environment
→ Register Adapters
→ Initialize Core Services
```

**2. Discovery Phase**
```
Scan Modules
→ Parse Manifests
→ Validate Dependencies
→ Register Modules
```

**3. Resolution Phase**
```
Resolve Workspace
→ Resolve Context
→ Filter Modules by Context
→ Build Dependency Graph
```

**4. Execution Phase**
```
Bootstrap Modules
→ Register Services
→ Register Routes
→ Register UI
→ Handle Request
```

**5. Shutdown Phase**
```
Cleanup Resources
→ Flush Caches
→ Log Metrics
```

---

## Quick Start

Ready to build? Continue to [Getting Started](02-getting-started.md) →
