# 4. Core Concepts (Mandatory Reading)

## 4.1 Manifest & Scope Charter

### Purpose

Manifest adalah **kontrak formal** antara module dan platform. Setiap module harus memiliki `module.json` yang mendeklarasikan:

- Identity (id, name, version)
- Dependencies (requires, conflicts)
- Context (provides, requires)
- Lifecycle (bootstrap, shutdown)
- UI (menu, capabilities)

**Why Manifest?**
- **Declarative:** Module behavior ditentukan oleh manifest, bukan code
- **Validatable:** Platform dapat validate sebelum load
- **Discoverable:** Platform dapat discover modules tanpa execute code
- **Portable:** Manifest format tidak terikat ke host

### Scope Charter

**Manifest Scope:**

✅ **What Manifest Declares:**
- Module metadata
- Dependencies
- Context requirements
- UI registration
- Lifecycle hooks
- Capabilities

❌ **What Manifest Does NOT Declare:**
- Business logic
- Database schema
- API endpoints
- Internal implementation

### Non-Goals

Manifest **bukan**:
- Configuration file (use separate config)
- Database migration (use lifecycle hooks)
- Route definition (use service provider)
- Asset manifest (use build tools)

### Scope Enforcement

Platform enforces manifest rules:

```php
// Validation on module load
$validator = new SchemaValidator();
$result = $validator->validate($manifest);

if (!$result->isValid()) {
    throw new InvalidManifestException($result->getErrors());
}
```

**Enforced Rules:**
- Required fields present
- Valid dependency references
- No circular dependencies
- Context declarations valid
- Version constraints satisfied

## 4.2 Core Contract

### Allowed Responsibilities

Core (`src/Core/`) bertanggung jawab untuk:

**1. Service Container**
```php
// ✅ Dependency injection
$container->singleton(ServiceInterface::class, ServiceImpl::class);
$service = $container->make(ServiceInterface::class);
```

**2. Context Resolution**
```php
// ✅ Resolve current context
$context = $contextResolver->resolve();
$modules = $registry->getByContext($context);
```

**3. Module Management**
```php
// ✅ Load and bootstrap modules
$loader->discover('viraloka-modules/');
$bootstrapper->bootstrap($module);
```

**4. Event Coordination**
```php
// ✅ Dispatch events
$dispatcher->dispatch(new ModuleLoadedEvent($module));
```

**5. Workspace Management**
```php
// ✅ Manage workspaces and tenants
$workspace = $workspaceRepo->create($data);
$tenant = $tenantRepo->createForWorkspace($workspace);
```

### Forbidden Behaviors

Core **tidak boleh**:

**1. Direct Host Access**
```php
// ❌ No WordPress functions
wp_get_current_user();
get_option('setting');
add_action('init', $callback);

// ✅ Use adapters instead
$this->authAdapter->currentUser();
$this->storageAdapter->get('setting');
$this->eventAdapter->listen('init', $callback);
```

**2. Global State**
```php
// ❌ No global variables
global $wpdb;
$_SERVER['HTTP_HOST'];
$GLOBALS['my_var'];

// ✅ Use adapters
$this->requestAdapter->getHeader('Host');
$this->storageAdapter->get('my_var');
```

**3. Direct I/O**
```php
// ❌ No direct database access
$pdo->query("SELECT * FROM users");

// ✅ Use storage adapter
$this->storageAdapter->query('users', ['status' => 'active']);
```

**4. UI Rendering**
```php
// ❌ No HTML in core
echo "<div>Hello</div>";

// ✅ Delegate to modules/adapters
$this->responseAdapter->render('template', $data);
```

### Contract Verification

**Automated Checks:**

```php
// tests/CoreIsolationIntegrationTest.php
public function test_core_has_no_wordpress_dependencies()
{
    $coreFiles = $this->scanDirectory('src/Core');
    
    foreach ($coreFiles as $file) {
        $content = file_get_contents($file);
        
        // Check for WordPress functions
        $this->assertStringNotContainsString('wp_', $content);
        $this->assertStringNotContainsString('get_option', $content);
        $this->assertStringNotContainsString('add_action', $content);
        
        // Check for globals
        $this->assertStringNotContainsString('global $', $content);
        $this->assertStringNotContainsString('$_SERVER', $content);
    }
}
```

## 4.3 Bootstrap Flow

### Activation

**What Happens on Plugin Activation:**

```php
// viraloka-core.php
register_activation_hook(__FILE__, function() {
    $installer = new Installer();
    $installer->run();
});
```

**Installation Steps:**

**1. Create Database Tables**
```sql
CREATE TABLE wp_viraloka_workspaces (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    domain VARCHAR(255),
    status VARCHAR(50) DEFAULT 'active',
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE wp_viraloka_tenants (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    settings JSON,
    created_at DATETIME,
    FOREIGN KEY (workspace_id) REFERENCES wp_viraloka_workspaces(id)
);

CREATE TABLE wp_viraloka_workspace_user_roles (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT UNSIGNED NOT NULL,
    user_id BIGINT UNSIGNED NOT NULL,
    role VARCHAR(50) NOT NULL,
    UNIQUE KEY workspace_user (workspace_id, user_id),
    FOREIGN KEY (workspace_id) REFERENCES wp_viraloka_workspaces(id)
);
```

**2. Create Default Workspace**
```php
$workspace = $workspaceRepo->create([
    'name' => 'Default Workspace',
    'slug' => 'default',
    'status' => 'active'
]);
```

**3. Register Capabilities**
```php
$admin = get_role('administrator');
$admin->add_cap('manage_viraloka');
$admin->add_cap('manage_workspaces');
$admin->add_cap('access_workspace');
```

**4. Initialize Core Services**
```php
$kernel = new Kernel($container, $adapterRegistry);
$kernel->boot();
```

### Runtime

**Request Lifecycle:**

**1. Early Bootstrap (WordPress `plugins_loaded`)**
```php
add_action('plugins_loaded', function() {
    $kernel = Kernel::getInstance();
    $kernel->boot();
}, 1);
```

**2. Service Registration**
```php
$kernel->boot() {
    // Register core services
    $this->registerCoreServices();
    
    // Register adapters
    $this->registerAdapters();
    
    // Discover modules
    $this->discoverModules();
}
```

**3. Context Resolution (WordPress `init`)**
```php
add_action('init', function() {
    $contextResolver = $container->make(ContextResolverInterface::class);
    $context = $contextResolver->resolve();
    
    // Store in container
    $container->instance('current.context', $context);
}, 10);
```

**4. Module Bootstrap (WordPress `init`)**
```php
add_action('init', function() {
    $bootstrapper = $container->make(ModuleBootstrapperInterface::class);
    $modules = $registry->getByContext($context);
    
    foreach ($modules as $module) {
        $bootstrapper->bootstrap($module);
    }
}, 20);
```

**5. Request Handling**
```php
// Modules handle their own routes
// Core coordinates via event system
```

### Shutdown

**Cleanup on Request End:**

```php
add_action('shutdown', function() {
    $kernel = Kernel::getInstance();
    $kernel->shutdown();
});
```

**Shutdown Tasks:**
- Flush caches
- Close connections
- Log metrics
- Cleanup temp files

## 4.4 Service Container

### Dependency Resolution

**Auto-Wiring:**

```php
class MyService
{
    public function __construct(
        private ModuleRegistryInterface $registry,
        private ContextResolverInterface $contextResolver
    ) {}
}

// Container auto-resolves dependencies
$service = $container->make(MyService::class);
```

**Manual Binding:**

```php
// Singleton
$container->singleton(
    ModuleRegistryInterface::class,
    ModuleRegistry::class
);

// Factory
$container->bind(LoggerInterface::class, function($container) {
    return new Logger($container->make(StorageAdapterInterface::class));
});

// Instance
$container->instance('config', $configArray);
```

### Lifecycle of Services

**Singleton Services:**
- Created once per request
- Shared across all consumers
- Stateful (can maintain state)

```php
$container->singleton(ModuleRegistryInterface::class, ModuleRegistry::class);

$registry1 = $container->make(ModuleRegistryInterface::class);
$registry2 = $container->make(ModuleRegistryInterface::class);

// $registry1 === $registry2 (same instance)
```

**Transient Services:**
- Created every time resolved
- Not shared
- Stateless (should not maintain state)

```php
$container->bind(RequestHandlerInterface::class, RequestHandler::class);

$handler1 = $container->make(RequestHandlerInterface::class);
$handler2 = $container->make(RequestHandlerInterface::class);

// $handler1 !== $handler2 (different instances)
```

**Scoped Services:**
- Created once per scope (e.g., per workspace)
- Shared within scope
- Isolated between scopes

```php
$container->scoped(
    TenantServiceInterface::class,
    TenantService::class,
    'workspace'
);

// Within workspace 1
$service1 = $container->make(TenantServiceInterface::class);

// Within workspace 2
$service2 = $container->make(TenantServiceInterface::class);

// $service1 !== $service2 (different workspace scopes)
```

## 4.5 Context System

### Context Definition

**Context** adalah label yang mendeskripsikan "mode" atau "environment" aplikasi saat ini.

**Examples:**
- `ecommerce` - E-commerce features active
- `blog` - Blog features active
- `admin` - Admin interface
- `api` - API mode
- `public` - Public-facing

**Context Properties:**
```php
interface ContextInterface
{
    public function getId(): string;
    public function getType(): string;
    public function getPriority(): int;
    public function getModules(): array;
    public function getMetadata(): array;
}
```

### Context Resolution Rules

**Resolution Priority (Highest to Lowest):**

1. **Workspace Configuration**
```php
// Workspace explicitly declares context
$workspace->setContext(['ecommerce', 'blog']);
```

2. **Theme Declaration**
```php
// Theme declares context in theme.json
{
    "viraloka": {
        "context": ["ecommerce"]
    }
}
```

3. **Module Recommendations**
```php
// Module recommends context
{
    "id": "product-catalog",
    "context": {
        "recommends": ["ecommerce"]
    }
}
```

4. **System Defaults**
```php
// Fallback to system defaults
['public', 'system']
```

### Context Fallback

**Fallback Chain:**

```php
$contextStack = $contextResolver->resolve();

// Result: ['ecommerce', 'blog', 'public', 'system']
//          ↑ workspace  ↑ theme  ↑ default ↑ system
```

**Module Filtering:**

```php
// Module requires 'ecommerce' context
{
    "context": {
        "requires": ["ecommerce"]
    }
}

// Only loaded if 'ecommerce' in context stack
if (in_array('ecommerce', $contextStack)) {
    $bootstrapper->bootstrap($module);
}
```

## 4.6 Workspace & Tenant

### Workspace Model

**Workspace** adalah unit isolasi tertinggi dalam Viraloka.

**Properties:**
```php
class Workspace
{
    public int $id;
    public string $name;
    public string $slug;
    public ?string $domain;
    public string $status; // active, suspended, deleted
    public array $settings;
    public DateTime $createdAt;
    public DateTime $updatedAt;
}
```

**Use Cases:**
- Multi-tenant SaaS: Each customer = 1 workspace
- Agency platform: Each agency = 1 workspace
- Internal tools: Company = 1 workspace

### Tenant Isolation

**Tenant** adalah sub-unit dalam workspace.

**Properties:**
```php
class Tenant
{
    public int $id;
    public int $workspaceId;
    public string $name;
    public array $settings;
    public DateTime $createdAt;
}
```

**Isolation Rules:**
- Tenants cannot access other tenants' data
- Workspace admins can access all tenants
- System admins can access all workspaces

**Data Isolation:**
```php
// Automatic tenant filtering
$products = $productRepo->findAll();
// Only returns products for current tenant

// Explicit workspace filtering
$products = $productRepo->findByWorkspace($workspaceId);
```

### Ownership & Permission

**Permission Levels:**

1. **System Admin**
   - Manage all workspaces
   - Access all data
   - Configure platform

2. **Workspace Admin**
   - Manage workspace settings
   - Manage workspace users
   - Access all workspace data

3. **Workspace Member**
   - Access assigned tenants
   - Limited permissions
   - Cannot manage workspace

**Permission Check:**
```php
$boundary = $container->make(PermissionBoundaryInterface::class);

// Check workspace access
if (!$boundary->canAccessWorkspace($userId, $workspaceId)) {
    throw new PermissionDeniedException();
}

// Check tenant access
if (!$boundary->canAccessTenant($userId, $tenantId)) {
    throw new PermissionDeniedException();
}
```

## 4.7 Host Adapter

### Adapter Responsibility

Adapter bertanggung jawab untuk:

1. **Translate Core Contracts to Host APIs**
```php
// Core calls adapter interface
$user = $this->authAdapter->currentUser();

// Adapter translates to WordPress
public function currentUser(): ?User
{
    $wpUser = wp_get_current_user();
    return $this->mapToUser($wpUser);
}
```

2. **Abstract Host-Specific Behavior**
```php
// Core doesn't know about WordPress hooks
$this->eventAdapter->listen('module.loaded', $callback);

// Adapter uses WordPress hooks
public function listen(string $event, callable $callback): void
{
    add_action("viraloka_{$event}", $callback);
}
```

3. **Provide Host Integration**
```php
// Core needs to store data
$this->storageAdapter->set('key', 'value');

// Adapter uses WordPress options
public function set(string $key, mixed $value): bool
{
    return update_option("viraloka_{$key}", $value);
}
```

### WordPress Adapter Overview

**Available Adapters:**

**1. AuthAdapter**
```php
interface AuthAdapterInterface
{
    public function currentUser(): ?User;
    public function authenticate(string $username, string $password): ?User;
    public function verifyNonce(string $nonce, string $action): bool;
    public function hasCapability(int $userId, string $capability): bool;
}
```

**2. StorageAdapter**
```php
interface StorageAdapterInterface
{
    public function get(string $key): mixed;
    public function set(string $key, mixed $value): bool;
    public function delete(string $key): bool;
    public function has(string $key): bool;
}
```

**3. EventAdapter**
```php
interface EventAdapterInterface
{
    public function dispatch(object|string $event, array $data = []): object|array;
    public function listen(string $event, callable $callback, int $priority = 10): void;
}
```

**4. RequestAdapter**
```php
interface RequestAdapterInterface
{
    public function getMethod(): string;
    public function getPath(): string;
    public function getHeader(string $name): ?string;
    public function getQuery(string $key): mixed;
    public function getBody(): array;
}
```

**5. ResponseAdapter**
```php
interface ResponseAdapterInterface
{
    public function json(array $data, int $status = 200): void;
    public function render(string $template, array $data = []): string;
    public function redirect(string $url, int $status = 302): void;
    public function sanitizeHtml(string $html): string;
}
```

**6. RuntimeAdapter**
```php
interface RuntimeAdapterInterface
{
    public function getEnvironment(): string;
    public function isDebugMode(): bool;
    public function getVersion(): string;
    public function getBasePath(): string;
}
```

### Future Engine Adapters

**Portability Strategy:**

```
Core (Pure PHP)
    ↓
Adapter Contracts
    ↓
┌─────────────┬──────────────┬──────────────┐
│  WordPress  │   Laravel    │   Symfony    │
│   Adapter   │   Adapter    │   Adapter    │
└─────────────┴──────────────┴──────────────┘
```

**Laravel Adapter Example:**
```php
class LaravelAuthAdapter implements AuthAdapterInterface
{
    public function currentUser(): ?User
    {
        $laravelUser = Auth::user();
        return $this->mapToUser($laravelUser);
    }
    
    public function authenticate(string $username, string $password): ?User
    {
        if (Auth::attempt(['email' => $username, 'password' => $password])) {
            return $this->currentUser();
        }
        return null;
    }
}
```

**Migration Path:**
1. Implement adapters for new host
2. Test adapter compliance
3. Deploy core + new adapters
4. Migrate data (if needed)
5. Switch host

---

## Next Steps

Ready to build your first module:

→ [Building Modules](05-building-modules.md)

Or dive deeper into context system:

→ [Context-Driven Development](06-context-driven-development.md)
