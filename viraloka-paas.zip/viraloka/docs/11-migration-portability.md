# 11. Migration & Portability

## 11.1 Engine Migration Strategy

Viraloka's adapter pattern enables migration from WordPress to other frameworks with minimal code changes.

### Adapter Replacement

**Migration Process Overview:**

```
1. Implement adapters for new host
2. Test adapter compliance
3. Deploy core + new adapters
4. Migrate data (if needed)
5. Switch host
```

**Step 1: Implement Adapters for New Host**

**Example: Laravel Adapters**

```php
// Laravel Auth Adapter
namespace Viraloka\Adapter\Laravel;

use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface;
use Viraloka\Core\Adapter\ValueObjects\User;
use Illuminate\Support\Facades\Auth;

class LaravelAuthAdapter implements AuthAdapterInterface
{
    public function currentUser(): ?User
    {
        $laravelUser = Auth::user();
        
        if (!$laravelUser) {
            return null;
        }
        
        return new User(
            id: $laravelUser->id,
            email: $laravelUser->email,
            name: $laravelUser->name
        );
    }
    
    public function authenticate(string $username, string $password): ?User
    {
        if (Auth::attempt(['email' => $username, 'password' => $password])) {
            return $this->currentUser();
        }
        
        return null;
    }
    
    public function verifyNonce(string $nonce, string $action): bool
    {
        // Laravel uses CSRF tokens
        return csrf_token() === $nonce;
    }
    
    public function hasCapability(int $userId, string $capability): bool
    {
        $user = \App\Models\User::find($userId);
        return $user?->can($capability) ?? false;
    }
}
```

```php
// Laravel Storage Adapter
namespace Viraloka\Adapter\Laravel;

use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class LaravelStorageAdapter implements StorageAdapterInterface
{
    public function get(string $key): mixed
    {
        return Cache::get("viraloka_{$key}");
    }
    
    public function set(string $key, mixed $value): bool
    {
        return Cache::put("viraloka_{$key}", $value);
    }
    
    public function delete(string $key): bool
    {
        return Cache::forget("viraloka_{$key}");
    }
    
    public function has(string $key): bool
    {
        return Cache::has("viraloka_{$key}");
    }
    
    public function query(string $table, array $conditions): array
    {
        $query = DB::table($table);
        
        foreach ($conditions as $key => $value) {
            if (is_null($value)) {
                $query->whereNull($key);
            } else {
                $query->where($key, $value);
            }
        }
        
        return $query->get()->toArray();
    }
    
    public function insert(string $table, array $data): int
    {
        return DB::table($table)->insertGetId($data);
    }
    
    public function update(string $table, int $id, array $data): bool
    {
        return DB::table($table)->where('id', $id)->update($data) > 0;
    }
    
    public function beginTransaction(): void
    {
        DB::beginTransaction();
    }
    
    public function commit(): void
    {
        DB::commit();
    }
    
    public function rollback(): void
    {
        DB::rollback();
    }
    
    public function execute(string $sql, array $params = []): bool
    {
        return DB::statement($sql, $params);
    }
    
    public function nextId(string $table): int
    {
        $max = DB::table($table)->max('id');
        return ($max ?? 0) + 1;
    }
    
    public function getCapabilities(): array
    {
        return [
            'transactions' => true,
            'foreign_keys' => true,
            'full_text_search' => true,
        ];
    }
}
```

```php
// Laravel Event Adapter
namespace Viraloka\Adapter\Laravel;

use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use Illuminate\Support\Facades\Event;

class LaravelEventAdapter implements EventAdapterInterface
{
    public function dispatch(object|string $event, array $data = []): object|array
    {
        if (is_string($event)) {
            Event::dispatch($event, $data);
            return $data;
        }
        
        Event::dispatch($event);
        return $event;
    }
    
    public function listen(string $event, callable $callback, int $priority = 10): void
    {
        Event::listen($event, $callback);
    }
}
```

**Step 2: Test Adapter Compliance**

```php
// Adapter compliance test suite
namespace Tests\Adapter\Laravel;

use PHPUnit\Framework\TestCase;
use Viraloka\Adapter\Laravel\LaravelAuthAdapter;
use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface;

class LaravelAuthAdapterTest extends TestCase
{
    private AuthAdapterInterface $adapter;
    
    protected function setUp(): void
    {
        $this->adapter = new LaravelAuthAdapter();
    }
    
    public function test_implements_auth_adapter_interface(): void
    {
        $this->assertInstanceOf(AuthAdapterInterface::class, $this->adapter);
    }
    
    public function test_current_user_returns_null_when_not_authenticated(): void
    {
        $user = $this->adapter->currentUser();
        $this->assertNull($user);
    }
    
    public function test_current_user_returns_user_when_authenticated(): void
    {
        // Authenticate user
        Auth::login($this->createTestUser());
        
        $user = $this->adapter->currentUser();
        
        $this->assertNotNull($user);
        $this->assertInstanceOf(User::class, $user);
        $this->assertEquals('test@example.com', $user->email);
    }
    
    public function test_authenticate_with_valid_credentials(): void
    {
        $this->createTestUser('test@example.com', 'password123');
        
        $user = $this->adapter->authenticate('test@example.com', 'password123');
        
        $this->assertNotNull($user);
        $this->assertEquals('test@example.com', $user->email);
    }
    
    public function test_authenticate_with_invalid_credentials(): void
    {
        $user = $this->adapter->authenticate('test@example.com', 'wrong');
        
        $this->assertNull($user);
    }
}
```

**Step 3: Deploy Core + New Adapters**

```php
// Laravel Service Provider
namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Viraloka\Core\Bootstrap\Kernel;
use Viraloka\Core\Adapter\AdapterRegistry;
use Viraloka\Adapter\Laravel\LaravelAuthAdapter;
use Viraloka\Adapter\Laravel\LaravelStorageAdapter;
use Viraloka\Adapter\Laravel\LaravelEventAdapter;
use Viraloka\Adapter\Laravel\LaravelRequestAdapter;
use Viraloka\Adapter\Laravel\LaravelResponseAdapter;
use Viraloka\Adapter\Laravel\LaravelRuntimeAdapter;

class ViralokaServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register adapter registry
        $this->app->singleton(AdapterRegistry::class, function() {
            $registry = new AdapterRegistry();
            
            // Register Laravel adapters
            $registry->register('auth', new LaravelAuthAdapter());
            $registry->register('storage', new LaravelStorageAdapter());
            $registry->register('event', new LaravelEventAdapter());
            $registry->register('request', new LaravelRequestAdapter());
            $registry->register('response', new LaravelResponseAdapter());
            $registry->register('runtime', new LaravelRuntimeAdapter());
            
            return $registry;
        });
        
        // Register Viraloka kernel
        $this->app->singleton(Kernel::class, function($app) {
            $container = $app->make(\Viraloka\Container\Container::class);
            $adapters = $app->make(AdapterRegistry::class);
            
            return new Kernel($container, $adapters);
        });
    }
    
    public function boot(): void
    {
        // Boot Viraloka
        $kernel = $this->app->make(Kernel::class);
        $kernel->boot();
    }
}
```

**Step 4: Migrate Data**

```php
// Data migration script
namespace App\Console\Commands;

use Illuminate\Console\Command;

class MigrateFromWordPress extends Command
{
    protected $signature = 'viraloka:migrate-from-wordpress';
    protected $description = 'Migrate data from WordPress to Laravel';
    
    public function handle(): void
    {
        $this->info('Starting migration from WordPress...');
        
        // Connect to WordPress database
        $wpDb = DB::connection('wordpress');
        
        // Migrate workspaces
        $this->migrateWorkspaces($wpDb);
        
        // Migrate tenants
        $this->migrateTenants($wpDb);
        
        // Migrate users
        $this->migrateUsers($wpDb);
        
        // Migrate module data
        $this->migrateModuleData($wpDb);
        
        $this->info('Migration completed!');
    }
    
    private function migrateWorkspaces($wpDb): void
    {
        $this->info('Migrating workspaces...');
        
        $workspaces = $wpDb->table('wp_viraloka_workspaces')->get();
        
        foreach ($workspaces as $workspace) {
            DB::table('workspaces')->insert([
                'id' => $workspace->id,
                'name' => $workspace->name,
                'slug' => $workspace->slug,
                'domain' => $workspace->domain,
                'status' => $workspace->status,
                'settings' => $workspace->settings,
                'created_at' => $workspace->created_at,
                'updated_at' => $workspace->updated_at,
            ]);
        }
        
        $this->info("Migrated {$workspaces->count()} workspaces");
    }
    
    private function migrateUsers($wpDb): void
    {
        $this->info('Migrating users...');
        
        $users = $wpDb->table('wp_users')->get();
        
        foreach ($users as $wpUser) {
            \App\Models\User::create([
                'id' => $wpUser->ID,
                'name' => $wpUser->display_name,
                'email' => $wpUser->user_email,
                'password' => $wpUser->user_pass, // Already hashed
                'created_at' => $wpUser->user_registered,
            ]);
        }
        
        $this->info("Migrated {$users->count()} users");
    }
}
```

**Step 5: Switch Host**

```php
// Update configuration
// .env
APP_HOST=laravel
VIRALOKA_ADAPTER_PATH=Viraloka\Adapter\Laravel

// config/viraloka.php
return [
    'host' => env('APP_HOST', 'laravel'),
    'adapter_namespace' => env('VIRALOKA_ADAPTER_PATH', 'Viraloka\Adapter\Laravel'),
];
```

## 11.2 What is Portable

### Contracts

**100% Portable:**

All interface definitions are pure PHP and host-agnostic.

```php
// ✅ Portable: Interface definition
namespace Viraloka\Core\Adapter\Contracts;

interface AuthAdapterInterface
{
    public function currentUser(): ?User;
    public function authenticate(string $username, string $password): ?User;
    public function verifyNonce(string $nonce, string $action): bool;
    public function hasCapability(int $userId, string $capability): bool;
}
```

**Migration Impact:** None - interfaces don't change

### Logic

**95% Portable:**

Core business logic is portable with minimal changes.

```php
// ✅ Portable: Business logic
namespace Viraloka\Core\Services;

class ProductService
{
    public function __construct(
        private ProductRepositoryInterface $products,
        private EventAdapterInterface $events
    ) {}
    
    public function createProduct(array $data): Product
    {
        // Pure business logic - works on any host
        $product = new Product($data);
        
        $this->products->save($product);
        
        $this->events->dispatch('product.created', [
            'product' => $product
        ]);
        
        return $product;
    }
}
```

**Migration Impact:** None - business logic stays the same

### Domain Models

**100% Portable:**

```php
// ✅ Portable: Domain entity
namespace MyModule\Domain\Entities;

class Product
{
    public function __construct(
        private int $id,
        private string $name,
        private Money $price,
        private int $stock
    ) {}
    
    public function reduceStock(int $quantity): void
    {
        if ($quantity > $this->stock) {
            throw new InsufficientStockException();
        }
        
        $this->stock -= $quantity;
    }
    
    // Pure domain logic - no host dependencies
}
```

**Migration Impact:** None - domain models are pure PHP

### Module Manifests

**100% Portable:**

```json
{
  "id": "product-catalog",
  "name": "Product Catalog",
  "version": "1.0.0",
  "type": "feature",
  "context": {
    "provides": ["ecommerce", "catalog"]
  },
  "dependencies": {
    "requires": {
      "viraloka-core": "^1.0"
    }
  }
}
```

**Migration Impact:** None - manifest format is host-agnostic

## 11.3 What is Not Portable

### UI Assumptions

**WordPress-Specific UI:**

```php
// ❌ Not portable: WordPress admin UI
class ProductAdminPage
{
    public function render(): void
    {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('product_options'); ?>
                <?php do_settings_sections('product_options'); ?>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
```

**Migration Impact:** High - needs complete rewrite for Laravel

**Laravel-Specific UI:**

```php
// ✅ Portable approach: Use templates
class ProductAdminPage
{
    public function __construct(
        private ResponseAdapterInterface $response
    ) {}
    
    public function render(): string
    {
        return $this->response->render('admin.products.index', [
            'products' => $this->getProducts()
        ]);
    }
}

// WordPress template: resources/views/admin/products/index.php
// Laravel template: resources/views/admin/products/index.blade.php
```

**Migration Impact:** Low - only template syntax changes

### Host-Specific Features

**WordPress Hooks:**

```php
// ❌ Not portable: Direct WordPress hooks
add_action('init', function() {
    register_post_type('product', []);
});

add_filter('the_content', function($content) {
    return $content . '<div>Advertisement</div>';
});
```

**Migration Impact:** High - Laravel doesn't have hooks

**Portable Alternative:**

```php
// ✅ Portable: Use event adapter
$this->events->listen('viraloka.init', function() {
    $this->registerProductType();
});

$this->events->listen('content.render', function($content) {
    return $content . '<div>Advertisement</div>';
});
```

### Database Schema Specifics

**WordPress-Specific:**

```sql
-- WordPress uses wp_ prefix
CREATE TABLE wp_viraloka_products (
    ID BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    post_title VARCHAR(255),
    post_content TEXT
);
```

**Laravel-Specific:**

```sql
-- Laravel uses standard naming
CREATE TABLE products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

**Migration Impact:** Medium - schema needs conversion, but data is portable

### Asset Management

**WordPress:**

```php
// WordPress asset loading
wp_enqueue_script('product-admin', 
    plugins_url('assets/js/admin.js', __FILE__),
    ['jquery'],
    '1.0.0'
);
```

**Laravel:**

```php
// Laravel asset loading
<script src="{{ asset('js/admin.js') }}"></script>
```

**Migration Impact:** Medium - asset loading code needs rewrite

## Migration Checklist

**Pre-Migration:**
- [ ] Audit code for WordPress-specific functions
- [ ] Identify UI components that need rewrite
- [ ] Document custom database schema
- [ ] List all third-party integrations
- [ ] Create adapter compliance tests

**During Migration:**
- [ ] Implement all adapter interfaces
- [ ] Run adapter compliance tests
- [ ] Migrate database schema
- [ ] Migrate data
- [ ] Rewrite UI components
- [ ] Update asset loading
- [ ] Test all modules

**Post-Migration:**
- [ ] Verify all features work
- [ ] Performance testing
- [ ] Security audit
- [ ] Update documentation
- [ ] Train team on new platform

---

## Next Steps

Learn about AI integration:

→ [AI & Automation](12-ai-automation.md)

Or explore contribution guidelines:

→ [Contribution & Governance](13-contribution-governance.md)
