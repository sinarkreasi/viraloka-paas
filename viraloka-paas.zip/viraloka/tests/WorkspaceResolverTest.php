<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Workspace\WorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;

/**
 * Unit Tests for Workspace Resolver
 * 
 * Tests specific resolution strategies and edge cases.
 * Requirements: 6.2, 6.3, 6.4, 6.5
 */
class WorkspaceResolverTest extends TestCase
{
    protected function tearDown(): void
    {
        // Clean up server variables after each test
        unset($_SERVER['HTTP_HOST']);
        unset($_SERVER['REQUEST_URI']);
        unset($_SERVER['SERVER_NAME']);
    }
    
    /**
     * Test domain-based resolution
     * Requirements: 6.2
     */
    public function testDomainBasedResolution(): void
    {
        $_SERVER['HTTP_HOST'] = 'tenant1.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => ['setting' => 'value1'],
                'enabled_modules' => ['module1', 'module2'],
                'context' => 'tenant1'
            ],
            [
                'id' => 'workspace-2',
                'name' => 'Tenant 2 Workspace',
                'domain' => 'tenant2.example.com',
                'config' => ['setting' => 'value2'],
                'enabled_modules' => ['module3'],
                'context' => 'tenant2'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
        $this->assertSame('Tenant 1 Workspace', $workspace->name);
        $this->assertSame('tenant1.example.com', $workspace->domain);
        $this->assertEquals(['setting' => 'value1'], $workspace->config);
        $this->assertEquals(['module1', 'module2'], $workspace->enabledModules);
        $this->assertSame('tenant1', $workspace->context);
    }
    
    /**
     * Test subdomain-based resolution fallback
     * Requirements: 6.3
     */
    public function testSubdomainBasedResolutionFallback(): void
    {
        $_SERVER['HTTP_HOST'] = 'tenant1.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        // No exact domain match, but subdomain match exists
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'subdomain' => 'tenant1',
                'config' => ['setting' => 'value1'],
                'enabled_modules' => ['module1'],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
        $this->assertSame('Tenant 1 Workspace', $workspace->name);
    }
    
    /**
     * Test path-based resolution fallback
     * Requirements: 6.4
     */
    public function testPathBasedResolutionFallback(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com';
        $_SERVER['REQUEST_URI'] = '/tenant1/dashboard';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        // No domain or subdomain match, but path match exists
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'path' => 'tenant1',
                'config' => ['setting' => 'value1'],
                'enabled_modules' => ['module1'],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
        $this->assertSame('Tenant 1 Workspace', $workspace->name);
    }
    
    /**
     * Test default workspace fallback
     * Requirements: 6.5
     */
    public function testDefaultWorkspaceFallback(): void
    {
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        // No matching workspace, should return default
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('default', $workspace->id);
        $this->assertSame('Default Workspace', $workspace->name);
    }
    
    /**
     * Test configured default workspace
     * Requirements: 6.5
     */
    public function testConfiguredDefaultWorkspace(): void
    {
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        // Configured default workspace
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ],
            [
                'id' => 'default-workspace',
                'name' => 'Configured Default',
                'is_default' => true,
                'config' => ['default' => true],
                'enabled_modules' => ['core'],
                'context' => 'default'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('default-workspace', $workspace->id);
        $this->assertSame('Configured Default', $workspace->name);
        $this->assertEquals(['default' => true], $workspace->config);
        $this->assertEquals(['core'], $workspace->enabledModules);
    }
    
    /**
     * Test workspace injection into container
     * Requirements: 6.5
     */
    public function testWorkspaceInjectionIntoContainer(): void
    {
        $_SERVER['HTTP_HOST'] = 'tenant1.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        // Inject workspace into container
        $app->instance(Workspace::class, $workspace);
        
        // Verify workspace can be retrieved from container
        $retrievedWorkspace = $app->make(Workspace::class);
        
        $this->assertInstanceOf(Workspace::class, $retrievedWorkspace);
        $this->assertSame($workspace->id, $retrievedWorkspace->id);
        $this->assertSame($workspace->name, $retrievedWorkspace->name);
    }
    
    /**
     * Test resolution with SERVER_NAME fallback
     */
    public function testResolutionWithServerNameFallback(): void
    {
        // HTTP_HOST not set, should use SERVER_NAME
        $_SERVER['SERVER_NAME'] = 'tenant1.example.com';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
    }
    
    /**
     * Test resolution with no server variables
     */
    public function testResolutionWithNoServerVariables(): void
    {
        // No server variables set
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        // Should return default workspace
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('default', $workspace->id);
    }
    
    /**
     * Test path resolution with query string
     */
    public function testPathResolutionWithQueryString(): void
    {
        $_SERVER['HTTP_HOST'] = 'example.com';
        $_SERVER['REQUEST_URI'] = '/tenant1/page?param=value';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'path' => 'tenant1',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
    }
    
    /**
     * Test case-insensitive domain matching
     */
    public function testCaseInsensitiveDomainMatching(): void
    {
        $_SERVER['HTTP_HOST'] = 'TENANT1.EXAMPLE.COM';
        
        $app = new Application(__DIR__);
        $resolver = new WorkspaceResolver($app);
        
        $resolver->setWorkspaceConfig([
            [
                'id' => 'workspace-1',
                'name' => 'Tenant 1 Workspace',
                'domain' => 'tenant1.example.com',
                'config' => [],
                'enabled_modules' => [],
                'context' => 'tenant1'
            ]
        ]);
        
        $workspace = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $workspace);
        $this->assertSame('workspace-1', $workspace->id);
    }
}
