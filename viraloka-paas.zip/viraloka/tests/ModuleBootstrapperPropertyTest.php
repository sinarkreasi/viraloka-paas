<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Modules\ModuleBootstrapper;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ResolutionResult;
use Viraloka\Core\Providers\ServiceProvider;

/**
 * Module Bootstrapper Property Test
 * 
 * Property-based tests for ModuleBootstrapper functionality.
 * Feature: core-bootstrap-flow
 */
class ModuleBootstrapperPropertyTest extends TestCase
{
    protected static array $bootOrder = [];
    
    protected function setUp(): void
    {
        self::$bootOrder = [];
    }
    
    /**
     * Property 18: Module Boot Dependency Order
     * 
     * For any set of active modules with dependencies, the Module Bootstrapper
     * SHALL boot them in dependency order.
     * 
     * Validates: Requirements 9.1
     * Feature: core-bootstrap-flow, Property 18: Module Boot Dependency Order
     */
    public function testModuleBootDependencyOrder(): void
    {
        // Test Case 1: Linear dependency chain (A -> B -> C)
        self::$bootOrder = [];
        $this->runDependencyOrderTest([
            ['id' => 'module.a', 'deps' => []],
            ['id' => 'module.b', 'deps' => ['module.a']],
            ['id' => 'module.c', 'deps' => ['module.b']],
        ]);
        
        // Verify A comes before B, and B comes before C
        $indexA = array_search('module.a', self::$bootOrder);
        $indexB = array_search('module.b', self::$bootOrder);
        $indexC = array_search('module.c', self::$bootOrder);
        
        $this->assertNotFalse($indexA);
        $this->assertNotFalse($indexB);
        $this->assertNotFalse($indexC);
        $this->assertLessThan($indexB, $indexA, 'module.a must come before module.b');
        $this->assertLessThan($indexC, $indexB, 'module.b must come before module.c');
        
        // Test Case 2: Diamond dependency (A <- B, A <- C, B,C <- D)
        self::$bootOrder = [];
        $this->runDependencyOrderTest([
            ['id' => 'module.d', 'deps' => ['module.b', 'module.c']],
            ['id' => 'module.b', 'deps' => ['module.a']],
            ['id' => 'module.c', 'deps' => ['module.a']],
            ['id' => 'module.a', 'deps' => []],
        ]);
        
        // Verify A comes before B and C, and both B and C come before D
        $indexA = array_search('module.a', self::$bootOrder);
        $indexB = array_search('module.b', self::$bootOrder);
        $indexC = array_search('module.c', self::$bootOrder);
        $indexD = array_search('module.d', self::$bootOrder);
        
        $this->assertNotFalse($indexA);
        $this->assertNotFalse($indexB);
        $this->assertNotFalse($indexC);
        $this->assertNotFalse($indexD);
        $this->assertLessThan($indexB, $indexA, 'module.a must come before module.b');
        $this->assertLessThan($indexC, $indexA, 'module.a must come before module.c');
        $this->assertLessThan($indexD, $indexB, 'module.b must come before module.d');
        $this->assertLessThan($indexD, $indexC, 'module.c must come before module.d');
        
        // Test Case 3: Multiple independent chains
        self::$bootOrder = [];
        $this->runDependencyOrderTest([
            ['id' => 'module.a', 'deps' => []],
            ['id' => 'module.b', 'deps' => ['module.a']],
            ['id' => 'module.x', 'deps' => []],
            ['id' => 'module.y', 'deps' => ['module.x']],
        ]);
        
        // Verify A comes before B, and X comes before Y
        $indexA = array_search('module.a', self::$bootOrder);
        $indexB = array_search('module.b', self::$bootOrder);
        $indexX = array_search('module.x', self::$bootOrder);
        $indexY = array_search('module.y', self::$bootOrder);
        
        $this->assertNotFalse($indexA);
        $this->assertNotFalse($indexB);
        $this->assertNotFalse($indexX);
        $this->assertNotFalse($indexY);
        $this->assertLessThan($indexB, $indexA, 'module.a must come before module.b');
        $this->assertLessThan($indexY, $indexX, 'module.x must come before module.y');
    }
    
    /**
     * Property 19: Service Provider Instantiation
     * 
     * For any active module, the Module Bootstrapper SHALL instantiate its
     * service provider during the ready phase.
     * 
     * Validates: Requirements 9.2
     * Feature: core-bootstrap-flow, Property 19: Service Provider Instantiation
     */
    public function testServiceProviderInstantiation(): void
    {
        $app = new Application();
        $registry = new ModuleRegistry();
        $bootstrapper = new ModuleBootstrapper($app, $registry);
        
        // Create multiple modules
        $moduleIds = ['module.a', 'module.b', 'module.c'];
        
        foreach ($moduleIds as $moduleId) {
            $manifest = $this->createManifest([
                'id' => $moduleId,
                'lifecycle' => [
                    'provider' => PropertyTestServiceProvider::class,
                    'boot' => true
                ]
            ]);
            
            $module = new Module($manifest, new ResolutionResult());
            $registry->register($module);
        }
        
        // Bootstrap all modules
        $bootstrapper->bootstrapAll();
        
        // Verify all modules have providers instantiated
        foreach ($registry->all() as $module) {
            $this->assertNotNull($module->provider, "Module {$module->getId()} should have provider instantiated");
            $this->assertInstanceOf(ServiceProvider::class, $module->provider);
        }
    }
    
    /**
     * Property 20: Service Provider Lifecycle
     * 
     * For any instantiated service provider, the Module Bootstrapper SHALL call
     * its register() method before its boot() method.
     * 
     * Validates: Requirements 9.3
     * Feature: core-bootstrap-flow, Property 20: Service Provider Lifecycle
     */
    public function testServiceProviderLifecycle(): void
    {
        $app = new Application();
        $registry = new ModuleRegistry();
        $bootstrapper = new ModuleBootstrapper($app, $registry);
        
        // Reset lifecycle tracking
        LifecycleTrackingProvider::$calls = [];
        
        // Create module with lifecycle tracking provider
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => LifecycleTrackingProvider::class,
                'boot' => true
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        $registry->register($module);
        
        // Bootstrap the module
        $bootstrapper->bootstrapAll();
        
        // Verify register was called before boot
        $this->assertCount(2, LifecycleTrackingProvider::$calls);
        $this->assertEquals('register', LifecycleTrackingProvider::$calls[0]);
        $this->assertEquals('boot', LifecycleTrackingProvider::$calls[1]);
    }
    
    /**
     * Property 21: Module Failure Isolation
     * 
     * For any module that fails during boot, the Module Bootstrapper SHALL log
     * the error and continue booting remaining modules.
     * 
     * Validates: Requirements 9.4
     * Feature: core-bootstrap-flow, Property 21: Module Failure Isolation
     */
    public function testModuleFailureIsolation(): void
    {
        $app = new Application();
        $registry = new ModuleRegistry();
        $bootstrapper = new ModuleBootstrapper($app, $registry);
        
        // Create modules: one that fails, and others that succeed
        $modules = [
            ['id' => 'module.good1', 'provider' => PropertyTestServiceProvider::class],
            ['id' => 'module.bad', 'provider' => FailingServiceProvider::class],
            ['id' => 'module.good2', 'provider' => PropertyTestServiceProvider::class],
        ];
        
        foreach ($modules as $moduleData) {
            $manifest = $this->createManifest([
                'id' => $moduleData['id'],
                'lifecycle' => [
                    'provider' => $moduleData['provider'],
                    'boot' => true
                ]
            ]);
            
            $module = new Module($manifest, new ResolutionResult());
            $registry->register($module);
        }
        
        // Bootstrap all modules (should not throw exception)
        $bootstrapper->bootstrapAll();
        
        // Verify good modules were bootstrapped
        $this->assertTrue($bootstrapper->isBootstrapped('module.good1'));
        $this->assertTrue($bootstrapper->isBootstrapped('module.good2'));
        
        // Verify bad module was not bootstrapped
        $this->assertFalse($bootstrapper->isBootstrapped('module.bad'));
        
        // Verify boot phase is complete despite failure
        $this->assertTrue($bootstrapper->isBootPhaseComplete());
    }
    
    /**
     * Run a dependency order test with given modules
     */
    protected function runDependencyOrderTest(array $modulesData): void
    {
        $app = new Application();
        $registry = new ModuleRegistry();
        $bootstrapper = new ModuleBootstrapper($app, $registry);
        
        // Create modules and register them
        foreach ($modulesData as $moduleData) {
            $manifest = $this->createManifest([
                'id' => $moduleData['id'],
                'dependencies' => [
                    'modules' => $moduleData['deps']
                ],
                'lifecycle' => [
                    'provider' => OrderTrackingServiceProvider::class,
                    'boot' => true
                ]
            ]);
            
            $module = new Module($manifest, new ResolutionResult());
            $registry->register($module);
        }
        
        // Bootstrap all modules
        $bootstrapper->bootstrapAll();
    }
    
    /**
     * Helper to create a manifest
     */
    protected function createManifest(array $data): Manifest
    {
        $defaults = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module'
        ];
        
        return new Manifest(array_merge($defaults, $data), '/test/path');
    }
}

/**
 * Service Provider that tracks boot order
 */
class OrderTrackingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Track when this module is registered
        // We need to get the module ID somehow - use a binding
        $moduleId = $this->findModuleId();
        if ($moduleId) {
            ModuleBootstrapperPropertyTest::$bootOrder[] = $moduleId;
        }
    }
    
    public function boot(): void
    {
        // Boot method
    }
    
    protected function findModuleId(): ?string
    {
        // Try to find module ID from debug backtrace
        $trace = debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT, 10);
        
        foreach ($trace as $frame) {
            if (isset($frame['object']) && $frame['object'] instanceof Module) {
                return $frame['object']->getId();
            }
            if (isset($frame['args'])) {
                foreach ($frame['args'] as $arg) {
                    if ($arg instanceof Module) {
                        return $arg->getId();
                    }
                }
            }
        }
        
        return null;
    }
}

/**
 * Simple service provider for property tests
 */
class PropertyTestServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Register something
        $this->app->bind('test.service', fn() => 'test');
    }
    
    public function boot(): void
    {
        // Boot method
    }
}

/**
 * Service provider that tracks lifecycle calls
 */
class LifecycleTrackingProvider extends ServiceProvider
{
    public static array $calls = [];
    
    public function register(): void
    {
        self::$calls[] = 'register';
    }
    
    public function boot(): void
    {
        self::$calls[] = 'boot';
    }
}

/**
 * Service provider that fails during register
 */
class FailingServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        throw new \RuntimeException('Intentional failure for testing');
    }
    
    public function boot(): void
    {
        // Should not be called
    }
}
