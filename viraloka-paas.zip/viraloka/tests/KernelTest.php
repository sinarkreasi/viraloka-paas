<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\Kernel;

/**
 * Kernel Test
 * 
 * Tests the Kernel class functionality including:
 * - Kernel instantiation with Application
 * - Lifecycle event dispatching
 * - Bootstrap state flag management
 */
class KernelTest extends TestCase
{
    protected Application $app;
    protected Kernel $kernel;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Reset WordPress actions global
        global $wp_actions;
        $wp_actions = [];
        
        // Create application instance
        $this->app = new Application(__DIR__);
        
        // Create kernel instance
        $this->kernel = new Kernel($this->app);
    }
    
    /**
     * Test that Kernel can be instantiated with Application
     * 
     * Validates: Requirements 2.1
     */
    public function testKernelInstantiationWithApplication(): void
    {
        $kernel = new Kernel($this->app);
        
        $this->assertInstanceOf(Kernel::class, $kernel);
        $this->assertFalse($kernel->isBootstrapped());
    }
    
    /**
     * Test that lifecycle events are dispatched during bootstrap
     * 
     * Validates: Requirements 14.1, 14.2, 14.3
     */
    public function testLifecycleEventDispatching(): void
    {
        // Bootstrap the kernel
        $this->kernel->bootstrap();
        
        // Assert all three lifecycle events were dispatched
        $this->assertEquals(1, did_action('viraloka.bootstrap.register'));
        $this->assertEquals(1, did_action('viraloka.bootstrap.boot'));
        $this->assertEquals(1, did_action('viraloka.bootstrap.ready'));
    }
    
    /**
     * Test that bootstrap state flag is managed correctly
     * 
     * Validates: Requirements 2.2
     */
    public function testBootstrapStateFlagManagement(): void
    {
        // Initially not bootstrapped
        $this->assertFalse($this->kernel->isBootstrapped());
        
        // Bootstrap the kernel
        $this->kernel->bootstrap();
        
        // Now bootstrapped
        $this->assertTrue($this->kernel->isBootstrapped());
    }
    
    /**
     * Test that bootstrap can only run once (idempotence)
     * 
     * Validates: Requirements 11.5
     */
    public function testBootstrapIdempotence(): void
    {
        // Bootstrap once
        $this->kernel->bootstrap();
        
        // Bootstrap again
        $this->kernel->bootstrap();
        
        // Each event should only have been dispatched once
        $this->assertEquals(1, did_action('viraloka.bootstrap.register'));
        $this->assertEquals(1, did_action('viraloka.bootstrap.boot'));
        $this->assertEquals(1, did_action('viraloka.bootstrap.ready'));
    }
    
    /**
     * Test that lifecycle phases are tracked correctly
     */
    public function testLifecyclePhaseTracking(): void
    {
        // Before bootstrap, no phase is set
        $this->assertEquals('', $this->kernel->getCurrentPhase());
        
        // After bootstrap, should be in ready phase
        $this->kernel->bootstrap();
        $this->assertEquals('ready', $this->kernel->getCurrentPhase());
    }
    
    /**
     * Test that viraloka.ready event is dispatched
     * 
     * Validates: Requirements 11.1
     */
    public function testReadyEventDispatch(): void
    {
        // Bootstrap the kernel
        $this->kernel->bootstrap();
        
        // Assert viraloka.ready event was dispatched
        $this->assertEquals(1, did_action('viraloka.ready'));
    }
    
    /**
     * Test that ready state flag is set correctly
     * 
     * Validates: Requirements 11.3
     */
    public function testReadyStateFlag(): void
    {
        // Initially not ready
        $this->assertFalse($this->kernel->isReady());
        
        // Bootstrap the kernel
        $this->kernel->bootstrap();
        
        // Now ready
        $this->assertTrue($this->kernel->isReady());
    }
    
    /**
     * Test that isReady() method works correctly
     * 
     * Validates: Requirements 11.4
     */
    public function testIsReadyMethod(): void
    {
        // Before bootstrap
        $this->assertFalse($this->kernel->isReady());
        $this->assertFalse($this->kernel->isBootstrapped());
        
        // After bootstrap
        $this->kernel->bootstrap();
        $this->assertTrue($this->kernel->isReady());
        $this->assertTrue($this->kernel->isBootstrapped());
    }
}
