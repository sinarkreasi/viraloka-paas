<?php

namespace Viraloka\Tests\Context;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\ContextStack;
use Viraloka\Core\Context\ContextInterface;
use Viraloka\Core\Context\WorkspaceContext;
use Viraloka\Core\Context\ThemeContext;
use Viraloka\Core\Context\SystemDefaultContext;

/**
 * Unit Tests for Context Stack Builder
 * 
 * Tests the ContextStackBuilder implementation including normalization,
 * priority ordering, deduplication, and edge cases.
 * 
 * Validates: Requirements 1.4, 1.5, 2.5, 10.1, 10.5
 */
class ContextStackBuilderTest extends TestCase
{
    private ContextStackBuilder $builder;
    
    protected function setUp(): void
    {
        $this->builder = new ContextStackBuilder();
    }
    
    /**
     * Test building with all valid sources
     * 
     * Validates: Requirements 1.5, 2.5
     */
    public function testBuildWithAllValidSources(): void
    {
        $sources = [
            new WorkspaceContext('marketplace', ['workspace_id' => 'ws_123']),
            new ThemeContext('digital', ['theme_name' => 'modern']),
            new SystemDefaultContext('default')
        ];
        
        $stack = $this->builder->build($sources);
        
        $this->assertInstanceOf(ContextStack::class, $stack);
        $this->assertTrue($stack->isFrozen());
        $this->assertCount(3, $stack->getAll());
        
        // Verify priority ordering
        $contexts = $stack->getAll();
        $this->assertEquals('marketplace', $contexts[0]->getKey());
        $this->assertEquals(100, $contexts[0]->getPriority());
        $this->assertEquals('digital', $contexts[1]->getKey());
        $this->assertEquals(50, $contexts[1]->getPriority());
        $this->assertEquals('default', $contexts[2]->getKey());
        $this->assertEquals(10, $contexts[2]->getPriority());
    }
    
    /**
     * Test building with mixed valid/invalid sources
     * 
     * Validates: Requirements 1.4
     */
    public function testBuildWithMixedValidInvalidSources(): void
    {
        $sources = [
            new WorkspaceContext('marketplace'),
            'invalid_string',
            new ThemeContext('digital'),
            null,
            new SystemDefaultContext(),
            42,
            ['array' => 'invalid']
        ];
        
        $stack = $this->builder->build($sources);
        
        $this->assertInstanceOf(ContextStack::class, $stack);
        $this->assertCount(3, $stack->getAll());
        
        // Verify only valid sources were included
        $contexts = $stack->getAll();
        $this->assertInstanceOf(ContextInterface::class, $contexts[0]);
        $this->assertInstanceOf(ContextInterface::class, $contexts[1]);
        $this->assertInstanceOf(ContextInterface::class, $contexts[2]);
    }
    
    /**
     * Test building with empty sources
     * 
     * Edge case: Empty source array
     */
    public function testBuildWithEmptySources(): void
    {
        $stack = $this->builder->build([]);
        
        $this->assertInstanceOf(ContextStack::class, $stack);
        $this->assertTrue($stack->isFrozen());
        $this->assertCount(0, $stack->getAll());
        $this->assertNull($stack->getPrimary());
    }
    
    /**
     * Test building with duplicate keys at different priorities
     * 
     * Validates: Requirements 10.1
     */
    public function testBuildWithDuplicateKeysAtDifferentPriorities(): void
    {
        $sources = [
            new WorkspaceContext('marketplace', ['source' => 'workspace']),
            new ThemeContext('marketplace', ['source' => 'theme']),
            new SystemDefaultContext('marketplace')
        ];
        
        $stack = $this->builder->build($sources);
        
        // Should only have one context after deduplication
        $this->assertCount(1, $stack->getAll());
        
        // Should keep the highest priority (workspace)
        $primary = $stack->getPrimary();
        $this->assertEquals('marketplace', $primary->getKey());
        $this->assertEquals(100, $primary->getPriority());
        $this->assertEquals('workspace', $primary->getMetadata()['source']);
    }
    
    /**
     * Test priority ordering with multiple contexts
     * 
     * Validates: Requirements 2.5, 10.5
     */
    public function testPriorityOrderingWithMultipleContexts(): void
    {
        $sources = [
            new SystemDefaultContext('default'),
            new WorkspaceContext('marketplace'),
            new ThemeContext('digital'),
            new WorkspaceContext('ai-service'),
            new ThemeContext('minimal')
        ];
        
        $stack = $this->builder->build($sources);
        $contexts = $stack->getAll();
        
        // Verify descending priority order
        $previousPriority = PHP_INT_MAX;
        foreach ($contexts as $context) {
            $currentPriority = $context->getPriority();
            $this->assertLessThanOrEqual($previousPriority, $currentPriority);
            $previousPriority = $currentPriority;
        }
        
        // Verify workspace contexts come first
        $this->assertEquals(100, $contexts[0]->getPriority());
        $this->assertEquals(100, $contexts[1]->getPriority());
        
        // Then theme contexts
        $this->assertEquals(50, $contexts[2]->getPriority());
        $this->assertEquals(50, $contexts[3]->getPriority());
        
        // Finally system default
        $this->assertEquals(10, $contexts[4]->getPriority());
    }
    
    /**
     * Test deduplication keeps highest priority
     * 
     * Validates: Requirements 10.1
     */
    public function testDeduplicationKeepsHighestPriority(): void
    {
        $sources = [
            new ThemeContext('shared-key', ['priority_level' => 'medium']),
            new WorkspaceContext('shared-key', ['priority_level' => 'high']),
            new SystemDefaultContext('shared-key')
        ];
        
        $stack = $this->builder->build($sources);
        
        $this->assertCount(1, $stack->getAll());
        
        $context = $stack->getPrimary();
        $this->assertEquals('shared-key', $context->getKey());
        $this->assertEquals(100, $context->getPriority());
        $this->assertEquals('high', $context->getMetadata()['priority_level']);
    }
    
    /**
     * Test stack is frozen after build
     * 
     * Validates: Requirements 2.5
     */
    public function testStackIsFrozenAfterBuild(): void
    {
        $sources = [
            new WorkspaceContext('marketplace')
        ];
        
        $stack = $this->builder->build($sources);
        
        $this->assertTrue($stack->isFrozen());
    }
    
    /**
     * Test building with only invalid sources
     * 
     * Edge case: All sources are invalid
     */
    public function testBuildWithOnlyInvalidSources(): void
    {
        $sources = [
            'string',
            42,
            null,
            ['array'],
            new \stdClass()
        ];
        
        $stack = $this->builder->build($sources);
        
        $this->assertInstanceOf(ContextStack::class, $stack);
        $this->assertCount(0, $stack->getAll());
        $this->assertTrue($stack->isFrozen());
    }
    
    /**
     * Test multiple duplicates with same priority
     * 
     * Edge case: Multiple contexts with same key and priority
     */
    public function testMultipleDuplicatesWithSamePriority(): void
    {
        $sources = [
            new WorkspaceContext('marketplace', ['instance' => '1']),
            new WorkspaceContext('marketplace', ['instance' => '2']),
            new WorkspaceContext('marketplace', ['instance' => '3'])
        ];
        
        $stack = $this->builder->build($sources);
        
        // Should keep only the first one encountered after sorting
        $this->assertCount(1, $stack->getAll());
        
        $context = $stack->getPrimary();
        $this->assertEquals('marketplace', $context->getKey());
        $this->assertEquals(100, $context->getPriority());
    }
    
    /**
     * Test complex scenario with multiple duplicates at different priorities
     * 
     * Validates: Requirements 1.4, 1.5, 10.1, 10.5
     */
    public function testComplexScenarioWithMultipleDuplicates(): void
    {
        $sources = [
            new SystemDefaultContext('context-a'),
            new WorkspaceContext('context-b'),
            new ThemeContext('context-a'),
            new WorkspaceContext('context-c'),
            new ThemeContext('context-b'),
            new SystemDefaultContext('context-c'),
            new WorkspaceContext('context-a')
        ];
        
        $stack = $this->builder->build($sources);
        
        // Should have 3 unique contexts
        $this->assertCount(3, $stack->getAll());
        
        $contexts = $stack->getAll();
        
        // All should be workspace priority (highest for each key)
        $this->assertEquals('context-a', $contexts[0]->getKey());
        $this->assertEquals(100, $contexts[0]->getPriority());
        
        $this->assertEquals('context-b', $contexts[1]->getKey());
        $this->assertEquals(100, $contexts[1]->getPriority());
        
        $this->assertEquals('context-c', $contexts[2]->getKey());
        $this->assertEquals(100, $contexts[2]->getPriority());
    }
}
