<?php

namespace Viraloka\Tests\Context;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Context\ContextStack;
use Viraloka\Core\Context\ContextInterface;

/**
 * Unit Tests for Context Stack
 * 
 * Tests the ContextStack implementation including immutability,
 * query operations, and edge cases.
 * 
 * Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5
 */
class ContextStackTest extends TestCase
{
    /**
     * Create a mock context for testing
     */
    private function createMockContext(string $key, int $priority, array $metadata = []): ContextInterface
    {
        return new class($key, $priority, $metadata) implements ContextInterface {
            private string $key;
            private int $priority;
            private array $metadata;
            
            public function __construct(string $key, int $priority, array $metadata)
            {
                $this->key = $key;
                $this->priority = $priority;
                $this->metadata = $metadata;
            }
            
            public function getKey(): string
            {
                return $this->key;
            }
            
            public function getPriority(): int
            {
                return $this->priority;
            }
            
            public function getMetadata(): array
            {
                return $this->metadata;
            }
        };
    }
    
    /**
     * Test creating a context stack with multiple contexts
     */
    public function testCreateContextStackWithMultipleContexts(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        $context3 = $this->createMockContext('creator', 50);
        
        $stack = new ContextStack([$context1, $context2, $context3]);
        
        $this->assertInstanceOf(ContextStack::class, $stack);
        $this->assertCount(3, $stack->getAll());
    }
    
    /**
     * Test getAll() returns all contexts
     */
    public function testGetAllReturnsAllContexts(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        
        $stack = new ContextStack([$context1, $context2]);
        $all = $stack->getAll();
        
        $this->assertCount(2, $all);
        $this->assertSame($context1, $all[0]);
        $this->assertSame($context2, $all[1]);
    }
    
    /**
     * Test getPrimary() returns first context
     */
    public function testGetPrimaryReturnsFirstContext(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        
        $stack = new ContextStack([$context1, $context2]);
        $primary = $stack->getPrimary();
        
        $this->assertSame($context1, $primary);
        $this->assertEquals('marketplace', $primary->getKey());
    }
    
    /**
     * Test getPrimary() returns null for empty stack
     */
    public function testGetPrimaryReturnsNullForEmptyStack(): void
    {
        $stack = new ContextStack([]);
        $primary = $stack->getPrimary();
        
        $this->assertNull($primary);
    }
    
    /**
     * Test hasContext() returns true when context exists
     */
    public function testHasContextReturnsTrueWhenContextExists(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        
        $stack = new ContextStack([$context1, $context2]);
        
        $this->assertTrue($stack->hasContext('marketplace'));
        $this->assertTrue($stack->hasContext('digital'));
    }
    
    /**
     * Test hasContext() returns false when context does not exist
     */
    public function testHasContextReturnsFalseWhenContextDoesNotExist(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        
        $stack = new ContextStack([$context1]);
        
        $this->assertFalse($stack->hasContext('nonexistent'));
        $this->assertFalse($stack->hasContext('ai-service'));
    }
    
    /**
     * Test getContext() returns matching context
     */
    public function testGetContextReturnsMatchingContext(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        
        $stack = new ContextStack([$context1, $context2]);
        
        $found = $stack->getContext('digital');
        $this->assertSame($context2, $found);
        $this->assertEquals('digital', $found->getKey());
    }
    
    /**
     * Test getContext() returns null when context does not exist
     */
    public function testGetContextReturnsNullWhenContextDoesNotExist(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        
        $stack = new ContextStack([$context1]);
        
        $found = $stack->getContext('nonexistent');
        $this->assertNull($found);
    }
    
    /**
     * Test freeze() makes stack immutable
     */
    public function testFreezeMarksStackAsImmutable(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $stack = new ContextStack([$context1]);
        
        $this->assertFalse($stack->isFrozen());
        
        $stack->freeze();
        
        $this->assertTrue($stack->isFrozen());
    }
    
    /**
     * Test empty stack behavior
     * 
     * Edge case: Empty context stack
     */
    public function testEmptyStackBehavior(): void
    {
        $stack = new ContextStack([]);
        
        $this->assertCount(0, $stack->getAll());
        $this->assertNull($stack->getPrimary());
        $this->assertFalse($stack->hasContext('any-key'));
        $this->assertNull($stack->getContext('any-key'));
    }
    
    /**
     * Test single context stack
     * 
     * Edge case: Stack with only one context
     */
    public function testSingleContextStack(): void
    {
        $context = $this->createMockContext('default', 10);
        $stack = new ContextStack([$context]);
        
        $this->assertCount(1, $stack->getAll());
        $this->assertSame($context, $stack->getPrimary());
        $this->assertTrue($stack->hasContext('default'));
        $this->assertSame($context, $stack->getContext('default'));
    }
    
    /**
     * Test query for non-existent context
     * 
     * Edge case: Querying for a context that doesn't exist
     */
    public function testQueryForNonExistentContext(): void
    {
        $context1 = $this->createMockContext('marketplace', 100);
        $context2 = $this->createMockContext('digital', 50);
        
        $stack = new ContextStack([$context1, $context2]);
        
        $this->assertFalse($stack->hasContext('ai-service'));
        $this->assertNull($stack->getContext('ai-service'));
        $this->assertFalse($stack->hasContext(''));
        $this->assertNull($stack->getContext(''));
    }
}
