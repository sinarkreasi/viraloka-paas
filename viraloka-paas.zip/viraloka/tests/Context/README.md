# Context Resolver Tests

This directory contains tests for the Context Resolver system.

## Test Structure

The tests are organized into two categories:

### Unit Tests
- Test specific examples and edge cases
- Verify concrete behavior with known inputs
- Located in files ending with `Test.php`

### Property-Based Tests
- Test universal properties across random inputs
- Verify correctness properties hold for all valid inputs
- Located in files ending with `PropertyTest.php`
- Use PHPUnit with Eris library

## Property-Based Testing with Eris

### Installation

Eris is included in the `composer.json` dev dependencies:

```bash
composer install
```

### Running Property Tests

Run all tests including property tests:
```bash
vendor/bin/phpunit
```

Run only property tests:
```bash
vendor/bin/phpunit --filter PropertyTest
```

### Writing Property Tests

Property tests use the Eris library to generate random test data and verify properties hold across all inputs.

Example structure:

```php
use Eris\Generator;
use Eris\TestTrait;

class MyPropertyTest extends TestCase
{
    use TestTrait;
    
    /**
     * Feature: context-resolver, Property 1: Context Stack Priority Ordering
     * 
     * @test
     */
    public function context_stack_maintains_priority_ordering(): void
    {
        $this->forAll(
            Generator\seq(Generator\associative([
                'key' => Generator\string(),
                'priority' => Generator\int(1, 100)
            ]))
        )->then(function ($contexts) {
            // Test implementation
            $this->assertTrue(true);
        });
    }
}
```

### Configuration

- Minimum iterations per property: 100
- Each property test is tagged with a comment referencing the design property
- Tag format: `// Feature: context-resolver, Property {number}: {property_text}`

## Test Coverage Goals

- Line Coverage: Minimum 90%
- Branch Coverage: Minimum 85%
- Property Coverage: 100% (all 14 properties must have tests)

## Running Tests

Run all tests:
```bash
vendor/bin/phpunit
```

Run specific test file:
```bash
vendor/bin/phpunit tests/Context/ContextInterfaceTest.php
```

Run with coverage:
```bash
vendor/bin/phpunit --coverage-html coverage
```
