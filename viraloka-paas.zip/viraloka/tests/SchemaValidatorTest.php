<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\SchemaValidator;

/**
 * Schema Validator Test
 * 
 * Tests for the SchemaValidator class.
 */
class SchemaValidatorTest extends TestCase
{
    private SchemaValidator $validator;
    
    protected function setUp(): void
    {
        $this->validator = new SchemaValidator();
    }
    
    /**
     * Test validation passes with all required fields
     */
    public function testValidationPassesWithAllRequiredFields(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\TestModule'
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertTrue($result->isValid());
        $this->assertEmpty($result->getErrors());
    }
    
    /**
     * Test validation fails when required field is missing
     */
    public function testValidationFailsWhenRequiredFieldMissing(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author'
            // Missing 'namespace'
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertFalse($result->isValid());
        $this->assertNotEmpty($result->getErrors());
        $this->assertStringContainsString('namespace', implode(' ', $result->getErrors()));
    }
    
    /**
     * Test validation fails with invalid semantic version
     */
    public function testValidationFailsWithInvalidSemanticVersion(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0', // Invalid - should be MAJOR.MINOR.PATCH
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\TestModule'
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertFalse($result->isValid());
        $this->assertNotEmpty($result->getErrors());
        $this->assertStringContainsString('semantic versioning', implode(' ', $result->getErrors()));
    }
    
    /**
     * Test validation fails with invalid PSR-4 namespace
     */
    public function testValidationFailsWithInvalidPsr4Namespace(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'viraloka\\testModule' // Invalid - should start with uppercase
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertFalse($result->isValid());
        $this->assertNotEmpty($result->getErrors());
        $this->assertStringContainsString('PSR-4', implode(' ', $result->getErrors()));
    }
    
    /**
     * Test validation passes with additional fields (schema extensibility)
     */
    public function testValidationPassesWithAdditionalFields(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\TestModule',
            'custom_field' => 'custom value',
            'another_field' => 123
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertTrue($result->isValid());
        $this->assertEmpty($result->getErrors());
    }
    
    /**
     * Test validation fails with incorrect type
     */
    public function testValidationFailsWithIncorrectType(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\TestModule',
            'capabilities' => 'not-an-array' // Should be array
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertFalse($result->isValid());
        $this->assertNotEmpty($result->getErrors());
        $this->assertStringContainsString('array', implode(' ', $result->getErrors()));
    }
    
    /**
     * Test validation passes with optional fields
     */
    public function testValidationPassesWithOptionalFields(): void
    {
        $data = [
            'id' => 'viraloka.test-module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\TestModule',
            'capabilities' => ['read', 'write'],
            'contexts' => [
                'supported' => ['creator', 'digital'],
                'primary' => 'creator',
                'priority' => 75
            ],
            'ui' => [
                'admin_menu' => true,
                'menu_title' => 'Test Module',
                'icon' => 'dashicons-admin-generic',
                'order' => 50
            ]
        ];
        
        $result = $this->validator->validate($data);
        
        $this->assertTrue($result->isValid());
        $this->assertEmpty($result->getErrors());
    }
}
