<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\Tenant;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Workspace\WorkspaceUserRole;

class WorkspaceEntityTest extends TestCase
{
    public function testTenantCreation(): void
    {
        $tenant = new Tenant(
            tenantId: 'tenant-123',
            name: 'Test Tenant',
            ownerUserId: 1
        );
        
        $this->assertEquals('tenant-123', $tenant->tenantId);
        $this->assertEquals('Test Tenant', $tenant->name);
        $this->assertEquals(1, $tenant->ownerUserId);
        $this->assertEquals(Tenant::STATUS_ACTIVE, $tenant->status);
        $this->assertTrue($tenant->isActive());
    }
    
    public function testTenantSuspend(): void
    {
        $tenant = new Tenant(
            tenantId: 'tenant-123',
            name: 'Test Tenant',
            ownerUserId: 1
        );
        
        $tenant->suspend();
        $this->assertEquals(Tenant::STATUS_SUSPENDED, $tenant->status);
        $this->assertFalse($tenant->isActive());
    }
    
    public function testTenantActivate(): void
    {
        $tenant = new Tenant(
            tenantId: 'tenant-123',
            name: 'Test Tenant',
            ownerUserId: 1,
            status: Tenant::STATUS_SUSPENDED
        );
        
        $tenant->activate();
        $this->assertEquals(Tenant::STATUS_ACTIVE, $tenant->status);
        $this->assertTrue($tenant->isActive());
    }
    
    public function testWorkspaceCreation(): void
    {
        $workspace = new Workspace(
            workspaceId: 'workspace-123',
            tenantId: 'tenant-123',
            name: 'Test Workspace',
            slug: 'test-workspace'
        );
        
        $this->assertEquals('workspace-123', $workspace->workspaceId);
        $this->assertEquals('tenant-123', $workspace->tenantId);
        $this->assertEquals('Test Workspace', $workspace->name);
        $this->assertEquals('test-workspace', $workspace->slug);
        $this->assertEquals(Workspace::STATUS_ACTIVE, $workspace->status);
        $this->assertEquals('default', $workspace->activeContext);
        $this->assertTrue($workspace->isActive());
    }
    
    public function testWorkspaceDomainConfiguration(): void
    {
        $workspace = new Workspace(
            workspaceId: 'workspace-123',
            tenantId: 'tenant-123',
            name: 'Test Workspace',
            slug: 'test-workspace'
        );
        
        $workspace->setCustomDomain('app.example.com');
        $workspace->setSubdomain('test');
        $workspace->setIsDefault(true);
        
        $this->assertEquals('app.example.com', $workspace->customDomain);
        $this->assertEquals('test', $workspace->subdomain);
        $this->assertTrue($workspace->isDefault);
    }
    
    public function testWorkspaceStatusTransitions(): void
    {
        $workspace = new Workspace(
            workspaceId: 'workspace-123',
            tenantId: 'tenant-123',
            name: 'Test Workspace',
            slug: 'test-workspace'
        );
        
        $workspace->suspend();
        $this->assertEquals(Workspace::STATUS_SUSPENDED, $workspace->status);
        $this->assertFalse($workspace->isActive());
        
        $workspace->activate();
        $this->assertEquals(Workspace::STATUS_ACTIVE, $workspace->status);
        $this->assertTrue($workspace->isActive());
        
        $workspace->archive();
        $this->assertEquals(Workspace::STATUS_ARCHIVED, $workspace->status);
        $this->assertFalse($workspace->isActive());
    }
    
    public function testWorkspaceUserRoleCreation(): void
    {
        $role = new WorkspaceUserRole(
            workspaceId: 'workspace-123',
            userId: 1,
            role: WorkspaceUserRole::ROLE_ADMIN
        );
        
        $this->assertEquals('workspace-123', $role->workspaceId);
        $this->assertEquals(1, $role->userId);
        $this->assertEquals(WorkspaceUserRole::ROLE_ADMIN, $role->role);
    }
    
    public function testWorkspaceUserRolePermissions(): void
    {
        $owner = new WorkspaceUserRole('workspace-123', 1, WorkspaceUserRole::ROLE_OWNER);
        $this->assertTrue($owner->canManageWorkspace());
        $this->assertTrue($owner->canEditContent());
        $this->assertTrue($owner->isOwner());
        
        $admin = new WorkspaceUserRole('workspace-123', 2, WorkspaceUserRole::ROLE_ADMIN);
        $this->assertTrue($admin->canManageWorkspace());
        $this->assertTrue($admin->canEditContent());
        $this->assertFalse($admin->isOwner());
        
        $member = new WorkspaceUserRole('workspace-123', 3, WorkspaceUserRole::ROLE_MEMBER);
        $this->assertFalse($member->canManageWorkspace());
        $this->assertTrue($member->canEditContent());
        $this->assertFalse($member->isOwner());
        
        $viewer = new WorkspaceUserRole('workspace-123', 4, WorkspaceUserRole::ROLE_VIEWER);
        $this->assertFalse($viewer->canManageWorkspace());
        $this->assertFalse($viewer->canEditContent());
        $this->assertFalse($viewer->isOwner());
    }
    
    public function testWorkspaceUserRoleInvalidRole(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid role: invalid');
        
        new WorkspaceUserRole('workspace-123', 1, 'invalid');
    }
}
