<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\CapabilityRegistry;
use Viraloka\Core\Modules\Manifest;

class CapabilityRegistryTest extends TestCase
{
    private CapabilityRegistry $registry;
    
    protected function setUp(): void
    {
        $this->registry = new CapabilityRegistry();
        
        // Clear any stored capabilities before each test
        global $wp_options;
        $wp_options = [];
    }
    
    protected function tearDown(): void
    {
        // Clean up after tests
        global $wp_options;
        $wp_options = [];
    }
    
    public function testRegisterCapabilitiesWithNamespacing(): void
    {
        $manifest = $this->createManifest('test-module', ['manage_posts', 'edit_posts']);
        
        $this->registry->registerCapabilities($manifest);
        
        $capabilities = $this->registry->getModuleCapabilities('test-module');
        
        $this->assertCount(2, $capabilities);
        $this->assertContains('test-module:manage_posts', $capabilities);
        $this->assertContains('test-module:edit_posts', $capabilities);
    }
    
    public function testRegisterCapabilitiesWithEmptyArray(): void
    {
        $manifest = $this->createManifest('test-module', []);
        
        $this->registry->registerCapabilities($manifest);
        
        $capabilities = $this->registry->getModuleCapabilities('test-module');
        
        $this->assertEmpty($capabilities);
    }
    
    public function testGetModuleCapabilitiesForNonExistentModule(): void
    {
        $capabilities = $this->registry->getModuleCapabilities('non-existent');
        
        $this->assertIsArray($capabilities);
        $this->assertEmpty($capabilities);
    }
    
    public function testUnregisterCapabilities(): void
    {
        $manifest = $this->createManifest('test-module', ['manage_posts']);
        
        $this->registry->registerCapabilities($manifest);
        $this->assertNotEmpty($this->registry->getModuleCapabilities('test-module'));
        
        $this->registry->unregisterCapabilities('test-module');
        
        $capabilities = $this->registry->getModuleCapabilities('test-module');
        $this->assertEmpty($capabilities);
    }
    
    public function testUnregisterNonExistentModule(): void
    {
        // Should not throw exception
        $this->registry->unregisterCapabilities('non-existent');
        
        $this->assertTrue(true); // If we get here, no exception was thrown
    }
    
    public function testCapabilityNamespacing(): void
    {
        $manifest1 = $this->createManifest('module-a', ['manage_posts']);
        $manifest2 = $this->createManifest('module-b', ['manage_posts']);
        
        $this->registry->registerCapabilities($manifest1);
        $this->registry->registerCapabilities($manifest2);
        
        $capsA = $this->registry->getModuleCapabilities('module-a');
        $capsB = $this->registry->getModuleCapabilities('module-b');
        
        $this->assertContains('module-a:manage_posts', $capsA);
        $this->assertContains('module-b:manage_posts', $capsB);
        $this->assertNotContains('module-b:manage_posts', $capsA);
        $this->assertNotContains('module-a:manage_posts', $capsB);
    }
    
    private function createManifest(string $id, array $capabilities): Manifest
    {
        $data = [
            'id' => $id,
            'name' => 'Test Module',
            'description' => 'Test Description',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Namespace',
            'capabilities' => $capabilities
        ];
        
        return new Manifest($data, '/fake/path');
    }
}

