<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\SecurityGuard;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ResolutionResult;

/**
 * SecurityGuard Unit Test
 * 
 * Unit tests for the SecurityGuard class.
 * Tests specific examples and edge cases for security functionality.
 * 
 * Feature: core-bootstrap-flow
 */
class SecurityGuardTest extends TestCase
{
    private Application $app;
    private SecurityGuard $guard;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create application instance
        $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
        mkdir($basePath, 0777, true);
        
        $this->app = new Application($basePath);
        $this->guard = new SecurityGuard($this->app);
    }
    
    protected function tearDown(): void
    {
        parent::tearDown();
        
        // Clean up
        if (is_dir($this->app->basePath())) {
            rmdir($this->app->basePath());
        }
    }
    
    /**
     * Test capability gate registration
     * 
     * Validates: Requirements 4.1
     */
    public function testCapabilityGateRegistration(): void
    {
        // Register a custom capability gate
        $this->guard->registerCapabilityGate('custom_capability', 'edit_posts');
        
        // Verify the gate was registered
        $gates = $this->guard->getCapabilityGates();
        $this->assertArrayHasKey('custom_capability', $gates);
        $this->assertEquals('edit_posts', $gates['custom_capability']);
    }
    
    /**
     * Test default capability gates are registered on activation
     * 
     * Validates: Requirements 4.1
     */
    public function testDefaultCapabilityGatesRegisteredOnActivation(): void
    {
        // Activate the security guard
        $this->guard->activate();
        
        // Verify default gates are registered
        $gates = $this->guard->getCapabilityGates();
        $this->assertArrayHasKey('manage_viraloka_modules', $gates);
        $this->assertArrayHasKey('manage_viraloka_workspaces', $gates);
        $this->assertArrayHasKey('manage_viraloka_contexts', $gates);
        
        // Verify they map to manage_options
        $this->assertEquals('manage_options', $gates['manage_viraloka_modules']);
        $this->assertEquals('manage_options', $gates['manage_viraloka_workspaces']);
        $this->assertEquals('manage_options', $gates['manage_viraloka_contexts']);
    }
    
    /**
     * Test security validation failure logging
     * 
     * Validates: Requirements 4.4
     */
    public function testSecurityValidationFailureLogging(): void
    {
        // Capture error log output
        $logMessages = [];
        $originalErrorLog = ini_get('error_log');
        
        // Create a temporary log file
        $logFile = sys_get_temp_dir() . '/test-error-' . uniqid() . '.log';
        ini_set('error_log', $logFile);
        
        // Test invalid nonce (should log warning)
        $result = $this->guard->validateNonce('test_action', 'invalid_nonce');
        $this->assertFalse($result);
        
        // Test unknown capability gate (should log warning)
        $result = $this->guard->enforceCapabilityGate('unknown_capability');
        $this->assertFalse($result);
        
        // Verify log file was created and contains warnings
        $this->assertFileExists($logFile);
        $logContent = file_get_contents($logFile);
        $this->assertStringContainsString('Nonce validation failed', $logContent);
        $this->assertStringContainsString('Unknown capability gate', $logContent);
        
        // Clean up
        ini_set('error_log', $originalErrorLog);
        unlink($logFile);
    }
    
    /**
     * Test activation during boot phase
     * 
     * Validates: Requirements 4.5
     */
    public function testActivationDuringBootPhase(): void
    {
        // Capture error log output to verify activation logging
        $logFile = sys_get_temp_dir() . '/test-error-' . uniqid() . '.log';
        $originalErrorLog = ini_get('error_log');
        ini_set('error_log', $logFile);
        
        // Activate the security guard
        $this->guard->activate();
        
        // Verify activation was logged
        $this->assertFileExists($logFile);
        $logContent = file_get_contents($logFile);
        $this->assertStringContainsString('Security Guard activated', $logContent);
        
        // Verify default capability gates are registered after activation
        $gates = $this->guard->getCapabilityGates();
        $this->assertNotEmpty($gates);
        $this->assertArrayHasKey('manage_viraloka_modules', $gates);
        
        // Clean up
        ini_set('error_log', $originalErrorLog);
        unlink($logFile);
    }
    
    /**
     * Test module sandboxing marks module as sandboxed
     */
    public function testModuleSandboxingMarksModuleAsSandboxed(): void
    {
        $module = $this->createMockModule('test_module');
        
        // Initially not sandboxed
        $this->assertFalse($this->guard->isModuleSandboxed('test_module'));
        
        // Sandbox the module
        $this->guard->sandboxModule($module);
        
        // Now should be sandboxed
        $this->assertTrue($this->guard->isModuleSandboxed('test_module'));
    }
    
    /**
     * Test non-sandboxed modules have unrestricted access
     */
    public function testNonSandboxedModulesHaveUnrestrictedAccess(): void
    {
        // Module not sandboxed, should have access to everything
        $this->assertTrue($this->guard->checkModuleAccess('unsandboxed_module', 'Viraloka\\Core\\Bootstrap\\Kernel'));
        $this->assertTrue($this->guard->checkModuleAccess('unsandboxed_module', 'Viraloka\\Core\\Application'));
        $this->assertTrue($this->guard->checkModuleAccess('unsandboxed_module', 'AnyClass'));
    }
    
    /**
     * Test capability gate enforcement with valid capability
     */
    public function testCapabilityGateEnforcementWithValidCapability(): void
    {
        // Register a capability gate
        $this->guard->registerCapabilityGate('test_capability', 'manage_options');
        
        // Enforce the gate (should pass since current_user_can returns true in tests)
        $result = $this->guard->enforceCapabilityGate('test_capability');
        $this->assertTrue($result);
    }
    
    /**
     * Test nonce validation with valid nonce
     */
    public function testNonceValidationWithValidNonce(): void
    {
        $action = 'test_action';
        $nonce = wp_create_nonce($action);
        
        // Validate the nonce
        $result = $this->guard->validateNonce($action, $nonce);
        $this->assertTrue($result);
    }
    
    /**
     * Test nonce validation with invalid nonce
     */
    public function testNonceValidationWithInvalidNonce(): void
    {
        $action = 'test_action';
        $invalidNonce = 'invalid_nonce';
        
        // Validate the nonce
        $result = $this->guard->validateNonce($action, $invalidNonce);
        $this->assertFalse($result);
    }
    
    /**
     * Create a mock module for testing
     * 
     * @param string $moduleId
     * @return Module
     */
    private function createMockModule(string $moduleId): Module
    {
        $manifestData = [
            'id' => $moduleId,
            'name' => 'Test Module',
            'version' => '1.0.0',
            'description' => 'Test module',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'capabilities' => [],
        ];
        
        $path = sys_get_temp_dir() . '/test-module-' . uniqid();
        $manifest = new Manifest($manifestData, $path);
        $dependencies = new ResolutionResult(true, [], [], [], []);
        
        return new Module($manifest, $dependencies);
    }
}
