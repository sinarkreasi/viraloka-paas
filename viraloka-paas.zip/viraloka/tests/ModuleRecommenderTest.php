<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\ContextConfig;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\ModuleRecommender;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\RecommendationConfig;
use Viraloka\Core\Modules\ResolutionResult;

class ModuleRecommenderTest extends TestCase
{
    private ModuleRecommender $recommender;
    private ModuleRegistry $registry;
    private ContextResolver $contextResolver;
    
    protected function setUp(): void
    {
        $this->registry = new ModuleRegistry();
        $this->contextResolver = new ContextResolver($this->registry);
        $this->recommender = new ModuleRecommender($this->contextResolver, $this->registry);
        
        // Clear WordPress options
        global $wp_options;
        $wp_options = [];
    }
    
    protected function tearDown(): void
    {
        global $wp_options;
        $wp_options = [];
    }
    
    public function testStoreRecommendationsFromManifest(): void
    {
        $manifest = $this->createManifestWithRecommendations(
            'source-module',
            ['recommended-module-1', 'recommended-module-2'],
            ['integration-1']
        );
        
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->recommender->storeRecommendations($module);
        
        $recommendations = $this->recommender->getModuleRecommendations('source-module');
        
        $this->assertCount(2, $recommendations['modules']);
        $this->assertContains('recommended-module-1', $recommendations['modules']);
        $this->assertContains('recommended-module-2', $recommendations['modules']);
        $this->assertCount(1, $recommendations['integrations']);
        $this->assertContains('integration-1', $recommendations['integrations']);
    }
    
    public function testStoreRecommendationsWithNoRecommendations(): void
    {
        $manifest = $this->createManifest('source-module');
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->recommender->storeRecommendations($module);
        
        $recommendations = $this->recommender->getModuleRecommendations('source-module');
        
        $this->assertEmpty($recommendations['modules']);
        $this->assertEmpty($recommendations['integrations']);
    }
    
    public function testGetRecommendationsForContextRankedByPriority(): void
    {
        // Create source modules with different priorities
        $highPriorityManifest = $this->createManifestWithContextAndRecommendations(
            'high-priority-module',
            ['creator'],
            null,
            80,
            ['recommended-module-1']
        );
        
        $lowPriorityManifest = $this->createManifestWithContextAndRecommendations(
            'low-priority-module',
            ['creator'],
            null,
            20,
            ['recommended-module-2']
        );
        
        $highPriorityModule = new Module($highPriorityManifest, new ResolutionResult(true, [], [], [], []));
        $lowPriorityModule = new Module($lowPriorityManifest, new ResolutionResult(true, [], [], [], []));
        
        $this->registry->register($highPriorityModule);
        $this->registry->register($lowPriorityModule);
        
        $this->recommender->storeRecommendations($highPriorityModule);
        $this->recommender->storeRecommendations($lowPriorityModule);
        
        $recommendations = $this->recommender->getRecommendationsForContext('creator');
        
        $this->assertCount(2, $recommendations);
        // High priority should come first
        $this->assertEquals('recommended-module-1', $recommendations[0]['recommended_module_id']);
        $this->assertEquals('recommended-module-2', $recommendations[1]['recommended_module_id']);
    }
    
    public function testGetRecommendationsForContextPrioritizesContextMatch(): void
    {
        // Create a module that matches the context
        $contextMatchManifest = $this->createManifestWithContextAndRecommendations(
            'context-match-module',
            ['creator'],
            null,
            50,
            ['recommended-module-1']
        );
        
        // Create a module that doesn't match the context (but has higher priority)
        $noContextMatchManifest = $this->createManifestWithContextAndRecommendations(
            'no-context-match-module',
            ['digital'],
            null,
            80,
            ['recommended-module-2']
        );
        
        $contextMatchModule = new Module($contextMatchManifest, new ResolutionResult(true, [], [], [], []));
        $noContextMatchModule = new Module($noContextMatchManifest, new ResolutionResult(true, [], [], [], []));
        
        $this->registry->register($contextMatchModule);
        $this->registry->register($noContextMatchModule);
        
        $this->recommender->storeRecommendations($contextMatchModule);
        $this->recommender->storeRecommendations($noContextMatchModule);
        
        $recommendations = $this->recommender->getRecommendationsForContext('creator');
        
        $this->assertCount(2, $recommendations);
        // Context match should come first, even with lower priority
        $this->assertEquals('recommended-module-1', $recommendations[0]['recommended_module_id']);
        $this->assertTrue($recommendations[0]['context_match']);
        $this->assertEquals('recommended-module-2', $recommendations[1]['recommended_module_id']);
        $this->assertFalse($recommendations[1]['context_match']);
    }
    
    public function testIsModuleInstalledReturnsTrueForRegisteredModule(): void
    {
        $manifest = $this->createManifest('installed-module');
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->registry->register($module);
        
        $this->assertTrue($this->recommender->isModuleInstalled('installed-module'));
    }
    
    public function testIsModuleInstalledReturnsFalseForUnregisteredModule(): void
    {
        $this->assertFalse($this->recommender->isModuleInstalled('non-existent-module'));
    }
    
    public function testGetRecommendationsIncludesInstallationStatus(): void
    {
        // Create source module with recommendations
        $sourceManifest = $this->createManifestWithRecommendations(
            'source-module',
            ['installed-module', 'not-installed-module'],
            []
        );
        
        $sourceModule = new Module($sourceManifest, new ResolutionResult(true, [], [], [], []));
        
        // Register the source module and one of the recommended modules
        $this->registry->register($sourceModule);
        
        $installedManifest = $this->createManifest('installed-module');
        $installedModule = new Module($installedManifest, new ResolutionResult(true, [], [], [], []));
        $this->registry->register($installedModule);
        
        $this->recommender->storeRecommendations($sourceModule);
        
        $recommendations = $this->recommender->getRecommendationsForContext('default');
        
        $this->assertCount(2, $recommendations);
        
        // Find the installed and not-installed recommendations
        $installedRec = null;
        $notInstalledRec = null;
        
        foreach ($recommendations as $rec) {
            if ($rec['recommended_module_id'] === 'installed-module') {
                $installedRec = $rec;
            } elseif ($rec['recommended_module_id'] === 'not-installed-module') {
                $notInstalledRec = $rec;
            }
        }
        
        $this->assertNotNull($installedRec);
        $this->assertNotNull($notInstalledRec);
        $this->assertTrue($installedRec['installed']);
        $this->assertFalse($notInstalledRec['installed']);
    }
    
    // Helper methods
    
    private function createManifest(string $id): Manifest
    {
        return new Manifest([
            'id' => $id,
            'name' => ucfirst($id),
            'description' => 'Test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Test',
        ], '/path/to/module');
    }
    
    private function createManifestWithRecommendations(
        string $id,
        array $modules,
        array $integrations
    ): Manifest {
        return new Manifest([
            'id' => $id,
            'name' => ucfirst($id),
            'description' => 'Test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Test',
            'recommendations' => [
                'modules' => $modules,
                'integrations' => $integrations,
            ],
        ], '/path/to/module');
    }
    
    private function createManifestWithContextAndRecommendations(
        string $id,
        array $supportedContexts,
        ?string $primaryContext,
        int $priority,
        array $recommendedModules
    ): Manifest {
        return new Manifest([
            'id' => $id,
            'name' => ucfirst($id),
            'description' => 'Test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Test',
            'contexts' => [
                'supported' => $supportedContexts,
                'primary' => $primaryContext,
                'priority' => $priority,
            ],
            'recommendations' => [
                'modules' => $recommendedModules,
                'integrations' => [],
            ],
        ], '/path/to/module');
    }
}
