<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\Kernel;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use Viraloka\Core\Adapter\AdapterRegistry;
use Viraloka\Adapter\WordPress\WordPressRuntimeAdapter;
use Viraloka\Adapter\WordPress\WordPressRequestAdapter;
use Viraloka\Adapter\WordPress\WordPressResponseAdapter;
use Viraloka\Adapter\WordPress\WordPressAuthAdapter;
use Viraloka\Adapter\WordPress\WordPressStorageAdapter;
use Viraloka\Adapter\WordPress\WordPressEventAdapter;

/**
 * Kernel Adapter Integration Tests
 * 
 * Tests the integration of the Adapter System with the Kernel bootstrap process.
 * Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5, 10.6
 */
class KernelAdapterIntegrationTest extends TestCase
{
    private Application $app;
    private string $testBasePath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create test base path
        $this->testBasePath = __DIR__;
        
        // Create fresh application instance
        $this->app = new Application($this->testBasePath);
    }
    
    /**
     * Test Kernel boots successfully with WordPress adapters
     * 
     * Validates: Requirements 10.1, 10.2
     */
    public function testKernelBootsWithWordPressAdapters(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Assert kernel is bootstrapped
        $this->assertTrue($kernel->isBootstrapped());
        $this->assertTrue($kernel->isReady());
        
        // Assert AdapterRegistry is registered in container
        $this->assertTrue($this->app->bound(AdapterRegistryInterface::class));
        $this->assertTrue($this->app->bound(AdapterRegistry::class));
    }
    
    /**
     * Test adapters are properly registered in container
     * 
     * Validates: Requirements 10.1, 10.2
     */
    public function testAdaptersAreProperlyRegisteredInContainer(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get adapter registry from container
        $registry = $this->app->make(AdapterRegistryInterface::class);
        
        // Assert registry is an instance of AdapterRegistry
        $this->assertInstanceOf(AdapterRegistry::class, $registry);
        
        // Assert all adapters are registered
        $this->assertInstanceOf(WordPressRuntimeAdapter::class, $registry->runtime());
        $this->assertInstanceOf(WordPressRequestAdapter::class, $registry->request());
        $this->assertInstanceOf(WordPressResponseAdapter::class, $registry->response());
        $this->assertInstanceOf(WordPressAuthAdapter::class, $registry->auth());
        $this->assertInstanceOf(WordPressStorageAdapter::class, $registry->storage());
        $this->assertInstanceOf(WordPressEventAdapter::class, $registry->event());
    }
    
    /**
     * Test Core services can access adapters through registry
     * 
     * Validates: Requirements 10.3
     */
    public function testCoreServicesCanAccessAdaptersThroughRegistry(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get adapter registry
        $registry = $this->app->make(AdapterRegistryInterface::class);
        
        // Test that each adapter type is accessible
        $runtime = $registry->runtime();
        $this->assertNotNull($runtime);
        $this->assertIsString($runtime->environment());
        
        $request = $registry->request();
        $this->assertNotNull($request);
        $this->assertIsString($request->getMethod());
        
        $response = $registry->response();
        $this->assertNotNull($response);
        
        $auth = $registry->auth();
        $this->assertNotNull($auth);
        $this->assertIsBool($auth->isAuthenticated());
        
        $storage = $registry->storage();
        $this->assertNotNull($storage);
        
        $event = $registry->event();
        $this->assertNotNull($event);
    }
    
    /**
     * Test Kernel uses RuntimeAdapter for environment detection
     * 
     * Validates: Requirements 10.3
     */
    public function testKernelUsesRuntimeAdapterForEnvironmentDetection(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get adapter registry
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $runtime = $registry->runtime();
        
        // Test environment detection
        $environment = $runtime->environment();
        $this->assertIsString($environment);
        $this->assertNotEmpty($environment);
        
        // Test isAdmin check
        $isAdmin = $runtime->isAdmin();
        $this->assertIsBool($isAdmin);
        
        // Test isCli check
        $isCli = $runtime->isCli();
        $this->assertIsBool($isCli);
    }
    
    /**
     * Test Kernel uses StorageAdapter for caching operations
     * 
     * Validates: Requirements 10.5
     */
    public function testKernelUsesStorageAdapterForCaching(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get adapter registry
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $storage = $registry->storage();
        
        // Test storage operations
        $testKey = 'test_kernel_cache';
        $testValue = 'test_value';
        
        // Set a value
        $result = $storage->set($testKey, $testValue);
        $this->assertTrue($result);
        
        // Get the value
        $retrieved = $storage->get($testKey);
        $this->assertEquals($testValue, $retrieved);
        
        // Delete the value
        $deleted = $storage->delete($testKey);
        $this->assertTrue($deleted);
        
        // Verify deletion
        $this->assertFalse($storage->has($testKey));
    }
    
    /**
     * Test Kernel uses EventAdapter for dispatching events
     * 
     * Validates: Requirements 10.4
     */
    public function testKernelUsesEventAdapterForDispatchingEvents(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        
        // Track lifecycle events
        $eventsDispatched = [];
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.register', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'register';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.boot', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'boot';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.ready', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'ready';
        });
        
        // Execute bootstrap
        $kernel->bootstrap();
        
        // Assert lifecycle events were dispatched
        $this->assertContains('register', $eventsDispatched);
        $this->assertContains('boot', $eventsDispatched);
        $this->assertContains('ready', $eventsDispatched);
    }
    
    /**
     * Test AdapterRegistry is registered before other services
     * 
     * Validates: Requirements 10.1
     */
    public function testAdapterRegistryIsRegisteredBeforeOtherServices(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Track service registration order
        $registrationOrder = [];
        
        // Hook into container to track bindings
        $originalBound = $this->app->bound(AdapterRegistryInterface::class);
        
        // Bootstrap
        $kernel->bootstrap();
        
        // After bootstrap, AdapterRegistry should be bound
        $this->assertTrue($this->app->bound(AdapterRegistryInterface::class));
        
        // Other services should also be bound
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\SecurityGuard::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\PerformanceGuard::class));
    }
    
    /**
     * Test Kernel fails fast with descriptive error if adapters not configured
     * 
     * Validates: Requirements 10.6
     */
    public function testKernelFailsFastIfAdaptersNotConfigured(): void
    {
        // This test would require mocking the environment detection
        // to simulate a scenario where no adapters can be registered.
        // For now, we verify that the exception type is correct.
        
        $this->expectException(\Viraloka\Core\Adapter\Exceptions\RuntimeAdapterException::class);
        
        // Create a mock kernel that will fail adapter detection
        // by temporarily removing WordPress functions
        $originalAddAction = null;
        if (function_exists('add_action')) {
            // We can't actually remove the function, so we'll skip this test
            // in environments where WordPress is loaded
            $this->markTestSkipped('Cannot test adapter failure when WordPress is loaded');
        }
        
        // If we get here, WordPress is not loaded, so kernel should fail
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
    }
    
    /**
     * Test EventDispatcher receives adapters during Kernel bootstrap
     * 
     * Validates: Requirements 10.4
     */
    public function testEventDispatcherReceivesAdaptersDuringBootstrap(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get event dispatcher
        $eventDispatcher = $kernel->getEventDispatcher();
        
        // Verify EventDispatcher has adapters set
        // We can test this by dispatching an event and verifying it works
        $eventFired = false;
        
        $eventDispatcher->listen('test.event', function () use (&$eventFired) {
            $eventFired = true;
        });
        
        $eventDispatcher->dispatch('test.event', $this->app);
        
        $this->assertTrue($eventFired);
    }
    
    /**
     * Test Kernel bootstrap is idempotent with adapters
     * 
     * Validates: Requirements 10.1, 10.2
     */
    public function testKernelBootstrapIsIdempotentWithAdapters(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Bootstrap multiple times
        $kernel->bootstrap();
        $kernel->bootstrap();
        $kernel->bootstrap();
        
        // Assert kernel is bootstrapped only once
        $this->assertTrue($kernel->isBootstrapped());
        
        // Assert adapters are still accessible
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $this->assertInstanceOf(AdapterRegistry::class, $registry);
        
        // Verify all adapters are still registered
        $this->assertNotNull($registry->runtime());
        $this->assertNotNull($registry->request());
        $this->assertNotNull($registry->response());
        $this->assertNotNull($registry->auth());
        $this->assertNotNull($registry->storage());
        $this->assertNotNull($registry->event());
    }
    
    /**
     * Test Kernel uses adapter exceptions for error handling
     * 
     * Validates: Requirements 10.6
     */
    public function testKernelUsesAdapterExceptionsForErrorHandling(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Get adapter registry
        $registry = $this->app->make(AdapterRegistryInterface::class);
        
        // Test that adapter methods can throw appropriate exceptions
        // For example, ResponseAdapter should throw ResponseAdapterException for invalid status
        $response = $registry->response();
        
        try {
            // Try to send response with invalid status code
            $response->send('test', 999);
            $this->fail('Expected ResponseAdapterException to be thrown');
        } catch (\Viraloka\Core\Adapter\Exceptions\ResponseAdapterException $e) {
            // Expected exception
            $this->assertStringContainsString('status', strtolower($e->getMessage()));
        }
    }
    
    /**
     * Test all core services are available after bootstrap with adapters
     * 
     * Validates: Requirements 10.1, 10.2, 10.3
     */
    public function testAllCoreServicesAvailableAfterBootstrapWithAdapters(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        $kernel->bootstrap();
        
        // Assert all core services are registered
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\SecurityGuard::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\PerformanceGuard::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\WorkspaceResolver::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Context\ContextResolver::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Theme\ThemeIntegration::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Contracts\ModuleLoaderContract::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract::class));
        
        // Assert adapter registry is available
        $this->assertTrue($this->app->bound(AdapterRegistryInterface::class));
        
        // Verify services can be resolved
        $logger = $this->app->make(\Viraloka\Core\Modules\Logger::class);
        $this->assertInstanceOf(\Viraloka\Core\Modules\Logger::class, $logger);
        
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $this->assertInstanceOf(AdapterRegistry::class, $registry);
    }
}
