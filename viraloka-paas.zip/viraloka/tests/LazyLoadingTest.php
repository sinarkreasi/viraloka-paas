<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Container\Container;

/**
 * Test lazy loading functionality
 */
class LazyLoadingTest extends TestCase
{
    /**
     * Test that lazy factory bindings are not instantiated until first get()
     */
    public function testLazyFactoryDeferredInstantiation(): void
    {
        $container = new Container();
        $instantiated = false;

        // Register a lazy factory binding
        $container->bind('test.service', function() use (&$instantiated) {
            $instantiated = true;
            return new stdClass();
        }, ['lazy' => true]);

        // Service should not be instantiated yet
        $this->assertFalse($instantiated, 'Lazy service should not be instantiated during registration');

        // First get() should instantiate the service
        $instance = $container->get('test.service');
        $this->assertTrue($instantiated, 'Lazy service should be instantiated on first get()');
        $this->assertInstanceOf(stdClass::class, $instance);
    }

    /**
     * Test that lazy factory bindings are cached after first access
     */
    public function testLazyFactoryCaching(): void
    {
        $container = new Container();
        $instantiationCount = 0;

        // Register a lazy factory binding
        $container->bind('test.service', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new stdClass();
        }, ['lazy' => true]);

        // First get() should instantiate
        $instance1 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy service should be instantiated once on first get()');

        // Second get() should return cached instance
        $instance2 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy service should not be instantiated again on second get()');

        // Third get() should also return cached instance
        $instance3 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy service should not be instantiated again on third get()');

        // All instances should be the same (cached)
        $this->assertSame($instance1, $instance2, 'Lazy service should return same cached instance');
        $this->assertSame($instance1, $instance3, 'Lazy service should return same cached instance');
    }

    /**
     * Test that non-lazy factory bindings create new instances each time
     */
    public function testNonLazyFactoryCreatesNewInstances(): void
    {
        $container = new Container();
        $instantiationCount = 0;

        // Register a non-lazy factory binding
        $container->bind('test.service', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new stdClass();
        });

        // Each get() should create a new instance
        $instance1 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount);

        $instance2 = $container->get('test.service');
        $this->assertEquals(2, $instantiationCount);

        $instance3 = $container->get('test.service');
        $this->assertEquals(3, $instantiationCount);

        // Instances should be different
        $this->assertNotSame($instance1, $instance2, 'Non-lazy factory should create new instances');
        $this->assertNotSame($instance1, $instance3, 'Non-lazy factory should create new instances');
    }

    /**
     * Test that lazy singletons are cached after first access
     */
    public function testLazySingletonCaching(): void
    {
        $container = new Container();
        $instantiationCount = 0;

        // Register a lazy singleton binding
        $container->singleton('test.service', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new stdClass();
        }, ['lazy' => true]);

        // Service should not be instantiated yet
        $this->assertEquals(0, $instantiationCount, 'Lazy singleton should not be instantiated during registration');

        // First get() should instantiate
        $instance1 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy singleton should be instantiated once on first get()');

        // Second get() should return cached instance
        $instance2 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy singleton should not be instantiated again');

        // Instances should be the same
        $this->assertSame($instance1, $instance2, 'Lazy singleton should return same cached instance');
    }

    /**
     * Test that lazy scoped bindings are cached per scope
     */
    public function testLazyScopedCaching(): void
    {
        $contextResolver = new class implements \Viraloka\Core\Container\Contracts\ContextResolverInterface {
            public string $context = 'default';
            public function getCurrentContext(): string {
                return $this->context;
            }
        };

        $container = new Container($contextResolver);
        $instantiationCount = 0;

        // Register a lazy scoped binding
        $container->scoped('test.service', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new stdClass();
        }, ['lazy' => true]);

        // Service should not be instantiated yet
        $this->assertEquals(0, $instantiationCount, 'Lazy scoped service should not be instantiated during registration');

        // First get() should instantiate
        $instance1 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy scoped service should be instantiated once on first get()');

        // Second get() in same scope should return cached instance
        $instance2 = $container->get('test.service');
        $this->assertEquals(1, $instantiationCount, 'Lazy scoped service should not be instantiated again in same scope');
        $this->assertSame($instance1, $instance2, 'Lazy scoped service should return same cached instance in same scope');

        // Change context - should create new instance
        $contextResolver->context = 'different';
        $instance3 = $container->get('test.service');
        $this->assertEquals(2, $instantiationCount, 'Lazy scoped service should be instantiated again in different scope');
        $this->assertNotSame($instance1, $instance3, 'Lazy scoped service should return different instance in different scope');
    }

    /**
     * Test that lazy bindings work with class name resolvers
     */
    public function testLazyBindingWithClassName(): void
    {
        $container = new Container();

        // Register a lazy binding with a class name
        $container->bind('test.service', stdClass::class, ['lazy' => true]);

        // First get() should instantiate
        $instance1 = $container->get('test.service');
        $this->assertInstanceOf(stdClass::class, $instance1);

        // Second get() should return cached instance
        $instance2 = $container->get('test.service');
        $this->assertSame($instance1, $instance2, 'Lazy binding with class name should cache instance');
    }
}
