<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Container\Container;
use Viraloka\Core\Container\Contracts\ContextResolverInterface;
use Viraloka\Core\Container\Contracts\WorkspaceResolverInterface;

/**
 * Unit tests for scoped bindings.
 */
class ScopedBindingTest extends TestCase
{
    private Container $container;
    private MockContextResolver $contextResolver;
    private MockWorkspaceResolver $workspaceResolver;

    protected function setUp(): void
    {
        $this->contextResolver = new MockContextResolver();
        $this->workspaceResolver = new MockWorkspaceResolver();
        $this->container = new Container($this->contextResolver, $this->workspaceResolver);
    }

    /**
     * Test scoped binding returns same instance within same scope.
     */
    public function testScopedBindingReturnsSameInstanceInSameScope(): void
    {
        $counter = 0;
        $this->container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        // Set context and workspace
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');

        $instance1 = $this->container->get('service');
        $instance2 = $this->container->get('service');

        $this->assertSame($instance1, $instance2, 'Scoped binding should return same instance in same scope');
        $this->assertEquals(1, $instance1->id, 'Service should only be instantiated once');
    }

    /**
     * Test scoped binding returns different instances in different contexts.
     */
    public function testScopedBindingReturnsDifferentInstancesInDifferentContexts(): void
    {
        $counter = 0;
        $this->container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        // First context
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance1 = $this->container->get('service');

        // Different context, same workspace
        $this->contextResolver->setContext('frontend');
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance2 = $this->container->get('service');

        $this->assertNotSame($instance1, $instance2, 'Scoped binding should return different instances in different contexts');
        $this->assertEquals(1, $instance1->id);
        $this->assertEquals(2, $instance2->id);
    }

    /**
     * Test scoped binding returns different instances in different workspaces.
     */
    public function testScopedBindingReturnsDifferentInstancesInDifferentWorkspaces(): void
    {
        $counter = 0;
        $this->container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        // First workspace
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance1 = $this->container->get('service');

        // Different workspace, same context
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace2');
        $instance2 = $this->container->get('service');

        $this->assertNotSame($instance1, $instance2, 'Scoped binding should return different instances in different workspaces');
        $this->assertEquals(1, $instance1->id);
        $this->assertEquals(2, $instance2->id);
    }

    /**
     * Test scoped binding with null workspace.
     */
    public function testScopedBindingWithNullWorkspace(): void
    {
        $counter = 0;
        $this->container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        // Set context but no workspace
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace(null);

        $instance1 = $this->container->get('service');
        $instance2 = $this->container->get('service');

        $this->assertSame($instance1, $instance2, 'Scoped binding should return same instance when workspace is null');
        $this->assertEquals(1, $instance1->id);
    }

    /**
     * Test scoped binding returns same instance after switching back to original scope.
     */
    public function testScopedBindingReturnsSameInstanceAfterSwitchingBackToOriginalScope(): void
    {
        $counter = 0;
        $this->container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        // First scope
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance1 = $this->container->get('service');

        // Switch to different scope
        $this->contextResolver->setContext('frontend');
        $this->workspaceResolver->setWorkspace('workspace2');
        $instance2 = $this->container->get('service');

        // Switch back to first scope
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance3 = $this->container->get('service');

        $this->assertSame($instance1, $instance3, 'Should return cached instance when returning to original scope');
        $this->assertNotSame($instance1, $instance2);
        $this->assertEquals(1, $instance1->id);
        $this->assertEquals(2, $instance2->id);
    }

    /**
     * Test scoped binding without resolvers (default context).
     */
    public function testScopedBindingWithoutResolvers(): void
    {
        $container = new Container();
        
        $counter = 0;
        $container->scoped('service', function() use (&$counter) {
            return (object)['id' => ++$counter];
        });

        $instance1 = $container->get('service');
        $instance2 = $container->get('service');

        $this->assertSame($instance1, $instance2, 'Scoped binding should work without resolvers');
        $this->assertEquals(1, $instance1->id);
    }

    /**
     * Test scoped binding with circular dependency detection.
     */
    public function testScopedBindingWithCircularDependencyDetection(): void
    {
        $this->expectException(\Viraloka\Core\Container\Exceptions\CircularDependencyException::class);

        $this->container->scoped('serviceA', function($container) {
            return $container->get('serviceB');
        });

        $this->container->scoped('serviceB', function($container) {
            return $container->get('serviceA');
        });

        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('workspace1');

        $this->container->get('serviceA');
    }
}

/**
 * Mock context resolver for testing (reuse from ContainerTest if available).
 */
if (!class_exists('MockContextResolver')) {
    class MockContextResolver implements ContextResolverInterface
    {
        private string $context = 'default';

        public function setContext(string $context): void
        {
            $this->context = $context;
        }

        public function getCurrentContext(): string
        {
            return $this->context;
        }
    }
}

/**
 * Mock workspace resolver for testing (reuse from ContainerTest if available).
 */
if (!class_exists('MockWorkspaceResolver')) {
    class MockWorkspaceResolver implements WorkspaceResolverInterface
    {
        private ?string $workspace = null;

        public function setWorkspace(?string $workspace): void
        {
            $this->workspace = $workspace;
        }

        public function getCurrentWorkspace(): ?string
        {
            return $this->workspace;
        }
    }
}
