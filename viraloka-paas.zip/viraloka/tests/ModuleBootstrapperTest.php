<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Modules\ModuleBootstrapper;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\LifecycleConfig;
use Viraloka\Core\Modules\ResolutionResult;
use Viraloka\Core\Modules\Exceptions\BootstrapException;
use Viraloka\Core\Providers\ServiceProvider;

/**
 * Module Bootstrapper Test
 * 
 * Tests the ModuleBootstrapper class functionality.
 */
class ModuleBootstrapperTest extends TestCase
{
    protected Application $app;
    protected ModuleRegistry $registry;
    protected ModuleBootstrapper $bootstrapper;
    
    protected function setUp(): void
    {
        $this->app = new Application();
        $this->registry = new ModuleRegistry();
        $this->bootstrapper = new ModuleBootstrapper($this->app, $this->registry);
    }
    
    public function testBootstrapInstantiatesProvider(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
        
        $this->assertTrue($module->isBootstrapped);
        $this->assertInstanceOf(ServiceProvider::class, $module->provider);
        $this->assertInstanceOf(TestServiceProvider::class, $module->provider);
    }
    
    public function testBootstrapCallsRegisterMethod(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
        
        // Verify register was called by checking if service was bound
        $this->assertTrue($this->app->bound('test.service'));
    }
    
    public function testBootstrapCallsBootMethodWhenEnabled(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => true
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
        
        // Verify boot was called by checking if boot service was bound
        $this->assertTrue($this->app->bound('test.boot.service'));
    }
    
    public function testBootstrapDoesNotCallBootMethodWhenDisabled(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
        
        // Verify boot was NOT called
        $this->assertFalse($this->app->bound('test.boot.service'));
    }
    
    public function testBootstrapThrowsExceptionForMissingProvider(): void
    {
        $this->expectException(BootstrapException::class);
        $this->expectExceptionMessage('No provider class specified');
        
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => '',
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
    }
    
    public function testBootstrapThrowsExceptionForNonExistentProvider(): void
    {
        $this->expectException(BootstrapException::class);
        $this->expectExceptionMessage('does not exist');
        
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => 'NonExistent\\Provider\\Class',
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
    }
    
    public function testBootstrapThrowsExceptionForInvalidProvider(): void
    {
        $this->expectException(BootstrapException::class);
        $this->expectExceptionMessage('must extend');
        
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => InvalidProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->bootstrapper->bootstrap($module);
    }
    
    public function testIsBootstrappedReturnsTrueAfterBootstrap(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        $this->assertFalse($this->bootstrapper->isBootstrapped('test.module'));
        
        $this->bootstrapper->bootstrap($module);
        
        $this->assertTrue($this->bootstrapper->isBootstrapped('test.module'));
    }
    
    public function testBootstrapSkipsAlreadyBootstrappedModule(): void
    {
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => false
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        
        // Bootstrap once
        $this->bootstrapper->bootstrap($module);
        $firstProvider = $module->provider;
        
        // Bootstrap again
        $this->bootstrapper->bootstrap($module);
        $secondProvider = $module->provider;
        
        // Should be the same provider instance
        $this->assertSame($firstProvider, $secondProvider);
    }
    
    public function testBootstrapAllBootsModulesInDependencyOrder(): void
    {
        // Create modules with dependencies
        $manifestA = $this->createManifest([
            'id' => 'module.a',
            'dependencies' => [],
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => true
            ]
        ]);
        
        $manifestB = $this->createManifest([
            'id' => 'module.b',
            'dependencies' => [
                'modules' => ['module.a']
            ],
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => true
            ]
        ]);
        
        $moduleA = new Module($manifestA, new ResolutionResult());
        $moduleB = new Module($manifestB, new ResolutionResult());
        
        // Register modules in reverse order
        $this->registry->register($moduleB);
        $this->registry->register($moduleA);
        
        // Bootstrap all
        $this->bootstrapper->bootstrapAll();
        
        // Both should be bootstrapped
        $this->assertTrue($this->bootstrapper->isBootstrapped('module.a'));
        $this->assertTrue($this->bootstrapper->isBootstrapped('module.b'));
    }
    
    public function testBootstrapAllContinuesOnModuleFailure(): void
    {
        // Create a good module
        $manifestGood = $this->createManifest([
            'id' => 'module.good',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => true
            ]
        ]);
        
        // Create a bad module (non-existent provider)
        $manifestBad = $this->createManifest([
            'id' => 'module.bad',
            'lifecycle' => [
                'provider' => 'NonExistent\\Provider',
                'boot' => true
            ]
        ]);
        
        $moduleGood = new Module($manifestGood, new ResolutionResult());
        $moduleBad = new Module($manifestBad, new ResolutionResult());
        
        $this->registry->register($moduleBad);
        $this->registry->register($moduleGood);
        
        // Bootstrap all (should not throw exception)
        $this->bootstrapper->bootstrapAll();
        
        // Good module should be bootstrapped
        $this->assertTrue($this->bootstrapper->isBootstrapped('module.good'));
        
        // Bad module should not be bootstrapped
        $this->assertFalse($this->bootstrapper->isBootstrapped('module.bad'));
    }
    
    public function testBootPhaseCompleteMarker(): void
    {
        // Initially not complete
        $this->assertFalse($this->bootstrapper->isBootPhaseComplete());
        
        // Create and register a module
        $manifest = $this->createManifest([
            'id' => 'test.module',
            'lifecycle' => [
                'provider' => TestServiceProvider::class,
                'boot' => true
            ]
        ]);
        
        $module = new Module($manifest, new ResolutionResult());
        $this->registry->register($module);
        
        // Bootstrap all
        $this->bootstrapper->bootstrapAll();
        
        // Should be complete now
        $this->assertTrue($this->bootstrapper->isBootPhaseComplete());
    }
    
    public function testBootPhaseCompleteEvenWithFailures(): void
    {
        // Create a bad module
        $manifestBad = $this->createManifest([
            'id' => 'module.bad',
            'lifecycle' => [
                'provider' => 'NonExistent\\Provider',
                'boot' => true
            ]
        ]);
        
        $moduleBad = new Module($manifestBad, new ResolutionResult());
        $this->registry->register($moduleBad);
        
        // Bootstrap all
        $this->bootstrapper->bootstrapAll();
        
        // Boot phase should still be marked complete
        $this->assertTrue($this->bootstrapper->isBootPhaseComplete());
    }
    
    /**
     * Helper to create a manifest
     */
    protected function createManifest(array $data): Manifest
    {
        $defaults = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module'
        ];
        
        return new Manifest(array_merge($defaults, $data), '/test/path');
    }
}


// Test helper classes

/**
 * Test Service Provider
 */
class TestServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind('test.service', function() {
            return 'test service';
        });
    }
    
    public function boot(): void
    {
        $this->app->bind('test.boot.service', function() {
            return 'test boot service';
        });
    }
}

/**
 * Invalid Provider (does not extend ServiceProvider)
 */
class InvalidProvider
{
    public function __construct(Application $app)
    {
        // Invalid provider
    }
}
