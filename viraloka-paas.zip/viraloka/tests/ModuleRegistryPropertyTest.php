<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\ModuleLoader;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\DependencyResolver;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Workspace\Workspace;

/**
 * Module Registry Property Tests
 * 
 * Property-based tests for module registry bootstrap integration.
 * Feature: core-bootstrap-flow
 */
class ModuleRegistryPropertyTest extends TestCase
{
    protected string $testModulesPath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create temporary test modules directory
        $this->testModulesPath = sys_get_temp_dir() . '/viraloka-test-modules-' . uniqid();
        mkdir($this->testModulesPath, 0777, true);
    }
    
    protected function tearDown(): void
    {
        // Clean up test directory
        $this->removeDirectory($this->testModulesPath);
        parent::tearDown();
    }
    
    /**
     * Property 13: Module Discovery Completeness
     * 
     * For any modules directory containing module.json files, the Module Registry
     * SHALL discover all valid manifest files.
     * 
     * Feature: core-bootstrap-flow, Property 13: Module Discovery Completeness
     * Validates: Requirements 8.1
     */
    public function testModuleDiscoveryCompleteness(): void
    {
        // Test with different numbers of modules
        $testCases = [1, 3, 5, 10];
        
        foreach ($testCases as $moduleCount) {
            // Create test modules
            $expectedModuleIds = [];
            for ($i = 1; $i <= $moduleCount; $i++) {
                $moduleId = "test.module{$i}";
                $expectedModuleIds[] = $moduleId;
                $this->createValidModule($moduleId, "Test Module {$i}");
            }
            
            // Set up registry and loader
            $registry = new ModuleRegistry();
            $loader = $this->createModuleLoader($registry);
            
            // Initialize registry (triggers discovery)
            $registry->initialize($loader);
            
            // Assert all modules were discovered
            $discoveredModules = $registry->all();
            $discoveredIds = $discoveredModules->map(fn($m) => $m->getId())->toArray();
            
            sort($expectedModuleIds);
            sort($discoveredIds);
            
            $this->assertEquals(
                $expectedModuleIds,
                $discoveredIds,
                "Failed to discover all {$moduleCount} modules. Expected: " . 
                implode(', ', $expectedModuleIds) . " Got: " . implode(', ', $discoveredIds)
            );
            
            // Clean up for next iteration
            $this->removeDirectory($this->testModulesPath);
            mkdir($this->testModulesPath, 0777, true);
        }
    }
    
    /**
     * Property 14: Manifest Validation Consistency
     * 
     * For any manifest file, the Module Registry SHALL validate it against the schema
     * and mark it as valid or invalid accordingly.
     * 
     * Feature: core-bootstrap-flow, Property 14: Manifest Validation Consistency
     * Validates: Requirements 8.2
     */
    public function testManifestValidationConsistency(): void
    {
        // Test cases: valid and invalid manifests
        $testCases = [
            // Valid manifests
            [
                'valid' => true,
                'manifest' => [
                    'id' => 'valid.module1',
                    'name' => 'Valid Module 1',
                    'description' => 'A valid module',
                    'version' => '1.0.0',
                    'author' => 'Test Author',
                    'namespace' => 'Viraloka\\Modules\\ValidModule1'
                ]
            ],
            [
                'valid' => true,
                'manifest' => [
                    'id' => 'valid.module2',
                    'name' => 'Valid Module 2',
                    'description' => 'Another valid module',
                    'version' => '2.0.0',
                    'author' => 'Another Author',
                    'namespace' => 'Viraloka\\Modules\\ValidModule2',
                    'dependencies' => [
                        'core' => '>=1.0.0'
                    ]
                ]
            ],
            // Invalid manifests
            [
                'valid' => false,
                'manifest' => [
                    'id' => 'invalid.module1',
                    'name' => 'Invalid Module 1'
                    // Missing required fields: description, version, author, namespace
                ]
            ],
            [
                'valid' => false,
                'manifest' => [
                    'id' => 'invalid.module2',
                    'name' => 'Invalid Module 2',
                    'description' => 'Missing version',
                    'author' => 'Test Author',
                    'namespace' => 'Viraloka\\Modules\\InvalidModule2'
                    // Missing: version
                ]
            ],
            [
                'valid' => false,
                'manifest' => [
                    // Missing id
                    'name' => 'Invalid Module 3',
                    'description' => 'Missing ID',
                    'version' => '1.0.0',
                    'author' => 'Test Author',
                    'namespace' => 'Viraloka\\Modules\\InvalidModule3'
                ]
            ]
        ];
        
        foreach ($testCases as $index => $testCase) {
            $manifest = $testCase['manifest'];
            $shouldBeValid = $testCase['valid'];
            $moduleId = $manifest['id'] ?? "unknown{$index}";
            
            // Create module directory and manifest file
            $modulePath = $this->testModulesPath . '/' . str_replace('.', '-', $moduleId);
            mkdir($modulePath, 0777, true);
            file_put_contents($modulePath . '/module.json', json_encode($manifest, JSON_PRETTY_PRINT));
            
            // Set up registry and loader
            $registry = new ModuleRegistry();
            $loader = $this->createModuleLoader($registry);
            
            // Initialize registry
            $registry->initialize($loader);
            
            // Check validation result
            if ($shouldBeValid) {
                // Valid manifest should be in registry
                $this->assertTrue(
                    $registry->has($moduleId),
                    "Valid module '{$moduleId}' should be registered"
                );
                $this->assertCount(
                    0,
                    $registry->getInvalidModules(),
                    "Valid module '{$moduleId}' should not be in invalid modules"
                );
            } else {
                // Invalid manifest should be in invalid modules
                $invalidModules = $registry->getInvalidModules();
                $this->assertGreaterThan(
                    0,
                    $invalidModules->count(),
                    "Invalid module '{$moduleId}' should be in invalid modules collection"
                );
                
                // Should not be in valid registry
                if (isset($manifest['id'])) {
                    $this->assertFalse(
                        $registry->has($moduleId),
                        "Invalid module '{$moduleId}' should not be in valid registry"
                    );
                }
            }
            
            // Clean up for next iteration
            $this->removeDirectory($this->testModulesPath);
            mkdir($this->testModulesPath, 0777, true);
        }
    }
    
    /**
     * Helper: Create a valid module manifest
     */
    protected function createValidModule(string $id, string $name): void
    {
        $modulePath = $this->testModulesPath . '/' . str_replace('.', '-', $id);
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => $id,
            'name' => $name,
            'description' => "Description for {$name}",
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\' . str_replace('.', '', ucwords($id, '.'))
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest, JSON_PRETTY_PRINT));
    }
    
    /**
     * Helper: Create module loader with dependencies
     */
    protected function createModuleLoader(ModuleRegistry $registry): ModuleLoader
    {
        $validator = new SchemaValidator();
        $parser = new ManifestParser($validator);
        $dependencyResolver = new DependencyResolver($registry);
        $contextResolver = new ContextResolver($registry);
        
        return new ModuleLoader(
            $parser,
            $dependencyResolver,
            $registry,
            $contextResolver,
            $this->testModulesPath
        );
    }
    
    /**
     * Helper: Recursively remove directory
     */
    protected function removeDirectory(string $path): void
    {
        if (!file_exists($path)) {
            return;
        }
        
        if (is_dir($path)) {
            $files = array_diff(scandir($path), ['.', '..']);
            foreach ($files as $file) {
                $this->removeDirectory($path . '/' . $file);
            }
            rmdir($path);
        } else {
            unlink($path);
        }
    }

    /**
     * Property 15: Dependency Resolution Correctness
     * 
     * For any set of modules with soft dependencies, the Dependency Resolver SHALL
     * determine a valid loading order that respects dependencies.
     * 
     * Feature: core-bootstrap-flow, Property 15: Dependency Resolution Correctness
     * Validates: Requirements 8.3
     */
    public function testDependencyResolutionCorrectness(): void
    {
        // Test case 1: Module with satisfied dependency
        $this->createValidModule('base.module', 'Base Module');
        $this->createModuleWithDependency('dependent.module', 'Dependent Module', ['base.module']);
        
        $registry = new ModuleRegistry();
        $loader = $this->createModuleLoader($registry);
        $registry->initialize($loader);
        
        // Both modules should be loaded
        $this->assertTrue($registry->has('base.module'), 'Base module should be loaded');
        $this->assertTrue($registry->has('dependent.module'), 'Dependent module should be loaded');
        
        // Dependent module should have resolution result showing dependency is available
        $dependentModule = $registry->get('dependent.module');
        $this->assertNotNull($dependentModule);
        $this->assertContains('base.module', $dependentModule->resolutionResult->availableModules);
        
        // Clean up
        $this->removeDirectory($this->testModulesPath);
        mkdir($this->testModulesPath, 0777, true);
        
        // Test case 2: Module with missing dependency (soft dependency - should still load)
        $this->createModuleWithDependency('dependent2.module', 'Dependent Module 2', ['missing.module']);
        
        $registry2 = new ModuleRegistry();
        $loader2 = $this->createModuleLoader($registry2);
        $registry2->initialize($loader2);
        
        // Module should still be loaded (soft dependencies)
        $this->assertTrue($registry2->has('dependent2.module'), 'Module with missing dependency should still load');
        
        // Resolution result should show missing dependency
        $dependentModule2 = $registry2->get('dependent2.module');
        $this->assertNotNull($dependentModule2);
        $this->assertContains('missing.module', $dependentModule2->resolutionResult->missingModules);
        
        // Clean up
        $this->removeDirectory($this->testModulesPath);
        mkdir($this->testModulesPath, 0777, true);
        
        // Test case 3: Chain of dependencies
        $this->createValidModule('module.a', 'Module A');
        $this->createModuleWithDependency('module.b', 'Module B', ['module.a']);
        $this->createModuleWithDependency('module.c', 'Module C', ['module.b']);
        
        $registry3 = new ModuleRegistry();
        $loader3 = $this->createModuleLoader($registry3);
        $registry3->initialize($loader3);
        
        // All modules should be loaded
        $this->assertTrue($registry3->has('module.a'), 'Module A should be loaded');
        $this->assertTrue($registry3->has('module.b'), 'Module B should be loaded');
        $this->assertTrue($registry3->has('module.c'), 'Module C should be loaded');
        
        // Verify dependency chains
        $moduleB = $registry3->get('module.b');
        $this->assertContains('module.a', $moduleB->resolutionResult->availableModules);
        
        $moduleC = $registry3->get('module.c');
        $this->assertContains('module.b', $moduleC->resolutionResult->availableModules);
        
        // Clean up
        $this->removeDirectory($this->testModulesPath);
        mkdir($this->testModulesPath, 0777, true);
    }
    
    /**
     * Helper: Create a module with dependencies
     */
    protected function createModuleWithDependency(string $id, string $name, array $dependencies): void
    {
        $modulePath = $this->testModulesPath . '/' . str_replace('.', '-', $id);
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => $id,
            'name' => $name,
            'description' => "Description for {$name}",
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\' . str_replace('.', '', ucwords($id, '.')),
            'dependencies' => [
                'modules' => $dependencies
            ]
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest, JSON_PRETTY_PRINT));
    }

    /**
     * Property 16: Workspace Module Filtering
     * 
     * For any workspace with a list of enabled modules, the Module Registry SHALL
     * only activate modules that are enabled for that workspace.
     * 
     * Feature: core-bootstrap-flow, Property 16: Workspace Module Filtering
     * Validates: Requirements 8.4
     */
    public function testWorkspaceModuleFiltering(): void
    {
        // Create multiple modules
        $this->createValidModule('module.one', 'Module One');
        $this->createValidModule('module.two', 'Module Two');
        $this->createValidModule('module.three', 'Module Three');
        $this->createValidModule('module.four', 'Module Four');
        
        // Test case 1: Workspace with specific enabled modules
        $workspace1 = new Workspace(
            'workspace1',
            'Workspace 1',
            'example.com',
            [],
            ['module.one', 'module.three'] // Only these modules enabled
        );
        
        $registry1 = new ModuleRegistry();
        $loader1 = $this->createModuleLoader($registry1);
        $registry1->initialize($loader1, $workspace1);
        
        // Only enabled modules should be in registry
        $this->assertTrue($registry1->has('module.one'), 'Module one should be enabled');
        $this->assertFalse($registry1->has('module.two'), 'Module two should not be enabled');
        $this->assertTrue($registry1->has('module.three'), 'Module three should be enabled');
        $this->assertFalse($registry1->has('module.four'), 'Module four should not be enabled');
        
        $this->assertCount(2, $registry1->all(), 'Should have exactly 2 enabled modules');
        
        // Test case 2: Workspace with no enabled modules list (all enabled)
        $workspace2 = new Workspace(
            'workspace2',
            'Workspace 2',
            'example2.com',
            [],
            [] // Empty list means all modules enabled
        );
        
        $registry2 = new ModuleRegistry();
        $loader2 = $this->createModuleLoader($registry2);
        $registry2->initialize($loader2, $workspace2);
        
        // All modules should be enabled
        $this->assertTrue($registry2->has('module.one'));
        $this->assertTrue($registry2->has('module.two'));
        $this->assertTrue($registry2->has('module.three'));
        $this->assertTrue($registry2->has('module.four'));
        
        $this->assertCount(4, $registry2->all(), 'Should have all 4 modules enabled');
        
        // Test case 3: Workspace with different enabled modules
        $workspace3 = new Workspace(
            'workspace3',
            'Workspace 3',
            'example3.com',
            [],
            ['module.two', 'module.four']
        );
        
        $registry3 = new ModuleRegistry();
        $loader3 = $this->createModuleLoader($registry3);
        $registry3->initialize($loader3, $workspace3);
        
        // Only workspace3's enabled modules should be in registry
        $this->assertFalse($registry3->has('module.one'));
        $this->assertTrue($registry3->has('module.two'));
        $this->assertFalse($registry3->has('module.three'));
        $this->assertTrue($registry3->has('module.four'));
        
        $this->assertCount(2, $registry3->all(), 'Should have exactly 2 enabled modules');
        
        // Test getModulesForWorkspace method
        $registry4 = new ModuleRegistry();
        $loader4 = $this->createModuleLoader($registry4);
        $registry4->initialize($loader4); // Initialize without workspace filtering
        
        $workspace4 = new Workspace(
            'workspace4',
            'Workspace 4',
            'example4.com',
            [],
            ['module.one']
        );
        
        $filteredModules = $registry4->getModulesForWorkspace($workspace4);
        $this->assertCount(1, $filteredModules, 'Should return only enabled modules');
        $this->assertTrue($filteredModules->contains(fn($m) => $m->getId() === 'module.one'));
    }

    /**
     * Property 17: No Module Code Execution During Boot
     * 
     * For any module discovered during the boot phase, the Module Registry SHALL
     * not execute any module code until the ready phase.
     * 
     * Feature: core-bootstrap-flow, Property 17: No Module Code Execution During Boot
     * Validates: Requirements 8.5
     */
    public function testNoModuleCodeExecutionDuringBoot(): void
    {
        // Create a module with a service provider that would execute code
        $moduleId = 'test.execution';
        $modulePath = $this->testModulesPath . '/' . str_replace('.', '-', $moduleId);
        mkdir($modulePath, 0777, true);
        
        // Create a test file that will be "executed" if module code runs
        $executionMarkerFile = $modulePath . '/execution_marker.txt';
        
        // Create service provider that writes to marker file
        $srcPath = $modulePath . '/src';
        mkdir($srcPath, 0777, true);
        
        $serviceProviderCode = <<<'PHP'
<?php
namespace Viraloka\Modules\TestExecution;

class TestServiceProvider
{
    public function __construct()
    {
        // This should NOT be called during boot phase
        file_put_contents(__DIR__ . '/../execution_marker.txt', 'EXECUTED');
    }
    
    public function register()
    {
        // This should NOT be called during boot phase
        file_put_contents(__DIR__ . '/../execution_marker.txt', 'REGISTERED');
    }
    
    public function boot()
    {
        // This should NOT be called during boot phase
        file_put_contents(__DIR__ . '/../execution_marker.txt', 'BOOTED');
    }
}
PHP;
        
        file_put_contents($srcPath . '/TestServiceProvider.php', $serviceProviderCode);
        
        // Create manifest
        $manifest = [
            'id' => $moduleId,
            'name' => 'Test Execution Module',
            'description' => 'Module to test code execution',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestExecution',
            'provider' => 'Viraloka\\Modules\\TestExecution\\TestServiceProvider'
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest, JSON_PRETTY_PRINT));
        
        // Initialize registry (boot phase)
        $registry = new ModuleRegistry();
        $loader = $this->createModuleLoader($registry);
        $registry->initialize($loader);
        
        // Verify module was discovered
        $this->assertTrue($registry->has($moduleId), 'Module should be discovered');
        
        // Verify NO code was executed (marker file should not exist)
        $this->assertFileDoesNotExist(
            $executionMarkerFile,
            'Module code should NOT be executed during boot phase'
        );
        
        // Verify module is in registry but not bootstrapped
        $module = $registry->get($moduleId);
        $this->assertNotNull($module, 'Module should be in registry');
        $this->assertNotNull($module->manifest, 'Module should have manifest');
        
        // Test with multiple modules
        $this->createValidModule('module.a', 'Module A');
        $this->createValidModule('module.b', 'Module B');
        
        $registry2 = new ModuleRegistry();
        $loader2 = $this->createModuleLoader($registry2);
        $registry2->initialize($loader2);
        
        // All modules should be discovered
        $this->assertCount(3, $registry2->all(), 'All modules should be discovered');
        
        // But execution marker should still not exist
        $this->assertFileDoesNotExist(
            $executionMarkerFile,
            'No module code should be executed even with multiple modules'
        );
    }
}
