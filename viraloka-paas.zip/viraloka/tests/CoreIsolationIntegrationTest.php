<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\Kernel;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use Viraloka\Core\Adapter\AdapterRegistry;
use Viraloka\Adapter\Testing\NullRuntimeAdapter;
use Viraloka\Adapter\Testing\MockRequestAdapter;
use Viraloka\Adapter\Testing\MockResponseAdapter;
use Viraloka\Adapter\Testing\MockAuthAdapter;
use Viraloka\Adapter\Testing\InMemoryStorageAdapter;
use Viraloka\Adapter\Testing\MockEventAdapter;

/**
 * Core Isolation Integration Tests
 * 
 * Tests that Viraloka Core can boot and operate completely independently
 * of WordPress or any other host environment using test adapters.
 * 
 * Validates: Requirements 11.1, 11.2, 11.3
 */
class CoreIsolationIntegrationTest extends TestCase
{
    private Application $app;
    private string $testBasePath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create test base path
        $this->testBasePath = __DIR__;
        
        // Create fresh application instance
        $this->app = new Application($this->testBasePath);
    }
    
    /**
     * Test Core can boot with test adapters (no WordPress)
     * 
     * This is the critical test that proves Core isolation.
     * If this test passes, Core is truly engine-agnostic.
     * 
     * Validates: Requirements 11.1
     */
    public function testCoreBootsWithTestAdapters(): void
    {
        // Register test adapters BEFORE creating Kernel
        $this->registerTestAdapters();
        
        // Create kernel - it should NOT try to detect WordPress
        // because we've already registered adapters
        $kernel = $this->createKernelWithTestAdapters();
        
        // Bootstrap should complete successfully
        $kernel->bootstrap();
        
        // Assert kernel is bootstrapped
        $this->assertTrue($kernel->isBootstrapped());
        $this->assertTrue($kernel->isReady());
        
        // Assert no WordPress functions were called
        // (if they were, the test would fail because WordPress isn't loaded)
    }
    
    /**
     * Test Core services work with test adapters
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testCoreServicesWorkWithTestAdapters(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Get adapter registry
        $registry = $this->app->make(AdapterRegistryInterface::class);
        
        // Verify all adapters are test implementations
        $this->assertInstanceOf(NullRuntimeAdapter::class, $registry->runtime());
        $this->assertInstanceOf(MockRequestAdapter::class, $registry->request());
        $this->assertInstanceOf(MockResponseAdapter::class, $registry->response());
        $this->assertInstanceOf(MockAuthAdapter::class, $registry->auth());
        $this->assertInstanceOf(InMemoryStorageAdapter::class, $registry->storage());
        $this->assertInstanceOf(MockEventAdapter::class, $registry->event());
        
        // Test that services can use adapters
        $storage = $registry->storage();
        $storage->set('test_key', 'test_value');
        $this->assertEquals('test_value', $storage->get('test_key'));
        
        $runtime = $registry->runtime();
        $this->assertEquals('testing', $runtime->environment());
        $this->assertFalse($runtime->isAdmin());
    }
    
    /**
     * Test module loading works with test adapters
     * 
     * Validates: Requirements 11.2, 11.3
     */
    public function testModuleLoadingWorksWithTestAdapters(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Assert module loader is available
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Contracts\ModuleLoaderContract::class));
        
        // Get module loader
        $moduleLoader = $this->app->make(\Viraloka\Core\Modules\Contracts\ModuleLoaderContract::class);
        $this->assertInstanceOf(\Viraloka\Core\Modules\ModuleLoader::class, $moduleLoader);
        
        // Module loader should work without WordPress
        // (it will scan the modules directory and parse manifests)
        $modules = $moduleLoader->loadModules();
        $this->assertIsArray($modules);
    }
    
    /**
     * Test event system works with test adapters
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testEventSystemWorksWithTestAdapters(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        
        // Track events
        $eventsDispatched = [];
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.register', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'register';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.boot', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'boot';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.ready', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'ready';
        });
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert events were dispatched using test adapter
        $this->assertContains('register', $eventsDispatched);
        $this->assertContains('boot', $eventsDispatched);
        $this->assertContains('ready', $eventsDispatched);
    }
    
    /**
     * Test storage operations work with in-memory adapter
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testStorageOperationsWorkWithInMemoryAdapter(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Get storage adapter
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $storage = $registry->storage();
        
        // Test basic operations
        $storage->set('key1', 'value1');
        $this->assertEquals('value1', $storage->get('key1'));
        $this->assertTrue($storage->has('key1'));
        
        // Test TTL
        $storage->set('key2', 'value2', 1);
        $this->assertEquals('value2', $storage->get('key2'));
        sleep(2);
        $this->assertNull($storage->get('key2'));
        
        // Test delete
        $storage->set('key3', 'value3');
        $storage->delete('key3');
        $this->assertFalse($storage->has('key3'));
        
        // Test batch operations
        $storage->setMany(['a' => 1, 'b' => 2, 'c' => 3]);
        $values = $storage->getMany(['a', 'b', 'c']);
        $this->assertEquals(['a' => 1, 'b' => 2, 'c' => 3], $values);
        
        // Test clear
        $storage->clear();
        $this->assertFalse($storage->has('a'));
    }
    
    /**
     * Test authentication works with mock auth adapter
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testAuthenticationWorksWithMockAuthAdapter(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Get auth adapter
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $auth = $registry->auth();
        
        // Initially not authenticated
        $this->assertFalse($auth->isAuthenticated());
        $this->assertNull($auth->currentUser());
        
        // Set a mock user
        $user = new \Viraloka\Core\Adapter\ValueObjects\User(
            id: '123',
            email: 'test@example.com',
            displayName: 'Test User',
            roles: ['admin', 'editor'],
            meta: []
        );
        
        $auth->setCurrentUser($user);
        
        // Now authenticated
        $this->assertTrue($auth->isAuthenticated());
        $this->assertNotNull($auth->currentUser());
        $this->assertEquals('123', $auth->currentUser()->id);
        $this->assertEquals('test@example.com', $auth->currentUser()->email);
        
        // Test roles
        $this->assertTrue($auth->hasRole('admin'));
        $this->assertTrue($auth->hasRole('editor'));
        $this->assertFalse($auth->hasRole('subscriber'));
        
        // Test permissions
        $auth->addPermission('manage_workspace');
        $this->assertTrue($auth->hasPermission('manage_workspace'));
        $this->assertFalse($auth->hasPermission('delete_everything'));
    }
    
    /**
     * Test request/response work with mock adapters
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testRequestResponseWorkWithMockAdapters(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Get adapters
        $registry = $this->app->make(AdapterRegistryInterface::class);
        $request = $registry->request();
        $response = $registry->response();
        
        // Test request
        $request->setMethod('POST');
        $request->setPath('/api/test');
        $request->setQuery(['foo' => 'bar']);
        
        $this->assertEquals('POST', $request->getMethod());
        $this->assertEquals('/api/test', $request->getPath());
        $this->assertEquals('bar', $request->getQueryParam('foo'));
        
        // Test response
        $response->json(['status' => 'ok'], 200);
        $this->assertTrue($response->hasResponses());
        
        $lastResponse = $response->getLastResponse();
        $this->assertEquals('json', $lastResponse['type']);
        $this->assertEquals(['status' => 'ok'], $lastResponse['data']);
        $this->assertEquals(200, $lastResponse['status']);
    }
    
    /**
     * Test Core isolation - no WordPress dependencies
     * 
     * This test verifies that Core doesn't call any WordPress functions
     * by running in an environment where WordPress is not loaded.
     * 
     * Validates: Requirements 11.1, 11.3
     */
    public function testCoreIsolationNoWordPressDependencies(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        
        // If Core tries to call WordPress functions, this will fail
        // because WordPress is not loaded in the test environment
        $kernel->bootstrap();
        
        // If we get here, Core didn't call any WordPress functions
        $this->assertTrue($kernel->isBootstrapped());
        
        // Verify all core services are available
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\SecurityGuard::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Bootstrap\PerformanceGuard::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\WorkspaceResolver::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Context\ContextResolver::class));
    }
    
    /**
     * Test runtime adapter environment configuration
     * 
     * Validates: Requirements 11.1, 11.2
     */
    public function testRuntimeAdapterEnvironmentConfiguration(): void
    {
        // Create custom runtime adapter with specific configuration
        $runtime = new NullRuntimeAdapter('production', true, false);
        
        $this->assertEquals('production', $runtime->environment());
        $this->assertTrue($runtime->isEnvironment('production'));
        $this->assertFalse($runtime->isEnvironment('development'));
        $this->assertTrue($runtime->isAdmin());
        $this->assertFalse($runtime->isCli());
        
        // Test environment switching
        $runtime->setEnvironment('development');
        $this->assertEquals('development', $runtime->environment());
        $this->assertTrue($runtime->isEnvironment('development'));
        
        // Test context switching
        $runtime->setIsAdmin(false);
        $this->assertFalse($runtime->isAdmin());
        
        $runtime->setIsCli(true);
        $this->assertTrue($runtime->isCli());
    }
    
    /**
     * Test module bootstrapper works with test adapters
     * 
     * Validates: Requirements 11.2, 11.3
     */
    public function testModuleBootstrapperWorksWithTestAdapters(): void
    {
        // Register test adapters
        $this->registerTestAdapters();
        
        // Create and bootstrap kernel
        $kernel = $this->createKernelWithTestAdapters();
        $kernel->bootstrap();
        
        // Assert module bootstrapper is available
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract::class));
        
        // Get module bootstrapper
        $bootstrapper = $this->app->make(\Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract::class);
        $this->assertInstanceOf(\Viraloka\Core\Modules\ModuleBootstrapper::class, $bootstrapper);
        
        // Bootstrapper should work without WordPress
        // (it will register service providers and execute bootstrap hooks)
    }
    
    // Helper methods
    
    /**
     * Register test adapters in the application container
     */
    private function registerTestAdapters(): void
    {
        $registry = new AdapterRegistry();
        
        // Register all test adapters
        $registry->registerRuntime(new NullRuntimeAdapter('testing', false, false));
        $registry->registerRequest(new MockRequestAdapter());
        $registry->registerResponse(new MockResponseAdapter());
        $registry->registerAuth(new MockAuthAdapter());
        $registry->registerStorage(new InMemoryStorageAdapter());
        $registry->registerEvent(new MockEventAdapter());
        
        // Register in container
        $this->app->instance(AdapterRegistryInterface::class, $registry);
        $this->app->instance(AdapterRegistry::class, $registry);
    }
    
    /**
     * Create a Kernel that uses pre-registered test adapters
     * 
     * This bypasses the normal adapter detection in Kernel
     */
    private function createKernelWithTestAdapters(): Kernel
    {
        // Create a custom Kernel subclass that doesn't detect adapters
        return new class($this->app) extends Kernel {
            protected function detectAndRegisterAdapters(\Viraloka\Core\Adapter\AdapterRegistry $registry): void
            {
                // Do nothing - adapters are already registered
                // This prevents the Kernel from trying to detect WordPress
            }
        };
    }
}
