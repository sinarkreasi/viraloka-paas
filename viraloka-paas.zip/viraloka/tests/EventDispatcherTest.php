<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Events\EventDispatcher;

/**
 * Unit Tests for Event Dispatcher
 * 
 * Tests specific examples and edge cases for the Event Dispatcher.
 */
class EventDispatcherTest extends TestCase
{
    protected EventDispatcher $dispatcher;
    
    protected function setUp(): void
    {
        parent::setUp();
        $this->dispatcher = new EventDispatcher();
    }
    
    /**
     * Test basic listener registration and execution
     */
    public function testBasicListenerRegistration(): void
    {
        $executed = false;
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed = true;
        });
        
        $this->dispatcher->dispatch('test.event');
        
        $this->assertTrue($executed, 'Listener should be executed');
    }
    
    /**
     * Test listener receives arguments
     */
    public function testListenerReceivesArguments(): void
    {
        $receivedArg = null;
        
        $this->dispatcher->listen('test.event', function ($arg) use (&$receivedArg) {
            $receivedArg = $arg;
        });
        
        $this->dispatcher->dispatch('test.event', 'test-value');
        
        $this->assertEquals('test-value', $receivedArg, 'Listener should receive arguments');
    }
    
    /**
     * Test multiple arguments are passed correctly
     */
    public function testMultipleArguments(): void
    {
        $receivedArgs = [];
        
        $this->dispatcher->listen('test.event', function (...$args) use (&$receivedArgs) {
            $receivedArgs = $args;
        });
        
        $this->dispatcher->dispatch('test.event', 'arg1', 'arg2', 'arg3');
        
        $this->assertEquals(['arg1', 'arg2', 'arg3'], $receivedArgs, 'All arguments should be passed');
    }
    
    /**
     * Test hasListeners method
     */
    public function testHasListeners(): void
    {
        $this->assertFalse($this->dispatcher->hasListeners('test.event'), 'Should not have listeners initially');
        
        $this->dispatcher->listen('test.event', function () {});
        
        $this->assertTrue($this->dispatcher->hasListeners('test.event'), 'Should have listeners after registration');
    }
    
    /**
     * Test getListeners returns listeners in correct order
     */
    public function testGetListeners(): void
    {
        $this->dispatcher->listen('test.event', function () {}, 10);
        $this->dispatcher->listen('test.event', function () {}, 5);
        $this->dispatcher->listen('test.event', function () {}, 10);
        
        $listeners = $this->dispatcher->getListeners('test.event');
        
        $this->assertCount(3, $listeners, 'Should have 3 listeners');
        
        // Verify order: priority 5, then two priority 10s in registration order
        $this->assertEquals(5, $listeners[0]['priority']);
        $this->assertEquals(10, $listeners[1]['priority']);
        $this->assertEquals(10, $listeners[2]['priority']);
        
        // Verify registration order within same priority
        $this->assertLessThan($listeners[2]['order'], $listeners[1]['order']);
    }
    
    /**
     * Test removeListeners method
     */
    public function testRemoveListeners(): void
    {
        $this->dispatcher->listen('test.event', function () {});
        $this->assertTrue($this->dispatcher->hasListeners('test.event'));
        
        $this->dispatcher->removeListeners('test.event');
        
        $this->assertFalse($this->dispatcher->hasListeners('test.event'), 'Listeners should be removed');
    }
    
    /**
     * Test getListenerCount method
     */
    public function testGetListenerCount(): void
    {
        $this->assertEquals(0, $this->dispatcher->getListenerCount(), 'Should have 0 listeners initially');
        
        $this->dispatcher->listen('event1', function () {});
        $this->dispatcher->listen('event1', function () {});
        $this->dispatcher->listen('event2', function () {});
        
        $this->assertEquals(3, $this->dispatcher->getListenerCount(), 'Should count all listeners across events');
    }
    
    /**
     * Test dispatching event with no listeners doesn't error
     */
    public function testDispatchWithNoListeners(): void
    {
        // Should not throw
        $this->dispatcher->dispatch('nonexistent.event');
        
        $this->assertTrue(true, 'Dispatching event with no listeners should not error');
    }
    
    /**
     * Test listener exception doesn't prevent other listeners from executing
     */
    public function testListenerExceptionDoesNotBlockOthers(): void
    {
        $executed = [];
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'first';
        });
        
        $this->dispatcher->listen('test.event', function () {
            throw new \RuntimeException('Test exception');
        });
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'third';
        });
        
        // Should not throw
        $this->dispatcher->dispatch('test.event');
        
        $this->assertEquals(['first', 'third'], $executed, 'Non-failing listeners should execute');
    }
    
    /**
     * Test priority ordering
     */
    public function testPriorityOrdering(): void
    {
        $executed = [];
        
        // Register in reverse priority order
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'priority-20';
        }, 20);
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'priority-10';
        }, 10);
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'priority-5';
        }, 5);
        
        $this->dispatcher->dispatch('test.event');
        
        $this->assertEquals(['priority-5', 'priority-10', 'priority-20'], $executed, 
            'Listeners should execute in priority order (lower priority first)');
    }
    
    /**
     * Test default priority is 10
     */
    public function testDefaultPriority(): void
    {
        $executed = [];
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'priority-5';
        }, 5);
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'default';
        }); // Default priority should be 10
        
        $this->dispatcher->listen('test.event', function () use (&$executed) {
            $executed[] = 'priority-15';
        }, 15);
        
        $this->dispatcher->dispatch('test.event');
        
        $this->assertEquals(['priority-5', 'default', 'priority-15'], $executed,
            'Default priority should be 10');
    }
}
