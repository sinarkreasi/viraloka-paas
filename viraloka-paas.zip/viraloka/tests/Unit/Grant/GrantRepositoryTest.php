<?php

declare(strict_types=1);

namespace Tests\Unit\Grant;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Grant\Grant;
use Viraloka\Core\Grant\Repositories\GrantRepository;
use Viraloka\Adapter\Testing\InMemoryStorageAdapter;
use DateTimeImmutable;

/**
 * Unit tests for GrantRepository
 * 
 * Tests grant persistence and retrieval operations.
 */
class GrantRepositoryTest extends TestCase
{
    private InMemoryStorageAdapter $storageAdapter;
    private GrantRepository $repository;

    protected function setUp(): void
    {
        $this->storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new GrantRepository($this->storageAdapter);
    }

    public function testCreateGrant(): void
    {
        // Arrange
        $grant = new Grant(
            'grant-123',
            'identity-456',
            'workspace-789',
            'member',
            new DateTimeImmutable('+1 hour')
        );

        // Act
        $result = $this->repository->create($grant);

        // Assert
        $this->assertInstanceOf(Grant::class, $result);
        $this->assertEquals($grant->grantId, $result->grantId);
    }

    public function testFindById(): void
    {
        // Arrange
        $grant = new Grant(
            'grant-123',
            'identity-456',
            'workspace-789',
            'member',
            new DateTimeImmutable('+1 hour'),
            null,
            null,
            ['key' => 'value']
        );
        $this->repository->create($grant);

        // Act
        $found = $this->repository->findById('grant-123');

        // Assert
        $this->assertNotNull($found);
        $this->assertEquals('grant-123', $found->grantId);
        $this->assertEquals('identity-456', $found->identityId);
        $this->assertEquals('workspace-789', $found->workspaceId);
        $this->assertEquals('member', $found->role);
        $this->assertEquals(['key' => 'value'], $found->metadata);
    }

    public function testFindByIdReturnsNullForNonExistent(): void
    {
        // Act
        $found = $this->repository->findById('non-existent');

        // Assert
        $this->assertNull($found);
    }

    public function testUpdateGrant(): void
    {
        // Arrange
        $grant = new Grant(
            'grant-123',
            'identity-456',
            'workspace-789',
            'member',
            null,
            5
        );
        $this->repository->create($grant);

        // Consume usage
        $grant->consume();

        // Act
        $updated = $this->repository->update($grant);

        // Assert
        $this->assertEquals(1, $updated->currentUsage);

        // Verify persistence
        $found = $this->repository->findById('grant-123');
        $this->assertEquals(1, $found->currentUsage);
    }

    public function testDeleteGrant(): void
    {
        // Arrange
        $grant = new Grant(
            'grant-123',
            'identity-456',
            'workspace-789',
            'member',
            new DateTimeImmutable('+1 hour')
        );
        $this->repository->create($grant);

        // Act
        $result = $this->repository->delete('grant-123');

        // Assert
        $this->assertTrue($result);
        $this->assertNull($this->repository->findById('grant-123'));
    }

    public function testFindActiveByIdentityAndWorkspace(): void
    {
        // Arrange
        $grant1 = new Grant('grant-1', 'identity-1', 'workspace-1', 'member', new DateTimeImmutable('+1 hour'));
        $grant2 = new Grant('grant-2', 'identity-1', 'workspace-1', 'admin', null, 5);
        $grant3 = new Grant('grant-3', 'identity-1', 'workspace-2', 'member', new DateTimeImmutable('+1 hour'));
        $grant4 = new Grant('grant-4', 'identity-2', 'workspace-1', 'member', new DateTimeImmutable('+1 hour'));

        $this->repository->create($grant1);
        $this->repository->create($grant2);
        $this->repository->create($grant3);
        $this->repository->create($grant4);

        // Revoke grant2 to test active filtering
        $grant2->revoke();
        $this->repository->update($grant2);

        // Act
        $grants = $this->repository->findActiveByIdentityAndWorkspace('identity-1', 'workspace-1');

        // Assert
        $this->assertCount(1, $grants); // Only grant1 should be active
        $this->assertEquals('grant-1', $grants[0]->grantId);
    }

    public function testFindByIdentity(): void
    {
        // Arrange
        $grant1 = new Grant('grant-1', 'identity-1', 'workspace-1', 'member', new DateTimeImmutable('+1 hour'));
        $grant2 = new Grant('grant-2', 'identity-1', 'workspace-2', 'admin', null, 5);
        $grant3 = new Grant('grant-3', 'identity-2', 'workspace-1', 'member', new DateTimeImmutable('+1 hour'));

        $this->repository->create($grant1);
        $this->repository->create($grant2);
        $this->repository->create($grant3);

        // Act
        $grants = $this->repository->findByIdentity('identity-1');

        // Assert
        $this->assertCount(2, $grants);
        $grantIds = array_map(fn($g) => $g->grantId, $grants);
        $this->assertContains('grant-1', $grantIds);
        $this->assertContains('grant-2', $grantIds);
    }

    public function testFindByWorkspace(): void
    {
        // Arrange
        $grant1 = new Grant('grant-1', 'identity-1', 'workspace-1', 'member', new DateTimeImmutable('+1 hour'));
        $grant2 = new Grant('grant-2', 'identity-2', 'workspace-1', 'admin', null, 5);
        $grant3 = new Grant('grant-3', 'identity-1', 'workspace-2', 'member', new DateTimeImmutable('+1 hour'));

        $this->repository->create($grant1);
        $this->repository->create($grant2);
        $this->repository->create($grant3);

        // Act
        $grants = $this->repository->findByWorkspace('workspace-1');

        // Assert
        $this->assertCount(2, $grants);
        $grantIds = array_map(fn($g) => $g->grantId, $grants);
        $this->assertContains('grant-1', $grantIds);
        $this->assertContains('grant-2', $grantIds);
    }

    public function testGrantPersistenceWithAllConstraints(): void
    {
        // Arrange
        $expiresAt = new DateTimeImmutable('+2 hours');
        $grant = new Grant(
            'grant-123',
            'identity-456',
            'workspace-789',
            'admin',
            $expiresAt,
            10,
            ['read', 'write', 'delete'],
            ['purpose' => 'testing']
        );

        // Act
        $this->repository->create($grant);
        $found = $this->repository->findById('grant-123');

        // Assert
        $this->assertNotNull($found);
        $this->assertEquals($expiresAt->format('Y-m-d H:i:s'), $found->expiresAt->format('Y-m-d H:i:s'));
        $this->assertEquals(10, $found->maxUsage);
        $this->assertEquals(['read', 'write', 'delete'], $found->allowedActions);
        $this->assertEquals(['purpose' => 'testing'], $found->metadata);
    }
}
