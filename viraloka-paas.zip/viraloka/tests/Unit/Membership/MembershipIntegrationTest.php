<?php

declare(strict_types=1);

namespace Tests\Unit\Membership;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Membership\MembershipEngine;
use Viraloka\Core\Membership\Repositories\MembershipRepository;
use Viraloka\Core\Membership\RoleRegistry;
use Viraloka\Core\Membership\Membership;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Adapter\Testing\InMemoryStorageAdapter;

/**
 * Integration tests for Membership system
 * 
 * Tests the complete workflow with real repository and storage adapter.
 */
class MembershipIntegrationTest extends TestCase
{
    private MembershipEngine $engine;
    private MembershipRepository $repository;
    private RoleRegistry $roleRegistry;
    private EventDispatcher $eventDispatcher;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        $storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new MembershipRepository($storageAdapter);
        $this->roleRegistry = new RoleRegistry();
        
        $this->eventDispatcher = new EventDispatcher();
        $this->dispatchedEvents = [];
        
        // Capture all membership events
        $this->eventDispatcher->listen('membership.attached', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.attached', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.requested', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.requested', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.approved', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.approved', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.revoked', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.revoked', 'event' => $event];
        });
        
        $this->engine = new MembershipEngine($this->repository, $this->eventDispatcher, $this->roleRegistry);
    }

    public function testCompleteAttachWorkflow(): void
    {
        // Attach identity to workspace
        $membership = $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        
        // Verify membership was created
        $this->assertNotNull($membership);
        $this->assertEquals(Membership::STATUS_ACTIVE, $membership->status);
        $this->assertEquals(Membership::ROLE_OWNER, $membership->role);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.attached', $this->dispatchedEvents[0]['name']);
        
        // Verify membership can be retrieved
        $retrieved = $this->engine->getMembership('identity-1', 'workspace-1');
        $this->assertNotNull($retrieved);
        $this->assertEquals($membership->membershipId, $retrieved->membershipId);
    }

    public function testCompleteRequestApproveWorkflow(): void
    {
        // Request membership
        $membership = $this->engine->request('identity-1', 'workspace-1');
        
        // Verify membership is pending
        $this->assertEquals(Membership::STATUS_PENDING, $membership->status);
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.requested', $this->dispatchedEvents[0]['name']);
        
        // Approve membership
        $approved = $this->engine->approve('identity-1', 'workspace-1', Membership::ROLE_ADMIN);
        
        // Verify membership is now active
        $this->assertEquals(Membership::STATUS_ACTIVE, $approved->status);
        $this->assertEquals(Membership::ROLE_ADMIN, $approved->role);
        $this->assertCount(2, $this->dispatchedEvents);
        $this->assertEquals('membership.approved', $this->dispatchedEvents[1]['name']);
    }

    public function testMultipleMembershipsForIdentity(): void
    {
        // Create multiple memberships for same identity
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-1', 'workspace-2', Membership::ROLE_ADMIN);
        $this->engine->attach('identity-1', 'workspace-3', Membership::ROLE_MEMBER);
        
        // Get all memberships for identity
        $memberships = $this->engine->getMembershipsForIdentity('identity-1');
        
        // Verify all memberships are returned
        $this->assertCount(3, $memberships);
        
        $workspaceIds = array_map(fn($m) => $m->workspaceId, $memberships);
        $this->assertContains('workspace-1', $workspaceIds);
        $this->assertContains('workspace-2', $workspaceIds);
        $this->assertContains('workspace-3', $workspaceIds);
    }

    public function testMultipleMembershipsForWorkspace(): void
    {
        // Create multiple memberships for same workspace
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-2', 'workspace-1', Membership::ROLE_ADMIN);
        $this->engine->attach('identity-3', 'workspace-1', Membership::ROLE_MEMBER);
        
        // Get all memberships for workspace
        $memberships = $this->engine->getMembershipsForWorkspace('workspace-1');
        
        // Verify all memberships are returned
        $this->assertCount(3, $memberships);
        
        $identityIds = array_map(fn($m) => $m->identityId, $memberships);
        $this->assertContains('identity-1', $identityIds);
        $this->assertContains('identity-2', $identityIds);
        $this->assertContains('identity-3', $identityIds);
    }

    public function testRevokeNonOwnerMembership(): void
    {
        // Create workspace with owner and member
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-2', 'workspace-1', Membership::ROLE_MEMBER);
        
        // Revoke member
        $result = $this->engine->revoke('identity-2', 'workspace-1');
        
        // Verify revocation succeeded
        $this->assertTrue($result);
        
        // Verify membership is revoked
        $membership = $this->engine->getMembership('identity-2', 'workspace-1');
        $this->assertEquals(Membership::STATUS_REVOKED, $membership->status);
    }

    public function testOwnerProtectionWithMultipleOwners(): void
    {
        // Create workspace with two owners
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-2', 'workspace-1', Membership::ROLE_OWNER);
        
        // Revoke one owner - should succeed
        $result = $this->engine->revoke('identity-1', 'workspace-1');
        $this->assertTrue($result);
        
        // Verify first owner is revoked
        $membership1 = $this->engine->getMembership('identity-1', 'workspace-1');
        $this->assertEquals(Membership::STATUS_REVOKED, $membership1->status);
        
        // Verify second owner is still active
        $membership2 = $this->engine->getMembership('identity-2', 'workspace-1');
        $this->assertEquals(Membership::STATUS_ACTIVE, $membership2->status);
    }

    public function testEventSequenceForCompleteLifecycle(): void
    {
        // Create owner
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        
        // Request membership
        $this->engine->request('identity-2', 'workspace-1');
        
        // Approve membership
        $this->engine->approve('identity-2', 'workspace-1', Membership::ROLE_MEMBER);
        
        // Revoke membership
        $this->engine->revoke('identity-2', 'workspace-1');
        
        // Verify all events were dispatched in order
        $this->assertCount(4, $this->dispatchedEvents);
        $this->assertEquals('membership.attached', $this->dispatchedEvents[0]['name']);
        $this->assertEquals('membership.requested', $this->dispatchedEvents[1]['name']);
        $this->assertEquals('membership.approved', $this->dispatchedEvents[2]['name']);
        $this->assertEquals('membership.revoked', $this->dispatchedEvents[3]['name']);
    }

    public function testPermissionCheckingWithDefaultRoles(): void
    {
        // Create memberships with different roles
        $this->engine->attach('identity-owner', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-admin', 'workspace-1', Membership::ROLE_ADMIN);
        $this->engine->attach('identity-member', 'workspace-1', Membership::ROLE_MEMBER);
        
        // Owner should have all capabilities
        $this->assertTrue($this->engine->hasPermission('identity-owner', 'workspace-1', 'billing.manage'));
        $this->assertTrue($this->engine->hasPermission('identity-owner', 'workspace-1', 'workspace.delete'));
        $this->assertTrue($this->engine->hasPermission('identity-owner', 'workspace-1', 'content.edit'));
        
        // Admin should have management but not billing
        $this->assertTrue($this->engine->hasPermission('identity-admin', 'workspace-1', 'workspace.manage'));
        $this->assertTrue($this->engine->hasPermission('identity-admin', 'workspace-1', 'content.edit'));
        $this->assertFalse($this->engine->hasPermission('identity-admin', 'workspace-1', 'billing.manage'));
        $this->assertFalse($this->engine->hasPermission('identity-admin', 'workspace-1', 'workspace.delete'));
        
        // Member should have basic capabilities only
        $this->assertTrue($this->engine->hasPermission('identity-member', 'workspace-1', 'content.create'));
        $this->assertTrue($this->engine->hasPermission('identity-member', 'workspace-1', 'content.edit'));
        $this->assertFalse($this->engine->hasPermission('identity-member', 'workspace-1', 'workspace.manage'));
        $this->assertFalse($this->engine->hasPermission('identity-member', 'workspace-1', 'billing.manage'));
    }

    public function testPermissionCheckingWithCustomRole(): void
    {
        // Register custom role
        $this->roleRegistry->registerRole('editor', ['content.create', 'content.edit', 'content.publish']);
        
        // Create membership with custom role
        $this->engine->attach('identity-1', 'workspace-1', 'editor');
        
        // Verify custom role permissions
        $this->assertTrue($this->engine->hasPermission('identity-1', 'workspace-1', 'content.create'));
        $this->assertTrue($this->engine->hasPermission('identity-1', 'workspace-1', 'content.edit'));
        $this->assertTrue($this->engine->hasPermission('identity-1', 'workspace-1', 'content.publish'));
        $this->assertFalse($this->engine->hasPermission('identity-1', 'workspace-1', 'workspace.manage'));
    }

    public function testPermissionCheckingReturnsFalseForNonexistentMembership(): void
    {
        // Check permission without creating membership
        $result = $this->engine->hasPermission('identity-1', 'workspace-1', 'content.edit');
        
        // Should return false without throwing exception
        $this->assertFalse($result);
    }

    public function testPermissionCheckingReturnsFalseForRevokedMembership(): void
    {
        // Create and revoke membership
        $this->engine->attach('identity-1', 'workspace-1', Membership::ROLE_OWNER);
        $this->engine->attach('identity-2', 'workspace-1', Membership::ROLE_ADMIN);
        $this->engine->revoke('identity-2', 'workspace-1');
        
        // Revoked membership should not have permissions
        $result = $this->engine->hasPermission('identity-2', 'workspace-1', 'content.edit');
        $this->assertFalse($result);
    }
}
