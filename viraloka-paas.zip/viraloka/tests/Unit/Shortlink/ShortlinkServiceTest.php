<?php

namespace Viraloka\Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Services\ShortlinkService;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkRepository;
use Viraloka\Core\Billing\Contracts\EntitlementEngineInterface;
use Viraloka\Core\Billing\Contracts\UsageEngineInterface;
use Viraloka\Core\Membership\Contracts\MembershipEngineInterface;
use Viraloka\Core\Grant\Contracts\GrantEngineInterface;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use Viraloka\Container\Contracts\WorkspaceResolverInterface;
use Viraloka\Core\Context\Workspace;
use Viraloka\Modules\Shortlink\Exceptions\AuthorizationException;
use Viraloka\Modules\Shortlink\Exceptions\FeatureNotAvailableException;
use Viraloka\Modules\Shortlink\Exceptions\QuotaExceededException;
use Viraloka\Modules\Shortlink\Shortlink;

class ShortlinkServiceTest extends TestCase
{
    private ShortlinkService $service;
    private $entitlements;
    private $usage;
    private $membership;
    private $grants;
    private $events;
    private $workspaceResolver;
    private $repository;
    private Workspace $workspace;

    protected function setUp(): void
    {
        $this->entitlements = $this->createMock(EntitlementEngineInterface::class);
        $this->usage = $this->createMock(UsageEngineInterface::class);
        $this->membership = $this->createMock(MembershipEngineInterface::class);
        $this->grants = $this->createMock(GrantEngineInterface::class);
        $this->events = $this->createMock(EventAdapterInterface::class);
        $this->workspaceResolver = $this->createMock(WorkspaceResolverInterface::class);
        $this->repository = $this->createMock(ShortlinkRepository::class);

        $this->workspace = new Workspace('ws-001', 'user-001', 'Test Workspace');
        $this->workspaceResolver->method('resolve')->willReturn($this->workspace);

        $this->service = new ShortlinkService(
            $this->entitlements,
            $this->usage,
            $this->membership,
            $this->grants,
            $this->events,
            $this->workspaceResolver,
            $this->repository
        );
    }

    public function testCreateShortlinkChecksPermission(): void
    {
        // Arrange: No permission
        $this->membership->method('hasPermission')
            ->with('user-001', 'ws-001', 'shortlink.create')
            ->willReturn(false);

        // Act & Assert
        $this->expectException(AuthorizationException::class);
        $this->expectExceptionMessage('You do not have permission to create shortlinks.');

        $this->service->create([
            'target_url' => 'https://example.com'
        ]);
    }

    public function testCreateShortlinkChecksFeatureEntitlement(): void
    {
        // Arrange: Has permission but feature disabled
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')
            ->with('ws-001', 'shortlink.enabled')
            ->willReturn(false);

        // Act & Assert
        $this->expectException(FeatureNotAvailableException::class);
        $this->expectExceptionMessage('Shortlink feature is not available in your plan.');

        $this->service->create([
            'target_url' => 'https://example.com'
        ]);
    }

    public function testCreateShortlinkConsumesQuota(): void
    {
        // Arrange: Has permission and feature enabled
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')
            ->with('ws-001', 'shortlink.enabled')
            ->willReturn(true);
        
        // Quota consumption succeeds
        $this->entitlements->method('consume')
            ->with('ws-001', 'shortlink.max_links', 1)
            ->willReturn(true);

        $this->repository->method('save')->willReturn(true);
        $this->events->method('dispatch')->willReturn(true);

        // Act
        $shortlink = $this->service->create([
            'target_url' => 'https://example.com'
        ]);

        // Assert
        $this->assertInstanceOf(Shortlink::class, $shortlink);
        $this->assertEquals('https://example.com', $shortlink->targetUrl);
        $this->assertEquals('ws-001', $shortlink->workspaceId);
    }

    public function testCreateShortlinkThrowsQuotaExceeded(): void
    {
        // Arrange: Has permission and feature enabled but quota exceeded
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')
            ->with('ws-001', 'shortlink.enabled')
            ->willReturn(true);
        
        // Quota consumption fails
        $this->entitlements->method('consume')
            ->with('ws-001', 'shortlink.max_links', 1)
            ->willReturn(false);
        
        $this->entitlements->method('current')
            ->with('ws-001', 'shortlink.max_links')
            ->willReturn(10);

        // Act & Assert
        $this->expectException(QuotaExceededException::class);
        $this->expectExceptionMessage("You've reached your shortlink limit of 10");

        $this->service->create([
            'target_url' => 'https://example.com'
        ]);
    }

    public function testCreateShortlinkWithCustomSlugChecksEntitlement(): void
    {
        // Arrange: Has permission and feature enabled
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')
            ->willReturnMap([
                ['ws-001', 'shortlink.enabled', true],
                ['ws-001', 'shortlink.custom_slug', false]
            ]);

        // Act & Assert
        $this->expectException(FeatureNotAvailableException::class);
        $this->expectExceptionMessage('Custom slugs require a Pro plan');

        $this->service->create([
            'target_url' => 'https://example.com',
            'slug' => 'my-custom-slug'
        ]);
    }

    public function testCreateShortlinkWithCustomSlugSucceeds(): void
    {
        // Arrange: Has all permissions and entitlements
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')->willReturn(true);
        $this->entitlements->method('consume')->willReturn(true);
        $this->repository->method('save')->willReturn(true);
        $this->events->method('dispatch')->willReturn(true);

        // Act
        $shortlink = $this->service->create([
            'target_url' => 'https://example.com',
            'slug' => 'my-custom-slug'
        ]);

        // Assert
        $this->assertEquals('my-custom-slug', $shortlink->slug);
    }

    public function testGetAnalyticsChecksPermission(): void
    {
        // Arrange: No permission
        $this->membership->method('hasPermission')
            ->with('user-001', 'ws-001', 'shortlink.view_analytics')
            ->willReturn(false);

        // Act & Assert
        $this->expectException(AuthorizationException::class);

        $this->service->getAnalytics('shortlink-001');
    }

    public function testGetAnalyticsChecksEntitlement(): void
    {
        // Arrange: Has permission but no analytics entitlement
        $this->membership->method('hasPermission')->willReturn(true);
        $this->entitlements->method('check')
            ->with('ws-001', 'shortlink.analytics')
            ->willReturn(false);

        $mockShortlink = new Shortlink(
            'shortlink-001',
            'ws-001',
            'test-slug',
            'https://example.com'
        );
        $this->repository->method('findById')->willReturn($mockShortlink);

        // Act & Assert
        $this->expectException(FeatureNotAvailableException::class);
        $this->expectExceptionMessage('Analytics feature is not available');

        $this->service->getAnalytics('shortlink-001');
    }

    public function testUpdateShortlinkChecksPermission(): void
    {
        // Arrange: No permission
        $this->membership->method('hasPermission')
            ->with('user-001', 'ws-001', 'shortlink.edit')
            ->willReturn(false);

        $mockShortlink = new Shortlink(
            'shortlink-001',
            'ws-001',
            'test-slug',
            'https://example.com'
        );
        $this->repository->method('findById')->willReturn($mockShortlink);

        // Act & Assert
        $this->expectException(AuthorizationException::class);

        $this->service->update('shortlink-001', [
            'target_url' => 'https://newurl.com'
        ]);
    }

    public function testDeleteShortlinkChecksPermission(): void
    {
        // Arrange: No permission
        $this->membership->method('hasPermission')
            ->with('user-001', 'ws-001', 'shortlink.delete')
            ->willReturn(false);

        $mockShortlink = new Shortlink(
            'shortlink-001',
            'ws-001',
            'test-slug',
            'https://example.com'
        );
        $this->repository->method('findById')->willReturn($mockShortlink);

        // Act & Assert
        $this->expectException(AuthorizationException::class);

        $this->service->delete('shortlink-001');
    }

    public function testGetUsageStatsReturnsCorrectData(): void
    {
        // Arrange
        $this->entitlements->method('current')
            ->with('ws-001', 'shortlink.max_links')
            ->willReturn(10);

        $this->repository->method('countByWorkspace')
            ->with('ws-001')
            ->willReturn(7);

        // Act
        $stats = $this->service->getUsageStats();

        // Assert
        $this->assertEquals(10, $stats['limit']);
        $this->assertEquals(7, $stats['used']);
        $this->assertEquals(3, $stats['remaining']);
    }
}
