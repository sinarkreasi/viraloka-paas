<?php

namespace Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkRepository;
use Viraloka\Modules\Shortlink\Shortlink;
use Viraloka\Modules\Shortlink\Exceptions\SlugConflictException;
use DateTimeImmutable;

/**
 * Test database-level unique constraint validation for slugs
 * 
 * Validates Requirements 10.6, 11.2
 */
class SlugUniquenessConstraintTest extends TestCase
{
    private ShortlinkRepository $repository;
    
    protected function setUp(): void
    {
        parent::setUp();
        $this->repository = new ShortlinkRepository();
        
        // Clean up test data
        $this->cleanupTestData();
    }
    
    protected function tearDown(): void
    {
        $this->cleanupTestData();
        parent::tearDown();
    }
    
    private function cleanupTestData(): void
    {
        global $wpdb;
        $tableName = $wpdb->prefix . 'viraloka_shortlinks';
        $wpdb->query("DELETE FROM {$tableName} WHERE workspace_id LIKE 'test-workspace-%'");
    }
    
    /**
     * Test that database constraint prevents duplicate slugs
     */
    public function testDatabaseConstraintPreventsDuplicateSlugs(): void
    {
        $workspaceId = 'test-workspace-' . uniqid();
        $slug = 'test-slug-' . uniqid();
        
        // Create first shortlink
        $shortlink1 = new Shortlink(
            shortlinkId: 'shortlink-1-' . uniqid(),
            workspaceId: $workspaceId,
            slug: $slug,
            targetUrl: 'https://example.com/page1',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $saved = $this->repository->save($shortlink1);
        $this->assertTrue($saved, 'First shortlink should be saved successfully');
        
        // Try to create second shortlink with same slug
        $shortlink2 = new Shortlink(
            shortlinkId: 'shortlink-2-' . uniqid(),
            workspaceId: $workspaceId,
            slug: $slug, // Same slug
            targetUrl: 'https://example.com/page2',
            status: Shortlink::STATUS_ACTIVE
        );
        
        // Should throw SlugConflictException due to database constraint
        $this->expectException(SlugConflictException::class);
        $this->expectExceptionMessage("The slug '{$slug}' is already taken");
        
        $this->repository->save($shortlink2);
    }
    
    /**
     * Test that constraint works across different workspaces
     */
    public function testConstraintEnforcesGlobalSlugUniqueness(): void
    {
        $slug = 'global-slug-' . uniqid();
        
        // Create shortlink in workspace 1
        $shortlink1 = new Shortlink(
            shortlinkId: 'shortlink-1-' . uniqid(),
            workspaceId: 'test-workspace-1-' . uniqid(),
            slug: $slug,
            targetUrl: 'https://example.com/page1',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $saved = $this->repository->save($shortlink1);
        $this->assertTrue($saved, 'First shortlink should be saved successfully');
        
        // Try to create shortlink with same slug in workspace 2
        $shortlink2 = new Shortlink(
            shortlinkId: 'shortlink-2-' . uniqid(),
            workspaceId: 'test-workspace-2-' . uniqid(),
            slug: $slug, // Same slug, different workspace
            targetUrl: 'https://example.com/page2',
            status: Shortlink::STATUS_ACTIVE
        );
        
        // Should throw SlugConflictException - slugs are globally unique
        $this->expectException(SlugConflictException::class);
        
        $this->repository->save($shortlink2);
    }
    
    /**
     * Test that updating a shortlink with its own slug works
     */
    public function testUpdatingShortlinkWithSameSlugWorks(): void
    {
        $workspaceId = 'test-workspace-' . uniqid();
        $slug = 'update-slug-' . uniqid();
        
        // Create shortlink
        $shortlink = new Shortlink(
            shortlinkId: 'shortlink-' . uniqid(),
            workspaceId: $workspaceId,
            slug: $slug,
            targetUrl: 'https://example.com/page1',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $saved = $this->repository->save($shortlink);
        $this->assertTrue($saved, 'Shortlink should be saved successfully');
        
        // Update the shortlink (keeping same slug)
        $shortlink->updateTargetUrl('https://example.com/page2');
        
        // Should not throw exception - updating with same slug is allowed
        $updated = $this->repository->save($shortlink);
        $this->assertTrue($updated, 'Shortlink should be updated successfully');
        
        // Verify the update
        $retrieved = $this->repository->findBySlug($slug);
        $this->assertNotNull($retrieved);
        $this->assertEquals('https://example.com/page2', $retrieved->targetUrl);
    }
    
    /**
     * Test that different slugs can be created without conflict
     */
    public function testDifferentSlugsCanBeCreated(): void
    {
        $workspaceId = 'test-workspace-' . uniqid();
        
        // Create multiple shortlinks with different slugs
        $shortlink1 = new Shortlink(
            shortlinkId: 'shortlink-1-' . uniqid(),
            workspaceId: $workspaceId,
            slug: 'slug-1-' . uniqid(),
            targetUrl: 'https://example.com/page1',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $shortlink2 = new Shortlink(
            shortlinkId: 'shortlink-2-' . uniqid(),
            workspaceId: $workspaceId,
            slug: 'slug-2-' . uniqid(),
            targetUrl: 'https://example.com/page2',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $shortlink3 = new Shortlink(
            shortlinkId: 'shortlink-3-' . uniqid(),
            workspaceId: $workspaceId,
            slug: 'slug-3-' . uniqid(),
            targetUrl: 'https://example.com/page3',
            status: Shortlink::STATUS_ACTIVE
        );
        
        // All should save successfully
        $this->assertTrue($this->repository->save($shortlink1));
        $this->assertTrue($this->repository->save($shortlink2));
        $this->assertTrue($this->repository->save($shortlink3));
    }
}
