<?php

namespace Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Services\ShortlinkResolver;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkRepository;
use Viraloka\Modules\Shortlink\Shortlink;
use Viraloka\Modules\Shortlink\Contracts\ResolveResult;
use DateTimeImmutable;

class ShortlinkResolverTest extends TestCase
{
    private ShortlinkRepository $repository;
    private ShortlinkResolver $resolver;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock repository
        $this->repository = $this->createMock(ShortlinkRepository::class);
        $this->resolver = new ShortlinkResolver($this->repository);
    }
    
    public function test_resolve_returns_redirect_for_active_shortlink(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'test-id',
            workspaceId: 'workspace-1',
            slug: 'abc123',
            targetUrl: 'https://example.com',
            status: Shortlink::STATUS_ACTIVE
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('abc123')
            ->willReturn($shortlink);
        
        $result = $this->resolver->resolve('abc123');
        
        $this->assertTrue($result->success);
        $this->assertEquals(302, $result->httpStatus);
        $this->assertEquals('https://example.com', $result->targetUrl);
        $this->assertNull($result->errorMessage);
    }
    
    public function test_resolve_returns_not_found_for_nonexistent_slug(): void
    {
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('nonexistent')
            ->willReturn(null);
        
        $result = $this->resolver->resolve('nonexistent');
        
        $this->assertFalse($result->success);
        $this->assertEquals(404, $result->httpStatus);
        $this->assertNull($result->targetUrl);
        $this->assertEquals('Shortlink not found', $result->errorMessage);
    }
    
    public function test_resolve_returns_not_found_for_inactive_shortlink(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'test-id',
            workspaceId: 'workspace-1',
            slug: 'inactive',
            targetUrl: 'https://example.com',
            status: Shortlink::STATUS_INACTIVE
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('inactive')
            ->willReturn($shortlink);
        
        $result = $this->resolver->resolve('inactive');
        
        $this->assertFalse($result->success);
        $this->assertEquals(404, $result->httpStatus);
        $this->assertNull($result->targetUrl);
    }
    
    public function test_resolve_returns_gone_for_expired_shortlink_by_status(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'test-id',
            workspaceId: 'workspace-1',
            slug: 'expired',
            targetUrl: 'https://example.com',
            status: Shortlink::STATUS_EXPIRED
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('expired')
            ->willReturn($shortlink);
        
        $result = $this->resolver->resolve('expired');
        
        $this->assertFalse($result->success);
        $this->assertEquals(410, $result->httpStatus);
        $this->assertNull($result->targetUrl);
        $this->assertEquals('Shortlink has expired', $result->errorMessage);
    }
    
    public function test_resolve_returns_gone_for_shortlink_past_expiration_date(): void
    {
        $pastDate = new DateTimeImmutable('-1 day');
        
        $shortlink = new Shortlink(
            shortlinkId: 'test-id',
            workspaceId: 'workspace-1',
            slug: 'pastdate',
            targetUrl: 'https://example.com',
            status: Shortlink::STATUS_ACTIVE,
            expiresAt: $pastDate
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('pastdate')
            ->willReturn($shortlink);
        
        $result = $this->resolver->resolve('pastdate');
        
        $this->assertFalse($result->success);
        $this->assertEquals(410, $result->httpStatus);
        $this->assertNull($result->targetUrl);
    }
    
    public function test_resolve_returns_redirect_for_active_shortlink_with_future_expiration(): void
    {
        $futureDate = new DateTimeImmutable('+1 day');
        
        $shortlink = new Shortlink(
            shortlinkId: 'test-id',
            workspaceId: 'workspace-1',
            slug: 'future',
            targetUrl: 'https://example.com',
            status: Shortlink::STATUS_ACTIVE,
            expiresAt: $futureDate
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('future')
            ->willReturn($shortlink);
        
        $result = $this->resolver->resolve('future');
        
        $this->assertTrue($result->success);
        $this->assertEquals(302, $result->httpStatus);
        $this->assertEquals('https://example.com', $result->targetUrl);
    }
}
