<?php

namespace Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Services\ExpirationManager;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkRepository;
use Viraloka\Modules\Shortlink\Shortlink;
use Viraloka\Modules\Shortlink\Events\ShortlinkExpiredEvent;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use DateTimeImmutable;

class ExpirationManagerTest extends TestCase
{
    private ExpirationManager $expirationManager;
    private ShortlinkRepository $repository;
    private EventAdapterInterface $events;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock dependencies
        $this->repository = $this->createMock(ShortlinkRepository::class);
        $this->events = $this->createMock(EventAdapterInterface::class);
        
        // Create service
        $this->expirationManager = new ExpirationManager(
            $this->repository,
            $this->events
        );
        
        // Setup WordPress test environment
        global $wpdb;
        if (!isset($wpdb)) {
            $wpdb = $this->createMock(\wpdb::class);
            $wpdb->prefix = 'wp_';
        }
    }
    
    public function testMarkExpiredShortlinksWithNoExpiredLinks(): void
    {
        global $wpdb;
        
        // Mock database query to return no results
        $wpdb->expects($this->once())
            ->method('get_results')
            ->willReturn([]);
        
        // Execute
        $result = $this->expirationManager->markExpiredShortlinks();
        
        // Assert
        $this->assertEquals(0, $result['processed']);
        $this->assertEquals(0, $result['expired']);
    }
    
    public function testMarkExpiredShortlinksWithExpiredLinks(): void
    {
        global $wpdb;
        
        // Create mock expired shortlink data
        $expiredShortlinkData = [
            'shortlink_id' => 'test-id-1',
            'workspace_id' => 'workspace-1',
            'slug' => 'test-slug',
            'target_url' => 'https://example.com',
            'status' => Shortlink::STATUS_ACTIVE,
            'expires_at' => (new DateTimeImmutable('-1 day'))->format('Y-m-d H:i:s'),
            'metadata' => '[]',
            'created_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
            'updated_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
        ];
        
        // Mock database query to return expired shortlink
        $wpdb->expects($this->once())
            ->method('get_results')
            ->willReturn([$expiredShortlinkData]);
        
        // Mock repository save
        $this->repository->expects($this->once())
            ->method('save')
            ->with($this->callback(function ($shortlink) {
                return $shortlink instanceof Shortlink 
                    && $shortlink->status === Shortlink::STATUS_EXPIRED;
            }))
            ->willReturn(true);
        
        // Mock event dispatch
        $this->events->expects($this->once())
            ->method('dispatch')
            ->with($this->isInstanceOf(ShortlinkExpiredEvent::class));
        
        // Execute
        $result = $this->expirationManager->markExpiredShortlinks();
        
        // Assert
        $this->assertEquals(1, $result['processed']);
        $this->assertEquals(1, $result['expired']);
    }
    
    public function testMarkExpiredShortlinksWithMultipleExpiredLinks(): void
    {
        global $wpdb;
        
        // Create mock expired shortlink data
        $expiredShortlinks = [
            [
                'shortlink_id' => 'test-id-1',
                'workspace_id' => 'workspace-1',
                'slug' => 'test-slug-1',
                'target_url' => 'https://example.com/1',
                'status' => Shortlink::STATUS_ACTIVE,
                'expires_at' => (new DateTimeImmutable('-1 day'))->format('Y-m-d H:i:s'),
                'metadata' => '[]',
                'created_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
                'updated_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
            ],
            [
                'shortlink_id' => 'test-id-2',
                'workspace_id' => 'workspace-2',
                'slug' => 'test-slug-2',
                'target_url' => 'https://example.com/2',
                'status' => Shortlink::STATUS_ACTIVE,
                'expires_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
                'metadata' => '[]',
                'created_at' => (new DateTimeImmutable('-3 days'))->format('Y-m-d H:i:s'),
                'updated_at' => (new DateTimeImmutable('-3 days'))->format('Y-m-d H:i:s'),
            ],
        ];
        
        // Mock database query to return expired shortlinks
        $wpdb->expects($this->once())
            ->method('get_results')
            ->willReturn($expiredShortlinks);
        
        // Mock repository save (called twice)
        $this->repository->expects($this->exactly(2))
            ->method('save')
            ->willReturn(true);
        
        // Mock event dispatch (called twice)
        $this->events->expects($this->exactly(2))
            ->method('dispatch')
            ->with($this->isInstanceOf(ShortlinkExpiredEvent::class));
        
        // Execute
        $result = $this->expirationManager->markExpiredShortlinks();
        
        // Assert
        $this->assertEquals(2, $result['processed']);
        $this->assertEquals(2, $result['expired']);
    }
    
    public function testMarkExpiredShortlinksHandlesSaveFailure(): void
    {
        global $wpdb;
        
        // Create mock expired shortlink data
        $expiredShortlinkData = [
            'shortlink_id' => 'test-id-1',
            'workspace_id' => 'workspace-1',
            'slug' => 'test-slug',
            'target_url' => 'https://example.com',
            'status' => Shortlink::STATUS_ACTIVE,
            'expires_at' => (new DateTimeImmutable('-1 day'))->format('Y-m-d H:i:s'),
            'metadata' => '[]',
            'created_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
            'updated_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
        ];
        
        // Mock database query to return expired shortlink
        $wpdb->expects($this->once())
            ->method('get_results')
            ->willReturn([$expiredShortlinkData]);
        
        // Mock repository save to fail
        $this->repository->expects($this->once())
            ->method('save')
            ->willReturn(false);
        
        // Event should not be dispatched on save failure
        $this->events->expects($this->never())
            ->method('dispatch');
        
        // Execute
        $result = $this->expirationManager->markExpiredShortlinks();
        
        // Assert - processed but not expired due to save failure
        $this->assertEquals(1, $result['processed']);
        $this->assertEquals(0, $result['expired']);
    }
    
    public function testExpiredEventContainsCorrectData(): void
    {
        global $wpdb;
        
        // Create mock expired shortlink data
        $expiredShortlinkData = [
            'shortlink_id' => 'test-id-1',
            'workspace_id' => 'workspace-1',
            'slug' => 'test-slug',
            'target_url' => 'https://example.com',
            'status' => Shortlink::STATUS_ACTIVE,
            'expires_at' => (new DateTimeImmutable('-1 day'))->format('Y-m-d H:i:s'),
            'metadata' => '[]',
            'created_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
            'updated_at' => (new DateTimeImmutable('-2 days'))->format('Y-m-d H:i:s'),
        ];
        
        // Mock database query
        $wpdb->expects($this->once())
            ->method('get_results')
            ->willReturn([$expiredShortlinkData]);
        
        // Mock repository save
        $this->repository->expects($this->once())
            ->method('save')
            ->willReturn(true);
        
        // Capture the event
        $capturedEvent = null;
        $this->events->expects($this->once())
            ->method('dispatch')
            ->with($this->callback(function ($event) use (&$capturedEvent) {
                $capturedEvent = $event;
                return $event instanceof ShortlinkExpiredEvent;
            }));
        
        // Execute
        $this->expirationManager->markExpiredShortlinks();
        
        // Assert event data
        $this->assertNotNull($capturedEvent);
        $this->assertEquals('test-id-1', $capturedEvent->shortlinkId);
        $this->assertEquals('workspace-1', $capturedEvent->workspaceId);
        $this->assertEquals('test-slug', $capturedEvent->slug);
        $this->assertInstanceOf(DateTimeImmutable::class, $capturedEvent->expiredAt);
    }
}
