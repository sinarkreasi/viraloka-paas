<?php

namespace Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Services\ClickTracker;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkClickRepository;
use Viraloka\Core\Billing\Contracts\UsageEngineInterface;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use Viraloka\Modules\Shortlink\Shortlink;
use Viraloka\Modules\Shortlink\ShortlinkClick;
use Viraloka\Modules\Shortlink\Events\ShortlinkClickedEvent;
use DateTimeImmutable;

class ClickTrackerTest extends TestCase
{
    private ShortlinkClickRepository $repository;
    private UsageEngineInterface $usage;
    private EventAdapterInterface $events;
    private ClickTracker $tracker;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock dependencies
        $this->repository = $this->createMock(ShortlinkClickRepository::class);
        $this->usage = $this->createMock(UsageEngineInterface::class);
        $this->events = $this->createMock(EventAdapterInterface::class);
        
        $this->tracker = new ClickTracker(
            $this->repository,
            $this->usage,
            $this->events
        );
    }
    
    public function test_track_records_click_with_metadata(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'shortlink-123',
            workspaceId: 'workspace-456',
            slug: 'abc123',
            targetUrl: 'https://example.com'
        );
        
        $metadata = [
            'referrer' => 'https://google.com',
            'user_agent' => 'Mozilla/5.0',
            'ip_address' => '192.168.1.1'
        ];
        
        // Expect repository save to be called
        $this->repository
            ->expects($this->once())
            ->method('save')
            ->with($this->callback(function(ShortlinkClick $click) use ($shortlink, $metadata) {
                return $click->shortlinkId === $shortlink->shortlinkId
                    && $click->referrer === $metadata['referrer']
                    && $click->userAgent === $metadata['user_agent']
                    && $click->ipAddress === $metadata['ip_address']
                    && $click->clickedAt instanceof DateTimeImmutable;
            }))
            ->willReturn(true);
        
        // Expect usage recording
        $this->usage
            ->expects($this->once())
            ->method('record')
            ->with(
                'workspace-456',
                'shortlink.clicks',
                1,
                $this->callback(function($context) {
                    return $context['shortlink_id'] === 'shortlink-123'
                        && $context['slug'] === 'abc123';
                })
            );
        
        // Expect event emission
        $this->events
            ->expects($this->once())
            ->method('dispatch')
            ->with($this->callback(function($event) use ($shortlink, $metadata) {
                return $event instanceof ShortlinkClickedEvent
                    && $event->shortlinkId === $shortlink->shortlinkId
                    && $event->workspaceId === $shortlink->workspaceId
                    && $event->slug === $shortlink->slug
                    && $event->referrer === $metadata['referrer']
                    && $event->clickedAt instanceof DateTimeImmutable;
            }));
        
        $click = $this->tracker->track($shortlink, $metadata);
        
        $this->assertInstanceOf(ShortlinkClick::class, $click);
        $this->assertEquals('shortlink-123', $click->shortlinkId);
        $this->assertEquals('https://google.com', $click->referrer);
        $this->assertEquals('Mozilla/5.0', $click->userAgent);
        $this->assertEquals('192.168.1.1', $click->ipAddress);
    }
    
    public function test_track_handles_missing_metadata(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'shortlink-123',
            workspaceId: 'workspace-456',
            slug: 'abc123',
            targetUrl: 'https://example.com'
        );
        
        // Expect repository save with null metadata
        $this->repository
            ->expects($this->once())
            ->method('save')
            ->with($this->callback(function(ShortlinkClick $click) {
                return $click->referrer === null
                    && $click->userAgent === null
                    && $click->ipAddress === null;
            }))
            ->willReturn(true);
        
        $this->usage->expects($this->once())->method('record');
        $this->events->expects($this->once())->method('dispatch');
        
        $click = $this->tracker->track($shortlink, []);
        
        $this->assertNull($click->referrer);
        $this->assertNull($click->userAgent);
        $this->assertNull($click->ipAddress);
    }
    
    public function test_get_click_count_delegates_to_repository(): void
    {
        $shortlinkId = 'shortlink-123';
        $startDate = new DateTimeImmutable('2024-01-01');
        $endDate = new DateTimeImmutable('2024-01-31');
        
        $this->repository
            ->expects($this->once())
            ->method('countByShortlink')
            ->with($shortlinkId, $startDate, $endDate)
            ->willReturn(42);
        
        $count = $this->tracker->getClickCount($shortlinkId, $startDate, $endDate);
        
        $this->assertEquals(42, $count);
    }
    
    public function test_get_click_count_without_date_filters(): void
    {
        $shortlinkId = 'shortlink-123';
        
        $this->repository
            ->expects($this->once())
            ->method('countByShortlink')
            ->with($shortlinkId, null, null)
            ->willReturn(100);
        
        $count = $this->tracker->getClickCount($shortlinkId);
        
        $this->assertEquals(100, $count);
    }
    
    public function test_get_analytics_returns_comprehensive_data(): void
    {
        $shortlinkId = 'shortlink-123';
        $startDate = new DateTimeImmutable('2024-01-01');
        $endDate = new DateTimeImmutable('2024-01-31');
        
        // Mock repository methods
        $this->repository
            ->expects($this->once())
            ->method('countByShortlink')
            ->with($shortlinkId, $startDate, $endDate)
            ->willReturn(150);
        
        $this->repository
            ->expects($this->once())
            ->method('getClicksByDay')
            ->with($shortlinkId, $startDate, $endDate)
            ->willReturn([
                ['date' => '2024-01-01', 'count' => 10],
                ['date' => '2024-01-02', 'count' => 15],
            ]);
        
        $this->repository
            ->expects($this->once())
            ->method('getReferrerBreakdown')
            ->with($shortlinkId, $startDate, $endDate)
            ->willReturn([
                ['referrer' => 'https://google.com', 'count' => 50],
                ['referrer' => 'Direct', 'count' => 30],
            ]);
        
        $this->repository
            ->expects($this->once())
            ->method('getUserAgentBreakdown')
            ->with($shortlinkId, $startDate, $endDate)
            ->willReturn([
                ['user_agent' => 'Mozilla/5.0', 'count' => 80],
                ['user_agent' => 'Chrome/90.0', 'count' => 40],
            ]);
        
        $analytics = $this->tracker->getAnalytics($shortlinkId, $startDate, $endDate);
        
        $this->assertIsArray($analytics);
        $this->assertArrayHasKey('total_clicks', $analytics);
        $this->assertArrayHasKey('clicks_by_day', $analytics);
        $this->assertArrayHasKey('referrer_breakdown', $analytics);
        $this->assertArrayHasKey('user_agent_breakdown', $analytics);
        
        $this->assertEquals(150, $analytics['total_clicks']);
        $this->assertCount(2, $analytics['clicks_by_day']);
        $this->assertCount(2, $analytics['referrer_breakdown']);
        $this->assertCount(2, $analytics['user_agent_breakdown']);
    }
    
    public function test_get_analytics_without_date_filters(): void
    {
        $shortlinkId = 'shortlink-123';
        
        $this->repository->method('countByShortlink')->willReturn(200);
        $this->repository->method('getClicksByDay')->willReturn([]);
        $this->repository->method('getReferrerBreakdown')->willReturn([]);
        $this->repository->method('getUserAgentBreakdown')->willReturn([]);
        
        $analytics = $this->tracker->getAnalytics($shortlinkId);
        
        $this->assertEquals(200, $analytics['total_clicks']);
        $this->assertIsArray($analytics['clicks_by_day']);
        $this->assertIsArray($analytics['referrer_breakdown']);
        $this->assertIsArray($analytics['user_agent_breakdown']);
    }
    
    public function test_track_generates_unique_click_ids(): void
    {
        $shortlink = new Shortlink(
            shortlinkId: 'shortlink-123',
            workspaceId: 'workspace-456',
            slug: 'abc123',
            targetUrl: 'https://example.com'
        );
        
        $clickIds = [];
        
        $this->repository->method('save')->willReturn(true);
        $this->usage->method('record');
        $this->events->method('dispatch');
        
        // Track multiple clicks and collect IDs
        for ($i = 0; $i < 10; $i++) {
            $click = $this->tracker->track($shortlink, []);
            $clickIds[] = $click->clickId;
        }
        
        // Verify all IDs are unique
        $uniqueIds = array_unique($clickIds);
        $this->assertCount(10, $uniqueIds, 'All click IDs should be unique');
        
        // Verify UUID format
        foreach ($clickIds as $id) {
            $this->assertMatchesRegularExpression(
                '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
                $id,
                'Click ID should be a valid UUID v4'
            );
        }
    }
}
