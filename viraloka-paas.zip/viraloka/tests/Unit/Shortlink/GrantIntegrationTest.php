<?php

namespace Tests\Unit\Shortlink;

use PHPUnit\Framework\TestCase;
use Viraloka\Modules\Shortlink\Services\ShortlinkService;
use Viraloka\Modules\Shortlink\Repositories\ShortlinkRepository;
use Viraloka\Modules\Shortlink\Contracts\ClickTrackerInterface;
use Viraloka\Core\Billing\Contracts\EntitlementEngineInterface;
use Viraloka\Core\Billing\Contracts\UsageEngineInterface;
use Viraloka\Core\Membership\Contracts\MembershipEngineInterface;
use Viraloka\Core\Grant\Contracts\GrantEngineInterface;
use Viraloka\Core\Adapter\Contracts\EventAdapterInterface;
use Viraloka\Container\Contracts\WorkspaceResolverInterface;
use Viraloka\Core\Grant\Grant;
use Viraloka\Modules\Shortlink\Shortlink;
use Viraloka\Modules\Shortlink\Exceptions\AuthorizationException;
use DateTimeImmutable;

class GrantIntegrationTest extends TestCase
{
    private ShortlinkService $service;
    private EntitlementEngineInterface $entitlements;
    private UsageEngineInterface $usage;
    private MembershipEngineInterface $membership;
    private GrantEngineInterface $grants;
    private EventAdapterInterface $events;
    private WorkspaceResolverInterface $workspaceResolver;
    private ShortlinkRepository $repository;
    private ClickTrackerInterface $clickTracker;
    
    protected function setUp(): void
    {
        $this->entitlements = $this->createMock(EntitlementEngineInterface::class);
        $this->usage = $this->createMock(UsageEngineInterface::class);
        $this->membership = $this->createMock(MembershipEngineInterface::class);
        $this->grants = $this->createMock(GrantEngineInterface::class);
        $this->events = $this->createMock(EventAdapterInterface::class);
        $this->workspaceResolver = $this->createMock(WorkspaceResolverInterface::class);
        $this->repository = $this->createMock(ShortlinkRepository::class);
        $this->clickTracker = $this->createMock(ClickTrackerInterface::class);
        
        $this->service = new ShortlinkService(
            $this->entitlements,
            $this->usage,
            $this->membership,
            $this->grants,
            $this->events,
            $this->workspaceResolver,
            $this->repository,
            $this->clickTracker
        );
    }
    
    public function testIssueAnalyticsGrantCreatesGrantWithCorrectConstraints(): void
    {
        $shortlinkId = 'shortlink-123';
        $workspaceId = 'workspace-456';
        $identityId = 'identity-789';
        
        $workspace = new class($workspaceId, $identityId) {
            public function __construct(private string $id, private string $identityId) {}
            public function getId(): string { return $this->id; }
            public function getIdentityId(): string { return $this->identityId; }
        };
        
        $shortlink = new Shortlink(
            $shortlinkId,
            $workspaceId,
            'test-slug',
            'https://example.com',
            Shortlink::STATUS_ACTIVE
        );
        
        $expiresAt = new DateTimeImmutable('+7 days');
        $constraints = [
            'expires_at' => $expiresAt,
            'max_usage' => 10,
        ];
        
        $grant = new Grant(
            'grant-123',
            'anonymous',
            $workspaceId,
            'viewer',
            $expiresAt,
            10,
            ['shortlink.view_analytics'],
            ['shortlink_id' => $shortlinkId, 'slug' => 'test-slug', 'issued_by' => $identityId]
        );
        
        $this->workspaceResolver->method('resolve')->willReturn($workspace);
        $this->membership->method('hasPermission')->willReturn(true);
        $this->repository->method('findById')->willReturn($shortlink);
        
        $this->grants->expects($this->once())
            ->method('issue')
            ->with(
                $this->equalTo('anonymous'),
                $this->equalTo($workspaceId),
                $this->equalTo('viewer'),
                $this->callback(function($constraints) use ($expiresAt) {
                    return $constraints['expires_at'] === $expiresAt
                        && $constraints['max_usage'] === 10
                        && $constraints['allowed_actions'] === ['shortlink.view_analytics'];
                }),
                $this->callback(function($metadata) use ($shortlinkId, $identityId) {
                    return $metadata['shortlink_id'] === $shortlinkId
                        && $metadata['issued_by'] === $identityId;
                })
            )
            ->willReturn($grant);
        
        $this->events->expects($this->once())
            ->method('dispatch');
        
        $result = $this->service->issueAnalyticsGrant($shortlinkId, $constraints);
        
        $this->assertInstanceOf(Grant::class, $result);
        $this->assertEquals('grant-123', $result->grantId);
    }
    
    public function testGetAnalyticsWithGrantValidatesGrantBeforeAccess(): void
    {
        $shortlinkId = 'shortlink-123';
        $grantId = 'grant-456';
        
        $grant = new Grant(
            $grantId,
            'anonymous',
            'workspace-123',
            'viewer',
            new DateTimeImmutable('+7 days'),
            10,
            ['shortlink.view_analytics'],
            ['shortlink_id' => $shortlinkId]
        );
        
        $shortlink = new Shortlink(
            $shortlinkId,
            'workspace-123',
            'test-slug',
            'https://example.com',
            Shortlink::STATUS_ACTIVE
        );
        
        $this->grants->method('validate')->with($grantId)->willReturn(true);
        $this->grants->method('findById')->with($grantId)->willReturn($grant);
        $this->grants->expects($this->once())->method('consume')->with($grantId);
        $this->repository->method('findById')->willReturn($shortlink);
        
        $expectedAnalytics = [
            'total_clicks' => 42,
            'clicks_by_day' => [],
            'referrer_breakdown' => [],
            'user_agent_breakdown' => [],
        ];
        
        $this->clickTracker->method('getAnalytics')->willReturn($expectedAnalytics);
        
        $result = $this->service->getAnalyticsWithGrant($shortlinkId, $grantId);
        
        $this->assertEquals($expectedAnalytics, $result);
    }
    
    public function testGetAnalyticsWithGrantRejectsInvalidGrant(): void
    {
        $shortlinkId = 'shortlink-123';
        $grantId = 'grant-456';
        
        $this->grants->method('validate')->with($grantId)->willReturn(false);
        
        $this->expectException(AuthorizationException::class);
        $this->expectExceptionMessage('Grant is invalid, expired, or exhausted.');
        
        $this->service->getAnalyticsWithGrant($shortlinkId, $grantId);
    }
    
    public function testGetAnalyticsWithGrantRejectsGrantForWrongShortlink(): void
    {
        $shortlinkId = 'shortlink-123';
        $grantId = 'grant-456';
        
        $grant = new Grant(
            $grantId,
            'anonymous',
            'workspace-123',
            'viewer',
            new DateTimeImmutable('+7 days'),
            10,
            ['shortlink.view_analytics'],
            ['shortlink_id' => 'different-shortlink'] // Wrong shortlink
        );
        
        $this->grants->method('validate')->with($grantId)->willReturn(true);
        $this->grants->method('findById')->with($grantId)->willReturn($grant);
        
        $this->expectException(AuthorizationException::class);
        $this->expectExceptionMessage('Grant is not valid for this shortlink.');
        
        $this->service->getAnalyticsWithGrant($shortlinkId, $grantId);
    }
    
    public function testGetAnalyticsWithGrantRejectsGrantWithoutAnalyticsAction(): void
    {
        $shortlinkId = 'shortlink-123';
        $grantId = 'grant-456';
        
        $grant = new Grant(
            $grantId,
            'anonymous',
            'workspace-123',
            'viewer',
            new DateTimeImmutable('+7 days'),
            10,
            ['some.other.action'], // Wrong action
            ['shortlink_id' => $shortlinkId]
        );
        
        $this->grants->method('validate')->with($grantId)->willReturn(true);
        $this->grants->method('findById')->with($grantId)->willReturn($grant);
        
        $this->expectException(AuthorizationException::class);
        $this->expectExceptionMessage('Grant does not allow analytics access.');
        
        $this->service->getAnalyticsWithGrant($shortlinkId, $grantId);
    }
}
