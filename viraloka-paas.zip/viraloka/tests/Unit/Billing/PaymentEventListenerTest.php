<?php

namespace Tests\Unit\Billing;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Billing\PaymentEventListener;
use Viraloka\Core\Billing\SubscriptionEngine;
use Viraloka\Core\Billing\Subscription;
use Viraloka\Core\Billing\Events\PaymentSucceededEvent;
use Viraloka\Core\Billing\Events\PaymentFailedEvent;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Billing\Repositories\SubscriptionRepository;
use Viraloka\Core\Billing\Repositories\PlanRepository;
use Viraloka\Core\Billing\EntitlementEngine;
use Viraloka\Core\Billing\Plan;
use DateTimeImmutable;

/**
 * Payment Event Listener Test
 * 
 * Tests payment event handling and subscription status updates.
 * 
 * Requirements: 8.4, 8.6, 8.7, 9.1, 9.3
 */
class PaymentEventListenerTest extends TestCase
{
    private PaymentEventListener $listener;
    private SubscriptionEngine $subscriptionEngine;
    private SubscriptionRepository $subscriptionRepository;
    private PlanRepository $planRepository;
    private EntitlementEngine $entitlementEngine;
    private EventDispatcher $eventDispatcher;
    
    protected function setUp(): void
    {
        // Create mock repositories
        $this->subscriptionRepository = $this->createMock(SubscriptionRepository::class);
        $this->planRepository = $this->createMock(PlanRepository::class);
        $this->entitlementEngine = $this->createMock(EntitlementEngine::class);
        $this->eventDispatcher = new EventDispatcher();
        
        // Create subscription engine
        $this->subscriptionEngine = new SubscriptionEngine(
            $this->subscriptionRepository,
            $this->planRepository,
            $this->eventDispatcher,
            $this->entitlementEngine
        );
        
        // Create payment event listener
        $this->listener = new PaymentEventListener($this->subscriptionEngine);
    }
    
    /**
     * Test payment.succeeded event listener registration
     * 
     * Requirement: 8.6
     */
    public function testPaymentSucceededListenerRegistration(): void
    {
        $this->listener->register($this->eventDispatcher);
        
        $this->assertTrue($this->eventDispatcher->hasListeners('payment.succeeded'));
    }
    
    /**
     * Test payment.failed event listener registration
     * 
     * Requirement: 8.7
     */
    public function testPaymentFailedListenerRegistration(): void
    {
        $this->listener->register($this->eventDispatcher);
        
        $this->assertTrue($this->eventDispatcher->hasListeners('payment.failed'));
    }
    
    /**
     * Test payment.succeeded ensures subscription is active
     * 
     * Requirement: 9.1
     */
    public function testPaymentSucceededEnsuresSubscriptionActive(): void
    {
        $workspaceId = 'workspace-123';
        $subscriptionId = 'sub-123';
        
        // Create active subscription
        $subscription = new Subscription(
            $subscriptionId,
            $workspaceId,
            'plan-starter',
            Subscription::STATUS_ACTIVE,
            Subscription::PERIOD_MONTHLY,
            new DateTimeImmutable()
        );
        
        // Mock repository to return active subscription
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($subscription);
        
        // Create payment succeeded event
        $event = new PaymentSucceededEvent(
            'txn-123',
            $workspaceId,
            1000,
            'USD',
            'stripe',
            new DateTimeImmutable()
        );
        
        // Handle event
        $this->listener->handlePaymentSucceeded($event);
        
        // Subscription should remain active
        $this->assertEquals(Subscription::STATUS_ACTIVE, $subscription->status);
    }
    
    /**
     * Test payment.succeeded resumes paused subscription
     * 
     * Requirement: 9.1
     */
    public function testPaymentSucceededResumesPausedSubscription(): void
    {
        $workspaceId = 'workspace-123';
        $subscriptionId = 'sub-123';
        
        // Create paused subscription
        $subscription = new Subscription(
            $subscriptionId,
            $workspaceId,
            'plan-starter',
            Subscription::STATUS_PAUSED,
            Subscription::PERIOD_MONTHLY,
            new DateTimeImmutable()
        );
        
        // Mock repository to return paused subscription
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($subscription);
        
        // Mock repository update
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('update')
            ->with($this->callback(function ($sub) {
                return $sub->status === Subscription::STATUS_ACTIVE;
            }));
        
        // Create payment succeeded event
        $event = new PaymentSucceededEvent(
            'txn-123',
            $workspaceId,
            1000,
            'USD',
            'stripe',
            new DateTimeImmutable()
        );
        
        // Handle event
        $this->listener->handlePaymentSucceeded($event);
        
        // Subscription should be resumed
        $this->assertEquals(Subscription::STATUS_ACTIVE, $subscription->status);
    }
    
    /**
     * Test payment.failed pauses active subscription
     * 
     * Requirement: 9.3
     */
    public function testPaymentFailedPausesActiveSubscription(): void
    {
        $workspaceId = 'workspace-123';
        $subscriptionId = 'sub-123';
        
        // Create active subscription
        $subscription = new Subscription(
            $subscriptionId,
            $workspaceId,
            'plan-starter',
            Subscription::STATUS_ACTIVE,
            Subscription::PERIOD_MONTHLY,
            new DateTimeImmutable()
        );
        
        // Mock repository to return active subscription
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($subscription);
        
        // Mock repository update
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('update')
            ->with($this->callback(function ($sub) {
                return $sub->status === Subscription::STATUS_PAUSED;
            }));
        
        // Create payment failed event
        $event = new PaymentFailedEvent(
            'txn-123',
            $workspaceId,
            1000,
            'USD',
            'stripe',
            'insufficient_funds',
            new DateTimeImmutable()
        );
        
        // Handle event
        $this->listener->handlePaymentFailed($event);
        
        // Subscription should be paused
        $this->assertEquals(Subscription::STATUS_PAUSED, $subscription->status);
    }
    
    /**
     * Test payment.failed does nothing for non-existent subscription
     * 
     * Requirement: 8.7
     */
    public function testPaymentFailedIgnoresNonExistentSubscription(): void
    {
        $workspaceId = 'workspace-123';
        
        // Mock repository to return null (no subscription)
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn(null);
        
        // Mock repository should not be called for update
        $this->subscriptionRepository
            ->expects($this->never())
            ->method('update');
        
        // Create payment failed event
        $event = new PaymentFailedEvent(
            'txn-123',
            $workspaceId,
            1000,
            'USD',
            'stripe',
            'insufficient_funds',
            new DateTimeImmutable()
        );
        
        // Handle event - should not throw
        $this->listener->handlePaymentFailed($event);
        
        // Test passes if no exception is thrown
        $this->assertTrue(true);
    }
    
    /**
     * Test payment event listener integration with EventDispatcher
     * 
     * Requirement: 8.4
     */
    public function testPaymentEventListenerIntegration(): void
    {
        $workspaceId = 'workspace-123';
        $subscriptionId = 'sub-123';
        
        // Create active subscription
        $subscription = new Subscription(
            $subscriptionId,
            $workspaceId,
            'plan-starter',
            Subscription::STATUS_ACTIVE,
            Subscription::PERIOD_MONTHLY,
            new DateTimeImmutable()
        );
        
        // Mock repository
        $this->subscriptionRepository
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($subscription);
        
        $this->subscriptionRepository
            ->method('update');
        
        // Register listener
        $this->listener->register($this->eventDispatcher);
        
        // Dispatch payment.failed event
        $event = new PaymentFailedEvent(
            'txn-123',
            $workspaceId,
            1000,
            'USD',
            'stripe',
            'insufficient_funds',
            new DateTimeImmutable()
        );
        
        $this->eventDispatcher->dispatch('payment.failed', $event);
        
        // Subscription should be paused
        $this->assertEquals(Subscription::STATUS_PAUSED, $subscription->status);
    }
}
