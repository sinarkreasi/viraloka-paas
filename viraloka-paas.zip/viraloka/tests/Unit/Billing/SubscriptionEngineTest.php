<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Billing\SubscriptionEngine;
use Viraloka\Core\Billing\Repositories\SubscriptionRepository;
use Viraloka\Core\Billing\Repositories\PlanRepository;
use Viraloka\Core\Billing\Repositories\EntitlementRepository;
use Viraloka\Core\Billing\EntitlementEngine;
use Viraloka\Core\Billing\Plan;
use Viraloka\Core\Billing\Subscription;
use Viraloka\Core\Billing\Exceptions\SubscriptionExistsException;
use Viraloka\Core\Billing\Exceptions\SubscriptionNotFoundException;
use Viraloka\Core\Billing\Exceptions\PlanNotFoundException;
use Viraloka\Core\Billing\Exceptions\InvalidStatusException;
use Viraloka\Core\Events\EventDispatcher;
use DateTimeImmutable;

/**
 * Subscription Engine Test
 * 
 * Tests the SubscriptionEngine lifecycle methods.
 */
class SubscriptionEngineTest extends TestCase
{
    private SubscriptionEngine $engine;
    private SubscriptionRepository $subscriptionRepo;
    private PlanRepository $planRepo;
    private EntitlementEngine $entitlementEngine;
    private EventDispatcher $eventDispatcher;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Initialize repositories and event dispatcher
        $this->subscriptionRepo = new SubscriptionRepository();
        $this->planRepo = new PlanRepository();
        $this->eventDispatcher = new EventDispatcher();
        
        // Initialize entitlement engine
        $entitlementRepo = new EntitlementRepository();
        $this->entitlementEngine = new EntitlementEngine($entitlementRepo, $this->eventDispatcher);
        
        // Create engine
        $this->engine = new SubscriptionEngine(
            $this->subscriptionRepo,
            $this->planRepo,
            $this->eventDispatcher,
            $this->entitlementEngine
        );
        
        // Clean up any existing test data
        $this->cleanupTestData();
    }
    
    protected function tearDown(): void
    {
        $this->cleanupTestData();
        parent::tearDown();
    }
    
    private function cleanupTestData(): void
    {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_subscriptions WHERE workspace_id LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_plans WHERE plan_id LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_entitlements WHERE workspace_id LIKE 'test-%'");
    }
    
    private function createTestPlan(string $planId = 'test-starter', ?int $trialDays = null): Plan
    {
        $plan = new Plan(
            $planId,
            'Test Starter Plan',
            Subscription::PERIOD_MONTHLY,
            ['shortlink.max_links' => 100],
            $trialDays,
            true,
            ['description' => 'Test plan']
        );
        
        return $this->planRepo->save($plan);
    }
    
    public function test_create_subscription_with_active_status(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-1';
        $plan = $this->createTestPlan();
        
        // Act
        $subscription = $this->engine->create($workspaceId, $plan->planId);
        
        // Assert
        $this->assertNotNull($subscription);
        $this->assertEquals($workspaceId, $subscription->workspaceId);
        $this->assertEquals($plan->planId, $subscription->planId);
        $this->assertEquals(Subscription::STATUS_ACTIVE, $subscription->status);
        $this->assertEquals(Subscription::PERIOD_MONTHLY, $subscription->billingPeriod);
        $this->assertNull($subscription->endsAt);
    }
    
    public function test_create_subscription_with_trial_status(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-2';
        $plan = $this->createTestPlan('test-trial-plan', 14);
        
        // Act
        $subscription = $this->engine->create($workspaceId, $plan->planId);
        
        // Assert
        $this->assertEquals(Subscription::STATUS_TRIAL, $subscription->status);
        $this->assertNotNull($subscription->endsAt);
        $this->assertGreaterThan($subscription->startedAt, $subscription->endsAt);
    }
    
    public function test_create_subscription_throws_exception_if_workspace_has_active_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-3';
        $plan = $this->createTestPlan();
        $this->engine->create($workspaceId, $plan->planId);
        
        // Act & Assert
        $this->expectException(SubscriptionExistsException::class);
        $this->engine->create($workspaceId, $plan->planId);
    }
    
    public function test_create_subscription_throws_exception_if_plan_not_found(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-4';
        
        // Act & Assert
        $this->expectException(PlanNotFoundException::class);
        $this->engine->create($workspaceId, 'non-existent-plan');
    }
    
    public function test_change_plan(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-5';
        $plan1 = $this->createTestPlan('test-plan-1');
        $plan2 = $this->createTestPlan('test-plan-2');
        $subscription = $this->engine->create($workspaceId, $plan1->planId);
        
        // Act
        $updatedSubscription = $this->engine->changePlan($workspaceId, $plan2->planId);
        
        // Assert
        $this->assertEquals($subscription->subscriptionId, $updatedSubscription->subscriptionId);
        $this->assertEquals($plan2->planId, $updatedSubscription->planId);
    }
    
    public function test_pause_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-6';
        $plan = $this->createTestPlan();
        $this->engine->create($workspaceId, $plan->planId);
        
        // Act
        $result = $this->engine->pause($workspaceId);
        
        // Assert
        $this->assertTrue($result);
        $subscription = $this->subscriptionRepo->findByWorkspace($workspaceId);
        $this->assertEquals(Subscription::STATUS_PAUSED, $subscription->status);
    }
    
    public function test_resume_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-7';
        $plan = $this->createTestPlan();
        $this->engine->create($workspaceId, $plan->planId);
        $this->engine->pause($workspaceId);
        
        // Act
        $result = $this->engine->resume($workspaceId);
        
        // Assert
        $this->assertTrue($result);
        $subscription = $this->subscriptionRepo->findByWorkspace($workspaceId);
        $this->assertEquals(Subscription::STATUS_ACTIVE, $subscription->status);
    }
    
    public function test_cancel_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-8';
        $plan = $this->createTestPlan();
        $this->engine->create($workspaceId, $plan->planId);
        
        // Act
        $result = $this->engine->cancel($workspaceId);
        
        // Assert
        $this->assertTrue($result);
        $subscription = $this->subscriptionRepo->findByWorkspace($workspaceId);
        $this->assertEquals(Subscription::STATUS_CANCELLED, $subscription->status);
        $this->assertNotNull($subscription->endsAt);
    }
    
    public function test_current_returns_active_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-9';
        $plan = $this->createTestPlan();
        $created = $this->engine->create($workspaceId, $plan->planId);
        
        // Act
        $current = $this->engine->current($workspaceId);
        
        // Assert
        $this->assertNotNull($current);
        $this->assertEquals($created->subscriptionId, $current->subscriptionId);
    }
    
    public function test_current_returns_null_for_workspace_without_subscription(): void
    {
        // Act
        $current = $this->engine->current('test-workspace-nonexistent');
        
        // Assert
        $this->assertNull($current);
    }
    
    public function test_has_active_subscription(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-10';
        $plan = $this->createTestPlan();
        
        // Act & Assert - before creation
        $this->assertFalse($this->engine->hasActiveSubscription($workspaceId));
        
        // Create subscription
        $this->engine->create($workspaceId, $plan->planId);
        
        // Act & Assert - after creation
        $this->assertTrue($this->engine->hasActiveSubscription($workspaceId));
    }
    
    public function test_process_expirations(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-11';
        $plan = $this->createTestPlan('test-expired-plan', 1);
        
        // Create subscription with trial that expired yesterday
        $subscription = $this->subscriptionRepo->create(
            $workspaceId,
            $plan->planId,
            Subscription::STATUS_TRIAL,
            $plan->billingPeriod,
            (new DateTimeImmutable())->modify('-2 days'),
            (new DateTimeImmutable())->modify('-1 day')
        );
        
        // Act
        $count = $this->engine->processExpirations();
        
        // Assert
        $this->assertEquals(1, $count);
        $updated = $this->subscriptionRepo->findById($subscription->subscriptionId);
        $this->assertEquals(Subscription::STATUS_EXPIRED, $updated->status);
    }
    
    public function test_create_subscription_grants_plan_entitlements(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-12';
        $plan = $this->createTestPlan('test-plan-entitlements');
        
        // Act
        $subscription = $this->engine->create($workspaceId, $plan->planId);
        
        // Assert - verify entitlements were granted
        $entitlements = $this->entitlementEngine->getAllForWorkspace($workspaceId);
        $this->assertCount(1, $entitlements);
        $this->assertEquals('shortlink.max_links', $entitlements[0]->key);
        $this->assertEquals(100, $entitlements[0]->value);
    }
    
    public function test_change_plan_updates_entitlements(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-13';
        
        // Create plan 1 with one entitlement
        $plan1 = new Plan(
            'test-plan-change-1',
            'Plan 1',
            Subscription::PERIOD_MONTHLY,
            ['shortlink.max_links' => 100, 'analytics.enabled' => true],
            null,
            true
        );
        $this->planRepo->save($plan1);
        
        // Create plan 2 with different entitlements
        $plan2 = new Plan(
            'test-plan-change-2',
            'Plan 2',
            Subscription::PERIOD_MONTHLY,
            ['shortlink.max_links' => 500, 'custom_domain.enabled' => true],
            null,
            true
        );
        $this->planRepo->save($plan2);
        
        // Create subscription with plan 1
        $this->engine->create($workspaceId, $plan1->planId);
        
        // Verify initial entitlements
        $this->assertTrue($this->entitlementEngine->check($workspaceId, 'shortlink.max_links'));
        $this->assertTrue($this->entitlementEngine->check($workspaceId, 'analytics.enabled'));
        $this->assertFalse($this->entitlementEngine->check($workspaceId, 'custom_domain.enabled'));
        
        // Act - change to plan 2
        $this->engine->changePlan($workspaceId, $plan2->planId);
        
        // Assert - verify entitlements updated
        $this->assertTrue($this->entitlementEngine->check($workspaceId, 'shortlink.max_links'));
        $this->assertEquals(500, $this->entitlementEngine->current($workspaceId, 'shortlink.max_links'));
        $this->assertFalse($this->entitlementEngine->check($workspaceId, 'analytics.enabled')); // Revoked
        $this->assertTrue($this->entitlementEngine->check($workspaceId, 'custom_domain.enabled')); // Granted
    }
    
    public function test_process_expirations_revokes_entitlements(): void
    {
        // Arrange
        $workspaceId = 'test-workspace-14';
        $plan = $this->createTestPlan('test-expired-plan-2', 1);
        
        // Create subscription with trial that expired yesterday
        $subscription = $this->subscriptionRepo->create(
            $workspaceId,
            $plan->planId,
            Subscription::STATUS_TRIAL,
            $plan->billingPeriod,
            (new DateTimeImmutable())->modify('-2 days'),
            (new DateTimeImmutable())->modify('-1 day')
        );
        
        // Grant entitlements manually (simulating they were granted at creation)
        $this->entitlementEngine->grantPlanEntitlements($workspaceId, $plan);
        
        // Verify entitlements exist
        $this->assertTrue($this->entitlementEngine->check($workspaceId, 'shortlink.max_links'));
        
        // Act
        $count = $this->engine->processExpirations();
        
        // Assert - verify entitlements were revoked
        $this->assertEquals(1, $count);
        $this->assertFalse($this->entitlementEngine->check($workspaceId, 'shortlink.max_links'));
    }
}
