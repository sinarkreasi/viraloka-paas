<?php

declare(strict_types=1);

namespace Tests\Unit\Identity;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Identity\Repositories\IdentityRepository;
use Viraloka\Core\Identity\Identity;
use Viraloka\Core\Adapter\Testing\InMemoryStorageAdapter;

/**
 * Unit tests for IdentityRepository
 * 
 * Tests persistence operations using in-memory storage.
 */
class IdentityRepositoryTest extends TestCase
{
    private InMemoryStorageAdapter $storageAdapter;
    private IdentityRepository $repository;

    protected function setUp(): void
    {
        $this->storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new IdentityRepository($this->storageAdapter);
    }

    public function testSaveAndFindById(): void
    {
        // Arrange
        $identity = new Identity(
            'test-id-123',
            'test@example.com',
            Identity::STATUS_ACTIVE,
            ['name' => 'Test User']
        );
        
        // Act
        $saved = $this->repository->save($identity);
        $found = $this->repository->findById('test-id-123');
        
        // Assert
        $this->assertTrue($saved);
        $this->assertNotNull($found);
        $this->assertEquals($identity->identityId, $found->identityId);
        $this->assertEquals($identity->email, $found->email);
        $this->assertEquals($identity->status, $found->status);
        $this->assertEquals($identity->metadata, $found->metadata);
    }

    public function testFindByEmail(): void
    {
        // Arrange
        $identity = new Identity('test-id', 'test@example.com');
        $this->repository->save($identity);
        
        // Act
        $found = $this->repository->findByEmail('test@example.com');
        
        // Assert
        $this->assertNotNull($found);
        $this->assertEquals($identity->identityId, $found->identityId);
    }

    public function testFindByEmailIsCaseInsensitive(): void
    {
        // Arrange
        $identity = new Identity('test-id', 'Test@Example.COM');
        $this->repository->save($identity);
        
        // Act
        $found = $this->repository->findByEmail('test@example.com');
        
        // Assert
        $this->assertNotNull($found);
        $this->assertEquals($identity->identityId, $found->identityId);
    }

    public function testEmailExists(): void
    {
        // Arrange
        $identity = new Identity('test-id', 'test@example.com');
        $this->repository->save($identity);
        
        // Act & Assert
        $this->assertTrue($this->repository->emailExists('test@example.com'));
        $this->assertFalse($this->repository->emailExists('other@example.com'));
    }

    public function testSaveReturnsFalseForDuplicateEmail(): void
    {
        // Arrange
        $identity1 = new Identity('id-1', 'test@example.com');
        $identity2 = new Identity('id-2', 'test@example.com');
        
        // Act
        $saved1 = $this->repository->save($identity1);
        $saved2 = $this->repository->save($identity2);
        
        // Assert
        $this->assertTrue($saved1);
        $this->assertFalse($saved2);
    }

    public function testUpdate(): void
    {
        // Arrange
        $identity = new Identity('test-id', 'test@example.com', Identity::STATUS_ACTIVE);
        $this->repository->save($identity);
        
        // Act
        $identity->suspend();
        $updated = $this->repository->update($identity);
        $found = $this->repository->findById('test-id');
        
        // Assert
        $this->assertTrue($updated);
        $this->assertNotNull($found);
        $this->assertEquals(Identity::STATUS_SUSPENDED, $found->status);
    }

    public function testUpdateReturnsFalseForNonExistentIdentity(): void
    {
        // Arrange
        $identity = new Identity('non-existent', 'test@example.com');
        
        // Act
        $updated = $this->repository->update($identity);
        
        // Assert
        $this->assertFalse($updated);
    }

    public function testDelete(): void
    {
        // Arrange
        $identity = new Identity('test-id', 'test@example.com');
        $this->repository->save($identity);
        
        // Act
        $deleted = $this->repository->delete('test-id');
        $found = $this->repository->findById('test-id');
        
        // Assert
        $this->assertTrue($deleted);
        $this->assertNull($found);
        $this->assertFalse($this->repository->emailExists('test@example.com'));
    }

    public function testDeleteReturnsFalseForNonExistentIdentity(): void
    {
        // Act
        $deleted = $this->repository->delete('non-existent');
        
        // Assert
        $this->assertFalse($deleted);
    }

    public function testFindByIdReturnsNullForNonExistent(): void
    {
        // Act
        $found = $this->repository->findById('non-existent');
        
        // Assert
        $this->assertNull($found);
    }

    public function testFindByEmailReturnsNullForNonExistent(): void
    {
        // Act
        $found = $this->repository->findByEmail('nonexistent@example.com');
        
        // Assert
        $this->assertNull($found);
    }
}
