<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;

/**
 * Application Property Tests
 * 
 * Property-based tests for the Application service container.
 * Tests universal properties that should hold across all valid inputs.
 */
class ApplicationPropertyTest extends TestCase
{
    /**
     * Property 4: Singleton Binding Identity
     * 
     * For any service bound as a singleton, resolving it multiple times 
     * from the Service Container SHALL return the same instance.
     * 
     * Feature: core-bootstrap-flow, Property 4: Singleton Binding Identity
     * Validates: Requirements 3.4
     */
    public function testSingletonBindingIdentity(): void
    {
        // Test with multiple random service names
        $serviceNames = [
            'TestService1',
            'TestService2',
            'Some\\Namespace\\Service',
            'AnotherService',
            'YetAnotherService'
        ];
        
        foreach ($serviceNames as $serviceName) {
            $app = new Application(__DIR__);
            
            // Bind service as singleton
            $app->singleton($serviceName, function() {
                return new \stdClass();
            });
            
            // Resolve multiple times
            $instance1 = $app->make($serviceName);
            $instance2 = $app->make($serviceName);
            $instance3 = $app->make($serviceName);
            
            // Assert same instance (identity check)
            $this->assertSame($instance1, $instance2, 
                "Singleton service [{$serviceName}] should return same instance on second make()");
            $this->assertSame($instance1, $instance3, 
                "Singleton service [{$serviceName}] should return same instance on third make()");
            $this->assertSame($instance2, $instance3, 
                "Singleton service [{$serviceName}] should return same instance consistently");
        }
    }
    
    /**
     * Property 4: Singleton Binding Identity (with different concrete types)
     * 
     * Tests singleton identity with various concrete implementations
     */
    public function testSingletonBindingIdentityWithDifferentTypes(): void
    {
        $app = new Application(__DIR__);
        
        // Test with object
        $app->singleton('ObjectService', function() {
            return new \stdClass();
        });
        
        $obj1 = $app->make('ObjectService');
        $obj2 = $app->make('ObjectService');
        $this->assertSame($obj1, $obj2);
        
        // Test with array
        $app->singleton('ArrayService', function() {
            return ['key' => 'value', 'random' => rand()];
        });
        
        $arr1 = $app->make('ArrayService');
        $arr2 = $app->make('ArrayService');
        $this->assertSame($arr1, $arr2);
        
        // Test with closure
        $app->singleton('ClosureService', function() {
            return function() { return 'test'; };
        });
        
        $closure1 = $app->make('ClosureService');
        $closure2 = $app->make('ClosureService');
        $this->assertSame($closure1, $closure2);
    }
    
    /**
     * Property 5: Factory Binding Uniqueness
     * 
     * For any service bound as a factory, resolving it multiple times 
     * from the Service Container SHALL return different instances.
     * 
     * Feature: core-bootstrap-flow, Property 5: Factory Binding Uniqueness
     * Validates: Requirements 3.5
     */
    public function testFactoryBindingUniqueness(): void
    {
        // Test with multiple random service names
        $serviceNames = [
            'FactoryService1',
            'FactoryService2',
            'Some\\Namespace\\FactoryService',
            'AnotherFactoryService',
            'YetAnotherFactoryService'
        ];
        
        foreach ($serviceNames as $serviceName) {
            $app = new Application(__DIR__);
            
            // Bind service as factory (using bind, not singleton)
            $app->bind($serviceName, function() {
                return new \stdClass();
            });
            
            // Resolve multiple times
            $instance1 = $app->make($serviceName);
            $instance2 = $app->make($serviceName);
            $instance3 = $app->make($serviceName);
            
            // Assert different instances (not same identity)
            $this->assertNotSame($instance1, $instance2, 
                "Factory service [{$serviceName}] should return different instance on second make()");
            $this->assertNotSame($instance1, $instance3, 
                "Factory service [{$serviceName}] should return different instance on third make()");
            $this->assertNotSame($instance2, $instance3, 
                "Factory service [{$serviceName}] should return different instance consistently");
        }
    }
    
    /**
     * Property 5: Factory Binding Uniqueness (with different concrete types)
     * 
     * Tests factory uniqueness with various concrete implementations
     */
    public function testFactoryBindingUniquenessWithDifferentTypes(): void
    {
        $app = new Application(__DIR__);
        
        // Test with object
        $app->bind('ObjectFactory', function() {
            return new \stdClass();
        });
        
        $obj1 = $app->make('ObjectFactory');
        $obj2 = $app->make('ObjectFactory');
        $this->assertNotSame($obj1, $obj2);
        
        // Test with array (each call should create new array)
        $app->bind('ArrayFactory', function() {
            return ['key' => 'value', 'random' => rand()];
        });
        
        $arr1 = $app->make('ArrayFactory');
        $arr2 = $app->make('ArrayFactory');
        $this->assertNotSame($arr1, $arr2);
        
        // Test with closure
        $app->bind('ClosureFactory', function() {
            return function() { return 'test'; };
        });
        
        $closure1 = $app->make('ClosureFactory');
        $closure2 = $app->make('ClosureFactory');
        $this->assertNotSame($closure1, $closure2);
    }
    
    /**
     * Property 8: Lazy Service Loading
     * 
     * For any service marked as lazy, the Service Container SHALL not 
     * instantiate it during bootstrap and SHALL instantiate it on first request.
     * 
     * Feature: core-bootstrap-flow, Property 8: Lazy Service Loading
     * Validates: Requirements 5.2, 13.1, 13.2
     */
    public function testLazyServiceLoading(): void
    {
        // Test with multiple random service names
        $serviceNames = [
            'LazyService1',
            'LazyService2',
            'Some\\Namespace\\LazyService',
            'AnotherLazyService',
            'YetAnotherLazyService'
        ];
        
        foreach ($serviceNames as $serviceName) {
            $app = new Application(__DIR__);
            
            // Track instantiation
            $instantiated = false;
            
            // Mark service as lazy
            $app->lazy($serviceName, function() use (&$instantiated) {
                $instantiated = true;
                return new \stdClass();
            });
            
            // Service should NOT be instantiated yet
            $this->assertFalse($instantiated, 
                "Lazy service [{$serviceName}] should not be instantiated during registration");
            
            // First make() call should instantiate
            $instance = $app->make($serviceName);
            $this->assertTrue($instantiated, 
                "Lazy service [{$serviceName}] should be instantiated on first make()");
            $this->assertInstanceOf(\stdClass::class, $instance);
        }
    }
    
    /**
     * Property 8: Lazy Service Loading (verify no instantiation during bootstrap)
     * 
     * Tests that lazy services are not instantiated during the bootstrap phase
     */
    public function testLazyServiceNotInstantiatedDuringBootstrap(): void
    {
        $app = new Application(__DIR__);
        
        // Track instantiation count
        $instantiationCount = 0;
        
        // Register multiple lazy services
        for ($i = 1; $i <= 5; $i++) {
            $app->lazy("LazyService{$i}", function() use (&$instantiationCount) {
                $instantiationCount++;
                return new \stdClass();
            });
        }
        
        // No services should be instantiated yet
        $this->assertEquals(0, $instantiationCount, 
            "No lazy services should be instantiated during registration");
        
        // Make one service
        $app->make('LazyService1');
        $this->assertEquals(1, $instantiationCount, 
            "Only requested lazy service should be instantiated");
        
        // Make another service
        $app->make('LazyService3');
        $this->assertEquals(2, $instantiationCount, 
            "Only requested lazy services should be instantiated");
        
        // Other services should still not be instantiated
        $this->assertEquals(2, $instantiationCount);
    }
    
    /**
     * Property 29: Lazy Service Caching
     * 
     * For any lazy service that has been instantiated, subsequent requests 
     * SHALL return the cached instance.
     * 
     * Feature: core-bootstrap-flow, Property 29: Lazy Service Caching
     * Validates: Requirements 13.3
     */
    public function testLazyServiceCaching(): void
    {
        // Test with multiple random service names
        $serviceNames = [
            'CachedLazyService1',
            'CachedLazyService2',
            'Some\\Namespace\\CachedLazyService',
            'AnotherCachedLazyService',
            'YetAnotherCachedLazyService'
        ];
        
        foreach ($serviceNames as $serviceName) {
            $app = new Application(__DIR__);
            
            // Track instantiation count
            $instantiationCount = 0;
            
            // Mark service as lazy
            $app->lazy($serviceName, function() use (&$instantiationCount) {
                $instantiationCount++;
                return new \stdClass();
            });
            
            // First make() call should instantiate
            $instance1 = $app->make($serviceName);
            $this->assertEquals(1, $instantiationCount, 
                "Lazy service [{$serviceName}] should be instantiated once on first make()");
            
            // Second make() call should return cached instance
            $instance2 = $app->make($serviceName);
            $this->assertEquals(1, $instantiationCount, 
                "Lazy service [{$serviceName}] should not be instantiated again on second make()");
            
            // Third make() call should also return cached instance
            $instance3 = $app->make($serviceName);
            $this->assertEquals(1, $instantiationCount, 
                "Lazy service [{$serviceName}] should not be instantiated again on third make()");
            
            // All instances should be the same (cached)
            $this->assertSame($instance1, $instance2, 
                "Lazy service [{$serviceName}] should return same cached instance");
            $this->assertSame($instance1, $instance3, 
                "Lazy service [{$serviceName}] should return same cached instance");
        }
    }
    
    /**
     * Property 29: Lazy Service Caching (verify single instantiation)
     * 
     * Tests that lazy services are only instantiated once regardless of 
     * how many times they are requested
     */
    public function testLazyServiceSingleInstantiation(): void
    {
        $app = new Application(__DIR__);
        
        $instantiationCount = 0;
        
        $app->lazy('CountedService', function() use (&$instantiationCount) {
            $instantiationCount++;
            $obj = new \stdClass();
            $obj->id = $instantiationCount;
            return $obj;
        });
        
        // Make the service 10 times
        $instances = [];
        for ($i = 0; $i < 10; $i++) {
            $instances[] = $app->make('CountedService');
        }
        
        // Should only be instantiated once
        $this->assertEquals(1, $instantiationCount, 
            "Lazy service should only be instantiated once");
        
        // All instances should be the same
        $firstInstance = $instances[0];
        foreach ($instances as $instance) {
            $this->assertSame($firstInstance, $instance, 
                "All resolved instances should be the same cached instance");
        }
        
        // All should have the same ID (from first instantiation)
        foreach ($instances as $instance) {
            $this->assertEquals(1, $instance->id, 
                "All instances should have ID from first instantiation");
        }
    }
    
    /**
     * Property 30: Lazy Service Instantiation Failure
     * 
     * For any lazy service that fails to instantiate, the Service Container 
     * SHALL throw a descriptive exception.
     * 
     * Feature: core-bootstrap-flow, Property 30: Lazy Service Instantiation Failure
     * Validates: Requirements 13.4
     */
    public function testLazyServiceInstantiationFailure(): void
    {
        // Test with multiple random service names and different failure scenarios
        $testCases = [
            [
                'name' => 'FailingLazyService1',
                'exception' => new \RuntimeException('Service initialization failed'),
            ],
            [
                'name' => 'FailingLazyService2',
                'exception' => new \InvalidArgumentException('Invalid configuration'),
            ],
            [
                'name' => 'Some\\Namespace\\FailingLazyService',
                'exception' => new \Exception('Generic error'),
            ],
            [
                'name' => 'AnotherFailingLazyService',
                'exception' => new \LogicException('Logic error occurred'),
            ],
            [
                'name' => 'YetAnotherFailingLazyService',
                'exception' => new \RuntimeException('Database connection failed'),
            ],
        ];
        
        foreach ($testCases as $testCase) {
            $app = new Application(__DIR__);
            $serviceName = $testCase['name'];
            $originalException = $testCase['exception'];
            
            // Mark service as lazy with failing instantiation
            $app->lazy($serviceName, function() use ($originalException) {
                throw $originalException;
            });
            
            // Attempt to make the service should throw descriptive exception
            try {
                $app->make($serviceName);
                $this->fail("Expected RuntimeException for lazy service [{$serviceName}] but none was thrown");
            } catch (\RuntimeException $e) {
                // Assert exception message is descriptive
                $this->assertStringContainsString('Failed to instantiate lazy service', $e->getMessage(),
                    "Exception should contain descriptive message about lazy service failure");
                $this->assertStringContainsString($serviceName, $e->getMessage(),
                    "Exception should contain the service name [{$serviceName}]");
                $this->assertStringContainsString($originalException->getMessage(), $e->getMessage(),
                    "Exception should contain the original error message");
                
                // Assert original exception is preserved as previous
                $this->assertSame($originalException, $e->getPrevious(),
                    "Original exception should be preserved as previous exception");
            }
        }
    }
    
    /**
     * Property 30: Lazy Service Instantiation Failure (verify exception details)
     * 
     * Tests that lazy service instantiation failures provide complete context
     */
    public function testLazyServiceInstantiationFailureDetails(): void
    {
        $app = new Application(__DIR__);
        
        $app->lazy('DetailedFailingService', function() {
            throw new \RuntimeException('Detailed error message with context');
        });
        
        try {
            $app->make('DetailedFailingService');
            $this->fail('Expected RuntimeException but none was thrown');
        } catch (\RuntimeException $e) {
            // Verify exception structure
            $this->assertInstanceOf(\RuntimeException::class, $e);
            $this->assertStringContainsString('Failed to instantiate lazy service', $e->getMessage());
            $this->assertStringContainsString('DetailedFailingService', $e->getMessage());
            $this->assertStringContainsString('Detailed error message with context', $e->getMessage());
            
            // Verify previous exception exists
            $this->assertNotNull($e->getPrevious());
            $this->assertInstanceOf(\RuntimeException::class, $e->getPrevious());
            $this->assertEquals('Detailed error message with context', $e->getPrevious()->getMessage());
        }
    }
}
