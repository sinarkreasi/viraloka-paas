<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\Kernel;
use Viraloka\Core\Bootstrap\SecurityGuard;
use Viraloka\Core\Bootstrap\PerformanceGuard;
use Viraloka\Core\Workspace\WorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Theme\ThemeIntegration;
use Viraloka\Core\Modules\Contracts\ModuleLoaderContract;
use Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract;

/**
 * Bootstrap Integration Tests
 * 
 * Tests the complete bootstrap flow from entry point to ready state.
 * Validates: Requirements 2.1, 2.2, 2.3, 2.4
 */
class BootstrapIntegrationTest extends TestCase
{
    private Application $app;
    private string $testBasePath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create test base path
        $this->testBasePath = __DIR__;
        
        // Create fresh application instance
        $this->app = new Application($this->testBasePath);
    }
    
    /**
     * Test full bootstrap sequence from entry point to ready state
     * 
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testFullBootstrapSequence(): void
    {
        // Create and bootstrap kernel
        $kernel = new Kernel($this->app);
        
        // Track lifecycle events
        $eventsDispatched = [];
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.register', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'register';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.boot', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'boot';
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.ready', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'ready';
        });
        
        $eventDispatcher->listen('viraloka.ready', function () use (&$eventsDispatched) {
            $eventsDispatched[] = 'system_ready';
        });
        
        // Execute bootstrap
        $kernel->bootstrap();
        
        // Assert kernel is bootstrapped
        $this->assertTrue($kernel->isBootstrapped());
        $this->assertTrue($kernel->isReady());
        
        // Assert lifecycle events were dispatched in correct order
        $this->assertEquals(['register', 'boot', 'ready', 'system_ready'], $eventsDispatched);
        
        // Assert core services are registered
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($this->app->bound(SecurityGuard::class));
        $this->assertTrue($this->app->bound(PerformanceGuard::class));
        $this->assertTrue($this->app->bound(WorkspaceResolver::class));
        $this->assertTrue($this->app->bound(ContextResolver::class));
        $this->assertTrue($this->app->bound(ThemeIntegration::class));
        
        // Assert workspace was resolved and injected
        $this->assertTrue($this->app->bound(Workspace::class));
        $workspace = $this->app->make(Workspace::class);
        $this->assertInstanceOf(Workspace::class, $workspace);
        
        // Assert guards were activated
        $performanceGuard = $this->app->make(PerformanceGuard::class);
        $this->assertTrue($performanceGuard->isActive());
        
        // Assert security guard has capability gates
        $securityGuard = $this->app->make(SecurityGuard::class);
        $capabilityGates = $securityGuard->getCapabilityGates();
        $this->assertNotEmpty($capabilityGates);
    }
    
    /**
     * Test bootstrap with module failures
     * 
     * Validates that module failures don't compromise Core stability.
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testBootstrapWithModuleFailures(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Bootstrap should complete even if modules fail
        $kernel->bootstrap();
        
        // Assert kernel completed bootstrap
        $this->assertTrue($kernel->isBootstrapped());
        $this->assertTrue($kernel->isReady());
        
        // Assert Core services are still available
        $this->assertTrue($this->app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($this->app->bound(SecurityGuard::class));
        $this->assertTrue($this->app->bound(PerformanceGuard::class));
    }
    
    /**
     * Test bootstrap with workspace resolution
     * 
     * Validates that workspace is resolved and injected into container.
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testBootstrapWithWorkspaceResolution(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert workspace was resolved
        $this->assertTrue($this->app->bound(Workspace::class));
        
        $workspace = $this->app->make(Workspace::class);
        $this->assertInstanceOf(Workspace::class, $workspace);
        
        // Assert workspace has required properties
        $this->assertNotEmpty($workspace->id);
        $this->assertNotEmpty($workspace->name);
    }
    
    /**
     * Test bootstrap with context resolution
     * 
     * Validates that context is resolved during boot phase.
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testBootstrapWithContextResolution(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert context resolver is available
        $this->assertTrue($this->app->bound(ContextResolver::class));
        
        $contextResolver = $this->app->make(ContextResolver::class);
        $this->assertInstanceOf(ContextResolver::class, $contextResolver);
        
        // Context should be resolved
        $context = $contextResolver->resolve();
        $this->assertIsString($context);
        $this->assertNotEmpty($context);
    }
    
    /**
     * Test bootstrap idempotence
     * 
     * Validates that calling bootstrap multiple times doesn't cause issues.
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testBootstrapIdempotence(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Track event dispatch count
        $registerCount = 0;
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.register', function () use (&$registerCount) {
            $registerCount++;
        });
        
        // Bootstrap multiple times
        $kernel->bootstrap();
        $kernel->bootstrap();
        $kernel->bootstrap();
        
        // Assert bootstrap only executed once
        $this->assertEquals(1, $registerCount);
        $this->assertTrue($kernel->isBootstrapped());
    }
    
    /**
     * Test Application bootstrap() delegates to Kernel
     * 
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testApplicationBootstrapDelegatesToKernel(): void
    {
        // Create fresh application
        $app = new Application($this->testBasePath);
        
        // Bootstrap via Application
        $app->bootstrap();
        
        // Assert application is bootstrapped
        $this->assertTrue($app->isBootstrapped());
        
        // Assert core services are available (proving Kernel was used)
        $this->assertTrue($app->bound(\Viraloka\Core\Modules\Logger::class));
        $this->assertTrue($app->bound(SecurityGuard::class));
        $this->assertTrue($app->bound(PerformanceGuard::class));
    }
    
    /**
     * Test guards are activated in boot phase
     * 
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testGuardsActivatedInBootPhase(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Track when guards are activated
        $securityActivated = false;
        $performanceActivated = false;
        
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.boot', function () use (&$securityActivated, &$performanceActivated) {
            // After boot event, guards should be activated
            $securityActivated = true;
            $performanceActivated = true;
        });
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert guards were activated
        $this->assertTrue($securityActivated);
        $this->assertTrue($performanceActivated);
        
        // Verify guards are actually active
        $performanceGuard = $this->app->make(PerformanceGuard::class);
        $this->assertTrue($performanceGuard->isActive());
    }
    
    /**
     * Test theme integration is activated in ready phase
     * 
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testThemeIntegrationActivatedInReadyPhase(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert theme integration is available
        $this->assertTrue($this->app->bound(ThemeIntegration::class));
        
        $themeIntegration = $this->app->make(ThemeIntegration::class);
        $this->assertInstanceOf(ThemeIntegration::class, $themeIntegration);
    }
    
    /**
     * Test complete lifecycle phase execution order
     * 
     * Validates: Requirements 2.1, 2.2, 2.3, 2.4
     */
    public function testLifecyclePhaseExecutionOrder(): void
    {
        // Create kernel
        $kernel = new Kernel($this->app);
        
        // Track phase execution
        $phases = [];
        $eventDispatcher = $kernel->getEventDispatcher();
        
        $eventDispatcher->listen('viraloka.bootstrap.register', function () use (&$phases, $kernel) {
            $phases[] = $kernel->getCurrentPhase();
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.boot', function () use (&$phases, $kernel) {
            $phases[] = $kernel->getCurrentPhase();
        });
        
        $eventDispatcher->listen('viraloka.bootstrap.ready', function () use (&$phases, $kernel) {
            $phases[] = $kernel->getCurrentPhase();
        });
        
        // Bootstrap
        $kernel->bootstrap();
        
        // Assert phases executed in correct order
        $this->assertEquals(['register', 'boot', 'ready'], $phases);
    }
}
