<?php

/**
 * WordPress Function Stubs for Testing
 * 
 * These are minimal implementations of WordPress functions
 * needed for testing the module system.
 */

// Global storage for WordPress options
global $wp_options;
$wp_options = [];

if (!function_exists('get_option')) {
    /**
     * Mock WordPress get_option function
     * 
     * @param string $option
     * @param mixed $default
     * @return mixed
     */
    function get_option(string $option, $default = false)
    {
        global $wp_options;
        return $wp_options[$option] ?? $default;
    }
}

if (!function_exists('update_option')) {
    /**
     * Mock WordPress update_option function
     * 
     * @param string $option
     * @param mixed $value
     * @return bool
     */
    function update_option(string $option, $value): bool
    {
        global $wp_options;
        $wp_options[$option] = $value;
        return true;
    }
}

if (!function_exists('delete_option')) {
    /**
     * Mock WordPress delete_option function
     * 
     * @param string $option
     * @return bool
     */
    function delete_option(string $option): bool
    {
        global $wp_options;
        unset($wp_options[$option]);
        return true;
    }
}

if (!function_exists('is_plugin_active')) {
    /**
     * Mock WordPress is_plugin_active function
     * 
     * @param string $plugin
     * @return bool
     */
    function is_plugin_active(string $plugin): bool
    {
        global $wp_active_plugins;
        if (!isset($wp_active_plugins)) {
            $wp_active_plugins = [];
        }
        return in_array($plugin, $wp_active_plugins);
    }
}

// Global storage for WordPress actions
global $wp_actions;
$wp_actions = [];
$wp_filter = [];

if (!function_exists('do_action')) {
    /**
     * Mock WordPress do_action function
     * 
     * @param string $hook_name
     * @param mixed ...$args
     * @return void
     */
    function do_action(string $hook_name, ...$args): void
    {
        global $wp_actions, $wp_filter;
        
        // Track that action was called
        if (!isset($wp_actions[$hook_name])) {
            $wp_actions[$hook_name] = 0;
        }
        $wp_actions[$hook_name]++;
        
        // Execute registered callbacks
        if (isset($wp_filter[$hook_name])) {
            // Sort by priority
            $callbacks = $wp_filter[$hook_name];
            ksort($callbacks);
            
            foreach ($callbacks as $priority => $callbackList) {
                foreach ($callbackList as $callback) {
                    call_user_func($callback, ...$args);
                }
            }
        }
    }
}

if (!function_exists('did_action')) {
    /**
     * Mock WordPress did_action function
     * 
     * @param string $hook_name
     * @return int
     */
    function did_action(string $hook_name): int
    {
        global $wp_actions;
        return isset($wp_actions[$hook_name]) ? $wp_actions[$hook_name] : 0;
    }
}

if (!function_exists('add_action')) {
    /**
     * Mock WordPress add_action function
     * 
     * @param string $hook_name
     * @param callable $callback
     * @param int $priority
     * @param int $accepted_args
     * @return bool
     */
    function add_action(string $hook_name, callable $callback, int $priority = 10, int $accepted_args = 1): bool
    {
        global $wp_filter;
        
        if (!isset($wp_filter[$hook_name])) {
            $wp_filter[$hook_name] = [];
        }
        
        if (!isset($wp_filter[$hook_name][$priority])) {
            $wp_filter[$hook_name][$priority] = [];
        }
        
        $wp_filter[$hook_name][$priority][] = $callback;
        
        return true;
    }
}

if (!function_exists('esc_html')) {
    /**
     * Mock WordPress esc_html function
     * 
     * @param string $text
     * @return string
     */
    function esc_html(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('plugin_dir_path')) {
    /**
     * Mock WordPress plugin_dir_path function
     * 
     * @param string $file
     * @return string
     */
    function plugin_dir_path(string $file): string
    {
        return dirname($file) . '/';
    }
}

if (!function_exists('plugin_dir_url')) {
    /**
     * Mock WordPress plugin_dir_url function
     * 
     * @param string $file
     * @return string
     */
    function plugin_dir_url(string $file): string
    {
        return 'http://example.com/wp-content/plugins/' . basename(dirname($file)) . '/';
    }
}

if (!function_exists('plugin_basename')) {
    /**
     * Mock WordPress plugin_basename function
     * 
     * @param string $file
     * @return string
     */
    function plugin_basename(string $file): string
    {
        return basename(dirname($file)) . '/' . basename($file);
    }
}

if (!function_exists('current_user_can')) {
    /**
     * Mock WordPress current_user_can function
     * 
     * @param string $capability
     * @return bool
     */
    function current_user_can(string $capability): bool
    {
        return true; // For testing, assume user has all capabilities
    }
}

if (!function_exists('wp_create_nonce')) {
    /**
     * Mock WordPress wp_create_nonce function
     * 
     * @param string|int $action
     * @return string
     */
    function wp_create_nonce($action = -1): string
    {
        // Simple mock implementation - just hash the action
        return substr(md5($action . 'salt'), 0, 10);
    }
}

if (!function_exists('wp_verify_nonce')) {
    /**
     * Mock WordPress wp_verify_nonce function
     * 
     * @param string $nonce
     * @param string|int $action
     * @return int|false
     */
    function wp_verify_nonce($nonce, $action = -1)
    {
        // Simple mock implementation - verify the nonce matches
        $expected = wp_create_nonce($action);
        return $nonce === $expected ? 1 : false;
    }
}

// Set global WordPress version for testing
global $wp_version;
if (!isset($wp_version)) {
    $wp_version = '6.4.0';
}

