<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Workspace\Workspace;

/**
 * Property-Based Tests for Context Resolver
 * 
 * Feature: core-bootstrap-flow
 * Tests universal properties of context resolution
 */
class ContextResolverPropertyTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock WordPress functions if not already defined
        if (!function_exists('wp_get_theme')) {
            eval('
                function wp_get_theme() {
                    return new class {
                        public function get($key) {
                            return "";
                        }
                    };
                }
            ');
        }
        
        if (!function_exists('get_stylesheet_directory')) {
            eval('
                function get_stylesheet_directory() {
                    return "/tmp/nonexistent";
                }
            ');
        }
    }
    
    /**
     * Property 12: Context Resolution Determinism
     * 
     * For any valid domain, subdomain, or path, the Context Resolver SHALL
     * return a valid context string.
     * 
     * Validates: Requirements 7.1
     */
    public function testProperty12ContextResolutionDeterminismWithWorkspace(): void
    {
        // Feature: core-bootstrap-flow, Property 12: Context Resolution Determinism
        
        $iterations = 100;
        
        for ($i = 0; $i < $iterations; $i++) {
            // Generate random workspace with random context
            $workspaceContexts = ['default', 'ecommerce', 'blog', 'portfolio', 'saas', 'marketing', ''];
            $workspaceContext = $workspaceContexts[array_rand($workspaceContexts)];
            
            $workspace = new Workspace(
                'test-workspace-' . $i,
                'Test Workspace ' . $i,
                'example.com',
                [],
                [],
                $workspaceContext
            );
            
            // Create application and inject workspace
            $app = new Application(__DIR__);
            $app->instance(Workspace::class, $workspace);
            
            // Create registry and resolver
            $registry = new ModuleRegistry();
            $resolver = new ContextResolver($registry, $app);
            
            // Get current context
            $context = $resolver->getCurrentContext();
            
            // Assert context is always a non-empty string
            $this->assertIsString($context);
            $this->assertNotEmpty($context);
            
            // If workspace had a context, it should be used
            if (!empty($workspaceContext)) {
                $this->assertEquals($workspaceContext, $context);
            } else {
                // Otherwise, should fallback to default
                $this->assertEquals('default', $context);
            }
        }
    }
    
    /**
     * Property 12: Context Resolution Determinism - without workspace
     * 
     * For any resolver without workspace, it SHALL return 'default' context.
     */
    public function testProperty12ContextResolutionDeterminismWithoutWorkspace(): void
    {
        // Feature: core-bootstrap-flow, Property 12: Context Resolution Determinism
        
        $iterations = 100;
        
        for ($i = 0; $i < $iterations; $i++) {
            // Create application without workspace
            $app = new Application(__DIR__);
            
            // Create registry and resolver
            $registry = new ModuleRegistry();
            $resolver = new ContextResolver($registry, $app);
            
            // Get current context
            $context = $resolver->getCurrentContext();
            
            // Should always return 'default' when no workspace or theme metadata
            $this->assertEquals('default', $context);
        }
    }
    
    /**
     * Property 12: Context Resolution Determinism - caching
     * 
     * For any resolver, calling getCurrentContext() multiple times SHALL
     * return the same value (deterministic).
     */
    public function testProperty12ContextResolutionDeterminismCaching(): void
    {
        // Feature: core-bootstrap-flow, Property 12: Context Resolution Determinism
        
        $iterations = 100;
        
        for ($i = 0; $i < $iterations; $i++) {
            // Generate random workspace
            $contexts = ['default', 'ecommerce', 'blog', 'portfolio'];
            $workspaceContext = $contexts[array_rand($contexts)];
            
            $workspace = new Workspace(
                'test-workspace-' . $i,
                'Test Workspace ' . $i,
                'example.com',
                [],
                [],
                $workspaceContext
            );
            
            $app = new Application(__DIR__);
            $app->instance(Workspace::class, $workspace);
            
            $registry = new ModuleRegistry();
            $resolver = new ContextResolver($registry, $app);
            
            // Call getCurrentContext multiple times
            $context1 = $resolver->getCurrentContext();
            $context2 = $resolver->getCurrentContext();
            $context3 = $resolver->getCurrentContext();
            
            // All calls should return the same value
            $this->assertEquals($context1, $context2);
            $this->assertEquals($context2, $context3);
            $this->assertEquals($workspaceContext, $context1);
        }
    }
}
