<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\InvalidModule;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ResolutionResult;
use Viraloka\Core\Modules\Exceptions\DuplicateModuleException;

class ModuleRegistryTest extends TestCase
{
    private ModuleRegistry $registry;
    
    protected function setUp(): void
    {
        $this->registry = new ModuleRegistry();
    }
    
    public function testRegisterModule(): void
    {
        $manifest = $this->createManifest('test-module');
        $module = new Module($manifest, new ResolutionResult());
        
        $this->registry->register($module);
        
        $this->assertTrue($this->registry->has('test-module'));
        $this->assertSame($module, $this->registry->get('test-module'));
    }
    
    public function testGetNonExistentModule(): void
    {
        $this->assertNull($this->registry->get('non-existent'));
    }
    
    public function testHasReturnsFalseForNonExistentModule(): void
    {
        $this->assertFalse($this->registry->has('non-existent'));
    }
    
    public function testAllReturnsCollection(): void
    {
        $manifest1 = $this->createManifest('module-1');
        $manifest2 = $this->createManifest('module-2');
        
        $module1 = new Module($manifest1, new ResolutionResult());
        $module2 = new Module($manifest2, new ResolutionResult());
        
        $this->registry->register($module1);
        $this->registry->register($module2);
        
        $all = $this->registry->all();
        
        $this->assertCount(2, $all);
        $this->assertContains($module1, $all->all());
        $this->assertContains($module2, $all->all());
    }
    
    public function testRegisterDuplicateModuleThrowsException(): void
    {
        $manifest = $this->createManifest('duplicate-module');
        $module1 = new Module($manifest, new ResolutionResult());
        $module2 = new Module($manifest, new ResolutionResult());
        
        $this->registry->register($module1);
        
        $this->expectException(DuplicateModuleException::class);
        $this->expectExceptionMessage("Module with ID 'duplicate-module' is already registered");
        
        $this->registry->register($module2);
    }
    
    public function testRegisterInvalidModule(): void
    {
        $invalidModule = new InvalidModule('/path/to/module', 'Parse error', 'invalid-module');
        
        $this->registry->registerInvalid($invalidModule);
        
        $invalidModules = $this->registry->getInvalidModules();
        
        $this->assertCount(1, $invalidModules);
        $this->assertSame($invalidModule, $invalidModules->first());
    }
    
    public function testInvalidModulesAreSeparateFromValidModules(): void
    {
        $manifest = $this->createManifest('valid-module');
        $validModule = new Module($manifest, new ResolutionResult());
        $invalidModule = new InvalidModule('/path/to/invalid', 'Error', 'invalid-module');
        
        $this->registry->register($validModule);
        $this->registry->registerInvalid($invalidModule);
        
        $this->assertCount(1, $this->registry->all());
        $this->assertCount(1, $this->registry->getInvalidModules());
        
        $this->assertTrue($this->registry->has('valid-module'));
        $this->assertFalse($this->registry->has('invalid-module'));
    }
    
    public function testGetPublicModulesFiltersCorrectly(): void
    {
        $publicManifest = $this->createManifestWithVisibility('public-module', true, true);
        $privateManifest = $this->createManifestWithVisibility('private-module', false, true);
        
        $publicModule = new Module($publicManifest, new ResolutionResult());
        $privateModule = new Module($privateManifest, new ResolutionResult());
        
        $this->registry->register($publicModule);
        $this->registry->register($privateModule);
        
        $publicModules = $this->registry->getPublicModules();
        
        $this->assertCount(1, $publicModules);
        $this->assertTrue($publicModules->contains(function ($module) {
            return $module->getId() === 'public-module';
        }));
    }
    
    public function testGetPublicModulesReturnsEmptyWhenNoPublicModules(): void
    {
        $privateManifest = $this->createManifestWithVisibility('private-module', false, true);
        $privateModule = new Module($privateManifest, new ResolutionResult());
        
        $this->registry->register($privateModule);
        
        $publicModules = $this->registry->getPublicModules();
        
        $this->assertCount(0, $publicModules);
    }
    
    public function testGetByIdBypassesVisibilityFiltering(): void
    {
        // Test direct installation bypass (Requirement 9.4)
        $privateManifest = $this->createManifestWithVisibility('private-module', false, false);
        $privateModule = new Module($privateManifest, new ResolutionResult());
        
        $this->registry->register($privateModule);
        
        // Module should not appear in public listing
        $publicModules = $this->registry->getPublicModules();
        $this->assertCount(0, $publicModules);
        
        // But should be retrievable by ID (direct installation bypass)
        $retrieved = $this->registry->get('private-module');
        $this->assertNotNull($retrieved);
        $this->assertSame($privateModule, $retrieved);
    }
    
    private function createManifest(string $id): Manifest
    {
        $manifest = new Manifest();
        $manifest->id = $id;
        $manifest->name = 'Test Module';
        $manifest->description = 'Test Description';
        $manifest->version = '1.0.0';
        $manifest->author = 'Test Author';
        $manifest->namespace = 'Test\\Namespace';
        $manifest->capabilities = [];
        
        return $manifest;
    }
    
    private function createManifestWithVisibility(string $id, bool $public, bool $marketplace): Manifest
    {
        $manifest = $this->createManifest($id);
        $manifest->visibility = new \Viraloka\Core\Modules\VisibilityConfig([
            'public' => $public,
            'marketplace' => $marketplace
        ]);
        
        return $manifest;
    }
}
