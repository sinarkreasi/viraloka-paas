<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\PermissionBoundary;
use Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Workspace\WorkspaceUserRole;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Modules\Logger;

/**
 * Permission Boundary Tests
 * 
 * Tests workspace-level permission checks and role-based access control.
 * Validates cross-workspace access prevention and logging.
 */
class PermissionBoundaryTest extends TestCase
{
    private PermissionBoundary $permissionBoundary;
    private WorkspaceUserRoleRepositoryInterface $roleRepository;
    private WorkspaceRepositoryInterface $workspaceRepository;
    private Logger $logger;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create mock repositories
        $this->roleRepository = $this->createMock(WorkspaceUserRoleRepositoryInterface::class);
        $this->workspaceRepository = $this->createMock(WorkspaceRepositoryInterface::class);
        $this->logger = $this->createMock(Logger::class);
        
        // Create permission boundary
        $this->permissionBoundary = new PermissionBoundary(
            $this->roleRepository,
            $this->workspaceRepository,
            $this->logger
        );
    }
    
    public function testCanAccessReturnsTrueWhenUserHasAccess(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        
        // Mock workspace exists and is active
        $workspace = new Workspace(
            $workspaceId,
            'tenant-123',
            'Test Workspace',
            'test-workspace'
        );
        
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($workspaceId)
            ->willReturn($workspace);
        
        // Mock user has access
        $this->roleRepository
            ->expects($this->once())
            ->method('hasAccess')
            ->with($workspaceId, $userId)
            ->willReturn(true);
        
        $result = $this->permissionBoundary->canAccess($userId, $workspaceId);
        
        $this->assertTrue($result);
    }
    
    public function testCanAccessReturnsFalseWhenWorkspaceNotFound(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        
        // Mock workspace not found
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($workspaceId)
            ->willReturn(null);
        
        $result = $this->permissionBoundary->canAccess($userId, $workspaceId);
        
        $this->assertFalse($result);
    }
    
    public function testCanAccessReturnsFalseWhenWorkspaceNotActive(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        
        // Mock workspace exists but is suspended
        $workspace = new Workspace(
            $workspaceId,
            'tenant-123',
            'Test Workspace',
            'test-workspace',
            Workspace::STATUS_SUSPENDED
        );
        
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($workspaceId)
            ->willReturn($workspace);
        
        $result = $this->permissionBoundary->canAccess($userId, $workspaceId);
        
        $this->assertFalse($result);
    }
    
    public function testCanAccessLogsCrossWorkspaceAttempt(): void
    {
        $userId = 1;
        $currentWorkspaceId = 'workspace-123';
        $targetWorkspaceId = 'workspace-456';
        
        // Set current workspace
        $this->permissionBoundary->setCurrentWorkspace($currentWorkspaceId);
        
        // Mock workspace exists and is active
        $workspace = new Workspace(
            $targetWorkspaceId,
            'tenant-456',
            'Target Workspace',
            'target-workspace'
        );
        
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($targetWorkspaceId)
            ->willReturn($workspace);
        
        // Mock user does not have access
        $this->roleRepository
            ->expects($this->once())
            ->method('hasAccess')
            ->with($targetWorkspaceId, $userId)
            ->willReturn(false);
        
        // Expect warning to be logged
        $this->logger
            ->expects($this->once())
            ->method('warning')
            ->with($this->stringContains('Cross-workspace access attempt'));
        
        $result = $this->permissionBoundary->canAccess($userId, $targetWorkspaceId);
        
        $this->assertFalse($result);
    }
    
    public function testHasRoleReturnsTrueWhenUserHasRole(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        $role = WorkspaceUserRole::ROLE_ADMIN;
        
        $this->roleRepository
            ->expects($this->once())
            ->method('hasRole')
            ->with($workspaceId, $userId, $role)
            ->willReturn(true);
        
        $result = $this->permissionBoundary->hasRole($userId, $workspaceId, $role);
        
        $this->assertTrue($result);
    }
    
    public function testHasRoleReturnsFalseForInvalidRole(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        $invalidRole = 'invalid-role';
        
        $this->logger
            ->expects($this->once())
            ->method('warning')
            ->with($this->stringContains('Invalid role check'));
        
        $result = $this->permissionBoundary->hasRole($userId, $workspaceId, $invalidRole);
        
        $this->assertFalse($result);
    }
    
    public function testCanPerformReturnsTrueWhenUserCanPerformAction(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        $action = 'edit';
        
        // Mock workspace exists and is active
        $workspace = new Workspace(
            $workspaceId,
            'tenant-123',
            'Test Workspace',
            'test-workspace'
        );
        
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($workspaceId)
            ->willReturn($workspace);
        
        // Mock user has access
        $this->roleRepository
            ->expects($this->once())
            ->method('hasAccess')
            ->with($workspaceId, $userId)
            ->willReturn(true);
        
        // Mock user role
        $roleAssignment = new WorkspaceUserRole($workspaceId, $userId, WorkspaceUserRole::ROLE_MEMBER);
        $this->roleRepository
            ->expects($this->once())
            ->method('getUserRole')
            ->with($workspaceId, $userId)
            ->willReturn($roleAssignment);
        
        $result = $this->permissionBoundary->canPerform($userId, $workspaceId, $action);
        
        $this->assertTrue($result);
    }
    
    public function testCanPerformReturnsFalseWhenUserLacksPermission(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        $action = 'configure';
        
        // Mock workspace exists and is active
        $workspace = new Workspace(
            $workspaceId,
            'tenant-123',
            'Test Workspace',
            'test-workspace'
        );
        
        $this->workspaceRepository
            ->expects($this->once())
            ->method('findById')
            ->with($workspaceId)
            ->willReturn($workspace);
        
        // Mock user has access
        $this->roleRepository
            ->expects($this->once())
            ->method('hasAccess')
            ->with($workspaceId, $userId)
            ->willReturn(true);
        
        // Mock user role (viewer cannot configure)
        $roleAssignment = new WorkspaceUserRole($workspaceId, $userId, WorkspaceUserRole::ROLE_VIEWER);
        $this->roleRepository
            ->expects($this->once())
            ->method('getUserRole')
            ->with($workspaceId, $userId)
            ->willReturn($roleAssignment);
        
        // Expect warning to be logged
        $this->logger
            ->expects($this->once())
            ->method('warning')
            ->with($this->stringContains('Permission denied'));
        
        $result = $this->permissionBoundary->canPerform($userId, $workspaceId, $action);
        
        $this->assertFalse($result);
    }
    
    public function testGetUserRoleReturnsRoleWhenUserHasRole(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        $expectedRole = WorkspaceUserRole::ROLE_ADMIN;
        
        $roleAssignment = new WorkspaceUserRole($workspaceId, $userId, $expectedRole);
        
        $this->roleRepository
            ->expects($this->once())
            ->method('getUserRole')
            ->with($workspaceId, $userId)
            ->willReturn($roleAssignment);
        
        $result = $this->permissionBoundary->getUserRole($userId, $workspaceId);
        
        $this->assertEquals($expectedRole, $result);
    }
    
    public function testGetUserRoleReturnsNullWhenUserHasNoRole(): void
    {
        $userId = 1;
        $workspaceId = 'workspace-123';
        
        $this->roleRepository
            ->expects($this->once())
            ->method('getUserRole')
            ->with($workspaceId, $userId)
            ->willReturn(null);
        
        $result = $this->permissionBoundary->getUserRole($userId, $workspaceId);
        
        $this->assertNull($result);
    }
    
    public function testValidateWorkspaceContextReturnsTrueWhenNoCurrentWorkspace(): void
    {
        $workspaceId = 'workspace-123';
        
        $result = $this->permissionBoundary->validateWorkspaceContext($workspaceId);
        
        $this->assertTrue($result);
    }
    
    public function testValidateWorkspaceContextReturnsTrueWhenWorkspaceMatches(): void
    {
        $workspaceId = 'workspace-123';
        
        $this->permissionBoundary->setCurrentWorkspace($workspaceId);
        
        $result = $this->permissionBoundary->validateWorkspaceContext($workspaceId);
        
        $this->assertTrue($result);
    }
    
    public function testValidateWorkspaceContextReturnsFalseAndLogsWhenWorkspaceMismatch(): void
    {
        $currentWorkspaceId = 'workspace-123';
        $targetWorkspaceId = 'workspace-456';
        
        $this->permissionBoundary->setCurrentWorkspace($currentWorkspaceId);
        
        // Expect warning to be logged
        $this->logger
            ->expects($this->once())
            ->method('warning')
            ->with($this->stringContains('Cross-workspace context violation'));
        
        $result = $this->permissionBoundary->validateWorkspaceContext($targetWorkspaceId);
        
        $this->assertFalse($result);
    }
    
    public function testSetAndGetCurrentWorkspace(): void
    {
        $workspaceId = 'workspace-123';
        
        $this->permissionBoundary->setCurrentWorkspace($workspaceId);
        
        $result = $this->permissionBoundary->getCurrentWorkspace();
        
        $this->assertEquals($workspaceId, $result);
    }
}
