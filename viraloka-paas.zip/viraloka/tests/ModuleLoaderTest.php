<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\ModuleLoader;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\DependencyResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\InvalidModule;

/**
 * Module Loader Test
 * 
 * Tests the ModuleLoader class functionality including:
 * - Directory scanning with recursive subdirectory support
 * - Manifest parsing integration
 * - Dependency resolution
 * - Context matching
 * - Invalid module handling
 */
class ModuleLoaderTest extends TestCase
{
    protected string $testModulesPath;
    protected ModuleLoader $loader;
    protected ModuleRegistry $registry;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create temporary test modules directory
        $this->testModulesPath = sys_get_temp_dir() . '/viraloka-test-modules-' . uniqid();
        mkdir($this->testModulesPath, 0777, true);
        
        // Set up dependencies
        $validator = new SchemaValidator();
        $parser = new ManifestParser($validator);
        $this->registry = new ModuleRegistry();
        $dependencyResolver = new DependencyResolver($this->registry);
        $contextResolver = new ContextResolver($this->registry);
        
        // Create loader
        $this->loader = new ModuleLoader(
            $parser,
            $dependencyResolver,
            $this->registry,
            $contextResolver,
            $this->testModulesPath
        );
    }
    
    protected function tearDown(): void
    {
        // Clean up test directory
        $this->removeDirectory($this->testModulesPath);
        parent::tearDown();
    }
    
    /**
     * Test that loader scans directories and finds module.json files
     */
    public function testScanModuleDirectories(): void
    {
        // Create test module structure
        $modulePath = $this->testModulesPath . '/test-module';
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert module was loaded
        $this->assertCount(1, $modules);
        $this->assertEquals('test.module', $modules->first()->getId());
    }
    
    /**
     * Test recursive subdirectory scanning
     */
    public function testRecursiveDirectoryScanning(): void
    {
        // Create nested module structure
        $nestedPath = $this->testModulesPath . '/category/subcategory/nested-module';
        mkdir($nestedPath, 0777, true);
        
        $manifest = [
            'id' => 'nested.module',
            'name' => 'Nested Module',
            'description' => 'A nested test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\NestedModule'
        ];
        
        file_put_contents($nestedPath . '/module.json', json_encode($manifest));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert nested module was found
        $this->assertCount(1, $modules);
        $this->assertEquals('nested.module', $modules->first()->getId());
    }
    
    /**
     * Test handling of missing manifest files
     */
    public function testMissingManifestHandling(): void
    {
        // Create directory without module.json
        $modulePath = $this->testModulesPath . '/no-manifest-module';
        mkdir($modulePath, 0777, true);
        file_put_contents($modulePath . '/readme.txt', 'This module has no manifest');
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert no modules were loaded
        $this->assertCount(0, $modules);
        
        // Assert no invalid modules were registered (directory should be ignored)
        $invalidModules = $this->loader->getInvalidModules();
        $this->assertCount(0, $invalidModules);
    }
    
    /**
     * Test handling of invalid JSON in manifest
     */
    public function testInvalidJsonHandling(): void
    {
        // Create module with invalid JSON
        $modulePath = $this->testModulesPath . '/invalid-json-module';
        mkdir($modulePath, 0777, true);
        file_put_contents($modulePath . '/module.json', '{invalid json}');
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert no valid modules were loaded
        $this->assertCount(0, $modules);
        
        // Assert invalid module was registered
        $invalidModules = $this->loader->getInvalidModules();
        $this->assertCount(1, $invalidModules);
        $this->assertStringContainsString('Invalid JSON', $invalidModules->first()->error);
    }
    
    /**
     * Test handling of missing required fields
     */
    public function testMissingRequiredFieldsHandling(): void
    {
        // Create module with missing required fields
        $modulePath = $this->testModulesPath . '/incomplete-module';
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => 'incomplete.module',
            'name' => 'Incomplete Module'
            // Missing: description, version, author, namespace
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert no valid modules were loaded
        $this->assertCount(0, $modules);
        
        // Assert invalid module was registered
        $invalidModules = $this->loader->getInvalidModules();
        $this->assertCount(1, $invalidModules);
        $this->assertEquals('incomplete.module', $invalidModules->first()->moduleId);
    }
    
    /**
     * Test handling of incompatible core version
     */
    public function testIncompatibleCoreVersionHandling(): void
    {
        // Create module with incompatible core version
        $modulePath = $this->testModulesPath . '/incompatible-module';
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => 'incompatible.module',
            'name' => 'Incompatible Module',
            'description' => 'Module with incompatible core version',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\IncompatibleModule',
            'dependencies' => [
                'core' => '>=99.0.0' // Impossible version requirement
            ]
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert no valid modules were loaded
        $this->assertCount(0, $modules);
        
        // Assert invalid module was registered
        $invalidModules = $this->loader->getInvalidModules();
        $this->assertCount(1, $invalidModules);
        $this->assertStringContainsString('Incompatible core version', $invalidModules->first()->error);
    }
    
    /**
     * Test loading module with optional dependencies
     */
    public function testOptionalDependenciesHandling(): void
    {
        // Create module with optional dependencies
        $modulePath = $this->testModulesPath . '/dependent-module';
        mkdir($modulePath, 0777, true);
        
        $manifest = [
            'id' => 'dependent.module',
            'name' => 'Dependent Module',
            'description' => 'Module with optional dependencies',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\DependentModule',
            'dependencies' => [
                'modules' => [
                    ['id' => 'nonexistent.module', 'optional' => true]
                ]
            ]
        ];
        
        file_put_contents($modulePath . '/module.json', json_encode($manifest));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert module was loaded despite missing optional dependency
        $this->assertCount(1, $modules);
        $this->assertEquals('dependent.module', $modules->first()->getId());
    }
    
    /**
     * Test loading specific module by ID
     */
    public function testLoadModuleById(): void
    {
        // Create two modules
        $module1Path = $this->testModulesPath . '/module1';
        mkdir($module1Path, 0777, true);
        file_put_contents($module1Path . '/module.json', json_encode([
            'id' => 'module.one',
            'name' => 'Module One',
            'description' => 'First module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\ModuleOne'
        ]));
        
        $module2Path = $this->testModulesPath . '/module2';
        mkdir($module2Path, 0777, true);
        file_put_contents($module2Path . '/module.json', json_encode([
            'id' => 'module.two',
            'name' => 'Module Two',
            'description' => 'Second module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\ModuleTwo'
        ]));
        
        // Load specific module
        $module = $this->loader->loadModule('module.two');
        
        // Assert correct module was loaded
        $this->assertNotNull($module);
        $this->assertEquals('module.two', $module->getId());
        
        // Assert only one module is in registry
        $this->assertCount(1, $this->registry->all());
    }
    
    /**
     * Test loading multiple valid modules
     */
    public function testLoadMultipleModules(): void
    {
        // Create three modules
        for ($i = 1; $i <= 3; $i++) {
            $modulePath = $this->testModulesPath . "/module{$i}";
            mkdir($modulePath, 0777, true);
            file_put_contents($modulePath . '/module.json', json_encode([
                'id' => "test.module{$i}",
                'name' => "Test Module {$i}",
                'description' => "Test module number {$i}",
                'version' => '1.0.0',
                'author' => 'Test Author',
                'namespace' => "Viraloka\\Modules\\TestModule{$i}"
            ]));
        }
        
        // Load all modules
        $modules = $this->loader->loadModules();
        
        // Assert all modules were loaded
        $this->assertCount(3, $modules);
    }
    
    /**
     * Test duplicate module ID handling
     */
    public function testDuplicateModuleIdHandling(): void
    {
        // Create two modules with same ID
        $module1Path = $this->testModulesPath . '/module1';
        mkdir($module1Path, 0777, true);
        file_put_contents($module1Path . '/module.json', json_encode([
            'id' => 'duplicate.module',
            'name' => 'First Module',
            'description' => 'First module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\FirstModule'
        ]));
        
        $module2Path = $this->testModulesPath . '/module2';
        mkdir($module2Path, 0777, true);
        file_put_contents($module2Path . '/module.json', json_encode([
            'id' => 'duplicate.module',
            'name' => 'Second Module',
            'description' => 'Second module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\SecondModule'
        ]));
        
        // Load modules
        $modules = $this->loader->loadModules();
        
        // Assert only one module was loaded
        $this->assertCount(1, $modules);
        
        // Assert one invalid module was registered
        $invalidModules = $this->loader->getInvalidModules();
        $this->assertCount(1, $invalidModules);
        $this->assertStringContainsString('Duplicate module ID', $invalidModules->first()->error);
    }
    
    /**
     * Helper method to recursively remove directory
     */
    protected function removeDirectory(string $path): void
    {
        if (!file_exists($path)) {
            return;
        }
        
        if (is_dir($path)) {
            $files = array_diff(scandir($path), ['.', '..']);
            foreach ($files as $file) {
                $this->removeDirectory($path . '/' . $file);
            }
            rmdir($path);
        } else {
            unlink($path);
        }
    }
}
