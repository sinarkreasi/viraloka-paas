<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\PerformanceGuard;

/**
 * PerformanceGuard Unit Test
 * 
 * Unit tests for the PerformanceGuard class.
 * Tests specific examples, edge cases, and integration points.
 * 
 * Requirements: 5.1, 5.5
 */
class PerformanceGuardTest extends TestCase
{
    protected Application $app;
    protected string $basePath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create temporary directory for test
        $this->basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
        mkdir($this->basePath, 0777, true);
        
        // Create application instance
        $this->app = new Application($this->basePath);
    }
    
    protected function tearDown(): void
    {
        // Clean up temporary directory
        if (is_dir($this->basePath)) {
            rmdir($this->basePath);
        }
        
        parent::tearDown();
    }
    
    /**
     * Test cache adapter detection - object cache
     * 
     * Validates: Requirements 5.1
     */
    public function testDetectCacheAdapterObjectCache(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Detect cache adapter
        $adapter = $guard->detectCacheAdapter();
        
        // Verify adapter is one of the expected types
        $this->assertContains($adapter, ['object_cache', 'transients', 'file_cache', 'none'],
            'Detected cache adapter should be one of the supported types');
    }
    
    /**
     * Test cache adapter detection returns transients when available
     * 
     * Validates: Requirements 5.1
     */
    public function testDetectCacheAdapterTransients(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // In WordPress environment, transients should be available
        $adapter = $guard->detectCacheAdapter();
        
        // Verify we get a valid adapter
        $this->assertNotEmpty($adapter, 'Cache adapter should not be empty');
        $this->assertIsString($adapter, 'Cache adapter should be a string');
    }
    
    /**
     * Test cache strategy configuration
     * 
     * Validates: Requirements 5.5
     */
    public function testConfigureCacheStrategy(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Configure cache strategy for manifests
        $guard->configureCacheStrategy('manifests', true, 7200);
        
        // Get cache strategy
        $strategy = $guard->getCacheStrategy();
        
        // Verify configuration was applied
        $this->assertArrayHasKey('manifests', $strategy,
            'Cache strategy should have manifests configuration');
        $this->assertTrue($strategy['manifests']['enabled'],
            'Manifests caching should be enabled');
        $this->assertEquals(7200, $strategy['manifests']['ttl'],
            'Manifests TTL should be 7200 seconds');
    }
    
    /**
     * Test cache strategy configuration for config
     * 
     * Validates: Requirements 5.5
     */
    public function testConfigureCacheStrategyForConfig(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Configure cache strategy for config
        $guard->configureCacheStrategy('config', false, 1800);
        
        // Get cache strategy
        $strategy = $guard->getCacheStrategy();
        
        // Verify configuration was applied
        $this->assertArrayHasKey('config', $strategy,
            'Cache strategy should have config configuration');
        $this->assertFalse($strategy['config']['enabled'],
            'Config caching should be disabled');
        $this->assertEquals(1800, $strategy['config']['ttl'],
            'Config TTL should be 1800 seconds');
    }
    
    /**
     * Test activation during boot phase
     * 
     * Validates: Requirements 5.5
     */
    public function testActivationDuringBootPhase(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Verify guard is not active initially
        $this->assertFalse($guard->isActive(),
            'Guard should not be active before activation');
        
        // Activate the guard
        $guard->activate();
        
        // Verify guard is now active
        $this->assertTrue($guard->isActive(),
            'Guard should be active after activation');
        
        // Verify cache adapter was detected
        $adapter = $guard->getCacheAdapter();
        $this->assertNotEmpty($adapter,
            'Cache adapter should be detected during activation');
    }
    
    /**
     * Test activation sets cache adapter
     * 
     * Validates: Requirements 5.1, 5.5
     */
    public function testActivationSetsCacheAdapter(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Activate the guard
        $guard->activate();
        
        // Verify cache adapter is set
        $adapter = $guard->getCacheAdapter();
        $this->assertNotEquals('', $adapter,
            'Cache adapter should be set after activation');
        $this->assertContains($adapter, ['object_cache', 'transients', 'file_cache', 'none'],
            'Cache adapter should be one of the supported types');
    }
    
    /**
     * Test default cache strategy configuration
     * 
     * Validates: Requirements 5.5
     */
    public function testDefaultCacheStrategyConfiguration(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Get default cache strategy
        $strategy = $guard->getCacheStrategy();
        
        // Verify default configuration for manifests
        $this->assertArrayHasKey('manifests', $strategy,
            'Default cache strategy should include manifests');
        $this->assertTrue($strategy['manifests']['enabled'],
            'Manifests caching should be enabled by default');
        $this->assertEquals(3600, $strategy['manifests']['ttl'],
            'Default manifests TTL should be 3600 seconds');
        
        // Verify default configuration for config
        $this->assertArrayHasKey('config', $strategy,
            'Default cache strategy should include config');
        $this->assertTrue($strategy['config']['enabled'],
            'Config caching should be enabled by default');
        $this->assertEquals(3600, $strategy['config']['ttl'],
            'Default config TTL should be 3600 seconds');
    }
    
    /**
     * Test guard prevents operations only when active
     * 
     * Validates: Requirements 5.5
     */
    public function testGuardPreventsOperationsOnlyWhenActive(): void
    {
        $guard = new PerformanceGuard($this->app);
        
        // Before activation, heavy operations should not throw exceptions
        $exceptionThrown = false;
        try {
            $guard->preventHeavyOperation('render_ui');
        } catch (\RuntimeException $e) {
            $exceptionThrown = true;
        }
        
        $this->assertFalse($exceptionThrown,
            'Heavy operations should not be blocked before activation');
        
        // After activation, heavy operations should throw exceptions
        $guard->activate();
        
        $exceptionThrown = false;
        try {
            $guard->preventHeavyOperation('render_ui');
        } catch (\RuntimeException $e) {
            $exceptionThrown = true;
        }
        
        $this->assertTrue($exceptionThrown,
            'Heavy operations should be blocked after activation');
    }
    
    /**
     * Test deferred hooks are stored correctly
     * 
     * Validates: Requirements 5.5
     */
    public function testDeferredHooksAreStoredCorrectly(): void
    {
        $guard = new PerformanceGuard($this->app);
        $guard->activate();
        
        // Defer multiple hooks
        $callback1 = function() { return 'callback1'; };
        $callback2 = function() { return 'callback2'; };
        
        $guard->deferHook('hook1', $callback1, 10);
        $guard->deferHook('hook2', $callback2, 20);
        
        // Get deferred hooks
        $deferredHooks = $guard->getDeferredHooks();
        
        // Verify hooks are stored
        $this->assertArrayHasKey('hook1', $deferredHooks,
            'hook1 should be in deferred hooks');
        $this->assertArrayHasKey('hook2', $deferredHooks,
            'hook2 should be in deferred hooks');
        
        // Verify callback and priority are stored correctly
        $this->assertSame($callback1, $deferredHooks['hook1'][0]['callback'],
            'hook1 callback should match');
        $this->assertEquals(10, $deferredHooks['hook1'][0]['priority'],
            'hook1 priority should be 10');
        
        $this->assertSame($callback2, $deferredHooks['hook2'][0]['callback'],
            'hook2 callback should match');
        $this->assertEquals(20, $deferredHooks['hook2'][0]['priority'],
            'hook2 priority should be 20');
    }
    
    /**
     * Test multiple callbacks can be deferred for same hook
     * 
     * Validates: Requirements 5.5
     */
    public function testMultipleCallbacksCanBeDeferredForSameHook(): void
    {
        $guard = new PerformanceGuard($this->app);
        $guard->activate();
        
        // Defer multiple callbacks for same hook
        $callback1 = function() { return 'callback1'; };
        $callback2 = function() { return 'callback2'; };
        
        $guard->deferHook('same_hook', $callback1, 10);
        $guard->deferHook('same_hook', $callback2, 20);
        
        // Get deferred hooks
        $deferredHooks = $guard->getDeferredHooks();
        
        // Verify both callbacks are stored
        $this->assertCount(2, $deferredHooks['same_hook'],
            'same_hook should have 2 deferred callbacks');
    }
}
