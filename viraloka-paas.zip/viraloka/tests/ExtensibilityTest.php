<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Container\Container;
use Viraloka\Core\Events\EventDispatcher;

/**
 * Test extensibility features: binding overrides and events
 */
class ExtensibilityTest extends TestCase
{
    /**
     * Test that bindings can be overridden
     */
    public function testBindingOverride(): void
    {
        $container = new Container();

        // Register initial binding
        $container->singleton('service', fn() => (object)['value' => 'original']);
        $instance1 = $container->get('service');
        $this->assertEquals('original', $instance1->value);

        // Override the binding
        $container->singleton('service', fn() => (object)['value' => 'overridden']);
        $instance2 = $container->get('service');
        $this->assertEquals('overridden', $instance2->value);

        // Verify it's a new instance (cache was cleared)
        $this->assertNotSame($instance1, $instance2);
    }

    /**
     * Test that factory bindings can be overridden
     */
    public function testFactoryBindingOverride(): void
    {
        $container = new Container();

        // Register initial factory binding
        $container->bind('service', fn() => (object)['value' => 'original']);
        $instance1 = $container->get('service');
        $this->assertEquals('original', $instance1->value);

        // Override the binding
        $container->bind('service', fn() => (object)['value' => 'overridden']);
        $instance2 = $container->get('service');
        $this->assertEquals('overridden', $instance2->value);
    }

    /**
     * Test that scoped bindings can be overridden
     */
    public function testScopedBindingOverride(): void
    {
        $container = new Container();

        // Register initial scoped binding
        $container->scoped('service', fn() => (object)['value' => 'original']);
        $instance1 = $container->get('service');
        $this->assertEquals('original', $instance1->value);

        // Override the binding
        $container->scoped('service', fn() => (object)['value' => 'overridden']);
        $instance2 = $container->get('service');
        $this->assertEquals('overridden', $instance2->value);

        // Verify it's a new instance (cache was cleared)
        $this->assertNotSame($instance1, $instance2);
    }

    /**
     * Test that binding events are emitted when registering
     */
    public function testBindingRegisteredEvent(): void
    {
        $eventDispatcher = new EventDispatcher();
        $container = new Container(null, null, $eventDispatcher);

        $eventFired = false;
        $eventData = null;

        // Listen for binding registered event
        $eventDispatcher->listen('container.binding.registered', function($data) use (&$eventFired, &$eventData) {
            $eventFired = true;
            $eventData = $data;
        });

        // Register a binding
        $container->singleton('test-service', fn() => new stdClass());

        // Verify event was fired
        $this->assertTrue($eventFired, 'Binding registered event should be fired');
        $this->assertIsArray($eventData);
        $this->assertEquals('test-service', $eventData['service_id']);
        $this->assertEquals('singleton', $eventData['binding_type']);
        $this->assertFalse($eventData['is_override']);
    }

    /**
     * Test that binding events are emitted when overriding
     */
    public function testBindingOverriddenEvent(): void
    {
        $eventDispatcher = new EventDispatcher();
        $container = new Container(null, null, $eventDispatcher);

        // Register initial binding
        $container->singleton('test-service', fn() => new stdClass());

        $eventFired = false;
        $eventData = null;

        // Listen for binding overridden event
        $eventDispatcher->listen('container.binding.overridden', function($data) use (&$eventFired, &$eventData) {
            $eventFired = true;
            $eventData = $data;
        });

        // Override the binding
        $container->singleton('test-service', fn() => (object)['overridden' => true]);

        // Verify event was fired
        $this->assertTrue($eventFired, 'Binding overridden event should be fired');
        $this->assertIsArray($eventData);
        $this->assertEquals('test-service', $eventData['service_id']);
        $this->assertEquals('singleton', $eventData['binding_type']);
        $this->assertTrue($eventData['is_override']);
    }

    /**
     * Test that context-scoped overrides don't affect global bindings
     */
    public function testContextScopedOverride(): void
    {
        $contextResolver = new class implements \Viraloka\Core\Container\Contracts\ContextResolverInterface {
            public string $currentContext = 'default';
            public function getCurrentContext(): string {
                return $this->currentContext;
            }
        };

        $container = new Container($contextResolver);

        // Register global binding
        $container->singleton('service', fn() => (object)['value' => 'global']);

        // Register context-specific override
        $container->bindForContext('special', 'service', fn() => (object)['value' => 'context-override'], [
            'type' => \Viraloka\Core\Container\BindingType::SINGLETON
        ]);

        // Verify global binding is used in default context
        $contextResolver->currentContext = 'default';
        $globalInstance = $container->get('service');
        $this->assertEquals('global', $globalInstance->value);

        // Verify context override is used in special context
        $contextResolver->currentContext = 'special';
        $contextInstance = $container->get('service');
        $this->assertEquals('context-override', $contextInstance->value);

        // Verify they are different instances
        $this->assertNotSame($globalInstance, $contextInstance);
    }

    /**
     * Test that workspace-scoped overrides don't affect global or context bindings
     */
    public function testWorkspaceScopedOverride(): void
    {
        $contextResolver = new class implements \Viraloka\Core\Container\Contracts\ContextResolverInterface {
            public string $currentContext = 'default';
            public function getCurrentContext(): string {
                return $this->currentContext;
            }
        };

        $workspaceResolver = new class implements \Viraloka\Core\Container\Contracts\WorkspaceResolverInterface {
            public ?string $currentWorkspace = null;
            public function getCurrentWorkspace(): ?string {
                return $this->currentWorkspace;
            }
        };

        $container = new Container($contextResolver, $workspaceResolver);

        // Register global binding
        $container->singleton('service', fn() => (object)['value' => 'global']);

        // Register workspace-specific override
        $container->bindForWorkspace('default', 'workspace-1', 'service', fn() => (object)['value' => 'workspace-override'], [
            'type' => \Viraloka\Core\Container\BindingType::SINGLETON
        ]);

        // Verify global binding is used without workspace
        $workspaceResolver->currentWorkspace = null;
        $globalInstance = $container->get('service');
        $this->assertEquals('global', $globalInstance->value);

        // Verify workspace override is used in workspace-1
        $workspaceResolver->currentWorkspace = 'workspace-1';
        $workspaceInstance = $container->get('service');
        $this->assertEquals('workspace-override', $workspaceInstance->value);

        // Verify they are different instances
        $this->assertNotSame($globalInstance, $workspaceInstance);
    }

    /**
     * Test that events include context information for context-scoped bindings
     */
    public function testContextBindingEventIncludesContext(): void
    {
        $eventDispatcher = new EventDispatcher();
        $container = new Container(null, null, $eventDispatcher);

        $eventData = null;

        // Listen for binding registered event
        $eventDispatcher->listen('container.binding.registered', function($data) use (&$eventData) {
            $eventData = $data;
        });

        // Register a context-specific binding
        $container->bindForContext('test-context', 'service', fn() => new stdClass());

        // Verify event includes context information
        $this->assertIsArray($eventData);
        $this->assertEquals('test-context', $eventData['context']);
        $this->assertNull($eventData['workspace']);
    }

    /**
     * Test that events include workspace information for workspace-scoped bindings
     */
    public function testWorkspaceBindingEventIncludesWorkspace(): void
    {
        $eventDispatcher = new EventDispatcher();
        $container = new Container(null, null, $eventDispatcher);

        $eventData = null;

        // Listen for binding registered event
        $eventDispatcher->listen('container.binding.registered', function($data) use (&$eventData) {
            $eventData = $data;
        });

        // Register a workspace-specific binding
        $container->bindForWorkspace('test-context', 'test-workspace', 'service', fn() => new stdClass());

        // Verify event includes workspace information
        $this->assertIsArray($eventData);
        $this->assertEquals('test-context', $eventData['context']);
        $this->assertEquals('test-workspace', $eventData['workspace']);
    }
}
