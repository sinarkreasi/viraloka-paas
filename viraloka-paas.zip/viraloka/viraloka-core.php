<?php
/**
 * Plugin Name: Viraloka - PaaS Engine
 * Plugin URI: https://viraloka.com/paas
 * Description: PaaS (Platform as a Service) foundation for your WaaS (WordPress as a Service).
 * Version: 1.0.0
 * Author: Viraloka
 * Author URI: https://viraloka.com
 * License: Proprietary
 * Text Domain: viraloka-core
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 8.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Validate PHP version requirement
 * 
 * @return bool True if PHP version meets requirements
 */
function viraloka_validate_php_version(): bool {
    return version_compare(PHP_VERSION, '8.0', '>=');
}

/**
 * Validate WordPress version requirement
 * 
 * @return bool True if WordPress version meets requirements
 */
function viraloka_validate_wordpress_version(): bool {
    global $wp_version;
    return version_compare($wp_version, '5.8', '>=');
}

/**
 * Display admin notice for validation failures
 * 
 * @param string $message The error message to display
 */
function viraloka_display_validation_error(string $message): void {
    add_action('admin_notices', function () use ($message) {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>Viraloka Core:</strong> ' . esc_html($message);
        echo '</p></div>';
    });
}

/**
 * Log validation error
 * 
 * @param string $message The error message to log
 */
function viraloka_log_validation_error(string $message): void {
    error_log('[Viraloka Core] Validation Error: ' . $message);
}

// Validate PHP version
if (!viraloka_validate_php_version()) {
    $message = 'PHP 8.0 or higher is required. Your server is running PHP ' . PHP_VERSION . '.';
    viraloka_log_validation_error($message);
    viraloka_display_validation_error($message);
    return;
}

// Validate WordPress version
if (!viraloka_validate_wordpress_version()) {
    global $wp_version;
    $message = 'WordPress 5.8 or higher is required. Your site is running WordPress ' . $wp_version . '.';
    viraloka_log_validation_error($message);
    viraloka_display_validation_error($message);
    return;
}

// Define plugin constants
define('VIRALOKA_CORE_VERSION', '1.0.0');
define('VIRALOKA_CORE_FILE', __FILE__);
define('VIRALOKA_CORE_PATH', plugin_dir_path(__FILE__));
define('VIRALOKA_CORE_URL', plugin_dir_url(__FILE__));
define('VIRALOKA_CORE_BASENAME', plugin_basename(__FILE__));

// Register Composer autoloader
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
} else {
    // Show admin notice if autoloader is missing
    $message = 'Composer autoloader not found. Please run composer install in the plugin directory.';
    viraloka_log_validation_error($message);
    add_action('admin_notices', function () use ($message) {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>Viraloka Core:</strong> ' . esc_html($message);
        echo '</p></div>';
    });
    return;
}

// Manually load Collection class if not already loaded (temporary fix until composer dump-autoload is run)
if (!class_exists('Illuminate\Support\Collection')) {
    require_once __DIR__ . '/src/Core/Support/Collection.php';
}

// Manually load CoreAdminPage if not already loaded
if (!class_exists('Viraloka\Core\Admin\CoreAdminPage')) {
    require_once __DIR__ . '/src/Core/Admin/CoreAdminPage.php';
}

// Manually load module service providers if not already loaded (temporary fix until composer dump-autoload is run)
if (!class_exists('Viraloka\Modules\Sample\SampleServiceProvider')) {
    $sampleProviderPath = __DIR__ . '/viraloka-modules/sample-module/src/SampleServiceProvider.php';
    if (file_exists($sampleProviderPath)) {
        require_once $sampleProviderPath;
    }
}

if (!class_exists('Viraloka\Modules\LinkInBio\LinkInBioServiceProvider')) {
    $linkInBioProviderPath = __DIR__ . '/viraloka-modules/linkinbio/src/LinkInBioServiceProvider.php';
    if (file_exists($linkInBioProviderPath)) {
        require_once $linkInBioProviderPath;
    }
}

if (!class_exists('Viraloka\\Modules\\Shortlink\\ShortlinkServiceProvider')) {
    $shortlinkProviderPath = __DIR__ . '/viraloka-modules/shortlink/src/ShortlinkServiceProvider.php';
    if (file_exists($shortlinkProviderPath)) {
        require_once $shortlinkProviderPath;
    }
}


// Initialize the application
add_action('plugins_loaded', function () {
    try {
        // Create the application instance
        $app = new Viraloka\Core\Application(VIRALOKA_CORE_PATH);
        
        // Store the application instance globally for access
        $GLOBALS['viraloka_app'] = $app;
        
        // Create and bootstrap the Kernel
        $kernel = new Viraloka\Core\Bootstrap\Kernel($app);
        $kernel->bootstrap();
        
        // Fire action hook for extensions
        do_action('viraloka_core_loaded', $app);
        
    } catch (\Exception $e) {
        // Log critical bootstrap errors
        $message = sprintf(
            'Critical bootstrap error: %s in %s:%d',
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        );
        viraloka_log_validation_error($message);
        
        // Show admin notice for critical errors
        add_action('admin_notices', function () use ($e) {
            if (current_user_can('manage_options')) {
                echo '<div class="notice notice-error"><p>';
                echo '<strong>Viraloka Core:</strong> Critical error during initialization. ';
                echo 'Check error logs for details.';
                echo '</p></div>';
            }
        });
    }
}, 10);

// Activation hook
register_activation_hook(__FILE__, function () {
    // Verify PHP version
    if (version_compare(PHP_VERSION, '8.0', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            '<p><strong>Viraloka Core</strong> requires PHP 8.0 or higher. ' .
            'Your server is running PHP ' . PHP_VERSION . '.</p>',
            'Plugin Activation Error',
            ['back_link' => true]
        );
    }
    
    // Verify WordPress version
    global $wp_version;
    if (version_compare($wp_version, '5.8', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            '<p><strong>Viraloka Core</strong> requires WordPress 5.8 or higher. ' .
            'Your site is running WordPress ' . $wp_version . '.</p>',
            'Plugin Activation Error',
            ['back_link' => true]
        );
    }
    
    // Create modules directory if it doesn't exist
    $modulesDir = VIRALOKA_CORE_PATH . 'viraloka-modules';
    if (!file_exists($modulesDir)) {
        wp_mkdir_p($modulesDir);
    }
    
    // Create database tables
    require_once __DIR__ . '/src/Core/Database/Schema.php';
    \Viraloka\Core\Database\Schema::createTables();
    
    // Flush rewrite rules
    flush_rewrite_rules();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function () {
    // Flush rewrite rules
    flush_rewrite_rules();
    
    // Clear any cached data
    delete_transient('viraloka_manifest_cache');
});

/**
 * Get the application instance
 * 
 * Helper function to access the application container from anywhere.
 * 
 * @return Viraloka\Core\Application|null
 */
function viraloka_app() {
    return $GLOBALS['viraloka_app'] ?? null;
}

/**
 * Get a service from the application container
 * 
 * @param string $abstract
 * @return mixed
 */
function viraloka_make(string $abstract) {
    $app = viraloka_app();
    return $app ? $app->make($abstract) : null;
}
