<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Adapter\Testing\InMemoryStorageAdapter;
use Viraloka\Adapter\Testing\MockEventAdapter;
use Viraloka\Adapter\Testing\NullRuntimeAdapter;

/**
 * Test suite for test adapters used in Core isolation testing.
 */
class TestAdaptersTest extends TestCase
{
    // ===== InMemoryStorageAdapter Tests =====

    public function testInMemoryStorageSetAndGet(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->set('test_key', 'test_value');
        
        $this->assertEquals('test_value', $storage->get('test_key'));
    }

    public function testInMemoryStorageGetWithDefault(): void
    {
        $storage = new InMemoryStorageAdapter();
        
        $this->assertEquals('default', $storage->get('non_existent', 'default'));
    }

    public function testInMemoryStorageHas(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->set('test_key', 'test_value');
        
        $this->assertTrue($storage->has('test_key'));
        $this->assertFalse($storage->has('non_existent'));
    }

    public function testInMemoryStorageDelete(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->set('test_key', 'test_value');
        $storage->delete('test_key');
        
        $this->assertFalse($storage->has('test_key'));
    }

    public function testInMemoryStorageSetManyAndGetMany(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->setMany(['key1' => 'value1', 'key2' => 'value2']);
        
        $values = $storage->getMany(['key1', 'key2']);
        
        $this->assertEquals('value1', $values['key1']);
        $this->assertEquals('value2', $values['key2']);
    }

    public function testInMemoryStorageClear(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->set('key1', 'value1');
        $storage->set('key2', 'value2');
        $storage->clear();
        
        $this->assertFalse($storage->has('key1'));
        $this->assertFalse($storage->has('key2'));
    }

    public function testInMemoryStorageTTL(): void
    {
        $storage = new InMemoryStorageAdapter();
        $storage->set('ttl_key', 'ttl_value', 3600);
        
        // Should still be available immediately
        $this->assertEquals('ttl_value', $storage->get('ttl_key'));
    }

    // ===== MockEventAdapter Tests =====

    public function testMockEventAdapterListenAndDispatch(): void
    {
        $events = new MockEventAdapter();
        $handlerCalled = false;
        
        $events->listen(TestEvent::class, function($event) use (&$handlerCalled) {
            $handlerCalled = true;
            $event->handled = true;
        });
        
        $event = new TestEvent();
        $events->dispatch($event);
        
        $this->assertTrue($handlerCalled);
        $this->assertTrue($event->handled);
    }

    public function testMockEventAdapterHasListeners(): void
    {
        $events = new MockEventAdapter();
        
        $this->assertFalse($events->hasListeners(TestEvent::class));
        
        $events->listen(TestEvent::class, function() {});
        
        $this->assertTrue($events->hasListeners(TestEvent::class));
    }

    public function testMockEventAdapterGetListeners(): void
    {
        $events = new MockEventAdapter();
        $handler = function() {};
        
        $events->listen(TestEvent::class, $handler);
        
        $listeners = $events->getListeners(TestEvent::class);
        
        $this->assertCount(1, $listeners);
        $this->assertSame($handler, $listeners[0]);
    }

    public function testMockEventAdapterPriorityOrdering(): void
    {
        $events = new MockEventAdapter();
        $order = [];
        
        $events->listen(TestEvent::class, function() use (&$order) {
            $order[] = 'second';
        }, 20);
        
        $events->listen(TestEvent::class, function() use (&$order) {
            $order[] = 'first';
        }, 10);
        
        $events->dispatch(new TestEvent());
        
        $this->assertEquals(['first', 'second'], $order);
    }

    public function testMockEventAdapterRemove(): void
    {
        $events = new MockEventAdapter();
        $handler = function() {};
        
        $events->listen(TestEvent::class, $handler);
        $events->remove(TestEvent::class, $handler);
        
        $this->assertFalse($events->hasListeners(TestEvent::class));
    }

    // ===== NullRuntimeAdapter Tests =====

    public function testNullRuntimeAdapterBoot(): void
    {
        $runtime = new NullRuntimeAdapter();
        $runtime->boot();
        
        $this->assertTrue($runtime->isBooted());
    }

    public function testNullRuntimeAdapterEnvironment(): void
    {
        $runtime = new NullRuntimeAdapter('testing');
        
        $this->assertEquals('testing', $runtime->environment());
        $this->assertTrue($runtime->isEnvironment('testing'));
        $this->assertFalse($runtime->isEnvironment('production'));
    }

    public function testNullRuntimeAdapterIsAdmin(): void
    {
        $runtime = new NullRuntimeAdapter('testing', true, false);
        
        $this->assertTrue($runtime->isAdmin());
    }

    public function testNullRuntimeAdapterIsCli(): void
    {
        $runtime = new NullRuntimeAdapter('testing', false, true);
        
        $this->assertTrue($runtime->isCli());
    }

    public function testNullRuntimeAdapterSetters(): void
    {
        $runtime = new NullRuntimeAdapter();
        
        $runtime->setEnvironment('production');
        $runtime->setIsAdmin(true);
        $runtime->setIsCli(true);
        
        $this->assertEquals('production', $runtime->environment());
        $this->assertTrue($runtime->isAdmin());
        $this->assertTrue($runtime->isCli());
    }

    public function testNullRuntimeAdapterShutdown(): void
    {
        $runtime = new NullRuntimeAdapter();
        $runtime->boot();
        $runtime->shutdown();
        
        $this->assertFalse($runtime->isBooted());
    }
}

/**
 * Simple test event class for testing MockEventAdapter.
 */
class TestEvent
{
    public bool $handled = false;
    private bool $propagationStopped = false;
    
    public function stopPropagation(): void
    {
        $this->propagationStopped = true;
    }
    
    public function isPropagationStopped(): bool
    {
        return $this->propagationStopped;
    }
}

