<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\SecurityGuard;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ResolutionResult;

/**
 * SecurityGuard Property Test
 * 
 * Property-based tests for the SecurityGuard class.
 * Each test runs multiple iterations with different inputs to verify
 * universal properties hold across all executions.
 * 
 * Feature: core-bootstrap-flow
 */
class SecurityGuardPropertyTest extends TestCase
{
    /**
     * Property 6: Nonce Validation Security
     * 
     * For any state-changing operation, the Security Guard SHALL reject
     * operations with invalid nonces and accept operations with valid nonces.
     * 
     * Validates: Requirements 4.2
     * Feature: core-bootstrap-flow, Property 6: Nonce Validation Security
     */
    public function testProperty6NonceValidationSecurity(): void
    {
        // Run property test 100 times with different nonce scenarios
        for ($i = 0; $i < 100; $i++) {
            // Create application and security guard
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $guard = new SecurityGuard($app);
            
            // Generate random action name
            $action = 'test_action_' . uniqid();
            
            // Test with valid nonce
            $validNonce = wp_create_nonce($action);
            $validResult = $guard->validateNonce($action, $validNonce);
            
            $this->assertTrue($validResult, 
                "Iteration {$i}: Valid nonce should be accepted for action: {$action}");
            
            // Test with invalid nonces (various invalid formats)
            $invalidNonces = [
                'invalid_nonce_' . uniqid(),
                '',
                '0',
                'wrong_nonce',
                str_repeat('x', 20),
                wp_create_nonce('different_action_' . uniqid()), // Valid nonce but wrong action
            ];
            
            foreach ($invalidNonces as $idx => $invalidNonce) {
                $invalidResult = $guard->validateNonce($action, $invalidNonce);
                
                $this->assertFalse($invalidResult, 
                    "Iteration {$i}, Invalid nonce {$idx}: Invalid nonce should be rejected for action: {$action}");
            }
            
            // Clean up
            rmdir($basePath);
        }
    }
    
    /**
     * Property 7: Module Sandboxing Enforcement
     * 
     * For any module attempting to access Core internals, the Security Guard
     * SHALL prevent unauthorized access.
     * 
     * Validates: Requirements 4.3
     * Feature: core-bootstrap-flow, Property 7: Module Sandboxing Enforcement
     */
    public function testProperty7ModuleSandboxingEnforcement(): void
    {
        // Run property test 100 times with different module access scenarios
        for ($i = 0; $i < 100; $i++) {
            // Create application and security guard
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $guard = new SecurityGuard($app);
            
            // Create a mock module
            $moduleId = 'test_module_' . uniqid();
            $mockModule = $this->createMockModule($moduleId);
            
            // Sandbox the module
            $guard->sandboxModule($mockModule);
            
            // Verify module is sandboxed
            $this->assertTrue($guard->isModuleSandboxed($moduleId),
                "Iteration {$i}: Module {$moduleId} should be marked as sandboxed");
            
            // Test access to protected Core classes (should be denied)
            $protectedClasses = [
                'Viraloka\\Core\\Bootstrap\\Kernel',
                'Viraloka\\Core\\Bootstrap\\SecurityGuard',
                'Viraloka\\Core\\Application',
            ];
            
            foreach ($protectedClasses as $className) {
                $accessAllowed = $guard->checkModuleAccess($moduleId, $className);
                
                $this->assertFalse($accessAllowed,
                    "Iteration {$i}: Module {$moduleId} should NOT be allowed to access protected class: {$className}");
            }
            
            // Test access to allowed classes (should be allowed)
            $allowedClasses = [
                'Viraloka\\Core\\Modules\\Module',
                'Viraloka\\Core\\Modules\\ModuleRegistry',
                'Viraloka\\Core\\Context\\ContextResolver',
                'SomeCustomClass',
            ];
            
            foreach ($allowedClasses as $className) {
                $accessAllowed = $guard->checkModuleAccess($moduleId, $className);
                
                $this->assertTrue($accessAllowed,
                    "Iteration {$i}: Module {$moduleId} should be allowed to access non-protected class: {$className}");
            }
            
            // Clean up
            rmdir($basePath);
        }
    }
    
    /**
     * Create a mock module for testing
     * 
     * @param string $moduleId
     * @return Module
     */
    private function createMockModule(string $moduleId): Module
    {
        // Create a minimal manifest
        $manifestData = [
            'id' => $moduleId,
            'name' => 'Test Module',
            'version' => '1.0.0',
            'description' => 'Test module for security testing',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'entryPoint' => 'src/TestServiceProvider.php',
            'capabilities' => [],
            'dependencies' => [
                'modules' => [],
                'plugins' => [],
            ],
        ];
        
        $path = sys_get_temp_dir() . '/test-module-' . uniqid();
        $manifest = new Manifest($manifestData, $path);
        $dependencies = new ResolutionResult(true, [], [], [], []);
        
        return new Module($manifest, $dependencies);
    }
}
