<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\DistributionManager;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\VisibilityConfig;
use Viraloka\Core\Modules\ResolutionResult;

class DistributionManagerTest extends TestCase
{
    private ModuleRegistry $registry;
    private DistributionManager $manager;
    
    protected function setUp(): void
    {
        $this->registry = new ModuleRegistry();
        $this->manager = new DistributionManager($this->registry);
    }
    
    /**
     * Test that getMarketplaceModules returns only modules with marketplace visibility
     */
    public function testGetMarketplaceModulesFiltersCorrectly(): void
    {
        // Create modules with different marketplace visibility settings
        $publicModule = $this->createModuleWithVisibility('public-module', true, true);
        $privateModule = $this->createModuleWithVisibility('private-module', true, false);
        $hiddenModule = $this->createModuleWithVisibility('hidden-module', false, false);
        
        $this->registry->register($publicModule);
        $this->registry->register($privateModule);
        $this->registry->register($hiddenModule);
        
        // Get marketplace modules
        $marketplaceModules = $this->manager->getMarketplaceModules();
        
        // Only the public module should be in marketplace
        $this->assertCount(1, $marketplaceModules);
        $this->assertTrue($marketplaceModules->contains(function ($module) {
            return $module->getId() === 'public-module';
        }));
    }

    
    /**
     * Test that getMarketplaceModules returns empty collection when no modules have marketplace visibility
     */
    public function testGetMarketplaceModulesReturnsEmptyWhenNoMarketplaceModules(): void
    {
        $privateModule = $this->createModuleWithVisibility('private-module', true, false);
        $this->registry->register($privateModule);
        
        $marketplaceModules = $this->manager->getMarketplaceModules();
        
        $this->assertCount(0, $marketplaceModules);
    }
    
    /**
     * Test that getMarketplaceModules returns all modules when all have marketplace visibility
     */
    public function testGetMarketplaceModulesReturnsAllWhenAllHaveMarketplaceVisibility(): void
    {
        $module1 = $this->createModuleWithVisibility('module-1', true, true);
        $module2 = $this->createModuleWithVisibility('module-2', true, true);
        $module3 = $this->createModuleWithVisibility('module-3', false, true);
        
        $this->registry->register($module1);
        $this->registry->register($module2);
        $this->registry->register($module3);
        
        $marketplaceModules = $this->manager->getMarketplaceModules();
        
        $this->assertCount(3, $marketplaceModules);
    }

    
    /**
     * Helper method to create a module with specific visibility settings
     */
    private function createModuleWithVisibility(string $id, bool $public, bool $marketplace): Module
    {
        $manifest = new Manifest();
        $manifest->id = $id;
        $manifest->name = "Test Module {$id}";
        $manifest->description = "Test description";
        $manifest->version = "1.0.0";
        $manifest->author = "Test Author";
        $manifest->namespace = "Viraloka\\Modules\\Test";
        $manifest->capabilities = [];
        $manifest->visibility = new VisibilityConfig([
            'public' => $public,
            'marketplace' => $marketplace
        ]);
        
        $dependencies = new ResolutionResult();
        $dependencies->coreVersionSatisfied = true;
        $dependencies->availableModules = [];
        $dependencies->missingModules = [];
        $dependencies->availablePlugins = [];
        $dependencies->missingPlugins = [];
        
        return new Module($manifest, $dependencies);
    }
}
