<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;

/**
 * Lazy Loading Integration Test
 * 
 * Integration tests to verify lazy loading works correctly in real scenarios
 */
class LazyLoadingIntegrationTest extends TestCase
{
    /**
     * Test that lazy services are not instantiated during registration
     */
    public function testLazyServicesNotInstantiatedDuringRegistration(): void
    {
        $app = new Application(__DIR__);
        
        $instantiationCount = 0;
        
        // Register multiple lazy services
        $app->lazy('HeavyService1', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new \stdClass();
        });
        
        $app->lazy('HeavyService2', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new \stdClass();
        });
        
        $app->lazy('HeavyService3', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new \stdClass();
        });
        
        // No services should be instantiated yet
        $this->assertEquals(0, $instantiationCount);
    }
    
    /**
     * Test that lazy services are instantiated on first use
     */
    public function testLazyServicesInstantiatedOnFirstUse(): void
    {
        $app = new Application(__DIR__);
        
        $instantiationCount = 0;
        
        $app->lazy('LazyService', function() use (&$instantiationCount) {
            $instantiationCount++;
            return new \stdClass();
        });
        
        // Not instantiated yet
        $this->assertEquals(0, $instantiationCount);
        
        // First make() instantiates
        $service = $app->make('LazyService');
        $this->assertEquals(1, $instantiationCount);
        $this->assertInstanceOf(\stdClass::class, $service);
        
        // Second make() returns cached instance
        $service2 = $app->make('LazyService');
        $this->assertEquals(1, $instantiationCount);
        $this->assertSame($service, $service2);
    }
    
    /**
     * Test that regular singletons still work as expected
     */
    public function testRegularSingletonsStillWork(): void
    {
        $app = new Application(__DIR__);
        
        $app->singleton('RegularService', function() {
            return new \stdClass();
        });
        
        $service1 = $app->make('RegularService');
        $service2 = $app->make('RegularService');
        
        $this->assertSame($service1, $service2);
    }
    
    /**
     * Test that factory bindings still work as expected
     */
    public function testFactoryBindingsStillWork(): void
    {
        $app = new Application(__DIR__);
        
        $app->bind('FactoryService', function() {
            return new \stdClass();
        });
        
        $service1 = $app->make('FactoryService');
        $service2 = $app->make('FactoryService');
        
        $this->assertNotSame($service1, $service2);
    }
    
    /**
     * Test that lazy service failures throw descriptive exceptions
     */
    public function testLazyServiceFailuresThrowDescriptiveExceptions(): void
    {
        $app = new Application(__DIR__);
        
        $app->lazy('FailingService', function() {
            throw new \RuntimeException('Service failed to initialize');
        });
        
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Failed to instantiate lazy service [FailingService]');
        $this->expectExceptionMessage('Service failed to initialize');
        
        $app->make('FailingService');
    }
}
