<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\EnhancedWorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Modules\Logger;

/**
 * Unit Tests for Enhanced Workspace Resolver
 * 
 * Tests domain resolution with priority-based routing.
 * Requirements: 4.1, 4.2, 4.3, 4.4, 5.1, 5.2, 5.5, 5.7, 8.4
 */
class EnhancedWorkspaceResolverTest extends TestCase
{
    private WorkspaceRepositoryInterface $repository;
    private Logger $logger;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create mock repository
        $this->repository = $this->createMock(WorkspaceRepositoryInterface::class);
        $this->logger = $this->createMock(Logger::class);
    }
    
    protected function tearDown(): void
    {
        // Clean up server variables after each test
        unset($_SERVER['HTTP_HOST']);
        unset($_SERVER['REQUEST_URI']);
        unset($_SERVER['SERVER_NAME']);
        
        parent::tearDown();
    }
    
    /**
     * Test resolution by custom domain (Priority 1)
     * Requirements: 4.1, 5.1
     */
    public function testResolveByCustomDomain(): void
    {
        $_SERVER['HTTP_HOST'] = 'app.client.com';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Client Workspace',
            slug: 'client',
            activeContext: 'client-context'
        );
        $workspace->setCustomDomain('app.client.com');
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('app.client.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($workspace, $result);
        $this->assertSame('domain', $resolver->getResolutionMethod());
        $this->assertFalse($resolver->usedFallback());
    }
    
    /**
     * Test resolution by subdomain (Priority 2)
     * Requirements: 4.2, 5.1
     */
    public function testResolveBySubdomain(): void
    {
        $_SERVER['HTTP_HOST'] = 'workspace.viraloka.app';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Workspace',
            slug: 'workspace',
            activeContext: 'workspace-context'
        );
        $workspace->setSubdomain('workspace');
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('workspace.viraloka.app')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySubdomain')
            ->with('workspace')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($workspace, $result);
        $this->assertSame('subdomain', $resolver->getResolutionMethod());
        $this->assertFalse($resolver->usedFallback());
    }
    
    /**
     * Test resolution by path (Priority 3)
     * Requirements: 4.3, 5.1
     */
    public function testResolveByPath(): void
    {
        $_SERVER['HTTP_HOST'] = 'viraloka.app';
        $_SERVER['REQUEST_URI'] = '/workspace-slug/dashboard';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Workspace',
            slug: 'workspace-slug',
            activeContext: 'workspace-context'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('viraloka.app')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySubdomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->with('workspace-slug')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($workspace, $result);
        $this->assertSame('path', $resolver->getResolutionMethod());
        $this->assertFalse($resolver->usedFallback());
    }
    
    /**
     * Test fallback to default workspace (Priority 4)
     * Requirements: 5.5, 9.1
     */
    public function testFallbackToDefaultWorkspace(): void
    {
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $defaultWorkspace = new Workspace(
            workspaceId: 'default-ws',
            tenantId: 'default-tenant',
            name: 'Default Workspace',
            slug: 'default',
            activeContext: 'default'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySubdomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('getDefault')
            ->willReturn($defaultWorkspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($defaultWorkspace, $result);
        $this->assertSame('default', $resolver->getResolutionMethod());
        $this->assertTrue($resolver->usedFallback());
    }
    
    /**
     * Test system default creation when no default exists
     * Requirements: 9.4, 9.5
     */
    public function testSystemDefaultCreation(): void
    {
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySubdomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('getDefault')
            ->willReturn(null);
        
        $this->logger
            ->expects($this->once())
            ->method('warning')
            ->with('No default workspace found, creating system default');
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertInstanceOf(Workspace::class, $result);
        $this->assertSame('system-default', $result->workspaceId);
        $this->assertSame('system', $result->tenantId);
        $this->assertSame('Default Workspace', $result->name);
        $this->assertSame('default', $result->slug);
        $this->assertTrue($resolver->usedFallback());
    }
    
    /**
     * Test resolution priority order
     * Requirements: 4.4, 5.1, 5.2
     */
    public function testResolutionPriorityOrder(): void
    {
        $_SERVER['HTTP_HOST'] = 'workspace.viraloka.app';
        $_SERVER['REQUEST_URI'] = '/workspace-slug/page';
        
        $domainWorkspace = new Workspace(
            workspaceId: 'ws-domain',
            tenantId: 'tenant-1',
            name: 'Domain Workspace',
            slug: 'domain',
            activeContext: 'domain-context'
        );
        
        // Domain match should take priority
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('workspace.viraloka.app')
            ->willReturn($domainWorkspace);
        
        // Subdomain and path should not be called
        $this->repository
            ->expects($this->never())
            ->method('findBySubdomain');
        
        $this->repository
            ->expects($this->never())
            ->method('findBySlug');
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($domainWorkspace, $result);
        $this->assertSame('domain', $resolver->getResolutionMethod());
    }
    
    /**
     * Test workspace caching
     * Requirements: 5.7
     */
    public function testWorkspaceCaching(): void
    {
        $_SERVER['HTTP_HOST'] = 'app.client.com';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Client Workspace',
            slug: 'client',
            activeContext: 'client-context'
        );
        
        // Repository should only be called once
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('app.client.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        
        // First call
        $result1 = $resolver->resolve();
        
        // Second call should return cached workspace
        $result2 = $resolver->resolve();
        
        $this->assertSame($workspace, $result1);
        $this->assertSame($workspace, $result2);
        $this->assertSame($result1, $result2);
    }
    
    /**
     * Test getCurrentWorkspace method
     * Requirements: 8.4
     */
    public function testGetCurrentWorkspace(): void
    {
        $_SERVER['HTTP_HOST'] = 'app.client.com';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Client Workspace',
            slug: 'client',
            activeContext: 'client-context'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('app.client.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $workspaceId = $resolver->getCurrentWorkspace();
        
        $this->assertSame('ws-123', $workspaceId);
    }
    
    /**
     * Test subdomain extraction with insufficient parts
     */
    public function testSubdomainExtractionWithInsufficientParts(): void
    {
        $_SERVER['HTTP_HOST'] = 'viraloka.app';
        
        $defaultWorkspace = new Workspace(
            workspaceId: 'default-ws',
            tenantId: 'default-tenant',
            name: 'Default Workspace',
            slug: 'default',
            activeContext: 'default'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->willReturn(null);
        
        // Subdomain should not be called because domain has < 3 parts
        $this->repository
            ->expects($this->never())
            ->method('findBySubdomain');
        
        $this->repository
            ->expects($this->once())
            ->method('findBySlug')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->once())
            ->method('getDefault')
            ->willReturn($defaultWorkspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($defaultWorkspace, $result);
    }
    
    /**
     * Test path resolution with empty path
     */
    public function testPathResolutionWithEmptyPath(): void
    {
        $_SERVER['HTTP_HOST'] = 'viraloka.app';
        $_SERVER['REQUEST_URI'] = '/';
        
        $defaultWorkspace = new Workspace(
            workspaceId: 'default-ws',
            tenantId: 'default-tenant',
            name: 'Default Workspace',
            slug: 'default',
            activeContext: 'default'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->willReturn(null);
        
        $this->repository
            ->expects($this->never())
            ->method('findBySubdomain');
        
        // Slug should not be called because path is empty
        $this->repository
            ->expects($this->never())
            ->method('findBySlug');
        
        $this->repository
            ->expects($this->once())
            ->method('getDefault')
            ->willReturn($defaultWorkspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($defaultWorkspace, $result);
    }
    
    /**
     * Test resolution with SERVER_NAME fallback
     */
    public function testResolutionWithServerNameFallback(): void
    {
        // HTTP_HOST not set, should use SERVER_NAME
        $_SERVER['SERVER_NAME'] = 'app.client.com';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Client Workspace',
            slug: 'client',
            activeContext: 'client-context'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('app.client.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($workspace, $result);
    }
    
    /**
     * Test case-insensitive domain matching
     */
    public function testCaseInsensitiveDomainMatching(): void
    {
        $_SERVER['HTTP_HOST'] = 'APP.CLIENT.COM';
        
        $workspace = new Workspace(
            workspaceId: 'ws-123',
            tenantId: 'tenant-456',
            name: 'Client Workspace',
            slug: 'client',
            activeContext: 'client-context'
        );
        
        $this->repository
            ->expects($this->once())
            ->method('findByDomain')
            ->with('app.client.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($this->repository, $this->logger);
        $result = $resolver->resolve();
        
        $this->assertSame($workspace, $result);
    }
}
