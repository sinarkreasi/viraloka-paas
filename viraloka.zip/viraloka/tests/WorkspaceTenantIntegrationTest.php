<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Workspace\EnhancedWorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Workspace\Tenant;
use Viraloka\Core\Workspace\Repositories\TenantRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceUserRoleRepository;
use Viraloka\Core\Workspace\PermissionBoundary;
use Viraloka\Core\Workspace\WorkspaceUserRole;
use Viraloka\Core\Workspace\Providers\WorkspaceTenantServiceProvider;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Workspace\Database\WorkspaceTenantSchema;

/**
 * Workspace & Tenant System Integration Tests
 * 
 * Tests the complete integration of the workspace-tenant system including:
 * - Request → Domain Resolver → Workspace → Context flow
 * - Container injection and service provider registration
 * - Permission boundaries and access control
 * - Database schema and migrations
 * 
 * Validates: Requirements 5.1, 5.2, 5.3, 5.4, 8.1, 8.2, 8.3, 8.5
 */
class WorkspaceTenantIntegrationTest extends TestCase
{
    private Application $app;
    private string $basePath;
    private TenantRepository $tenantRepo;
    private WorkspaceRepository $workspaceRepo;
    private WorkspaceUserRoleRepository $roleRepo;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->basePath = dirname(__DIR__);
        $this->app = new Application($this->basePath);
        
        // Initialize repositories
        $this->tenantRepo = new TenantRepository();
        $this->workspaceRepo = new WorkspaceRepository();
        $this->roleRepo = new WorkspaceUserRoleRepository();
        
        // Clean up test data
        $this->cleanupTestData();
        
        // Ensure schema exists
        $this->ensureSchema();
    }
    
    protected function tearDown(): void
    {
        $this->cleanupTestData();
        unset($_SERVER['HTTP_HOST']);
        unset($_SERVER['REQUEST_URI']);
        unset($_SERVER['SERVER_NAME']);
        parent::tearDown();
    }
    
    private function cleanupTestData(): void
    {
        global $wpdb;
        
        if (!$wpdb) {
            return;
        }
        
        // Delete test data (in reverse dependency order)
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_workspace_user_roles WHERE workspace_id LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_workspaces WHERE workspace_id LIKE 'test-%' OR slug LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_tenants WHERE tenant_id LIKE 'test-%' OR name LIKE 'Test %'");
    }
    
    private function ensureSchema(): void
    {
        $schema = new WorkspaceTenantSchema();
        if (!$schema->tablesExist()) {
            $schema->migrate();
        }
    }
    
    /**
     * Test full resolution flow: Request → Workspace → Context
     * 
     * Validates: Requirements 5.1, 5.2, 5.3, 5.4
     */
    public function testFullResolutionFlow(): void
    {
        // Create test tenant and workspace
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create(
            $tenant->tenantId,
            'Test Workspace',
            'test-workspace',
            'test-context'
        );
        $workspace->setCustomDomain('test.example.com');
        $this->workspaceRepo->update($workspace);
        
        // Simulate incoming request
        $_SERVER['HTTP_HOST'] = 'test.example.com';
        
        // Create resolver
        $resolver = new EnhancedWorkspaceResolver($this->workspaceRepo);
        
        // Resolve workspace
        $resolvedWorkspace = $resolver->resolve();
        
        // Assert workspace was resolved correctly
        $this->assertInstanceOf(Workspace::class, $resolvedWorkspace);
        $this->assertEquals($workspace->workspaceId, $resolvedWorkspace->workspaceId);
        $this->assertEquals('test-context', $resolvedWorkspace->activeContext);
        $this->assertEquals('domain', $resolver->getResolutionMethod());
        $this->assertFalse($resolver->usedFallback());
    }
    
    /**
     * Test container injection after workspace resolution
     * 
     * Validates: Requirements 5.3, 5.4
     */
    public function testContainerInjection(): void
    {
        // Register service provider
        $provider = new WorkspaceTenantServiceProvider($this->app);
        $provider->register();
        
        // Verify all services are bound
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\Contracts\TenantRepositoryInterface::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\Contracts\DomainResolverInterface::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface::class));
        $this->assertTrue($this->app->bound(\Viraloka\Core\Container\Contracts\WorkspaceResolverInterface::class));
        
        // Verify singletons
        $resolver1 = $this->app->make(\Viraloka\Core\Workspace\Contracts\DomainResolverInterface::class);
        $resolver2 = $this->app->make(\Viraloka\Core\Workspace\Contracts\DomainResolverInterface::class);
        $this->assertSame($resolver1, $resolver2);
        
        $boundary1 = $this->app->make(\Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface::class);
        $boundary2 = $this->app->make(\Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface::class);
        $this->assertSame($boundary1, $boundary2);
    }

    
    /**
     * Test workspace context integration with Context Resolver
     * 
     * Validates: Requirements 8.1, 8.2, 8.3, 8.5
     */
    public function testWorkspaceContextIntegration(): void
    {
        // Create test tenant and workspace with custom context
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create(
            $tenant->tenantId,
            'Test Workspace',
            'test-workspace',
            'custom-context'
        );
        
        // Simulate request
        $_SERVER['HTTP_HOST'] = 'test.example.com';
        $workspace->setCustomDomain('test.example.com');
        $this->workspaceRepo->update($workspace);
        
        // Register service provider to inject workspace
        $provider = new WorkspaceTenantServiceProvider($this->app);
        $provider->register();
        $provider->boot();
        
        // Verify workspace was injected into container
        $this->assertTrue($this->app->bound(Workspace::class));
        $injectedWorkspace = $this->app->make(Workspace::class);
        $this->assertEquals($workspace->workspaceId, $injectedWorkspace->workspaceId);
        $this->assertEquals('custom-context', $injectedWorkspace->activeContext);
    }
    
    /**
     * Test permission boundary enforcement
     * 
     * Validates: Requirements 6.1, 6.2, 6.3, 6.4, 6.5
     */
    public function testPermissionBoundaryEnforcement(): void
    {
        // Create test data
        $tenant1 = $this->tenantRepo->create('Test Tenant 1', 1);
        $tenant2 = $this->tenantRepo->create('Test Tenant 2', 2);
        
        $workspace1 = $this->workspaceRepo->create($tenant1->tenantId, 'Workspace 1', 'test-workspace-1');
        $workspace2 = $this->workspaceRepo->create($tenant2->tenantId, 'Workspace 2', 'test-workspace-2');
        
        // Assign user 1 to workspace 1
        $this->roleRepo->assignRole($workspace1->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        // Create permission boundary
        $boundary = new PermissionBoundary($this->roleRepo);
        
        // Test access control
        $this->assertTrue($boundary->canAccess(1, $workspace1->workspaceId));
        $this->assertFalse($boundary->canAccess(1, $workspace2->workspaceId));
        
        // Test role checks
        $this->assertTrue($boundary->hasRole(1, $workspace1->workspaceId, WorkspaceUserRole::ROLE_ADMIN));
        $this->assertFalse($boundary->hasRole(1, $workspace1->workspaceId, WorkspaceUserRole::ROLE_OWNER));
        
        // Test permission checks
        $this->assertTrue($boundary->canPerform(1, $workspace1->workspaceId, 'edit'));
        $this->assertFalse($boundary->canPerform(1, $workspace2->workspaceId, 'edit'));
    }
    
    /**
     * Test cross-workspace access prevention
     * 
     * Validates: Requirements 6.4, 6.5
     */
    public function testCrossWorkspaceAccessPrevention(): void
    {
        // Create two separate tenants with workspaces
        $tenant1 = $this->tenantRepo->create('Test Tenant 1', 1);
        $tenant2 = $this->tenantRepo->create('Test Tenant 2', 2);
        
        $workspace1 = $this->workspaceRepo->create($tenant1->tenantId, 'Workspace 1', 'test-workspace-1');
        $workspace2 = $this->workspaceRepo->create($tenant2->tenantId, 'Workspace 2', 'test-workspace-2');
        
        // User 1 belongs to workspace 1
        $this->roleRepo->assignRole($workspace1->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        // User 2 belongs to workspace 2
        $this->roleRepo->assignRole($workspace2->workspaceId, 2, WorkspaceUserRole::ROLE_ADMIN);
        
        $boundary = new PermissionBoundary($this->roleRepo);
        
        // User 1 cannot access workspace 2
        $this->assertFalse($boundary->canAccess(1, $workspace2->workspaceId));
        
        // User 2 cannot access workspace 1
        $this->assertFalse($boundary->canAccess(2, $workspace1->workspaceId));
        
        // Verify workspace context validation
        $this->assertTrue($boundary->validateWorkspaceContext($workspace1->workspaceId));
        $this->assertTrue($boundary->validateWorkspaceContext($workspace2->workspaceId));
    }
    
    /**
     * Test fallback behavior when workspace resolution fails
     * 
     * Validates: Requirements 5.5, 9.1, 9.4, 9.5
     */
    public function testFallbackBehavior(): void
    {
        // Create default workspace
        $tenant = $this->tenantRepo->create('Default Tenant', 1);
        $defaultWorkspace = $this->workspaceRepo->create(
            $tenant->tenantId,
            'Default Workspace',
            'default',
            'default'
        );
        $defaultWorkspace->setIsDefault(true);
        $this->workspaceRepo->update($defaultWorkspace);
        
        // Simulate request with unknown domain
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $resolver = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolvedWorkspace = $resolver->resolve();
        
        // Should fallback to default workspace
        $this->assertInstanceOf(Workspace::class, $resolvedWorkspace);
        $this->assertEquals($defaultWorkspace->workspaceId, $resolvedWorkspace->workspaceId);
        $this->assertEquals('default', $resolver->getResolutionMethod());
        $this->assertTrue($resolver->usedFallback());
    }
    
    /**
     * Test system default creation when no default exists
     * 
     * Validates: Requirements 9.4, 9.5
     */
    public function testSystemDefaultCreation(): void
    {
        // Ensure no default workspace exists
        global $wpdb;
        $wpdb->query("UPDATE {$wpdb->prefix}viraloka_workspaces SET is_default = 0");
        
        // Simulate request with unknown domain
        $_SERVER['HTTP_HOST'] = 'unknown.example.com';
        
        $resolver = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolvedWorkspace = $resolver->resolve();
        
        // Should create system default
        $this->assertInstanceOf(Workspace::class, $resolvedWorkspace);
        $this->assertEquals('system-default', $resolvedWorkspace->workspaceId);
        $this->assertEquals('system', $resolvedWorkspace->tenantId);
        $this->assertEquals('Default Workspace', $resolvedWorkspace->name);
        $this->assertTrue($resolver->usedFallback());
    }
    
    /**
     * Test domain resolution priority order
     * 
     * Validates: Requirements 4.4, 5.1, 5.2
     */
    public function testDomainResolutionPriority(): void
    {
        // Create tenant and workspaces with different routing methods
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        
        $domainWorkspace = $this->workspaceRepo->create($tenant->tenantId, 'Domain WS', 'test-domain-ws');
        $domainWorkspace->setCustomDomain('workspace.example.com');
        $this->workspaceRepo->update($domainWorkspace);
        
        $subdomainWorkspace = $this->workspaceRepo->create($tenant->tenantId, 'Subdomain WS', 'test-subdomain-ws');
        $subdomainWorkspace->setSubdomain('workspace');
        $this->workspaceRepo->update($subdomainWorkspace);
        
        $pathWorkspace = $this->workspaceRepo->create($tenant->tenantId, 'Path WS', 'workspace');
        
        // Test 1: Custom domain takes priority
        $_SERVER['HTTP_HOST'] = 'workspace.example.com';
        $_SERVER['REQUEST_URI'] = '/workspace/page';
        
        $resolver = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolved = $resolver->resolve();
        
        $this->assertEquals($domainWorkspace->workspaceId, $resolved->workspaceId);
        $this->assertEquals('domain', $resolver->getResolutionMethod());
        
        // Test 2: Subdomain takes priority over path
        unset($_SERVER['HTTP_HOST']);
        $_SERVER['HTTP_HOST'] = 'workspace.viraloka.app';
        
        $resolver2 = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolved2 = $resolver2->resolve();
        
        $this->assertEquals($subdomainWorkspace->workspaceId, $resolved2->workspaceId);
        $this->assertEquals('subdomain', $resolver2->getResolutionMethod());
        
        // Test 3: Path resolution when no domain/subdomain match
        unset($_SERVER['HTTP_HOST']);
        $_SERVER['HTTP_HOST'] = 'viraloka.app';
        $_SERVER['REQUEST_URI'] = '/workspace/page';
        
        $resolver3 = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolved3 = $resolver3->resolve();
        
        $this->assertEquals($pathWorkspace->workspaceId, $resolved3->workspaceId);
        $this->assertEquals('path', $resolver3->getResolutionMethod());
    }
    
    /**
     * Test workspace resolution caching
     * 
     * Validates: Requirements 5.7
     */
    public function testWorkspaceResolutionCaching(): void
    {
        // Create test workspace
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test WS', 'test-ws');
        $workspace->setCustomDomain('test.example.com');
        $this->workspaceRepo->update($workspace);
        
        $_SERVER['HTTP_HOST'] = 'test.example.com';
        
        // Create mock repository to track calls
        $mockRepo = $this->createMock(WorkspaceRepository::class);
        $mockRepo->expects($this->once())
            ->method('findByDomain')
            ->with('test.example.com')
            ->willReturn($workspace);
        
        $resolver = new EnhancedWorkspaceResolver($mockRepo);
        
        // First call
        $resolved1 = $resolver->resolve();
        
        // Second call should use cache (repository not called again)
        $resolved2 = $resolver->resolve();
        
        $this->assertSame($resolved1, $resolved2);
    }
    
    /**
     * Test database schema creation and migration
     * 
     * Validates: Requirements 7.1, 7.2, 7.3, 7.7, 7.8
     */
    public function testDatabaseSchemaMigration(): void
    {
        global $wpdb;
        
        $schema = new WorkspaceTenantSchema();
        
        // Verify tables exist
        $this->assertTrue($schema->tablesExist());
        
        // Verify table structure
        $tables = [
            "{$wpdb->prefix}viraloka_tenants",
            "{$wpdb->prefix}viraloka_workspaces",
            "{$wpdb->prefix}viraloka_tenant_users",
            "{$wpdb->prefix}viraloka_workspace_user_roles",
            "{$wpdb->prefix}viraloka_domain_verifications"
        ];
        
        foreach ($tables as $table) {
            $result = $wpdb->get_var("SHOW TABLES LIKE '{$table}'");
            $this->assertEquals($table, $result, "Table {$table} should exist");
        }
    }
    
    /**
     * Test complete user journey: tenant creation → workspace creation → access
     * 
     * Validates: Requirements 1.1, 2.1, 3.5, 5.1, 6.1
     */
    public function testCompleteUserJourney(): void
    {
        // Step 1: Create tenant
        $tenant = $this->tenantRepo->create('My Company', 1);
        $this->assertNotEmpty($tenant->tenantId);
        $this->assertEquals('My Company', $tenant->name);
        $this->assertEquals(1, $tenant->ownerUserId);
        
        // Step 2: Create workspace
        $workspace = $this->workspaceRepo->create(
            $tenant->tenantId,
            'Production',
            'production',
            'production-context'
        );
        $this->assertNotEmpty($workspace->workspaceId);
        $this->assertEquals($tenant->tenantId, $workspace->tenantId);
        
        // Step 3: Configure domain
        $workspace->setCustomDomain('app.mycompany.com');
        $this->workspaceRepo->update($workspace);
        
        // Step 4: Assign user role
        $role = $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_OWNER);
        $this->assertEquals(WorkspaceUserRole::ROLE_OWNER, $role->role);
        
        // Step 5: Resolve workspace from request
        $_SERVER['HTTP_HOST'] = 'app.mycompany.com';
        $resolver = new EnhancedWorkspaceResolver($this->workspaceRepo);
        $resolvedWorkspace = $resolver->resolve();
        
        $this->assertEquals($workspace->workspaceId, $resolvedWorkspace->workspaceId);
        $this->assertEquals('production-context', $resolvedWorkspace->activeContext);
        
        // Step 6: Verify access permissions
        $boundary = new PermissionBoundary($this->roleRepo);
        $this->assertTrue($boundary->canAccess(1, $workspace->workspaceId));
        $this->assertTrue($boundary->hasRole(1, $workspace->workspaceId, WorkspaceUserRole::ROLE_OWNER));
    }
    
    /**
     * Test multi-tenant isolation
     * 
     * Validates: Requirements 3.7, 6.4, 6.5
     */
    public function testMultiTenantIsolation(): void
    {
        // Create two separate tenants
        $tenant1 = $this->tenantRepo->create('Company A', 1);
        $tenant2 = $this->tenantRepo->create('Company B', 2);
        
        // Create workspaces for each tenant
        $workspace1 = $this->workspaceRepo->create($tenant1->tenantId, 'WS A', 'test-ws-a');
        $workspace2 = $this->workspaceRepo->create($tenant2->tenantId, 'WS B', 'test-ws-b');
        
        // Assign users to their respective workspaces
        $this->roleRepo->assignRole($workspace1->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        $this->roleRepo->assignRole($workspace2->workspaceId, 2, WorkspaceUserRole::ROLE_ADMIN);
        
        $boundary = new PermissionBoundary($this->roleRepo);
        
        // Verify isolation: User 1 cannot access Workspace 2
        $this->assertTrue($boundary->canAccess(1, $workspace1->workspaceId));
        $this->assertFalse($boundary->canAccess(1, $workspace2->workspaceId));
        
        // Verify isolation: User 2 cannot access Workspace 1
        $this->assertTrue($boundary->canAccess(2, $workspace2->workspaceId));
        $this->assertFalse($boundary->canAccess(2, $workspace1->workspaceId));
        
        // Verify workspace listing returns only accessible workspaces
        $user1Workspaces = $this->roleRepo->getUserWorkspaces(1);
        $this->assertCount(1, $user1Workspaces);
        $this->assertEquals($workspace1->workspaceId, $user1Workspaces[0]->workspaceId);
        
        $user2Workspaces = $this->roleRepo->getUserWorkspaces(2);
        $this->assertCount(1, $user2Workspaces);
        $this->assertEquals($workspace2->workspaceId, $user2Workspaces[0]->workspaceId);
    }
}
