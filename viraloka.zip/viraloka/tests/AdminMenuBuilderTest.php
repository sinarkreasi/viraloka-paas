<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\AdminMenuBuilder;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\UIConfig;
use Viraloka\Core\Modules\ResolutionResult;

/**
 * Admin Menu Builder Tests
 * 
 * Tests for the AdminMenuBuilder class that creates WordPress admin menus
 * from module UI hints.
 */
class AdminMenuBuilderTest extends TestCase
{
    protected AdminMenuBuilder $builder;
    
    protected function setUp(): void
    {
        parent::setUp();
        $this->builder = new AdminMenuBuilder();
        
        // Mock WordPress functions
        if (!function_exists('add_menu_page')) {
            function add_menu_page($pageTitle, $menuTitle, $capability, $menuSlug, $callback, $icon, $position) {
                global $wp_menu_pages;
                $wp_menu_pages[] = [
                    'page_title' => $pageTitle,
                    'menu_title' => $menuTitle,
                    'capability' => $capability,
                    'menu_slug' => $menuSlug,
                    'callback' => $callback,
                    'icon' => $icon,
                    'position' => $position,
                ];
            }
        }
    }
    
    /**
     * Test that menu is created when admin_menu is true
     */
    public function testBuildMenuCreatesMenuWhenAdminMenuIsTrue(): void
    {
        global $wp_menu_pages;
        $wp_menu_pages = [];
        
        $manifest = $this->createManifestWithUI([
            'admin_menu' => true,
            'menu_title' => 'Test Module',
            'icon' => 'dashicons-admin-generic',
            'order' => 50,
        ]);
        
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->builder->buildMenu($module);
        
        $this->assertCount(1, $wp_menu_pages);
        $this->assertEquals('Test Module', $wp_menu_pages[0]['menu_title']);
        $this->assertEquals('dashicons-admin-generic', $wp_menu_pages[0]['icon']);
        $this->assertEquals(50, $wp_menu_pages[0]['position']);
    }
    
    /**
     * Test that menu is not created when admin_menu is false
     */
    public function testBuildMenuSkipsWhenAdminMenuIsFalse(): void
    {
        global $wp_menu_pages;
        $wp_menu_pages = [];
        
        $manifest = $this->createManifestWithUI([
            'admin_menu' => false,
            'menu_title' => 'Test Module',
        ]);
        
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->builder->buildMenu($module);
        
        $this->assertCount(0, $wp_menu_pages);
    }
    
    /**
     * Test that menu is not created when UI config is null
     */
    public function testBuildMenuSkipsWhenUIConfigIsNull(): void
    {
        global $wp_menu_pages;
        $wp_menu_pages = [];
        
        $manifest = $this->createManifestWithoutUI();
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->builder->buildMenu($module);
        
        $this->assertCount(0, $wp_menu_pages);
    }
    
    /**
     * Test that defaults are applied for incomplete UI hints
     */
    public function testBuildMenuAppliesDefaults(): void
    {
        global $wp_menu_pages;
        $wp_menu_pages = [];
        
        $manifest = $this->createManifestWithUI([
            'admin_menu' => true,
            // menu_title, icon, and order are missing
        ]);
        
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        
        $this->builder->buildMenu($module);
        
        $this->assertCount(1, $wp_menu_pages);
        // Should use module name as default menu title
        $this->assertEquals('Test Module Name', $wp_menu_pages[0]['menu_title']);
        // Should use default icon
        $this->assertEquals('dashicons-admin-generic', $wp_menu_pages[0]['icon']);
        // Should use default order
        $this->assertEquals(50, $wp_menu_pages[0]['position']);
    }
    
    /**
     * Test building menus for multiple modules
     */
    public function testBuildMenusForMultipleModules(): void
    {
        global $wp_menu_pages;
        $wp_menu_pages = [];
        
        $manifest1 = $this->createManifestWithUI([
            'admin_menu' => true,
            'menu_title' => 'Module 1',
        ], 'module-1');
        
        $manifest2 = $this->createManifestWithUI([
            'admin_menu' => true,
            'menu_title' => 'Module 2',
        ], 'module-2');
        
        $module1 = new Module($manifest1, new ResolutionResult(true, [], [], [], []));
        $module2 = new Module($manifest2, new ResolutionResult(true, [], [], [], []));
        
        $this->builder->buildMenus([$module1, $module2]);
        
        $this->assertCount(2, $wp_menu_pages);
        $this->assertEquals('Module 1', $wp_menu_pages[0]['menu_title']);
        $this->assertEquals('Module 2', $wp_menu_pages[1]['menu_title']);
    }
    
    /**
     * Helper to create a manifest with UI config
     */
    protected function createManifestWithUI(array $uiData, string $id = 'test-module'): Manifest
    {
        $data = [
            'id' => $id,
            'name' => 'Test Module Name',
            'description' => 'Test Description',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'ui' => $uiData,
        ];
        
        return new Manifest($data, '/path/to/module');
    }
    
    /**
     * Helper to create a manifest without UI config
     */
    protected function createManifestWithoutUI(): Manifest
    {
        $data = [
            'id' => 'test-module',
            'name' => 'Test Module Name',
            'description' => 'Test Description',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
        ];
        
        return new Manifest($data, '/path/to/module');
    }
}
