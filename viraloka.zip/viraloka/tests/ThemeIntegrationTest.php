<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Theme\ThemeIntegration;

/**
 * Unit Tests for Theme Integration
 * 
 * These tests verify specific examples and edge cases for theme integration.
 */
class ThemeIntegrationTest extends TestCase
{
    protected Application $app;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Reset WordPress actions global
        global $wp_actions;
        $wp_actions = [];
        
        $this->app = new Application(__DIR__);
    }
    
    /**
     * Test context registration
     * 
     * Validates: Requirements 10.1
     */
    public function testContextRegistrationUpdatesContextResolverWithValidContext(): void
    {
        $moduleRegistry = new ModuleRegistry($this->app);
        $contextResolver = new ContextResolver($moduleRegistry, $this->app);
        $this->app->instance(ContextResolver::class, $contextResolver);
        
        $themeIntegration = new ThemeIntegration($this->app);
        
        // Register a valid context
        $result = $themeIntegration->registerContext('ecommerce');
        
        $this->assertTrue($result);
        $this->assertEquals('ecommerce', $contextResolver->getCurrentContext());
    }
    
    public function testContextRegistrationRejectsInvalidContext(): void
    {
        $moduleRegistry = new ModuleRegistry($this->app);
        $contextResolver = new ContextResolver($moduleRegistry, $this->app);
        $this->app->instance(ContextResolver::class, $contextResolver);
        
        $themeIntegration = new ThemeIntegration($this->app);
        
        $originalContext = $contextResolver->getCurrentContext();
        
        // Attempt to register an invalid context
        $result = $themeIntegration->registerContext('invalid-context');
        
        $this->assertFalse($result);
        $this->assertEquals($originalContext, $contextResolver->getCurrentContext());
    }
    
    /**
     * Test UI hints registration
     * 
     * Validates: Requirements 10.3
     */
    public function testUIHintsRegistrationStoresValidHints(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        $hints = [
            'menu_title' => 'Custom Menu',
            'icon' => 'dashicons-admin-site',
            'order' => 25,
        ];
        
        $themeIntegration->registerUIHints($hints);
        
        $registered = $themeIntegration->getUIHints();
        
        $this->assertEquals($hints, $registered);
    }
    
    public function testUIHintsRegistrationFiltersInvalidHintKeys(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        $hints = [
            'menu_title' => 'Custom Menu',
            'invalid_key' => 'should be filtered',
            'icon' => 'dashicons-admin-site',
            'malicious' => 'data',
        ];
        
        $themeIntegration->registerUIHints($hints);
        
        $registered = $themeIntegration->getUIHints();
        
        $this->assertArrayHasKey('menu_title', $registered);
        $this->assertArrayHasKey('icon', $registered);
        $this->assertArrayNotHasKey('invalid_key', $registered);
        $this->assertArrayNotHasKey('malicious', $registered);
    }
    
    public function testModuleRecommendationsRegistrationStoresModuleIDs(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        $recommendations = ['module1', 'module2', 'module3'];
        
        $themeIntegration->registerModuleRecommendations($recommendations);
        
        $registered = $themeIntegration->getModuleRecommendations();
        
        $this->assertEquals($recommendations, $registered);
    }
    
    public function testModuleRecommendationsRegistrationFiltersNonStringValues(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        $recommendations = ['module1', 123, 'module2', null, 'module3', ['array']];
        
        $themeIntegration->registerModuleRecommendations($recommendations);
        
        $registered = $themeIntegration->getModuleRecommendations();
        
        // Only string values should be registered
        $this->assertEquals(['module1', 'module2', 'module3'], $registered);
    }
    
    /**
     * Test WordPress action hook registration
     * 
     * Validates: Requirements 10.1
     */
    public function testActivateRegistersWordPressActionHook(): void
    {
        global $wp_actions;
        
        $themeIntegration = new ThemeIntegration($this->app);
        
        $themeIntegration->activate();
        
        // Verify action was registered
        $this->assertArrayHasKey('viraloka_theme_integration', $wp_actions);
    }
    
    public function testServiceModificationPreventionBlocksProtectedServices(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        // Test protected services
        $this->assertFalse($themeIntegration->allowServiceModification('config'));
        $this->assertFalse($themeIntegration->allowServiceModification('logger'));
        $this->assertFalse($themeIntegration->allowServiceModification('events'));
        $this->assertFalse($themeIntegration->allowServiceModification(Application::class));
    }
    
    public function testServiceModificationPreventionAllowsNonProtectedServices(): void
    {
        $themeIntegration = new ThemeIntegration($this->app);
        
        // Test non-protected services
        $this->assertTrue($themeIntegration->allowServiceModification('custom.service'));
        $this->assertTrue($themeIntegration->allowServiceModification('theme.service'));
        $this->assertTrue($themeIntegration->allowServiceModification('my.binding'));
    }
}
