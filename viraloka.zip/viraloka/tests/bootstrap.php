<?php

/**
 * PHPUnit Bootstrap File
 * 
 * Loads Composer autoloader and WordPress function stubs for testing.
 */

// Load Composer autoloader
require_once __DIR__ . '/../vendor/autoload.php';

// Load WordPress function stubs
require_once __DIR__ . '/wordpress-stubs.php';

// Define ABSPATH for WordPress compatibility
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/../');
}

// Load entry point validation functions
// We need to extract just the functions from viraloka-core.php for testing
// Since we can't include the full file (it has side effects), we'll define them here

if (!function_exists('viraloka_validate_php_version')) {
    function viraloka_validate_php_version(): bool {
        return version_compare(PHP_VERSION, '8.0', '>=');
    }
}

if (!function_exists('viraloka_validate_wordpress_version')) {
    function viraloka_validate_wordpress_version(): bool {
        global $wp_version;
        return version_compare($wp_version, '5.8', '>=');
    }
}

if (!function_exists('viraloka_display_validation_error')) {
    function viraloka_display_validation_error(string $message): void {
        add_action('admin_notices', function () use ($message) {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Viraloka Core:</strong> ' . esc_html($message);
            echo '</p></div>';
        });
    }
}

if (!function_exists('viraloka_log_validation_error')) {
    function viraloka_log_validation_error(string $message): void {
        error_log('[Viraloka Core] Validation Error: ' . $message);
    }
}

