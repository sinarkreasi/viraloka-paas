<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Container\Container;
use Viraloka\Core\Container\Exceptions\ContainerException;
use Viraloka\Core\Container\Exceptions\ServiceNotFoundException;
use Psr\Log\AbstractLogger;

/**
 * Test logger for capturing log messages.
 */
class TestLogger extends AbstractLogger
{
    public array $logs = [];

    public function log($level, $message, array $context = []): void
    {
        $this->logs[] = [
            'level' => $level,
            'message' => $message,
            'context' => $context,
        ];
    }

    public function clear(): void
    {
        $this->logs = [];
    }
}

/**
 * Tests for error handling and silent mode functionality.
 */
class ErrorHandlingTest extends TestCase
{
    /**
     * Test that resolver exceptions are wrapped in ContainerException.
     */
    public function testResolverExceptionWrapping(): void
    {
        $container = new Container();
        
        // Register a service that throws an exception
        $container->bind('failing-service', function() {
            throw new \RuntimeException('Original error message');
        });

        try {
            $container->get('failing-service');
            $this->fail('Should have thrown ContainerException');
        } catch (ContainerException $e) {
            // Check that the exception message includes the service ID
            $this->assertStringContainsString('failing-service', $e->getMessage());
            
            // Check that the exception message includes the original error
            $this->assertStringContainsString('Original error message', $e->getMessage());
            
            // Check that the original exception is preserved
            $this->assertInstanceOf(\RuntimeException::class, $e->getPrevious());
            $this->assertEquals('Original error message', $e->getPrevious()->getMessage());
        }
    }

    /**
     * Test that ContainerException is not double-wrapped.
     */
    public function testContainerExceptionNotDoubleWrapped(): void
    {
        $container = new Container();
        
        // Register a service that throws a ContainerException
        $container->bind('service', function() {
            throw new ContainerException('Already a ContainerException');
        });

        try {
            $container->get('service');
            $this->fail('Should have thrown ContainerException');
        } catch (ContainerException $e) {
            // Should not be wrapped again
            $this->assertEquals('Already a ContainerException', $e->getMessage());
            $this->assertNull($e->getPrevious());
        }
    }

    /**
     * Test that silent mode returns null on failure.
     */
    public function testSilentModeReturnsNull(): void
    {
        $container = new Container();
        $logger = new TestLogger();
        $container->enableSilentMode($logger);

        // Register a failing service
        $container->bind('failing-service', function() {
            throw new \Exception('Test error');
        });

        $result = $container->get('failing-service');

        $this->assertNull($result);
    }

    /**
     * Test that silent mode logs errors.
     */
    public function testSilentModeLogsErrors(): void
    {
        $container = new Container();
        $logger = new TestLogger();
        $container->enableSilentMode($logger);

        // Register a failing service
        $container->bind('failing-service', function() {
            throw new \Exception('Test error');
        });

        $container->get('failing-service');

        // Check that an error was logged
        $this->assertCount(1, $logger->logs);
        $this->assertEquals('error', $logger->logs[0]['level']);
        
        // Check that the log message contains the service ID
        $this->assertStringContainsString('failing-service', $logger->logs[0]['message']);
        
        // Check that context includes service_id
        $this->assertArrayHasKey('service_id', $logger->logs[0]['context']);
        $this->assertEquals('failing-service', $logger->logs[0]['context']['service_id']);
    }

    /**
     * Test that silent mode handles ServiceNotFoundException.
     */
    public function testSilentModeHandlesServiceNotFound(): void
    {
        $container = new Container();
        $logger = new TestLogger();
        $container->enableSilentMode($logger);

        $result = $container->get('non-existent-service');

        $this->assertNull($result);
        $this->assertCount(1, $logger->logs);
        $this->assertStringContainsString('non-existent-service', $logger->logs[0]['message']);
    }

    /**
     * Test that normal mode (not silent) still throws exceptions.
     */
    public function testNormalModeThrowsExceptions(): void
    {
        $container = new Container();

        $this->expectException(ServiceNotFoundException::class);
        $container->get('non-existent-service');
    }

    /**
     * Test that silent mode handles circular dependencies gracefully.
     */
    public function testSilentModeHandlesCircularDependencies(): void
    {
        $container = new Container();
        $logger = new TestLogger();
        $container->enableSilentMode($logger);

        // Create circular dependency
        $container->bind('service-a', function($c) {
            return $c->get('service-b');
        });
        $container->bind('service-b', function($c) {
            return $c->get('service-a');
        });

        $result = $container->get('service-a');

        $this->assertNull($result);
        $this->assertCount(1, $logger->logs);
        $this->assertStringContainsString('service-a', $logger->logs[0]['message']);
    }

    /**
     * Test that exception wrapping includes proper context.
     */
    public function testExceptionWrappingIncludesContext(): void
    {
        $container = new Container();
        
        $container->bind('service', function() {
            throw new \InvalidArgumentException('Invalid argument provided');
        });

        try {
            $container->get('service');
            $this->fail('Should have thrown ContainerException');
        } catch (ContainerException $e) {
            // Check message format
            $this->assertMatchesRegularExpression(
                "/Failed to resolve 'service': Invalid argument provided/",
                $e->getMessage()
            );
        }
    }
}
