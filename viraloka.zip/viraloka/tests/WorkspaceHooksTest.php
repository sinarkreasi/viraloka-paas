<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\WorkspaceHooks;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Modules\Logger;

/**
 * WorkspaceHooksTest
 * 
 * Tests the WorkspaceHooks class for resource limit, feature limit,
 * and billing integration hook points.
 */
class WorkspaceHooksTest extends TestCase
{
    private WorkspaceHooks $hooks;
    private Workspace $workspace;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->hooks = new WorkspaceHooks();
        
        // Create a test workspace
        $this->workspace = new Workspace(
            workspaceId: 'test-workspace-id',
            tenantId: 'test-tenant-id',
            name: 'Test Workspace',
            slug: 'test-workspace',
            status: Workspace::STATUS_ACTIVE,
            activeContext: 'default'
        );
    }
    
    protected function tearDown(): void
    {
        $this->hooks->clearHandlers();
        parent::tearDown();
    }
    
    /**
     * Test that hooks can be registered
     */
    public function testHooksCanBeRegistered(): void
    {
        $this->assertFalse($this->hooks->isRegistered());
        
        $this->hooks->register();
        
        $this->assertTrue($this->hooks->isRegistered());
    }
    
    /**
     * Test that registering hooks multiple times is idempotent
     */
    public function testRegisterIsIdempotent(): void
    {
        $this->hooks->register();
        $this->hooks->register();
        $this->hooks->register();
        
        $this->assertTrue($this->hooks->isRegistered());
    }
    
    /**
     * Test usage limit check with no handlers (default: allow unlimited)
     */
    public function testUsageLimitCheckWithNoHandlers(): void
    {
        $this->hooks->register();
        
        $isExceeded = $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 1000);
        
        $this->assertFalse($isExceeded, 'Should allow unlimited usage when no handlers registered');
    }
    
    /**
     * Test usage limit check with handler that allows usage
     */
    public function testUsageLimitCheckWithAllowingHandler(): void
    {
        $this->hooks->register();
        
        $this->hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
            // Allow up to 1000 API calls
            return $currentUsage > 1000;
        });
        
        $isExceeded = $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 500);
        
        $this->assertFalse($isExceeded, 'Should allow usage below limit');
    }
    
    /**
     * Test usage limit check with handler that denies usage
     */
    public function testUsageLimitCheckWithDenyingHandler(): void
    {
        $this->hooks->register();
        
        $this->hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
            // Allow up to 1000 API calls
            return $currentUsage > 1000;
        });
        
        $isExceeded = $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 1500);
        
        $this->assertTrue($isExceeded, 'Should deny usage above limit');
    }
    
    /**
     * Test usage limit check with multiple handlers
     */
    public function testUsageLimitCheckWithMultipleHandlers(): void
    {
        $this->hooks->register();
        
        // First handler allows
        $this->hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
            return false;
        });
        
        // Second handler denies
        $this->hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
            return $currentUsage > 1000;
        });
        
        $isExceeded = $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 1500);
        
        $this->assertTrue($isExceeded, 'Should deny if any handler returns true');
    }
    
    /**
     * Test feature limit check with no handlers (default: allow all features)
     */
    public function testFeatureLimitCheckWithNoHandlers(): void
    {
        $this->hooks->register();
        
        $isAvailable = $this->hooks->checkFeatureLimit($this->workspace, 'custom_domain');
        
        $this->assertTrue($isAvailable, 'Should allow all features when no handlers registered');
    }
    
    /**
     * Test feature limit check with handler that allows feature
     */
    public function testFeatureLimitCheckWithAllowingHandler(): void
    {
        $this->hooks->register();
        
        $this->hooks->onFeatureLimitCheck(function (Workspace $workspace, string $featureName): bool {
            // Allow custom_domain feature
            return $featureName === 'custom_domain';
        });
        
        $isAvailable = $this->hooks->checkFeatureLimit($this->workspace, 'custom_domain');
        
        $this->assertTrue($isAvailable, 'Should allow feature when handler returns true');
    }
    
    /**
     * Test feature limit check with handler that denies feature
     */
    public function testFeatureLimitCheckWithDenyingHandler(): void
    {
        $this->hooks->register();
        
        $this->hooks->onFeatureLimitCheck(function (Workspace $workspace, string $featureName): bool {
            // Deny advanced_analytics feature
            return $featureName !== 'advanced_analytics';
        });
        
        $isAvailable = $this->hooks->checkFeatureLimit($this->workspace, 'advanced_analytics');
        
        $this->assertFalse($isAvailable, 'Should deny feature when handler returns false');
    }
    
    /**
     * Test feature limit check with multiple handlers
     */
    public function testFeatureLimitCheckWithMultipleHandlers(): void
    {
        $this->hooks->register();
        
        // First handler allows
        $this->hooks->onFeatureLimitCheck(function (Workspace $workspace, string $featureName): bool {
            return true;
        });
        
        // Second handler denies
        $this->hooks->onFeatureLimitCheck(function (Workspace $workspace, string $featureName): bool {
            return false;
        });
        
        $isAvailable = $this->hooks->checkFeatureLimit($this->workspace, 'custom_domain');
        
        $this->assertFalse($isAvailable, 'Should deny if any handler returns false');
    }
    
    /**
     * Test recording usage with no handlers
     */
    public function testRecordUsageWithNoHandlers(): void
    {
        $this->hooks->register();
        
        // Should not throw exception
        $this->hooks->recordUsage($this->workspace, 'api_calls', 10);
        
        $this->assertTrue(true, 'Should handle no handlers gracefully');
    }
    
    /**
     * Test recording usage with handler
     */
    public function testRecordUsageWithHandler(): void
    {
        $this->hooks->register();
        
        $recorded = [];
        
        $this->hooks->onRecordUsage(function (Workspace $workspace, string $resourceType, float $amount, array $metadata) use (&$recorded) {
            $recorded = [
                'workspace_id' => $workspace->workspaceId,
                'resource_type' => $resourceType,
                'amount' => $amount,
                'metadata' => $metadata,
            ];
        });
        
        $this->hooks->recordUsage($this->workspace, 'api_calls', 10, ['endpoint' => '/api/users']);
        
        $this->assertEquals('test-workspace-id', $recorded['workspace_id']);
        $this->assertEquals('api_calls', $recorded['resource_type']);
        $this->assertEquals(10, $recorded['amount']);
        $this->assertEquals('/api/users', $recorded['metadata']['endpoint']);
        $this->assertArrayHasKey('workspace_id', $recorded['metadata']);
        $this->assertArrayHasKey('tenant_id', $recorded['metadata']);
        $this->assertArrayHasKey('timestamp', $recorded['metadata']);
    }
    
    /**
     * Test recording usage with multiple handlers
     */
    public function testRecordUsageWithMultipleHandlers(): void
    {
        $this->hooks->register();
        
        $callCount = 0;
        
        $this->hooks->onRecordUsage(function () use (&$callCount) {
            $callCount++;
        });
        
        $this->hooks->onRecordUsage(function () use (&$callCount) {
            $callCount++;
        });
        
        $this->hooks->recordUsage($this->workspace, 'api_calls', 10);
        
        $this->assertEquals(2, $callCount, 'Should call all registered handlers');
    }
    
    /**
     * Test triggering billing event with no handlers
     */
    public function testTriggerBillingEventWithNoHandlers(): void
    {
        $this->hooks->register();
        
        // Should not throw exception
        $this->hooks->triggerBillingEvent($this->workspace, 'workspace_created');
        
        $this->assertTrue(true, 'Should handle no handlers gracefully');
    }
    
    /**
     * Test triggering billing event with handler
     */
    public function testTriggerBillingEventWithHandler(): void
    {
        $this->hooks->register();
        
        $triggered = [];
        
        $this->hooks->onBillingEvent(function (Workspace $workspace, string $eventType, array $eventData) use (&$triggered) {
            $triggered = [
                'workspace_id' => $workspace->workspaceId,
                'event_type' => $eventType,
                'event_data' => $eventData,
            ];
        });
        
        $this->hooks->triggerBillingEvent($this->workspace, 'workspace_created', ['plan' => 'premium']);
        
        $this->assertEquals('test-workspace-id', $triggered['workspace_id']);
        $this->assertEquals('workspace_created', $triggered['event_type']);
        $this->assertEquals('premium', $triggered['event_data']['plan']);
        $this->assertArrayHasKey('workspace_id', $triggered['event_data']);
        $this->assertArrayHasKey('tenant_id', $triggered['event_data']);
        $this->assertArrayHasKey('workspace_status', $triggered['event_data']);
        $this->assertArrayHasKey('timestamp', $triggered['event_data']);
    }
    
    /**
     * Test triggering billing event with multiple handlers
     */
    public function testTriggerBillingEventWithMultipleHandlers(): void
    {
        $this->hooks->register();
        
        $callCount = 0;
        
        $this->hooks->onBillingEvent(function () use (&$callCount) {
            $callCount++;
        });
        
        $this->hooks->onBillingEvent(function () use (&$callCount) {
            $callCount++;
        });
        
        $this->hooks->triggerBillingEvent($this->workspace, 'workspace_created');
        
        $this->assertEquals(2, $callCount, 'Should call all registered handlers');
    }
    
    /**
     * Test getting handler count
     */
    public function testGetHandlerCount(): void
    {
        $this->hooks->register();
        
        $this->assertEquals(0, $this->hooks->getHandlerCount('usage_limit'));
        
        $this->hooks->onUsageLimitCheck(function () {
            return false;
        });
        
        $this->assertEquals(1, $this->hooks->getHandlerCount('usage_limit'));
        
        $this->hooks->onUsageLimitCheck(function () {
            return false;
        });
        
        $this->assertEquals(2, $this->hooks->getHandlerCount('usage_limit'));
    }
    
    /**
     * Test clearing handlers
     */
    public function testClearHandlers(): void
    {
        $this->hooks->register();
        
        $this->hooks->onUsageLimitCheck(function () {
            return false;
        });
        $this->hooks->onFeatureLimitCheck(function () {
            return true;
        });
        
        $this->assertEquals(1, $this->hooks->getHandlerCount('usage_limit'));
        $this->assertEquals(1, $this->hooks->getHandlerCount('feature_limit'));
        
        $this->hooks->clearHandlers();
        
        $this->assertEquals(0, $this->hooks->getHandlerCount('usage_limit'));
        $this->assertEquals(0, $this->hooks->getHandlerCount('feature_limit'));
    }
    
    /**
     * Test that hooks auto-register when methods are called
     */
    public function testAutoRegisterOnMethodCall(): void
    {
        $this->assertFalse($this->hooks->isRegistered());
        
        $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 100);
        
        $this->assertTrue($this->hooks->isRegistered(), 'Should auto-register when method is called');
    }
    
    /**
     * Test workspace context is passed to handlers
     */
    public function testWorkspaceContextPassedToHandlers(): void
    {
        $this->hooks->register();
        
        $receivedWorkspace = null;
        
        $this->hooks->onUsageLimitCheck(function (Workspace $workspace) use (&$receivedWorkspace): bool {
            $receivedWorkspace = $workspace;
            return false;
        });
        
        $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 100);
        
        $this->assertNotNull($receivedWorkspace);
        $this->assertEquals('test-workspace-id', $receivedWorkspace->workspaceId);
        $this->assertEquals('test-tenant-id', $receivedWorkspace->tenantId);
        $this->assertEquals('Test Workspace', $receivedWorkspace->name);
    }
    
    /**
     * Test error handling in usage limit check
     */
    public function testErrorHandlingInUsageLimitCheck(): void
    {
        $this->hooks->register();
        
        $this->hooks->onUsageLimitCheck(function () {
            throw new \Exception('Handler error');
        });
        
        // Should not throw exception, should fail open (allow usage)
        $isExceeded = $this->hooks->checkUsageLimit($this->workspace, 'api_calls', 100);
        
        $this->assertFalse($isExceeded, 'Should fail open on error');
    }
    
    /**
     * Test error handling in feature limit check
     */
    public function testErrorHandlingInFeatureLimitCheck(): void
    {
        $this->hooks->register();
        
        $this->hooks->onFeatureLimitCheck(function () {
            throw new \Exception('Handler error');
        });
        
        // Should not throw exception, should fail open (allow feature)
        $isAvailable = $this->hooks->checkFeatureLimit($this->workspace, 'custom_domain');
        
        $this->assertTrue($isAvailable, 'Should fail open on error');
    }
    
    /**
     * Test error handling in record usage
     */
    public function testErrorHandlingInRecordUsage(): void
    {
        $this->hooks->register();
        
        $this->hooks->onRecordUsage(function () {
            throw new \Exception('Handler error');
        });
        
        // Should not throw exception
        $this->hooks->recordUsage($this->workspace, 'api_calls', 10);
        
        $this->assertTrue(true, 'Should handle errors gracefully');
    }
    
    /**
     * Test error handling in billing event
     */
    public function testErrorHandlingInBillingEvent(): void
    {
        $this->hooks->register();
        
        $this->hooks->onBillingEvent(function () {
            throw new \Exception('Handler error');
        });
        
        // Should not throw exception
        $this->hooks->triggerBillingEvent($this->workspace, 'workspace_created');
        
        $this->assertTrue(true, 'Should handle errors gracefully');
    }
}
