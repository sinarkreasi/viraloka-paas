<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\ManifestCache;
use Viraloka\Core\Modules\Manifest;

/**
 * Manifest Cache Test
 * 
 * Tests the ManifestCache class functionality including:
 * - Caching and retrieval of manifests
 * - Cache invalidation on file modification
 * - Cache miss handling
 * - Manifest serialization round-trip
 */
class ManifestCacheTest extends TestCase
{
    protected ManifestCache $cache;
    protected string $testModulePath;
    protected string $testManifestPath;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create cache instance with short TTL for testing
        $this->cache = new ManifestCache(60);
        
        // Create temporary test module directory
        $this->testModulePath = sys_get_temp_dir() . '/viraloka-cache-test-' . uniqid();
        mkdir($this->testModulePath, 0777, true);
        $this->testManifestPath = $this->testModulePath . '/module.json';
        
        // Create test manifest file
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        file_put_contents($this->testManifestPath, json_encode($manifestData));
    }
    
    protected function tearDown(): void
    {
        // Clean up test directory
        if (file_exists($this->testManifestPath)) {
            unlink($this->testManifestPath);
        }
        if (is_dir($this->testModulePath)) {
            rmdir($this->testModulePath);
        }
        
        // Flush cache
        $this->cache->flush();
        
        parent::tearDown();
    }
    
    /**
     * Test basic cache put and get operations
     */
    public function testCachePutAndGet(): void
    {
        // Create a manifest
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        $manifest = new Manifest($manifestData, $this->testModulePath);
        
        // Store in cache
        $this->cache->put('test.module', $manifest);
        
        // Retrieve from cache
        $cached = $this->cache->get('test.module');
        
        // Assert manifest was retrieved
        $this->assertNotNull($cached);
        $this->assertEquals('test.module', $cached->id);
        $this->assertEquals('Test Module', $cached->name);
        $this->assertEquals('1.0.0', $cached->version);
    }
    
    /**
     * Test cache miss returns null
     */
    public function testCacheMissReturnsNull(): void
    {
        $cached = $this->cache->get('nonexistent.module');
        
        $this->assertNull($cached);
    }
    
    /**
     * Test cache invalidation with forget
     */
    public function testCacheForget(): void
    {
        // Create and cache a manifest
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        $manifest = new Manifest($manifestData, $this->testModulePath);
        $this->cache->put('test.module', $manifest);
        
        // Verify it's cached
        $this->assertNotNull($this->cache->get('test.module'));
        
        // Forget the cache
        $this->cache->forget('test.module');
        
        // Verify it's no longer cached
        $this->assertNull($this->cache->get('test.module'));
    }
    
    /**
     * Test cache invalidation on file modification
     */
    public function testCacheInvalidationOnFileModification(): void
    {
        // Create and cache a manifest
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        $manifest = new Manifest($manifestData, $this->testModulePath);
        $this->cache->put('test.module', $manifest);
        
        // Verify it's cached
        $this->assertNotNull($this->cache->get('test.module'));
        
        // Wait a moment to ensure different mtime
        sleep(1);
        
        // Modify the file
        touch($this->testManifestPath);
        
        // Try to get from cache - should return null due to mtime change
        $cached = $this->cache->get('test.module');
        $this->assertNull($cached);
    }
    
    /**
     * Test manifest serialization round-trip
     */
    public function testManifestSerializationRoundTrip(): void
    {
        // Create a manifest with all fields
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule',
            'contexts' => [
                'supported' => ['creator', 'digital'],
                'primary' => 'creator',
                'priority' => 75
            ],
            'dependencies' => [
                'core' => '>=1.0.0',
                'modules' => [
                    ['id' => 'other.module', 'optional' => true]
                ],
                'plugins' => []
            ],
            'capabilities' => ['manage_test', 'view_test'],
            'ui' => [
                'admin_menu' => true,
                'menu_title' => 'Test Module',
                'icon' => 'dashicons-admin-generic',
                'order' => 50
            ],
            'lifecycle' => [
                'provider' => 'Viraloka\\Modules\\TestModule\\ServiceProvider',
                'boot' => true
            ],
            'recommendations' => [
                'modules' => ['recommended.module'],
                'integrations' => ['stripe', 'mailchimp']
            ],
            'visibility' => [
                'public' => true,
                'marketplace' => false
            ]
        ];
        
        $manifest = new Manifest($manifestData, $this->testModulePath);
        
        // Store in cache
        $this->cache->put('test.module', $manifest);
        
        // Retrieve from cache
        $cached = $this->cache->get('test.module');
        
        // Assert all fields are preserved
        $this->assertNotNull($cached);
        $this->assertEquals('test.module', $cached->id);
        $this->assertEquals('Test Module', $cached->name);
        $this->assertEquals('A test module', $cached->description);
        $this->assertEquals('1.0.0', $cached->version);
        $this->assertEquals('Test Author', $cached->author);
        $this->assertEquals('Viraloka\\Modules\\TestModule', $cached->namespace);
        
        // Check contexts
        $this->assertNotNull($cached->contexts);
        $this->assertEquals(['creator', 'digital'], $cached->contexts->supported);
        $this->assertEquals('creator', $cached->contexts->primary);
        $this->assertEquals(75, $cached->contexts->priority);
        
        // Check dependencies
        $this->assertNotNull($cached->dependencies);
        $this->assertEquals('>=1.0.0', $cached->dependencies->core);
        
        // Check capabilities
        $this->assertEquals(['manage_test', 'view_test'], $cached->capabilities);
        
        // Check UI config
        $this->assertNotNull($cached->ui);
        $this->assertTrue($cached->ui->adminMenu);
        $this->assertEquals('Test Module', $cached->ui->menuTitle);
        
        // Check lifecycle
        $this->assertNotNull($cached->lifecycle);
        $this->assertEquals('Viraloka\\Modules\\TestModule\\ServiceProvider', $cached->lifecycle->provider);
        $this->assertTrue($cached->lifecycle->boot);
        
        // Check recommendations
        $this->assertNotNull($cached->recommendations);
        $this->assertEquals(['recommended.module'], $cached->recommendations->modules);
        
        // Check visibility
        $this->assertTrue($cached->visibility->public);
        $this->assertFalse($cached->visibility->marketplace);
    }
    
    /**
     * Test cache flush clears all entries
     */
    public function testCacheFlush(): void
    {
        // Create and cache multiple manifests
        for ($i = 1; $i <= 3; $i++) {
            $manifestData = [
                'id' => "test.module{$i}",
                'name' => "Test Module {$i}",
                'description' => "Test module {$i}",
                'version' => '1.0.0',
                'author' => 'Test Author',
                'namespace' => "Viraloka\\Modules\\TestModule{$i}"
            ];
            
            $manifest = new Manifest($manifestData, $this->testModulePath);
            $this->cache->put("test.module{$i}", $manifest);
        }
        
        // Verify all are cached
        $this->assertNotNull($this->cache->get('test.module1'));
        $this->assertNotNull($this->cache->get('test.module2'));
        $this->assertNotNull($this->cache->get('test.module3'));
        
        // Flush cache
        $this->cache->flush();
        
        // Verify all are cleared
        $this->assertNull($this->cache->get('test.module1'));
        $this->assertNull($this->cache->get('test.module2'));
        $this->assertNull($this->cache->get('test.module3'));
    }
    
    /**
     * Test cache handles missing file gracefully
     */
    public function testCacheHandlesMissingFile(): void
    {
        // Create and cache a manifest
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Viraloka\\Modules\\TestModule'
        ];
        
        $manifest = new Manifest($manifestData, $this->testModulePath);
        $this->cache->put('test.module', $manifest);
        
        // Verify it's cached
        $this->assertNotNull($this->cache->get('test.module'));
        
        // Delete the file
        unlink($this->testManifestPath);
        
        // Try to get from cache - should return null since file is missing
        $cached = $this->cache->get('test.module');
        $this->assertNull($cached);
    }
}
