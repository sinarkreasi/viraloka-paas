<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\ParseResult;

/**
 * Manifest Parser Test
 * 
 * Tests for the ManifestParser class
 */
class ManifestParserTest extends TestCase
{
    private ManifestParser $parser;
    private string $testDir;
    
    protected function setUp(): void
    {
        $validator = new SchemaValidator();
        $this->parser = new ManifestParser($validator);
        
        // Create temporary test directory
        $this->testDir = sys_get_temp_dir() . '/viraloka_test_' . uniqid();
        mkdir($this->testDir, 0777, true);
    }
    
    protected function tearDown(): void
    {
        // Clean up test directory
        if (is_dir($this->testDir)) {
            $this->removeDirectory($this->testDir);
        }
    }
    
    private function removeDirectory(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->removeDirectory($path) : unlink($path);
        }
        rmdir($dir);
    }
    
    private function createManifestFile(string $filename, string $content): string
    {
        $filePath = $this->testDir . '/' . $filename;
        file_put_contents($filePath, $content);
        return $filePath;
    }
    
    public function testParseValidManifest(): void
    {
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module'
        ];
        
        $filePath = $this->createManifestFile('module.json', json_encode($manifestData));
        
        $result = $this->parser->parse($filePath);
        
        $this->assertTrue($result->success);
        $this->assertNotNull($result->manifest);
        $this->assertNull($result->error);
        $this->assertEquals('test.module', $result->manifest->id);
        $this->assertEquals('Test Module', $result->manifest->name);
    }
    
    public function testParseNonExistentFile(): void
    {
        $result = $this->parser->parse('/non/existent/file.json');
        
        $this->assertFalse($result->success);
        $this->assertNull($result->manifest);
        $this->assertStringContainsString('not found', $result->error);
    }
    
    public function testParseInvalidJson(): void
    {
        $filePath = $this->createManifestFile('invalid.json', '{invalid json}');
        
        $result = $this->parser->parse($filePath);
        
        $this->assertFalse($result->success);
        $this->assertNull($result->manifest);
        $this->assertStringContainsString('Invalid JSON', $result->error);
    }
    
    public function testParseInvalidUtf8(): void
    {
        $filePath = $this->createManifestFile('invalid_utf8.json', "\xFF\xFE{\"test\": \"value\"}");
        
        $result = $this->parser->parse($filePath);
        
        $this->assertFalse($result->success);
        $this->assertNull($result->manifest);
        $this->assertStringContainsString('UTF-8', $result->error);
    }
    
    public function testParseMissingRequiredFields(): void
    {
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module'
            // Missing required fields: description, version, author, namespace
        ];
        
        $filePath = $this->createManifestFile('incomplete.json', json_encode($manifestData));
        
        $result = $this->parser->parse($filePath);
        
        $this->assertFalse($result->success);
        $this->assertNull($result->manifest);
        $this->assertStringContainsString('validation failed', $result->error);
    }
    
    public function testParseWithOptionalFields(): void
    {
        $manifestData = [
            'id' => 'test.module',
            'name' => 'Test Module',
            'description' => 'A test module',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'capabilities' => ['test.capability'],
            'contexts' => [
                'supported' => ['creator'],
                'primary' => 'creator',
                'priority' => 75
            ]
        ];
        
        $filePath = $this->createManifestFile('full.json', json_encode($manifestData));
        
        $result = $this->parser->parse($filePath);
        
        $this->assertTrue($result->success);
        $this->assertNotNull($result->manifest);
        $this->assertEquals(['test.capability'], $result->manifest->capabilities);
        $this->assertNotNull($result->manifest->contexts);
        $this->assertEquals(['creator'], $result->manifest->contexts->supported);
    }
}
