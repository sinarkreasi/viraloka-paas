<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\ContextConfig;
use Viraloka\Core\Workspace\Workspace;

/**
 * Unit Tests for Context Resolver
 * 
 * Tests specific examples and edge cases for context resolution.
 * 
 * Requirements: 7.2, 7.3, 7.4, 7.5
 */
class ContextResolverTest extends TestCase
{
    private ModuleRegistry $registry;
    private Application $app;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->registry = new ModuleRegistry();
        $this->app = new Application(__DIR__);
        
        // Mock WordPress functions if not already defined
        if (!function_exists('wp_get_theme')) {
            eval('
                function wp_get_theme() {
                    return new class {
                        private $headers = [];
                        
                        public function setHeader($key, $value) {
                            $this->headers[$key] = $value;
                        }
                        
                        public function get($key) {
                            return $this->headers[$key] ?? "";
                        }
                    };
                }
            ');
        }
        
        if (!function_exists('get_stylesheet_directory')) {
            eval('
                function get_stylesheet_directory() {
                    return "/tmp/nonexistent";
                }
            ');
        }
    }
    
    /**
     * Test theme metadata resolution
     * 
     * Requirements: 7.2
     */
    public function testResolveFromThemeMetadata(): void
    {
        // This test would require mocking wp_get_theme() to return a theme with context
        // Since we can't easily mock the global function, we'll test the fallback behavior
        
        $resolver = new ContextResolver($this->registry, $this->app);
        $context = $resolver->getCurrentContext();
        
        // Without theme metadata, should fallback to default
        $this->assertEquals('default', $context);
    }
    
    /**
     * Test workspace configuration fallback
     * 
     * Requirements: 7.3
     */
    public function testResolveFromWorkspaceConfigFallback(): void
    {
        // Create workspace with specific context
        $workspace = new Workspace(
            'test-workspace',
            'Test Workspace',
            'example.com',
            [],
            [],
            'ecommerce'
        );
        
        // Inject workspace into container
        $this->app->instance(Workspace::class, $workspace);
        
        // Create resolver
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // Should resolve from workspace config
        $context = $resolver->getCurrentContext();
        $this->assertEquals('ecommerce', $context);
    }
    
    /**
     * Test default context fallback
     * 
     * Requirements: 7.3
     */
    public function testDefaultContextFallback(): void
    {
        // Create workspace with empty context
        $workspace = new Workspace(
            'test-workspace',
            'Test Workspace',
            'example.com',
            [],
            [],
            ''
        );
        
        $this->app->instance(Workspace::class, $workspace);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // Should fallback to default
        $context = $resolver->getCurrentContext();
        $this->assertEquals('default', $context);
    }
    
    /**
     * Test default context fallback without workspace
     * 
     * Requirements: 7.3
     */
    public function testDefaultContextFallbackWithoutWorkspace(): void
    {
        // No workspace in container
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // Should fallback to default
        $context = $resolver->getCurrentContext();
        $this->assertEquals('default', $context);
    }
    
    /**
     * Test recommendation graph building
     * 
     * Requirements: 7.4
     */
    public function testBuildRecommendationGraph(): void
    {
        // Create test modules with different contexts
        $manifest1 = new Manifest(
            'module1',
            'Module 1',
            '1.0.0',
            'Test module 1',
            'Viraloka\\Modules\\Module1\\ServiceProvider',
            new ContextConfig(['ecommerce', 'blog'], 'ecommerce', 80),
            null,
            null,
            null,
            null,
            null
        );
        
        $manifest2 = new Manifest(
            'module2',
            'Module 2',
            '1.0.0',
            'Test module 2',
            'Viraloka\\Modules\\Module2\\ServiceProvider',
            new ContextConfig(['ecommerce'], 'ecommerce', 70),
            null,
            null,
            null,
            null,
            null
        );
        
        $manifest3 = new Manifest(
            'module3',
            'Module 3',
            '1.0.0',
            'Test module 3',
            'Viraloka\\Modules\\Module3\\ServiceProvider',
            new ContextConfig(['blog'], 'blog', 60),
            null,
            null,
            null,
            null,
            null
        );
        
        $module1 = new Module($manifest1, '/path/to/module1');
        $module2 = new Module($manifest2, '/path/to/module2');
        $module3 = new Module($manifest3, '/path/to/module3');
        
        $this->registry->register($module1);
        $this->registry->register($module2);
        $this->registry->register($module3);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // Build recommendation graph
        $graph = $resolver->buildRecommendationGraph();
        
        // Assert graph structure
        $this->assertIsArray($graph);
        $this->assertCount(3, $graph);
        
        // Check module1 entry
        $this->assertArrayHasKey('module1', $graph);
        $this->assertEquals('module1', $graph['module1']['id']);
        $this->assertEquals('Module 1', $graph['module1']['name']);
        $this->assertEquals(['ecommerce', 'blog'], $graph['module1']['contexts']);
        $this->assertEquals('ecommerce', $graph['module1']['primary_context']);
        $this->assertEquals(80, $graph['module1']['priority']);
        
        // Check recommended_with relationships
        // module1 shares 'ecommerce' with module2 and 'blog' with module3
        $this->assertContains('module2', $graph['module1']['recommended_with']);
        $this->assertContains('module3', $graph['module1']['recommended_with']);
        
        // module2 shares 'ecommerce' with module1
        $this->assertContains('module1', $graph['module2']['recommended_with']);
        
        // module3 shares 'blog' with module1
        $this->assertContains('module1', $graph['module3']['recommended_with']);
    }
    
    /**
     * Test recommendation graph with context-agnostic modules
     * 
     * Requirements: 7.4
     */
    public function testBuildRecommendationGraphWithContextAgnosticModules(): void
    {
        // Create context-agnostic module (no contexts)
        $manifest1 = new Manifest(
            'module1',
            'Module 1',
            '1.0.0',
            'Context-agnostic module',
            'Viraloka\\Modules\\Module1\\ServiceProvider',
            null, // No context config
            null,
            null,
            null,
            null,
            null
        );
        
        $manifest2 = new Manifest(
            'module2',
            'Module 2',
            '1.0.0',
            'Context-specific module',
            'Viraloka\\Modules\\Module2\\ServiceProvider',
            new ContextConfig(['ecommerce'], 'ecommerce', 70),
            null,
            null,
            null,
            null,
            null
        );
        
        $module1 = new Module($manifest1, '/path/to/module1');
        $module2 = new Module($manifest2, '/path/to/module2');
        
        $this->registry->register($module1);
        $this->registry->register($module2);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        $graph = $resolver->buildRecommendationGraph();
        
        // Context-agnostic module should have empty contexts array
        $this->assertEquals([], $graph['module1']['contexts']);
        $this->assertNull($graph['module1']['primary_context']);
        $this->assertEquals(50, $graph['module1']['priority']); // Default priority
        
        // Context-agnostic modules share all contexts
        $this->assertContains('module2', $graph['module1']['recommended_with']);
        $this->assertContains('module1', $graph['module2']['recommended_with']);
    }
    
    /**
     * Test context injection into container
     * 
     * Requirements: 7.5
     */
    public function testInjectContextIntoContainer(): void
    {
        // Create workspace with specific context
        $workspace = new Workspace(
            'test-workspace',
            'Test Workspace',
            'example.com',
            [],
            [],
            'blog'
        );
        
        $this->app->instance(Workspace::class, $workspace);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // Inject context into container
        $resolver->injectIntoContainer();
        
        // Verify context is available in container
        $this->assertTrue($this->app->bound('context'));
        $this->assertTrue($this->app->bound('viraloka.context'));
        
        $context = $this->app->make('context');
        $this->assertEquals('blog', $context);
        
        $viralokaContext = $this->app->make('viraloka.context');
        $this->assertEquals('blog', $viralokaContext);
    }
    
    /**
     * Test context injection without application
     * 
     * Requirements: 7.5
     */
    public function testInjectContextIntoContainerWithoutApp(): void
    {
        // Create resolver without app
        $resolver = new ContextResolver($this->registry, null);
        
        // Should not throw exception
        $resolver->injectIntoContainer();
        
        // No assertions needed - just verify no exception
        $this->assertTrue(true);
    }
    
    /**
     * Test context caching
     */
    public function testContextCaching(): void
    {
        $workspace = new Workspace(
            'test-workspace',
            'Test Workspace',
            'example.com',
            [],
            [],
            'portfolio'
        );
        
        $this->app->instance(Workspace::class, $workspace);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // First call
        $context1 = $resolver->getCurrentContext();
        
        // Change workspace context (should not affect cached value)
        $workspace->context = 'different';
        
        // Second call should return cached value
        $context2 = $resolver->getCurrentContext();
        
        $this->assertEquals($context1, $context2);
        $this->assertEquals('portfolio', $context2);
    }
    
    /**
     * Test recommendation graph caching
     */
    public function testRecommendationGraphCaching(): void
    {
        $manifest = new Manifest(
            'module1',
            'Module 1',
            '1.0.0',
            'Test module',
            'Viraloka\\Modules\\Module1\\ServiceProvider',
            new ContextConfig(['ecommerce'], 'ecommerce', 80),
            null,
            null,
            null,
            null,
            null
        );
        
        $module = new Module($manifest, '/path/to/module1');
        $this->registry->register($module);
        
        $resolver = new ContextResolver($this->registry, $this->app);
        
        // First call
        $graph1 = $resolver->buildRecommendationGraph();
        
        // Register another module (should not affect cached graph)
        $manifest2 = new Manifest(
            'module2',
            'Module 2',
            '1.0.0',
            'Test module 2',
            'Viraloka\\Modules\\Module2\\ServiceProvider',
            new ContextConfig(['blog'], 'blog', 70),
            null,
            null,
            null,
            null,
            null
        );
        $module2 = new Module($manifest2, '/path/to/module2');
        $this->registry->register($module2);
        
        // Second call should return cached graph
        $graph2 = $resolver->buildRecommendationGraph();
        
        $this->assertEquals($graph1, $graph2);
        $this->assertCount(1, $graph2); // Should still have only 1 module
    }
}
