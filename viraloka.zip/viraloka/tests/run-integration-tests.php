#!/usr/bin/env php
<?php
/**
 * Integration Test Runner
 * 
 * This script runs the integration tests and provides a summary of results.
 * It can be run directly without PHPUnit if needed for quick verification.
 */

// Check if vendor/autoload exists
if (!file_exists(__DIR__ . '/vendor/autoload.php')) {
    echo "Error: Composer dependencies not installed.\n";
    echo "Please run: composer install\n";
    exit(1);
}

require_once __DIR__ . '/vendor/autoload.php';

echo "=== Viraloka Core Integration Test Runner ===\n\n";

// Check if PHPUnit is available
$phpunitPath = __DIR__ . '/vendor/bin/phpunit';
if (file_exists($phpunitPath) || file_exists($phpunitPath . '.bat')) {
    echo "Running PHPUnit integration tests...\n\n";
    
    // Determine the correct PHPUnit command based on OS
    $isWindows = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    $phpunit = $isWindows ? 'vendor\\bin\\phpunit.bat' : 'vendor/bin/phpunit';
    
    // Run integration tests
    $command = "{$phpunit} --testdox tests/ModuleLifecycleIntegrationTest.php";
    
    echo "Command: {$command}\n";
    echo str_repeat('-', 60) . "\n\n";
    
    passthru($command, $exitCode);
    
    echo "\n" . str_repeat('-', 60) . "\n";
    
    if ($exitCode === 0) {
        echo "\n✓ All integration tests passed!\n";
    } else {
        echo "\n✗ Some integration tests failed. See output above.\n";
    }
    
    exit($exitCode);
} else {
    echo "PHPUnit not found. Please install dependencies:\n";
    echo "  composer install\n";
    exit(1);
}
