<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\Providers\WorkspaceTenantServiceProvider;
use Viraloka\Core\Container\Container;
use Viraloka\Core\Workspace\Contracts\TenantRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\DomainResolverInterface;
use Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface;
use Viraloka\Core\Container\Contracts\WorkspaceResolverInterface;
use Viraloka\Core\Workspace\EnhancedWorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;

/**
 * Test WorkspaceTenantServiceProvider
 * 
 * Validates that the service provider correctly registers all workspace
 * and tenant system services in the container.
 */
class WorkspaceTenantServiceProviderTest extends TestCase
{
    private Container $container;
    private WorkspaceTenantServiceProvider $provider;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Create a fresh container
        $this->container = new Container();
        
        // Create the service provider
        $this->provider = new WorkspaceTenantServiceProvider();
    }

    public function testRegisterBindsAllRepositories(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Verify all repository interfaces are bound
        $this->assertTrue($this->container->has(TenantRepositoryInterface::class));
        $this->assertTrue($this->container->has(WorkspaceRepositoryInterface::class));
        $this->assertTrue($this->container->has(WorkspaceUserRoleRepositoryInterface::class));
    }

    public function testRegisterBindsEnhancedWorkspaceResolver(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Verify EnhancedWorkspaceResolver is bound
        $this->assertTrue($this->container->has(EnhancedWorkspaceResolver::class));
        
        // Verify it's aliased to both interfaces
        $this->assertTrue($this->container->has(DomainResolverInterface::class));
        $this->assertTrue($this->container->has(WorkspaceResolverInterface::class));
    }

    public function testRegisterBindsPermissionBoundary(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Verify PermissionBoundary is bound
        $this->assertTrue($this->container->has(PermissionBoundaryInterface::class));
    }

    public function testRepositoriesAreSingletons(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Resolve repositories twice
        $tenantRepo1 = $this->container->get(TenantRepositoryInterface::class);
        $tenantRepo2 = $this->container->get(TenantRepositoryInterface::class);

        // Verify same instance is returned (singleton behavior)
        $this->assertSame($tenantRepo1, $tenantRepo2);

        $workspaceRepo1 = $this->container->get(WorkspaceRepositoryInterface::class);
        $workspaceRepo2 = $this->container->get(WorkspaceRepositoryInterface::class);

        $this->assertSame($workspaceRepo1, $workspaceRepo2);
    }

    public function testEnhancedWorkspaceResolverIsSingleton(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Resolve through different interfaces
        $resolver1 = $this->container->get(EnhancedWorkspaceResolver::class);
        $resolver2 = $this->container->get(DomainResolverInterface::class);
        $resolver3 = $this->container->get(WorkspaceResolverInterface::class);

        // Verify all return the same instance
        $this->assertSame($resolver1, $resolver2);
        $this->assertSame($resolver2, $resolver3);
    }

    public function testPermissionBoundaryIsSingleton(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Resolve twice
        $boundary1 = $this->container->get(PermissionBoundaryInterface::class);
        $boundary2 = $this->container->get(PermissionBoundaryInterface::class);

        // Verify same instance is returned
        $this->assertSame($boundary1, $boundary2);
    }

    public function testBootInjectsWorkspaceIntoContainer(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Boot the provider (will use fallback to system default if DB not available)
        $this->provider->boot($this->container);

        // Verify workspace is injected into container
        $this->assertTrue($this->container->has(Workspace::class));
        $this->assertTrue($this->container->has('workspace'));

        // Verify both resolve to the same instance
        $workspace1 = $this->container->get(Workspace::class);
        $workspace2 = $this->container->get('workspace');
        $this->assertSame($workspace1, $workspace2);
        
        // Verify it's a valid workspace instance
        $this->assertInstanceOf(Workspace::class, $workspace1);
    }

    public function testBootHandlesResolutionFailureGracefully(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Boot should not throw an exception even if resolution fails
        // The EnhancedWorkspaceResolver has built-in fallback to system default
        try {
            $this->provider->boot($this->container);
            $this->assertTrue(true); // If we get here, no exception was thrown
        } catch (\Throwable $e) {
            $this->fail('Boot should handle resolution failures gracefully: ' . $e->getMessage());
        }
    }

    public function testResolvedServicesAreCorrectTypes(): void
    {
        // Register the provider
        $this->provider->register($this->container);

        // Resolve and verify types
        $tenantRepo = $this->container->get(TenantRepositoryInterface::class);
        $this->assertInstanceOf(TenantRepositoryInterface::class, $tenantRepo);

        $workspaceRepo = $this->container->get(WorkspaceRepositoryInterface::class);
        $this->assertInstanceOf(WorkspaceRepositoryInterface::class, $workspaceRepo);

        $roleRepo = $this->container->get(WorkspaceUserRoleRepositoryInterface::class);
        $this->assertInstanceOf(WorkspaceUserRoleRepositoryInterface::class, $roleRepo);

        $resolver = $this->container->get(DomainResolverInterface::class);
        $this->assertInstanceOf(DomainResolverInterface::class, $resolver);
        $this->assertInstanceOf(WorkspaceResolverInterface::class, $resolver);

        $boundary = $this->container->get(PermissionBoundaryInterface::class);
        $this->assertInstanceOf(PermissionBoundaryInterface::class, $boundary);
    }
}
