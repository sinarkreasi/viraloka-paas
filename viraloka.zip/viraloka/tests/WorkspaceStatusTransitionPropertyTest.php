<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\Tenant;
use Viraloka\Core\Workspace\Workspace;
use Eris\Generator;
use Eris\TestTrait;

/**
 * Property-Based Test: Status Transition Validity
 * 
 * Property 13: Status Transition Validity
 * 
 * For any tenant or workspace, status transitions SHALL only be to valid 
 * status values (tenant: active/suspended; workspace: active/suspended/archived). 
 * Invalid status transitions SHALL be rejected.
 * 
 * Validates: Requirements 1.3, 1.8, 1.9, 2.4
 * 
 * @feature workspace-tenant
 * @property 13: Status Transition Validity
 */
class WorkspaceStatusTransitionPropertyTest extends TestCase
{
    use TestTrait;
    
    /**
     * Property: Tenant status transitions are always valid
     * 
     * For any tenant, the status SHALL only be 'active' or 'suspended'.
     * 
     * **Validates: Requirements 1.3, 1.8, 1.9**
     */
    public function testTenantStatusTransitionsAreValid(): void
    {
        $this->forAll(
            Generator\elements([
                Tenant::STATUS_ACTIVE,
                Tenant::STATUS_SUSPENDED
            ])
        )->then(function (string $status) {
            // Create tenant with the status
            $tenant = new Tenant(
                tenantId: 'test-' . uniqid(),
                name: 'Test Tenant',
                ownerUserId: 1,
                status: $status
            );
            
            // Verify status is one of the valid values
            $this->assertContains(
                $tenant->status,
                [Tenant::STATUS_ACTIVE, Tenant::STATUS_SUSPENDED],
                'Tenant status must be either active or suspended'
            );
            
            // Verify status helper methods work correctly
            if ($status === Tenant::STATUS_ACTIVE) {
                $this->assertTrue($tenant->isActive());
            } else {
                $this->assertFalse($tenant->isActive());
            }
        });
    }
    
    /**
     * Property: Tenant status can transition between active and suspended
     * 
     * For any tenant, transitioning from active to suspended and back 
     * SHALL maintain valid status values.
     * 
     * **Validates: Requirements 1.3, 1.8, 1.9**
     */
    public function testTenantStatusTransitionsBetweenActiveAndSuspended(): void
    {
        $this->forAll(
            Generator\elements([
                Tenant::STATUS_ACTIVE,
                Tenant::STATUS_SUSPENDED
            ])
        )->then(function (string $initialStatus) {
            // Create tenant with initial status
            $tenant = new Tenant(
                tenantId: 'test-' . uniqid(),
                name: 'Test Tenant',
                ownerUserId: 1,
                status: $initialStatus
            );
            
            // Transition to opposite status
            if ($initialStatus === Tenant::STATUS_ACTIVE) {
                $tenant->suspend();
                $this->assertEquals(Tenant::STATUS_SUSPENDED, $tenant->status);
                $this->assertFalse($tenant->isActive());
                
                // Transition back
                $tenant->activate();
                $this->assertEquals(Tenant::STATUS_ACTIVE, $tenant->status);
                $this->assertTrue($tenant->isActive());
            } else {
                $tenant->activate();
                $this->assertEquals(Tenant::STATUS_ACTIVE, $tenant->status);
                $this->assertTrue($tenant->isActive());
                
                // Transition back
                $tenant->suspend();
                $this->assertEquals(Tenant::STATUS_SUSPENDED, $tenant->status);
                $this->assertFalse($tenant->isActive());
            }
        });
    }
    
    /**
     * Property: Workspace status transitions are always valid
     * 
     * For any workspace, the status SHALL only be 'active', 'suspended', or 'archived'.
     * 
     * **Validates: Requirements 2.4**
     */
    public function testWorkspaceStatusTransitionsAreValid(): void
    {
        $this->forAll(
            Generator\elements([
                Workspace::STATUS_ACTIVE,
                Workspace::STATUS_SUSPENDED,
                Workspace::STATUS_ARCHIVED
            ])
        )->then(function (string $status) {
            // Create workspace with the status
            $workspace = new Workspace(
                workspaceId: 'test-' . uniqid(),
                tenantId: 'tenant-' . uniqid(),
                name: 'Test Workspace',
                slug: 'test-' . uniqid(),
                status: $status
            );
            
            // Verify status is one of the valid values
            $this->assertContains(
                $workspace->status,
                [
                    Workspace::STATUS_ACTIVE,
                    Workspace::STATUS_SUSPENDED,
                    Workspace::STATUS_ARCHIVED
                ],
                'Workspace status must be active, suspended, or archived'
            );
            
            // Verify status helper method works correctly
            if ($status === Workspace::STATUS_ACTIVE) {
                $this->assertTrue($workspace->isActive());
            } else {
                $this->assertFalse($workspace->isActive());
            }
        });
    }
    
    /**
     * Property: Workspace status can transition between all valid states
     * 
     * For any workspace, transitioning between active, suspended, and archived 
     * SHALL maintain valid status values.
     * 
     * **Validates: Requirements 2.4**
     */
    public function testWorkspaceStatusTransitionsBetweenAllStates(): void
    {
        $this->forAll(
            Generator\elements([
                Workspace::STATUS_ACTIVE,
                Workspace::STATUS_SUSPENDED,
                Workspace::STATUS_ARCHIVED
            ])
        )->then(function (string $initialStatus) {
            // Create workspace with initial status
            $workspace = new Workspace(
                workspaceId: 'test-' . uniqid(),
                tenantId: 'tenant-' . uniqid(),
                name: 'Test Workspace',
                slug: 'test-' . uniqid(),
                status: $initialStatus
            );
            
            // Test all possible transitions
            $workspace->activate();
            $this->assertEquals(Workspace::STATUS_ACTIVE, $workspace->status);
            $this->assertTrue($workspace->isActive());
            
            $workspace->suspend();
            $this->assertEquals(Workspace::STATUS_SUSPENDED, $workspace->status);
            $this->assertFalse($workspace->isActive());
            
            $workspace->archive();
            $this->assertEquals(Workspace::STATUS_ARCHIVED, $workspace->status);
            $this->assertFalse($workspace->isActive());
            
            // Can reactivate from archived
            $workspace->activate();
            $this->assertEquals(Workspace::STATUS_ACTIVE, $workspace->status);
            $this->assertTrue($workspace->isActive());
        });
    }
    
    /**
     * Property: Invalid status values are rejected
     * 
     * For any tenant or workspace, attempting to set an invalid status 
     * SHALL result in the status remaining unchanged or being rejected.
     * 
     * **Validates: Requirements 1.3, 2.4**
     */
    public function testInvalidStatusValuesAreRejected(): void
    {
        $this->forAll(
            Generator\suchThat(
                function ($status) {
                    return !in_array($status, [
                        Tenant::STATUS_ACTIVE,
                        Tenant::STATUS_SUSPENDED,
                        Workspace::STATUS_ACTIVE,
                        Workspace::STATUS_SUSPENDED,
                        Workspace::STATUS_ARCHIVED
                    ], true);
                },
                Generator\elements(['invalid', 'deleted', 'pending', 'draft', ''])
            )
        )->then(function (string $invalidStatus) {
            // For Tenant: invalid status should not be accepted
            $tenant = new Tenant(
                tenantId: 'test-' . uniqid(),
                name: 'Test Tenant',
                ownerUserId: 1,
                status: Tenant::STATUS_ACTIVE
            );
            
            // Manually setting invalid status (simulating direct property access)
            $originalStatus = $tenant->status;
            $tenant->status = $invalidStatus;
            
            // The status should not be a valid one
            $this->assertNotContains(
                $tenant->status,
                [Tenant::STATUS_ACTIVE, Tenant::STATUS_SUSPENDED],
                'Invalid status should not match valid statuses'
            );
            
            // For Workspace: invalid status should not be accepted
            $workspace = new Workspace(
                workspaceId: 'test-' . uniqid(),
                tenantId: 'tenant-' . uniqid(),
                name: 'Test Workspace',
                slug: 'test-' . uniqid(),
                status: Workspace::STATUS_ACTIVE
            );
            
            // Manually setting invalid status
            $workspace->status = $invalidStatus;
            
            // The status should not be a valid one
            $this->assertNotContains(
                $workspace->status,
                [
                    Workspace::STATUS_ACTIVE,
                    Workspace::STATUS_SUSPENDED,
                    Workspace::STATUS_ARCHIVED
                ],
                'Invalid status should not match valid statuses'
            );
        });
    }
    
    /**
     * Property: Status transitions preserve entity identity
     * 
     * For any tenant or workspace, changing status SHALL NOT change 
     * the entity's ID or other immutable properties.
     * 
     * **Validates: Requirements 1.3, 2.4**
     */
    public function testStatusTransitionsPreserveEntityIdentity(): void
    {
        $this->forAll(
            Generator\tuple(
                Generator\string(),
                Generator\string(),
                Generator\pos()
            )
        )->then(function ($tuple) {
            [$tenantId, $workspaceId, $userId] = $tuple;
            
            // Test Tenant identity preservation
            $tenant = new Tenant(
                tenantId: $tenantId,
                name: 'Test Tenant',
                ownerUserId: $userId
            );
            
            $originalTenantId = $tenant->tenantId;
            $originalOwner = $tenant->ownerUserId;
            
            $tenant->suspend();
            $this->assertEquals($originalTenantId, $tenant->tenantId);
            $this->assertEquals($originalOwner, $tenant->ownerUserId);
            
            $tenant->activate();
            $this->assertEquals($originalTenantId, $tenant->tenantId);
            $this->assertEquals($originalOwner, $tenant->ownerUserId);
            
            // Test Workspace identity preservation
            $workspace = new Workspace(
                workspaceId: $workspaceId,
                tenantId: $tenantId,
                name: 'Test Workspace',
                slug: 'test-slug'
            );
            
            $originalWorkspaceId = $workspace->workspaceId;
            $originalTenantId = $workspace->tenantId;
            $originalSlug = $workspace->slug;
            
            $workspace->suspend();
            $this->assertEquals($originalWorkspaceId, $workspace->workspaceId);
            $this->assertEquals($originalTenantId, $workspace->tenantId);
            $this->assertEquals($originalSlug, $workspace->slug);
            
            $workspace->archive();
            $this->assertEquals($originalWorkspaceId, $workspace->workspaceId);
            $this->assertEquals($originalTenantId, $workspace->tenantId);
            $this->assertEquals($originalSlug, $workspace->slug);
            
            $workspace->activate();
            $this->assertEquals($originalWorkspaceId, $workspace->workspaceId);
            $this->assertEquals($originalTenantId, $workspace->tenantId);
            $this->assertEquals($originalSlug, $workspace->slug);
        });
    }
}
