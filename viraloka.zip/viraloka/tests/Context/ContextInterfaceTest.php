<?php

namespace Viraloka\Tests\Context;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Context\ContextInterface;

/**
 * Unit Tests for Context Interface
 * 
 * Tests that concrete implementations of ContextInterface
 * properly implement the contract.
 * 
 * Validates: Requirements 3.1, 3.2, 3.3
 */
class ContextInterfaceTest extends TestCase
{
    /**
     * Test that ContextInterface defines required methods
     * 
     * This test verifies the interface contract exists and has
     * the correct method signatures.
     */
    public function testContextInterfaceDefinesRequiredMethods(): void
    {
        $reflection = new \ReflectionClass(ContextInterface::class);
        
        // Verify interface exists
        $this->assertTrue($reflection->isInterface());
        
        // Verify getKey() method exists
        $this->assertTrue($reflection->hasMethod('getKey'));
        $getKeyMethod = $reflection->getMethod('getKey');
        $this->assertTrue($getKeyMethod->isPublic());
        $this->assertEquals('string', (string) $getKeyMethod->getReturnType());
        
        // Verify getPriority() method exists
        $this->assertTrue($reflection->hasMethod('getPriority'));
        $getPriorityMethod = $reflection->getMethod('getPriority');
        $this->assertTrue($getPriorityMethod->isPublic());
        $this->assertEquals('int', (string) $getPriorityMethod->getReturnType());
        
        // Verify getMetadata() method exists
        $this->assertTrue($reflection->hasMethod('getMetadata'));
        $getMetadataMethod = $reflection->getMethod('getMetadata');
        $this->assertTrue($getMetadataMethod->isPublic());
        $this->assertEquals('array', (string) $getMetadataMethod->getReturnType());
    }
    
    /**
     * Test that a mock implementation can satisfy the interface
     * 
     * This verifies that the interface can be implemented correctly.
     */
    public function testMockImplementationSatisfiesInterface(): void
    {
        $mockContext = new class implements ContextInterface {
            public function getKey(): string
            {
                return 'test-context';
            }
            
            public function getPriority(): int
            {
                return 50;
            }
            
            public function getMetadata(): array
            {
                return ['source' => 'test'];
            }
        };
        
        $this->assertInstanceOf(ContextInterface::class, $mockContext);
        $this->assertEquals('test-context', $mockContext->getKey());
        $this->assertEquals(50, $mockContext->getPriority());
        $this->assertEquals(['source' => 'test'], $mockContext->getMetadata());
    }
}
