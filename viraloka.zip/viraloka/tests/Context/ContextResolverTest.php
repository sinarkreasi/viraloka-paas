<?php

namespace Viraloka\Tests\Context;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\RecommendationGraph;
use Viraloka\Core\Context\WorkspaceContext;
use Viraloka\Core\Context\ThemeContext;
use Viraloka\Core\Context\SystemDefaultContext;
use Viraloka\Core\Workspace\WorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Theme\ThemeIntegration;

/**
 * Unit Tests for Context Resolver
 * 
 * Tests the core resolution logic for the Context Resolver system.
 * Validates resolution flow, query methods, and caching behavior.
 * 
 * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6, 1.7, 5.1
 */
class ContextResolverTest extends TestCase
{
    private Application $app;
    
    protected function setUp(): void
    {
        parent::setUp();
        $this->app = new Application(__DIR__);
    }
    
    protected function tearDown(): void
    {
        parent::tearDown();
        // Clean up server variables
        unset($_SERVER['HTTP_HOST']);
        unset($_SERVER['SERVER_NAME']);
        unset($_SERVER['REQUEST_URI']);
    }
    
    /**
     * Test resolution with workspace, theme, and default contexts
     * 
     * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6
     */
    public function testResolveWithWorkspaceThemeAndDefault(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_marketplace',
                'name' => 'Marketplace Workspace',
                'domain' => 'marketplace.example.com',
                'context' => 'marketplace',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        // Simulate domain
        $_SERVER['HTTP_HOST'] = 'marketplace.example.com';
        
        // Setup theme with context
        $themeProvider = new ThemeIntegration($this->app);
        $themeProvider->registerUIHints(['context' => 'ecommerce']);
        
        // Create resolver
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Resolve context
        $stack = $resolver->resolve();
        
        // Verify stack contains all three contexts
        $contexts = $stack->getAll();
        $this->assertCount(3, $contexts);
        
        // Verify order: workspace (100), theme (50), default (10)
        $this->assertEquals('marketplace', $contexts[0]->getKey());
        $this->assertEquals(100, $contexts[0]->getPriority());
        
        $this->assertEquals('ecommerce', $contexts[1]->getKey());
        $this->assertEquals(50, $contexts[1]->getPriority());
        
        $this->assertEquals('default', $contexts[2]->getKey());
        $this->assertEquals(10, $contexts[2]->getPriority());
        
        // Verify primary context is workspace
        $primary = $stack->getPrimary();
        $this->assertNotNull($primary);
        $this->assertEquals('marketplace', $primary->getKey());
    }
    
    /**
     * Test resolution with only workspace and default
     * 
     * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6
     */
    public function testResolveWithWorkspaceAndDefault(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_blog',
                'name' => 'Blog Workspace',
                'domain' => 'blog.example.com',
                'context' => 'blog',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'blog.example.com';
        
        // Theme without context
        $themeProvider = new ThemeIntegration($this->app);
        
        // Create resolver
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Resolve context
        $stack = $resolver->resolve();
        
        // Verify stack contains workspace and default
        $contexts = $stack->getAll();
        $this->assertCount(2, $contexts);
        
        $this->assertEquals('blog', $contexts[0]->getKey());
        $this->assertEquals('default', $contexts[1]->getKey());
    }
    
    /**
     * Test resolution with only theme and default
     * 
     * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6
     */
    public function testResolveWithThemeAndDefault(): void
    {
        // Workspace without context (default workspace)
        $workspaceResolver = new WorkspaceResolver($this->app);
        
        // Theme with context
        $themeProvider = new ThemeIntegration($this->app);
        $themeProvider->registerUIHints(['context' => 'portfolio']);
        
        // Create resolver
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Resolve context
        $stack = $resolver->resolve();
        
        // Verify stack contains theme and default
        $contexts = $stack->getAll();
        $this->assertCount(2, $contexts);
        
        $this->assertEquals('portfolio', $contexts[0]->getKey());
        $this->assertEquals('default', $contexts[1]->getKey());
    }
    
    /**
     * Test resolution with only default context
     * 
     * Requirements: 1.1, 1.2, 1.3, 1.5, 1.6
     */
    public function testResolveWithOnlyDefault(): void
    {
        // Workspace without context
        $workspaceResolver = new WorkspaceResolver($this->app);
        
        // Theme without context
        $themeProvider = new ThemeIntegration($this->app);
        
        // Create resolver
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Resolve context
        $stack = $resolver->resolve();
        
        // Verify stack contains only default
        $contexts = $stack->getAll();
        $this->assertCount(1, $contexts);
        
        $this->assertEquals('default', $contexts[0]->getKey());
        $this->assertEquals(10, $contexts[0]->getPriority());
    }
    
    /**
     * Test getContextStack() method
     * 
     * Requirements: 1.7, 5.1
     */
    public function testGetContextStack(): void
    {
        $workspaceResolver = new WorkspaceResolver($this->app);
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get context stack (should trigger resolve)
        $stack = $resolver->getContextStack();
        
        $this->assertNotNull($stack);
        $this->assertTrue($stack->isFrozen());
        $this->assertGreaterThan(0, count($stack->getAll()));
    }
    
    /**
     * Test getPrimaryContext() method
     * 
     * Requirements: 1.7, 5.1
     */
    public function testGetPrimaryContext(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_test',
                'name' => 'Test Workspace',
                'domain' => 'test.example.com',
                'context' => 'test-context',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'test.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get primary context
        $primary = $resolver->getPrimaryContext();
        
        $this->assertNotNull($primary);
        $this->assertEquals('test-context', $primary->getKey());
        $this->assertEquals(100, $primary->getPriority());
    }
    
    /**
     * Test getRecommendations() method
     * 
     * Requirements: 1.7, 5.1
     */
    public function testGetRecommendations(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_marketplace',
                'name' => 'Marketplace',
                'domain' => 'marketplace.example.com',
                'context' => 'marketplace',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'marketplace.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        // Register recommendations for marketplace context
        $recommendationGraph->register('marketplace', [
            'recommended_modules' => ['payment', 'inventory', 'shipping'],
            'optional_integrations' => ['analytics', 'email'],
            'ui_hints' => [
                'show_product_grid' => true,
                'enable_cart' => true
            ]
        ]);
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get recommendations
        $recommendations = $resolver->getRecommendations();
        
        $this->assertIsArray($recommendations);
        $this->assertArrayHasKey('recommended_modules', $recommendations);
        $this->assertArrayHasKey('optional_integrations', $recommendations);
        $this->assertArrayHasKey('ui_hints', $recommendations);
        
        $this->assertEquals(['payment', 'inventory', 'shipping'], $recommendations['recommended_modules']);
        $this->assertEquals(['analytics', 'email'], $recommendations['optional_integrations']);
        $this->assertTrue($recommendations['ui_hints']['show_product_grid']);
    }
    
    /**
     * Test getRecommendations() with no recommendations
     * 
     * Requirements: 1.7, 5.1
     */
    public function testGetRecommendationsWithNoRecommendations(): void
    {
        $workspaceResolver = new WorkspaceResolver($this->app);
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get recommendations (none registered)
        $recommendations = $resolver->getRecommendations();
        
        $this->assertIsArray($recommendations);
        $this->assertEmpty($recommendations);
    }
    
    /**
     * Test context caching behavior
     * 
     * Requirements: 1.7
     */
    public function testContextCaching(): void
    {
        $workspaceResolver = new WorkspaceResolver($this->app);
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // First call
        $stack1 = $resolver->getContextStack();
        
        // Second call should return same instance
        $stack2 = $resolver->getContextStack();
        
        $this->assertSame($stack1, $stack2);
    }

    /**
     * Test module can check if specific context is active
     * 
     * Requirements: 5.1, 5.3
     */
    public function testIsContextActive(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_marketplace',
                'name' => 'Marketplace',
                'domain' => 'marketplace.example.com',
                'context' => 'marketplace',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'marketplace.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $themeProvider->registerUIHints(['context' => 'ecommerce']);
        
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Check active contexts
        $this->assertTrue($resolver->isContextActive('marketplace'));
        $this->assertTrue($resolver->isContextActive('ecommerce'));
        $this->assertTrue($resolver->isContextActive('default'));
        $this->assertFalse($resolver->isContextActive('nonexistent'));
    }
    
    /**
     * Test module can get all active contexts
     * 
     * Requirements: 5.1, 5.3, 5.4
     */
    public function testGetActiveContexts(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_blog',
                'name' => 'Blog',
                'domain' => 'blog.example.com',
                'context' => 'blog',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'blog.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $themeProvider->registerUIHints(['context' => 'portfolio']);
        
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get all active contexts
        $contexts = $resolver->getActiveContexts();
        
        $this->assertIsArray($contexts);
        $this->assertCount(3, $contexts);
        $this->assertEquals(['blog', 'portfolio', 'default'], $contexts);
    }
    
    /**
     * Test module can get context metadata
     * 
     * Requirements: 5.1, 5.3
     */
    public function testGetContextMetadata(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_test',
                'name' => 'Test Workspace',
                'domain' => 'test.example.com',
                'context' => 'test-context',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'test.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get metadata for workspace context
        $metadata = $resolver->getContextMetadata('test-context');
        
        $this->assertIsArray($metadata);
        $this->assertArrayHasKey('workspace_id', $metadata);
        $this->assertArrayHasKey('workspace_name', $metadata);
        $this->assertEquals('ws_test', $metadata['workspace_id']);
        $this->assertEquals('Test Workspace', $metadata['workspace_name']);
        
        // Get metadata for non-existent context
        $nullMetadata = $resolver->getContextMetadata('nonexistent');
        $this->assertNull($nullMetadata);
    }
    
    /**
     * Test theme can register recommendations
     * 
     * Requirements: 6.1, 6.2
     */
    public function testRegisterThemeRecommendations(): void
    {
        $workspaceResolver = new WorkspaceResolver($this->app);
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Theme registers recommendations
        $resolver->registerThemeRecommendations('ecommerce', [
            'recommended_modules' => ['payment', 'cart'],
            'optional_integrations' => ['shipping'],
            'ui_hints' => ['layout' => 'grid']
        ]);
        
        // Verify recommendations were registered
        $recommendations = $recommendationGraph->getRecommendations('ecommerce');
        
        $this->assertIsArray($recommendations);
        $this->assertEquals(['payment', 'cart'], $recommendations['recommended_modules']);
        $this->assertEquals(['shipping'], $recommendations['optional_integrations']);
        $this->assertEquals(['layout' => 'grid'], $recommendations['ui_hints']);
    }
    
    /**
     * Test theme can get context information
     * 
     * Requirements: 6.3, 6.4
     */
    public function testGetThemeContextInfo(): void
    {
        // Setup workspace with context
        $workspaceResolver = new WorkspaceResolver($this->app);
        $workspaceResolver->setWorkspaceConfig([
            [
                'id' => 'ws_marketplace',
                'name' => 'Marketplace',
                'domain' => 'marketplace.example.com',
                'context' => 'marketplace',
                'enabled_modules' => [],
                'config' => []
            ]
        ]);
        
        $_SERVER['HTTP_HOST'] = 'marketplace.example.com';
        
        $themeProvider = new ThemeIntegration($this->app);
        $themeProvider->registerUIHints(['context' => 'ecommerce']);
        
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        // Register recommendations
        $recommendationGraph->register('marketplace', [
            'recommended_modules' => ['payment'],
            'optional_integrations' => [],
            'ui_hints' => []
        ]);
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Get theme context info
        $info = $resolver->getThemeContextInfo();
        
        $this->assertIsArray($info);
        $this->assertArrayHasKey('primary_context', $info);
        $this->assertArrayHasKey('all_contexts', $info);
        $this->assertArrayHasKey('recommendations', $info);
        
        $this->assertEquals('marketplace', $info['primary_context']);
        $this->assertEquals(['marketplace', 'ecommerce', 'default'], $info['all_contexts']);
        $this->assertEquals(['payment'], $info['recommendations']['recommended_modules']);
    }
    
    /**
     * Test theme cannot register context after resolution
     * 
     * Requirements: 6.1, 6.3
     */
    public function testRegisterThemeContextAfterResolution(): void
    {
        $workspaceResolver = new WorkspaceResolver($this->app);
        $themeProvider = new ThemeIntegration($this->app);
        $stackBuilder = new ContextStackBuilder();
        $recommendationGraph = new RecommendationGraph();
        
        $resolver = new ContextResolver(
            $workspaceResolver,
            $themeProvider,
            $stackBuilder,
            $recommendationGraph
        );
        
        // Trigger resolution
        $resolver->resolve();
        
        // Attempt to register theme context after resolution
        $result = $resolver->registerThemeContext('ecommerce');
        
        // Should return false
        $this->assertFalse($result);
    }
}
