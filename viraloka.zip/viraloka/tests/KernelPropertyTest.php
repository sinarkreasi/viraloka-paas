<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\Kernel;

/**
 * Kernel Property Test
 * 
 * Property-based tests for the Kernel class.
 * Each test runs multiple iterations with different inputs to verify
 * universal properties hold across all executions.
 * 
 * Feature: core-bootstrap-flow
 */
class KernelPropertyTest extends TestCase
{
    /**
     * Recursively delete a directory
     * 
     * @param string $dir
     * @return void
     */
    private function deleteDirectory(string $dir): void
    {
        if (!file_exists($dir)) {
            return;
        }
        
        if (!is_dir($dir)) {
            unlink($dir);
            return;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . DIRECTORY_SEPARATOR . $file;
            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                unlink($path);
            }
        }
        rmdir($dir);
    }
    
    /**
     * Property 3: Lifecycle Method Execution Order
     * 
     * For any bootstrap execution, the Kernel SHALL execute lifecycle
     * methods in the exact order: register(), boot(), ready().
     * 
     * Validates: Requirements 2.4
     * Feature: core-bootstrap-flow, Property 3: Lifecycle Method Execution Order
     */
    public function testProperty3LifecycleMethodExecutionOrder(): void
    {
        // Run property test 100 times with different application instances
        for ($i = 0; $i < 100; $i++) {
            // Reset WordPress actions global
            global $wp_actions;
            $wp_actions = [];
            
            // Create unique application instance
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $kernel = new Kernel($app);
            
            // Bootstrap the kernel
            $kernel->bootstrap();
            
            // Verify events were dispatched in correct order
            $this->assertEquals(1, did_action('viraloka.bootstrap.register'), 
                "Iteration {$i}: register event should be dispatched exactly once");
            $this->assertEquals(1, did_action('viraloka.bootstrap.boot'), 
                "Iteration {$i}: boot event should be dispatched exactly once");
            $this->assertEquals(1, did_action('viraloka.bootstrap.ready'), 
                "Iteration {$i}: ready event should be dispatched exactly once");
            
            // Verify the order by checking the global actions array
            $actionKeys = array_keys($wp_actions);
            $registerIndex = array_search('viraloka.bootstrap.register', $actionKeys);
            $bootIndex = array_search('viraloka.bootstrap.boot', $actionKeys);
            $readyIndex = array_search('viraloka.bootstrap.ready', $actionKeys);
            
            $this->assertNotFalse($registerIndex, "Iteration {$i}: register event should exist");
            $this->assertNotFalse($bootIndex, "Iteration {$i}: boot event should exist");
            $this->assertNotFalse($readyIndex, "Iteration {$i}: ready event should exist");
            
            $this->assertLessThan($bootIndex, $registerIndex, 
                "Iteration {$i}: register must come before boot");
            $this->assertLessThan($readyIndex, $bootIndex, 
                "Iteration {$i}: boot must come before ready");
            
            // Clean up
            $this->deleteDirectory($basePath);
        }
    }
    
    /**
     * Property 26: Bootstrap Idempotence
     * 
     * For any number of bootstrap() calls on the Kernel, only the first
     * call SHALL execute the bootstrap sequence.
     * 
     * Validates: Requirements 11.5
     * Feature: core-bootstrap-flow, Property 26: Bootstrap Idempotence
     */
    public function testProperty26BootstrapIdempotence(): void
    {
        // Run property test 100 times with varying number of bootstrap calls
        for ($i = 0; $i < 100; $i++) {
            // Reset WordPress actions global
            global $wp_actions;
            $wp_actions = [];
            
            // Create unique application instance
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $kernel = new Kernel($app);
            
            // Call bootstrap a random number of times (2-10)
            $numCalls = rand(2, 10);
            for ($j = 0; $j < $numCalls; $j++) {
                $kernel->bootstrap();
            }
            
            // Verify each event was only dispatched once, regardless of how many times bootstrap was called
            $this->assertEquals(1, did_action('viraloka.bootstrap.register'), 
                "Iteration {$i} with {$numCalls} calls: register event should be dispatched exactly once");
            $this->assertEquals(1, did_action('viraloka.bootstrap.boot'), 
                "Iteration {$i} with {$numCalls} calls: boot event should be dispatched exactly once");
            $this->assertEquals(1, did_action('viraloka.bootstrap.ready'), 
                "Iteration {$i} with {$numCalls} calls: ready event should be dispatched exactly once");
            
            // Verify bootstrapped flag is set
            $this->assertTrue($kernel->isBootstrapped(), 
                "Iteration {$i}: kernel should be marked as bootstrapped");
            
            // Clean up
            $this->deleteDirectory($basePath);
        }
    }
    
    /**
     * Property 25: Event Listener Notification
     * 
     * For any registered event listeners, the Event Dispatcher SHALL notify
     * all listeners when the corresponding event is dispatched.
     * 
     * Validates: Requirements 11.2
     * Feature: core-bootstrap-flow, Property 25: Event Listener Notification
     */
    public function testProperty25EventListenerNotification(): void
    {
        // Run property test 100 times with varying number of listeners
        for ($i = 0; $i < 100; $i++) {
            // Reset WordPress actions global
            global $wp_actions, $wp_filter;
            $wp_actions = [];
            $wp_filter = [];
            
            // Create unique application instance
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $kernel = new Kernel($app);
            
            // Register a random number of listeners (1-10) for the viraloka.ready event
            $numListeners = rand(1, 10);
            $listenersCalled = [];
            
            for ($j = 0; $j < $numListeners; $j++) {
                $listenersCalled[$j] = false;
                
                add_action('viraloka.ready', function() use (&$listenersCalled, $j) {
                    $listenersCalled[$j] = true;
                });
            }
            
            // Bootstrap the kernel (which should dispatch viraloka.ready)
            $kernel->bootstrap();
            
            // Verify all listeners were called
            for ($j = 0; $j < $numListeners; $j++) {
                $this->assertTrue($listenersCalled[$j], 
                    "Iteration {$i}: Listener {$j} of {$numListeners} should have been called");
            }
            
            // Verify the ready event was dispatched
            $this->assertEquals(1, did_action('viraloka.ready'), 
                "Iteration {$i}: viraloka.ready event should be dispatched exactly once");
            
            // Clean up
            $this->deleteDirectory($basePath);
        }
    }
}
