<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Integration\WordPressHooks;
use Viraloka\Core\Adapter\AdapterRegistry;
use Viraloka\Adapter\Testing\MockEventAdapter;
use Viraloka\Adapter\Testing\InMemoryStorageAdapter;
use Viraloka\Adapter\Testing\NullRuntimeAdapter;
use Viraloka\Core\Adapter\ValueObjects\User;
use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface;
use Viraloka\Core\Adapter\Contracts\RequestAdapterInterface;
use Viraloka\Core\Adapter\Contracts\ResponseAdapterInterface;
use Viraloka\Core\Modules\Logger;

/**
 * Test suite for WordPressHooks adapter refactoring
 * 
 * Verifies that WordPressHooks correctly uses adapters instead of
 * direct WordPress function calls.
 */
class WordPressHooksAdapterTest extends TestCase
{
    private Application $app;
    private AdapterRegistry $registry;
    
    protected function setUp(): void
    {
        $this->app = new Application(__DIR__ . '/..');
        $this->registry = new AdapterRegistry();
        
        // Register test adapters
        $this->registry->registerRuntime(new NullRuntimeAdapter());
        $this->registry->registerEvent(new MockEventAdapter());
        $this->registry->registerAuth($this->createMockAuthAdapter());
        $this->registry->registerStorage(new InMemoryStorageAdapter());
        $this->registry->registerRequest($this->createMockRequestAdapter());
        $this->registry->registerResponse($this->createMockResponseAdapter());
        
        $this->app->instance(\Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface::class, $this->registry);
        $this->app->instance(Logger::class, new Logger());
    }
    
    public function testWordPressHooksCanBeInstantiatedWithAdapters(): void
    {
        $hooks = new WordPressHooks($this->app);
        
        $this->assertInstanceOf(WordPressHooks::class, $hooks);
        $this->assertFalse($hooks->isRegistered());
    }
    
    public function testHooksCanBeRegisteredUsingAdapters(): void
    {
        $hooks = new WordPressHooks($this->app);
        $hooks->register();
        
        $this->assertTrue($hooks->isRegistered());
    }
    
    public function testEventAdapterIsUsedForHookRegistration(): void
    {
        $hooks = new WordPressHooks($this->app);
        $hooks->register();
        
        $eventAdapter = $this->registry->event();
        
        // Verify WordPress hooks were registered via EventAdapter
        $this->assertTrue($eventAdapter->hasListeners('wp_login'));
        $this->assertTrue($eventAdapter->hasListeners('user_register'));
        $this->assertTrue($eventAdapter->hasListeners('wp_logout'));
    }
    
    public function testStorageAdapterIsAvailableForCaching(): void
    {
        $hooks = new WordPressHooks($this->app);
        $storageAdapter = $this->registry->storage();
        
        // Verify storage adapter is available
        $this->assertInstanceOf(\Viraloka\Core\Adapter\Contracts\StorageAdapterInterface::class, $storageAdapter);
        
        // Test storage operations
        $storageAdapter->set('test_key', 'test_value', 3600);
        $this->assertTrue($storageAdapter->has('test_key'));
        $this->assertEquals('test_value', $storageAdapter->get('test_key'));
        
        $storageAdapter->delete('test_key');
        $this->assertFalse($storageAdapter->has('test_key'));
    }
    
    public function testAuthAdapterIsUsedForUserOperations(): void
    {
        $hooks = new WordPressHooks($this->app);
        $authAdapter = $this->registry->auth();
        
        // Initially not authenticated
        $this->assertFalse($authAdapter->isAuthenticated());
        $this->assertNull($authAdapter->currentUser());
        
        // Set a user
        $user = new User('123', 'test@example.com', 'Test User', ['subscriber']);
        $authAdapter->setUser($user);
        
        // Now authenticated
        $this->assertTrue($authAdapter->isAuthenticated());
        $this->assertNotNull($authAdapter->currentUser());
        $this->assertEquals('123', $authAdapter->currentUser()->id);
    }
    
    public function testNoDirectWordPressFunctionCalls(): void
    {
        $source = file_get_contents(__DIR__ . '/../src/Core/Integration/WordPressHooks.php');
        
        // Check for direct WordPress calls that should be replaced
        $this->assertStringNotContainsString('add_action(', $source, 'Should use EventAdapter::listen instead of add_action');
        $this->assertStringNotContainsString('do_action(', $source, 'Should use EventAdapter::dispatch instead of do_action');
        $this->assertStringNotContainsString('is_user_logged_in()', $source, 'Should use AuthAdapter::isAuthenticated instead');
        $this->assertStringNotContainsString('get_current_user_id()', $source, 'Should use AuthAdapter::currentUser()->id instead');
        $this->assertStringNotContainsString('wp_cache_set(', $source, 'Should use StorageAdapter::set instead');
        $this->assertStringNotContainsString('wp_cache_delete(', $source, 'Should use StorageAdapter::delete instead');
    }
    
    public function testAdapterInterfacesAreUsed(): void
    {
        $source = file_get_contents(__DIR__ . '/../src/Core/Integration/WordPressHooks.php');
        
        // Verify adapter interfaces are imported
        $this->assertStringContainsString('use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface', $source);
        $this->assertStringContainsString('use Viraloka\Core\Adapter\Contracts\EventAdapterInterface', $source);
        $this->assertStringContainsString('use Viraloka\Core\Adapter\Contracts\AuthAdapterInterface', $source);
        $this->assertStringContainsString('use Viraloka\Core\Adapter\Contracts\StorageAdapterInterface', $source);
    }
    
    private function createMockAuthAdapter(): AuthAdapterInterface
    {
        return new class implements AuthAdapterInterface {
            private ?User $user = null;
            
            public function setUser(?User $user): void
            {
                $this->user = $user;
            }
            
            public function currentUser(): ?User
            {
                return $this->user;
            }
            
            public function isAuthenticated(): bool
            {
                return $this->user !== null;
            }
            
            public function hasPermission(string $permission): bool
            {
                return $this->isAuthenticated();
            }
            
            public function hasRole(string $role): bool
            {
                return $this->isAuthenticated();
            }
            
            public function getPermissions(): array
            {
                return [];
            }
            
            public function getRoles(): array
            {
                return [];
            }
        };
    }
    
    private function createMockRequestAdapter(): RequestAdapterInterface
    {
        return new class implements RequestAdapterInterface {
            public function getMethod(): string { return 'GET'; }
            public function getPath(): string { return '/'; }
            public function getHeaders(): array { return []; }
            public function getHeader(string $name, ?string $default = null): ?string { return $default; }
            public function getBody(): mixed { return []; }
            public function getRawBody(): string { return ''; }
            public function getQuery(): array { return []; }
            public function getQueryParam(string $key, mixed $default = null): mixed { return $default; }
            public function getPost(): array { return []; }
            public function getUrl(): string { return 'http://localhost'; }
        };
    }
    
    private function createMockResponseAdapter(): ResponseAdapterInterface
    {
        return new class implements ResponseAdapterInterface {
            public function send(mixed $data, int $status = 200, array $headers = []): void {}
            public function json(mixed $data, int $status = 200, array $headers = []): void {}
            public function html(string $html, int $status = 200, array $headers = []): void {}
            public function redirect(string $url, int $status = 302): void {}
            public function setHeader(string $name, string $value): void {}
        };
    }
}
