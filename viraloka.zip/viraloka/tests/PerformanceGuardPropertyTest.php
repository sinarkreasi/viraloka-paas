<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Bootstrap\PerformanceGuard;

/**
 * PerformanceGuard Property Test
 * 
 * Property-based tests for the PerformanceGuard class.
 * Each test runs multiple iterations with different inputs to verify
 * universal properties hold across all executions.
 * 
 * Feature: core-bootstrap-flow
 */
class PerformanceGuardPropertyTest extends TestCase
{
    /**
     * Property 9: Non-Essential Hook Deferral
     * 
     * For any hook marked as non-essential, the Performance Guard SHALL defer
     * its execution to after bootstrap completion.
     * 
     * Validates: Requirements 5.3
     * Feature: core-bootstrap-flow, Property 9: Non-Essential Hook Deferral
     */
    public function testProperty9NonEssentialHookDeferral(): void
    {
        // Run property test 100 times with different hook scenarios
        for ($i = 0; $i < 100; $i++) {
            // Create application and performance guard
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $guard = new PerformanceGuard($app);
            $guard->activate();
            
            // Generate random hook name
            $hookName = 'test_hook_' . uniqid();
            
            // Track if callback was executed
            $callbackExecuted = false;
            $callback = function() use (&$callbackExecuted) {
                $callbackExecuted = true;
            };
            
            // Defer the hook
            $guard->deferHook($hookName, $callback);
            
            // Verify hook is deferred (not executed immediately)
            $this->assertFalse($callbackExecuted,
                "Iteration {$i}: Hook {$hookName} should not be executed immediately when deferred");
            
            // Verify hook is stored in deferred hooks
            $deferredHooks = $guard->getDeferredHooks();
            $this->assertArrayHasKey($hookName, $deferredHooks,
                "Iteration {$i}: Hook {$hookName} should be stored in deferred hooks");
            
            $this->assertCount(1, $deferredHooks[$hookName],
                "Iteration {$i}: Hook {$hookName} should have one deferred callback");
            
            // Verify callback is stored correctly
            $this->assertSame($callback, $deferredHooks[$hookName][0]['callback'],
                "Iteration {$i}: Stored callback should match the original callback");
            
            // Clean up
            rmdir($basePath);
        }
    }
    
    /**
     * Property 10: Heavy Operation Prevention
     * 
     * For any operation classified as heavy (UI rendering, asset loading,
     * business logic, cron jobs), the Kernel SHALL prevent its execution
     * during bootstrap.
     * 
     * Validates: Requirements 5.4, 15.1, 15.2, 15.3, 15.4
     * Feature: core-bootstrap-flow, Property 10: Heavy Operation Prevention
     */
    public function testProperty10HeavyOperationPrevention(): void
    {
        // Run property test 100 times with different operation scenarios
        for ($i = 0; $i < 100; $i++) {
            // Create application and performance guard
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $guard = new PerformanceGuard($app);
            $guard->activate();
            
            // Test all heavy operations are blocked when guard is active
            $heavyOperations = [
                'render_ui',
                'load_assets',
                'execute_business_logic',
                'run_cron',
            ];
            
            foreach ($heavyOperations as $operation) {
                // Verify operation is blocked
                $this->assertTrue($guard->isOperationBlocked($operation),
                    "Iteration {$i}: Heavy operation '{$operation}' should be blocked when guard is active");
                
                // Verify preventHeavyOperation throws exception
                $exceptionThrown = false;
                try {
                    $guard->preventHeavyOperation($operation);
                } catch (\RuntimeException $e) {
                    $exceptionThrown = true;
                    $this->assertStringContainsString($operation, $e->getMessage(),
                        "Iteration {$i}: Exception message should mention the blocked operation");
                }
                
                $this->assertTrue($exceptionThrown,
                    "Iteration {$i}: preventHeavyOperation should throw exception for '{$operation}'");
            }
            
            // Test that non-heavy operations are not blocked
            $nonHeavyOperations = [
                'register_service',
                'resolve_context',
                'validate_manifest',
                'custom_operation_' . uniqid(),
            ];
            
            foreach ($nonHeavyOperations as $operation) {
                $this->assertFalse($guard->isOperationBlocked($operation),
                    "Iteration {$i}: Non-heavy operation '{$operation}' should not be blocked");
                
                // Verify preventHeavyOperation does not throw exception
                $exceptionThrown = false;
                try {
                    $guard->preventHeavyOperation($operation);
                } catch (\RuntimeException $e) {
                    $exceptionThrown = true;
                }
                
                $this->assertFalse($exceptionThrown,
                    "Iteration {$i}: preventHeavyOperation should not throw exception for non-heavy operation '{$operation}'");
            }
            
            // Clean up
            rmdir($basePath);
        }
    }
    
    /**
     * Property 33: Heavy Operation Detection and Deferral
     * 
     * For any heavy operation detected during bootstrap, the Performance Guard
     * SHALL log a warning and defer its execution.
     * 
     * Validates: Requirements 15.5
     * Feature: core-bootstrap-flow, Property 33: Heavy Operation Detection and Deferral
     */
    public function testProperty33HeavyOperationDetectionAndDeferral(): void
    {
        // Run property test 100 times with different operation scenarios
        for ($i = 0; $i < 100; $i++) {
            // Create application and performance guard
            $basePath = sys_get_temp_dir() . '/viraloka-test-' . uniqid();
            mkdir($basePath, 0777, true);
            
            $app = new Application($basePath);
            $guard = new PerformanceGuard($app);
            $guard->activate();
            
            // Capture error log output to verify warning logging
            $logFile = sys_get_temp_dir() . '/test-error-' . uniqid() . '.log';
            $originalErrorLog = ini_get('error_log');
            ini_set('error_log', $logFile);
            
            // Test heavy operations
            $heavyOperations = [
                'render_ui',
                'load_assets',
                'execute_business_logic',
                'run_cron',
            ];
            
            foreach ($heavyOperations as $operation) {
                // Clear log file
                if (file_exists($logFile)) {
                    unlink($logFile);
                }
                
                // Attempt to execute heavy operation
                $exceptionThrown = false;
                try {
                    $guard->preventHeavyOperation($operation);
                } catch (\RuntimeException $e) {
                    $exceptionThrown = true;
                }
                
                // Verify exception was thrown (operation was deferred/blocked)
                $this->assertTrue($exceptionThrown,
                    "Iteration {$i}: Heavy operation '{$operation}' should be blocked");
                
                // Verify warning was logged
                $this->assertFileExists($logFile,
                    "Iteration {$i}: Log file should exist after heavy operation detection");
                
                $logContent = file_get_contents($logFile);
                $this->assertStringContainsString('Heavy operation blocked', $logContent,
                    "Iteration {$i}: Log should contain warning about blocked operation");
                $this->assertStringContainsString($operation, $logContent,
                    "Iteration {$i}: Log should mention the specific operation '{$operation}'");
            }
            
            // Clean up
            ini_set('error_log', $originalErrorLog);
            if (file_exists($logFile)) {
                unlink($logFile);
            }
            rmdir($basePath);
        }
    }
}
