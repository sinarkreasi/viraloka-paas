<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Workspace\Repositories\TenantRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceUserRoleRepository;
use Viraloka\Core\Workspace\Tenant;
use Viraloka\Core\Workspace\Workspace;
use Viraloka\Core\Workspace\WorkspaceUserRole;
use Viraloka\Core\Workspace\Exceptions\DuplicateSlugException;
use Viraloka\Core\Workspace\Exceptions\DuplicateDomainException;
use Viraloka\Core\Workspace\Exceptions\InvalidRoleException;

/**
 * Repository Integration Tests
 * 
 * Tests the repository implementations with actual database operations.
 * Requires database tables to be created before running.
 */
class WorkspaceRepositoryTest extends TestCase
{
    private TenantRepository $tenantRepo;
    private WorkspaceRepository $workspaceRepo;
    private WorkspaceUserRoleRepository $roleRepo;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->tenantRepo = new TenantRepository();
        $this->workspaceRepo = new WorkspaceRepository();
        $this->roleRepo = new WorkspaceUserRoleRepository();
        
        // Clean up test data
        $this->cleanupTestData();
    }
    
    protected function tearDown(): void
    {
        $this->cleanupTestData();
        parent::tearDown();
    }
    
    private function cleanupTestData(): void
    {
        global $wpdb;
        
        // Delete test data (in reverse dependency order)
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_workspace_user_roles WHERE workspace_id LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_workspaces WHERE workspace_id LIKE 'test-%' OR slug LIKE 'test-%'");
        $wpdb->query("DELETE FROM {$wpdb->prefix}viraloka_tenants WHERE tenant_id LIKE 'test-%' OR name LIKE 'Test %'");
    }
    
    public function testTenantCreate(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        
        $this->assertNotEmpty($tenant->tenantId);
        $this->assertEquals('Test Tenant', $tenant->name);
        $this->assertEquals(1, $tenant->ownerUserId);
        $this->assertEquals(Tenant::STATUS_ACTIVE, $tenant->status);
        $this->assertInstanceOf(\DateTimeImmutable::class, $tenant->createdAt);
    }
    
    public function testTenantFindById(): void
    {
        $created = $this->tenantRepo->create('Test Tenant', 1);
        $found = $this->tenantRepo->findById($created->tenantId);
        
        $this->assertNotNull($found);
        $this->assertEquals($created->tenantId, $found->tenantId);
        $this->assertEquals($created->name, $found->name);
        $this->assertEquals($created->ownerUserId, $found->ownerUserId);
    }
    
    public function testTenantFindByOwner(): void
    {
        $tenant1 = $this->tenantRepo->create('Test Tenant 1', 1);
        $tenant2 = $this->tenantRepo->create('Test Tenant 2', 1);
        $tenant3 = $this->tenantRepo->create('Test Tenant 3', 2);
        
        $user1Tenants = $this->tenantRepo->findByOwner(1);
        
        $this->assertCount(2, $user1Tenants);
        $this->assertEquals($tenant2->tenantId, $user1Tenants[0]->tenantId); // Most recent first
        $this->assertEquals($tenant1->tenantId, $user1Tenants[1]->tenantId);
    }
    
    public function testTenantUpdate(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $tenant->name = 'Updated Tenant';
        
        $result = $this->tenantRepo->update($tenant);
        $this->assertTrue($result);
        
        $updated = $this->tenantRepo->findById($tenant->tenantId);
        $this->assertEquals('Updated Tenant', $updated->name);
    }
    
    public function testTenantSuspend(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        
        $result = $this->tenantRepo->suspend($tenant->tenantId);
        $this->assertTrue($result);
        
        $suspended = $this->tenantRepo->findById($tenant->tenantId);
        $this->assertEquals(Tenant::STATUS_SUSPENDED, $suspended->status);
    }
    
    public function testTenantActivate(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $this->tenantRepo->suspend($tenant->tenantId);
        
        $result = $this->tenantRepo->activate($tenant->tenantId);
        $this->assertTrue($result);
        
        $activated = $this->tenantRepo->findById($tenant->tenantId);
        $this->assertEquals(Tenant::STATUS_ACTIVE, $activated->status);
    }
    
    public function testWorkspaceCreate(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->assertNotEmpty($workspace->workspaceId);
        $this->assertEquals($tenant->tenantId, $workspace->tenantId);
        $this->assertEquals('Test Workspace', $workspace->name);
        $this->assertEquals('test-workspace', $workspace->slug);
        $this->assertEquals(Workspace::STATUS_ACTIVE, $workspace->status);
        $this->assertEquals('default', $workspace->activeContext);
    }
    
    public function testWorkspaceCreateDuplicateSlug(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 1', 'test-workspace');
        
        $this->expectException(DuplicateSlugException::class);
        $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 2', 'test-workspace');
    }
    
    public function testWorkspaceFindById(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $created = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        $found = $this->workspaceRepo->findById($created->workspaceId);
        
        $this->assertNotNull($found);
        $this->assertEquals($created->workspaceId, $found->workspaceId);
        $this->assertEquals($created->name, $found->name);
    }
    
    public function testWorkspaceFindBySlug(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $created = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        $found = $this->workspaceRepo->findBySlug('test-workspace');
        
        $this->assertNotNull($found);
        $this->assertEquals($created->workspaceId, $found->workspaceId);
    }
    
    public function testWorkspaceFindByDomain(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $workspace->setCustomDomain('test.example.com');
        $this->workspaceRepo->update($workspace);
        
        $found = $this->workspaceRepo->findByDomain('test.example.com');
        $this->assertNotNull($found);
        $this->assertEquals($workspace->workspaceId, $found->workspaceId);
    }
    
    public function testWorkspaceFindBySubdomain(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $workspace->setSubdomain('test');
        $this->workspaceRepo->update($workspace);
        
        $found = $this->workspaceRepo->findBySubdomain('test');
        $this->assertNotNull($found);
        $this->assertEquals($workspace->workspaceId, $found->workspaceId);
    }
    
    public function testWorkspaceFindByTenant(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace1 = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 1', 'test-workspace-1');
        $workspace2 = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 2', 'test-workspace-2');
        
        $workspaces = $this->workspaceRepo->findByTenant($tenant->tenantId);
        
        $this->assertCount(2, $workspaces);
        $this->assertEquals($workspace2->workspaceId, $workspaces[0]->workspaceId); // Most recent first
        $this->assertEquals($workspace1->workspaceId, $workspaces[1]->workspaceId);
    }
    
    public function testWorkspaceUpdate(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $workspace->name = 'Updated Workspace';
        $workspace->activeContext = 'custom';
        
        $result = $this->workspaceRepo->update($workspace);
        $this->assertTrue($result);
        
        $updated = $this->workspaceRepo->findById($workspace->workspaceId);
        $this->assertEquals('Updated Workspace', $updated->name);
        $this->assertEquals('custom', $updated->activeContext);
    }
    
    public function testWorkspaceSlugExists(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->assertTrue($this->workspaceRepo->slugExists('test-workspace'));
        $this->assertFalse($this->workspaceRepo->slugExists('non-existent'));
    }
    
    public function testWorkspaceDomainExists(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $workspace->setCustomDomain('test.example.com');
        $this->workspaceRepo->update($workspace);
        
        $this->assertTrue($this->workspaceRepo->domainExists('test.example.com'));
        $this->assertFalse($this->workspaceRepo->domainExists('non-existent.com'));
    }
    
    public function testWorkspaceUserRoleAssign(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $role = $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        $this->assertEquals($workspace->workspaceId, $role->workspaceId);
        $this->assertEquals(1, $role->userId);
        $this->assertEquals(WorkspaceUserRole::ROLE_ADMIN, $role->role);
    }
    
    public function testWorkspaceUserRoleGetUserRole(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        $role = $this->roleRepo->getUserRole($workspace->workspaceId, 1);
        
        $this->assertNotNull($role);
        $this->assertEquals(WorkspaceUserRole::ROLE_ADMIN, $role->role);
    }
    
    public function testWorkspaceUserRoleGetUserWorkspaces(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace1 = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 1', 'test-workspace-1');
        $workspace2 = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace 2', 'test-workspace-2');
        
        $this->roleRepo->assignRole($workspace1->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        $this->roleRepo->assignRole($workspace2->workspaceId, 1, WorkspaceUserRole::ROLE_MEMBER);
        
        $roles = $this->roleRepo->getUserWorkspaces(1);
        
        $this->assertCount(2, $roles);
    }
    
    public function testWorkspaceUserRoleHasAccess(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        $this->assertTrue($this->roleRepo->hasAccess($workspace->workspaceId, 1));
        $this->assertFalse($this->roleRepo->hasAccess($workspace->workspaceId, 999));
    }
    
    public function testWorkspaceUserRoleHasRole(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        $this->assertTrue($this->roleRepo->hasRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN));
        $this->assertFalse($this->roleRepo->hasRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_OWNER));
    }
    
    public function testWorkspaceUserRoleGetWorkspaceOwner(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_OWNER);
        $this->roleRepo->assignRole($workspace->workspaceId, 2, WorkspaceUserRole::ROLE_ADMIN);
        
        $ownerId = $this->roleRepo->getWorkspaceOwner($workspace->workspaceId);
        
        $this->assertEquals(1, $ownerId);
    }
    
    public function testWorkspaceUserRoleUpdateRole(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_MEMBER);
        $result = $this->roleRepo->updateRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        
        $this->assertTrue($result);
        
        $role = $this->roleRepo->getUserRole($workspace->workspaceId, 1);
        $this->assertEquals(WorkspaceUserRole::ROLE_ADMIN, $role->role);
    }
    
    public function testWorkspaceUserRoleRemoveRole(): void
    {
        $tenant = $this->tenantRepo->create('Test Tenant', 1);
        $workspace = $this->workspaceRepo->create($tenant->tenantId, 'Test Workspace', 'test-workspace');
        
        $this->roleRepo->assignRole($workspace->workspaceId, 1, WorkspaceUserRole::ROLE_ADMIN);
        $result = $this->roleRepo->removeRole($workspace->workspaceId, 1);
        
        $this->assertTrue($result);
        
        $role = $this->roleRepo->getUserRole($workspace->workspaceId, 1);
        $this->assertNull($role);
    }
}
