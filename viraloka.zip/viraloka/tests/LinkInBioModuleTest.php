<?php

namespace Viraloka\Tests;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Modules\ModuleLoader;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\DependencyResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\ModuleBootstrapper;
use Viraloka\Core\Modules\ManifestCache;

/**
 * LinkInBio Reference Module Test
 * 
 * Tests that the LinkInBio reference module is:
 * - Discovered by the Module Loader (Requirement 2.1)
 * - Parsed correctly by the Manifest Parser (Requirement 2.5)
 * - Bootstrapped successfully (Requirement 7.1)
 */
class LinkInBioModuleTest extends TestCase
{
    protected string $modulesPath;
    protected ModuleLoader $loader;
    protected ModuleRegistry $registry;
    protected ManifestParser $parser;
    protected ModuleBootstrapper $bootstrapper;
    protected Application $app;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Set up path to actual modules directory
        $this->modulesPath = dirname(__DIR__) . '/viraloka-modules';
        
        // Set up dependencies
        $validator = new SchemaValidator();
        $this->parser = new ManifestParser($validator);
        $this->registry = new ModuleRegistry();
        $dependencyResolver = new DependencyResolver($this->registry, '1.0.0');
        $contextResolver = new ContextResolver();
        $manifestCache = new ManifestCache();
        
        // Create loader
        $this->loader = new ModuleLoader(
            $this->parser,
            $this->registry,
            $dependencyResolver,
            $contextResolver,
            $manifestCache,
            $this->modulesPath
        );
        
        // Create application and bootstrapper
        $this->app = new Application(dirname(__DIR__));
        $this->bootstrapper = new ModuleBootstrapper($this->app, $this->registry);
    }
    
    /**
     * Test that LinkInBio module.json exists and is valid JSON
     * 
     * Validates: Requirements 1.1, 1.2
     */
    public function testModuleManifestExists(): void
    {
        $manifestPath = $this->modulesPath . '/linkinbio/module.json';
        
        $this->assertFileExists(
            $manifestPath,
            'LinkInBio module.json should exist'
        );
        
        $content = file_get_contents($manifestPath);
        $data = json_decode($content, true);
        
        $this->assertNotNull(
            $data,
            'module.json should contain valid JSON'
        );
        
        $this->assertEquals(
            'viraloka.linkinbio',
            $data['id'],
            'Module should have correct ID'
        );
        
        $this->assertEquals(
            'Viraloka\\Modules\\LinkInBio',
            $data['namespace'],
            'Module should have correct PSR-4 namespace'
        );
    }
    
    /**
     * Test that manifest is parsed correctly
     * 
     * Validates: Requirement 2.5
     */
    public function testManifestParsesCorrectly(): void
    {
        $manifestPath = $this->modulesPath . '/linkinbio/module.json';
        $parseResult = $this->parser->parse($manifestPath);
        
        $this->assertTrue(
            $parseResult->success,
            'Manifest should parse successfully'
        );
        
        $this->assertNotNull(
            $parseResult->manifest,
            'Parse result should contain Manifest object'
        );
        
        $manifest = $parseResult->manifest;
        
        $this->assertEquals('viraloka.linkinbio', $manifest->id);
        $this->assertEquals('Link In Bio', $manifest->name);
        $this->assertEquals('1.0.0', $manifest->version);
        $this->assertEquals('Viraloka\\Modules\\LinkInBio', $manifest->namespace);
        
        // Verify contexts
        $this->assertNotNull($manifest->contexts);
        $this->assertContains('link-in-bio', $manifest->contexts->supported);
        $this->assertEquals('link-in-bio', $manifest->contexts->primary);
        $this->assertEquals(80, $manifest->contexts->priority);
        
        // Verify capabilities
        $this->assertContains('manage_linkinbio', $manifest->capabilities);
        $this->assertContains('edit_linkinbio_pages', $manifest->capabilities);
        
        // Verify lifecycle
        $this->assertNotNull($manifest->lifecycle);
        $this->assertEquals(
            'Viraloka\\Modules\\LinkInBio\\LinkInBioServiceProvider',
            $manifest->lifecycle->provider
        );
        $this->assertTrue($manifest->lifecycle->boot);
    }
    
    /**
     * Test that module is discovered by ModuleLoader
     * 
     * Validates: Requirement 2.1
     */
    public function testModuleIsDiscovered(): void
    {
        $modules = $this->loader->loadModules();
        
        $linkInBioModule = null;
        foreach ($modules as $module) {
            if ($module->getId() === 'viraloka.linkinbio') {
                $linkInBioModule = $module;
                break;
            }
        }
        
        $this->assertNotNull(
            $linkInBioModule,
            'LinkInBio module should be discovered by ModuleLoader'
        );
        
        $this->assertEquals(
            'viraloka.linkinbio',
            $linkInBioModule->getId(),
            'Discovered module should have correct ID'
        );
    }
    
    /**
     * Test that ServiceProvider file exists with correct PSR-4 structure
     * 
     * Validates: Requirements 1.2, 7.1
     */
    public function testServiceProviderExists(): void
    {
        $providerPath = $this->modulesPath . '/linkinbio/src/LinkInBioServiceProvider.php';
        
        $this->assertFileExists(
            $providerPath,
            'ServiceProvider should exist at correct PSR-4 path'
        );
        
        // Verify the class can be loaded
        require_once $providerPath;
        
        $this->assertTrue(
            class_exists('Viraloka\\Modules\\LinkInBio\\LinkInBioServiceProvider'),
            'ServiceProvider class should be loadable'
        );
    }
    
    /**
     * Test that module can be bootstrapped successfully
     * 
     * Validates: Requirement 7.1
     */
    public function testModuleBootstraps(): void
    {
        // Load modules first
        $modules = $this->loader->loadModules();
        
        $linkInBioModule = null;
        foreach ($modules as $module) {
            if ($module->getId() === 'viraloka.linkinbio') {
                $linkInBioModule = $module;
                break;
            }
        }
        
        $this->assertNotNull($linkInBioModule, 'Module should be loaded');
        
        // Bootstrap the module
        $this->bootstrapper->bootstrap($linkInBioModule);
        
        $this->assertTrue(
            $linkInBioModule->isBootstrapped,
            'Module should be marked as bootstrapped'
        );
        
        $this->assertNotNull(
            $linkInBioModule->provider,
            'Module should have provider instance'
        );
        
        $this->assertInstanceOf(
            'Viraloka\\Modules\\LinkInBio\\LinkInBioServiceProvider',
            $linkInBioModule->provider,
            'Provider should be correct class'
        );
    }
    
    /**
     * Test that module has all required manifest fields
     * 
     * Validates: Requirements 1.1, 1.4
     */
    public function testModuleHasRequiredFields(): void
    {
        $manifestPath = $this->modulesPath . '/linkinbio/module.json';
        $parseResult = $this->parser->parse($manifestPath);
        
        $this->assertTrue($parseResult->success);
        $manifest = $parseResult->manifest;
        
        // Required fields from Requirement 1.4
        $this->assertNotEmpty($manifest->id, 'id is required');
        $this->assertNotEmpty($manifest->name, 'name is required');
        $this->assertNotEmpty($manifest->description, 'description is required');
        $this->assertNotEmpty($manifest->version, 'version is required');
        $this->assertNotEmpty($manifest->author, 'author is required');
        $this->assertNotEmpty($manifest->namespace, 'namespace is required');
    }
    
    /**
     * Test that module namespace follows PSR-4 conventions
     * 
     * Validates: Requirement 1.2
     */
    public function testModuleNamespaceFollowsPSR4(): void
    {
        $manifestPath = $this->modulesPath . '/linkinbio/module.json';
        $parseResult = $this->parser->parse($manifestPath);
        
        $this->assertTrue($parseResult->success);
        $manifest = $parseResult->manifest;
        
        // PSR-4 pattern: starts with uppercase, contains only alphanumeric and backslashes
        $this->assertMatchesRegularExpression(
            '/^[A-Z][a-zA-Z0-9\\\\]+$/',
            $manifest->namespace,
            'Namespace should follow PSR-4 pattern'
        );
        
        // Should start with capital letter
        $this->assertTrue(
            ctype_upper($manifest->namespace[0]),
            'Namespace should start with uppercase letter'
        );
    }
}
