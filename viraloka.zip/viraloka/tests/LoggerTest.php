<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\Logger;

/**
 * Logger Test
 * 
 * Tests for the Logger class
 */
class LoggerTest extends TestCase
{
    private Logger $logger;
    
    protected function setUp(): void
    {
        $this->logger = new Logger();
    }
    
    public function testErrorLogging(): void
    {
        // Test that error method doesn't throw exceptions
        $this->logger->error('Test error message');
        $this->logger->error('Test error with module', 'test.module');
        $this->logger->error('Test error with type', 'test.module', 'Parse Error');
        
        // If we get here without exceptions, the test passes
        $this->assertTrue(true);
    }
    
    public function testWarningLogging(): void
    {
        // Test that warning method doesn't throw exceptions
        $this->logger->warning('Test warning message');
        $this->logger->warning('Test warning with module', 'test.module');
        
        $this->assertTrue(true);
    }
    
    public function testInfoLogging(): void
    {
        // Test that info method doesn't throw exceptions
        $this->logger->info('Test info message');
        $this->logger->info('Test info with module', 'test.module');
        
        $this->assertTrue(true);
    }
    
    public function testParseErrorLogging(): void
    {
        // Test specialized parse error method
        $this->logger->parseError('/path/to/module.json', 'Invalid JSON');
        $this->logger->parseError('/path/to/module.json', 'Invalid JSON', 'test.module');
        
        $this->assertTrue(true);
    }
    
    public function testValidationErrorLogging(): void
    {
        // Test specialized validation error method
        $errors = ['Missing required field: id', 'Invalid version format'];
        $this->logger->validationError($errors);
        $this->logger->validationError($errors, 'test.module');
        
        $this->assertTrue(true);
    }
    
    public function testDependencyWarningLogging(): void
    {
        // Test specialized dependency warning method
        $missing = ['dep1', 'dep2'];
        $this->logger->dependencyWarning('test.module', $missing, 'module');
        $this->logger->dependencyWarning('test.module', $missing, 'plugin');
        
        $this->assertTrue(true);
    }
    
    public function testBootstrapErrorLogging(): void
    {
        // Test specialized bootstrap error method
        $this->logger->bootstrapError('test.module', 'Provider class not found');
        
        // Test with exception
        $exception = new \Exception('Test exception');
        $this->logger->bootstrapError('test.module', 'Bootstrap failed', $exception);
        
        $this->assertTrue(true);
    }
    
    public function testConflictErrorLogging(): void
    {
        // Test specialized conflict error method
        $this->logger->conflictError('test.module');
        
        $this->assertTrue(true);
    }
}
