<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Application;
use Viraloka\Core\Workspace\WorkspaceResolver;
use Viraloka\Core\Workspace\Workspace;

/**
 * Property-Based Tests for Workspace Resolver
 * 
 * Feature: core-bootstrap-flow
 * These tests validate universal properties that should hold across all inputs.
 */
class WorkspaceResolverPropertyTest extends TestCase
{
    protected function tearDown(): void
    {
        // Clean up server variables after each test
        unset($_SERVER['HTTP_HOST']);
        unset($_SERVER['REQUEST_URI']);
        unset($_SERVER['SERVER_NAME']);
    }
    
    /**
     * Property 11: Workspace Resolution Determinism
     * 
     * For any valid domain, subdomain, or path, the Workspace Resolver 
     * SHALL return a valid Workspace object.
     * 
     * Validates: Requirements 6.1
     * 
     * Feature: core-bootstrap-flow, Property 11: Workspace Resolution Determinism
     */
    public function testProperty11WorkspaceResolutionDeterminism(): void
    {
        // Test with 25 random inputs
        for ($i = 0; $i < 25; $i++) {
            $app = new Application(__DIR__);
            $resolver = new WorkspaceResolver($app);
            
            // Generate random domain, subdomain, or path
            $testType = rand(1, 4);
            
            switch ($testType) {
                case 1: // Domain-based
                    $domain = 'test' . rand(1, 1000) . '.example.com';
                    $_SERVER['HTTP_HOST'] = $domain;
                    
                    $resolver->setWorkspaceConfig([
                        [
                            'id' => 'workspace-' . rand(1, 100),
                            'name' => 'Test Workspace',
                            'domain' => $domain,
                            'config' => [],
                            'enabled_modules' => [],
                            'context' => 'default'
                        ]
                    ]);
                    break;
                    
                case 2: // Subdomain-based
                    $subdomain = 'tenant' . rand(1, 1000);
                    $_SERVER['HTTP_HOST'] = $subdomain . '.example.com';
                    
                    $resolver->setWorkspaceConfig([
                        [
                            'id' => 'workspace-' . rand(1, 100),
                            'name' => 'Test Workspace',
                            'subdomain' => $subdomain,
                            'config' => [],
                            'enabled_modules' => [],
                            'context' => 'default'
                        ]
                    ]);
                    break;
                    
                case 3: // Path-based
                    $pathSegment = 'tenant' . rand(1, 1000);
                    $_SERVER['HTTP_HOST'] = 'example.com';
                    $_SERVER['REQUEST_URI'] = '/' . $pathSegment . '/page';
                    
                    $resolver->setWorkspaceConfig([
                        [
                            'id' => 'workspace-' . rand(1, 100),
                            'name' => 'Test Workspace',
                            'path' => $pathSegment,
                            'config' => [],
                            'enabled_modules' => [],
                            'context' => 'default'
                        ]
                    ]);
                    break;
                    
                case 4: // Default fallback (no match)
                    $_SERVER['HTTP_HOST'] = 'unknown' . rand(1, 1000) . '.example.com';
                    $resolver->setWorkspaceConfig([
                        [
                            'id' => 'default',
                            'name' => 'Default Workspace',
                            'is_default' => true,
                            'config' => [],
                            'enabled_modules' => [],
                            'context' => 'default'
                        ]
                    ]);
                    break;
            }
            
            // Resolve workspace
            $workspace = $resolver->resolve();
            
            // Assert that a valid Workspace object is always returned
            $this->assertInstanceOf(Workspace::class, $workspace);
            $this->assertIsString($workspace->id);
            $this->assertIsString($workspace->name);
            $this->assertIsArray($workspace->config);
            $this->assertIsArray($workspace->enabledModules);
            $this->assertIsString($workspace->context);
            
            // Clean up server variables for next iteration
            unset($_SERVER['HTTP_HOST']);
            unset($_SERVER['REQUEST_URI']);
        }
    }
    
    /**
     * Additional property: Resolution is deterministic (same input = same output)
     */
    public function testWorkspaceResolutionIsDeterministicForSameInput(): void
    {
        for ($i = 0; $i < 15; $i++) {
            $domain = 'test' . rand(1, 100) . '.example.com';
            $_SERVER['HTTP_HOST'] = $domain;
            
            $config = [
                [
                    'id' => 'workspace-1',
                    'name' => 'Test Workspace',
                    'domain' => $domain,
                    'config' => ['key' => 'value'],
                    'enabled_modules' => ['module1'],
                    'context' => 'test'
                ]
            ];
            
            // Resolve twice with same configuration
            $app1 = new Application(__DIR__);
            $resolver1 = new WorkspaceResolver($app1);
            $resolver1->setWorkspaceConfig($config);
            $workspace1 = $resolver1->resolve();
            
            $app2 = new Application(__DIR__);
            $resolver2 = new WorkspaceResolver($app2);
            $resolver2->setWorkspaceConfig($config);
            $workspace2 = $resolver2->resolve();
            
            // Assert same workspace is resolved
            $this->assertSame($workspace1->id, $workspace2->id);
            $this->assertSame($workspace1->name, $workspace2->name);
            $this->assertSame($workspace1->domain, $workspace2->domain);
            $this->assertEquals($workspace1->config, $workspace2->config);
            $this->assertEquals($workspace1->enabledModules, $workspace2->enabledModules);
            $this->assertSame($workspace1->context, $workspace2->context);
            
            unset($_SERVER['HTTP_HOST']);
        }
    }
    
    /**
     * Additional property: Default workspace is always available
     */
    public function testDefaultWorkspaceIsAlwaysReturnedWhenNoMatchFound(): void
    {
        for ($i = 0; $i < 15; $i++) {
            $_SERVER['HTTP_HOST'] = 'random' . rand(1, 10000) . '.example.com';
            
            $app = new Application(__DIR__);
            $resolver = new WorkspaceResolver($app);
            
            // Set config with no matching workspace
            $resolver->setWorkspaceConfig([
                [
                    'id' => 'other-workspace',
                    'name' => 'Other Workspace',
                    'domain' => 'other.example.com',
                    'config' => [],
                    'enabled_modules' => [],
                    'context' => 'default'
                ]
            ]);
            
            $workspace = $resolver->resolve();
            
            // Should return default workspace
            $this->assertInstanceOf(Workspace::class, $workspace);
            $this->assertSame('default', $workspace->id);
            $this->assertSame('Default Workspace', $workspace->name);
            
            unset($_SERVER['HTTP_HOST']);
        }
    }
}
