<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Container\Container;
use Viraloka\Core\Container\Exceptions\ServiceNotFoundException;
use Viraloka\Core\Container\Exceptions\CircularDependencyException;

/**
 * Unit tests for the Container class.
 */
class ContainerTest extends TestCase
{
    private Container $container;

    protected function setUp(): void
    {
        $this->container = new Container();
    }

    /**
     * Test factory binding registration and resolution.
     */
    public function testFactoryBinding(): void
    {
        $this->container->bind('test', fn() => new stdClass());

        $instance1 = $this->container->get('test');
        $instance2 = $this->container->get('test');

        $this->assertInstanceOf(stdClass::class, $instance1);
        $this->assertInstanceOf(stdClass::class, $instance2);
        $this->assertNotSame($instance1, $instance2, 'Factory should return different instances');
    }

    /**
     * Test singleton binding registration and resolution.
     */
    public function testSingletonBinding(): void
    {
        $this->container->singleton('test', fn() => new stdClass());

        $instance1 = $this->container->get('test');
        $instance2 = $this->container->get('test');

        $this->assertInstanceOf(stdClass::class, $instance1);
        $this->assertSame($instance1, $instance2, 'Singleton should return the same instance');
    }

    /**
     * Test has() method returns true for bound services.
     */
    public function testHasReturnsTrueForBoundService(): void
    {
        $this->container->bind('test', fn() => new stdClass());

        $this->assertTrue($this->container->has('test'));
    }

    /**
     * Test has() method returns false for unbound services.
     */
    public function testHasReturnsFalseForUnboundService(): void
    {
        $this->assertFalse($this->container->has('nonexistent'));
    }

    /**
     * Test get() throws ServiceNotFoundException for unbound service.
     */
    public function testGetThrowsExceptionForUnboundService(): void
    {
        $this->expectException(ServiceNotFoundException::class);
        $this->expectExceptionMessage("Service 'nonexistent' not found in container");

        $this->container->get('nonexistent');
    }

    /**
     * Test binding with class name string.
     */
    public function testBindingWithClassName(): void
    {
        $this->container->bind('test', stdClass::class);

        $instance = $this->container->get('test');

        $this->assertInstanceOf(stdClass::class, $instance);
    }

    /**
     * Test singleton with class name string.
     */
    public function testSingletonWithClassName(): void
    {
        $this->container->singleton('test', stdClass::class);

        $instance1 = $this->container->get('test');
        $instance2 = $this->container->get('test');

        $this->assertSame($instance1, $instance2);
    }

    /**
     * Test instance registration returns the exact same object.
     */
    public function testInstanceRegistration(): void
    {
        $instance = new stdClass();
        $instance->value = 'test';

        $this->container->instance('test', $instance);

        $retrieved1 = $this->container->get('test');
        $retrieved2 = $this->container->get('test');

        $this->assertSame($instance, $retrieved1, 'Should return the exact registered instance');
        $this->assertSame($instance, $retrieved2, 'Should return the same instance on multiple calls');
        $this->assertEquals('test', $retrieved1->value);
    }

    /**
     * Test instance registration is treated as singleton.
     */
    public function testInstanceIsSingleton(): void
    {
        $instance = new stdClass();
        $this->container->instance('test', $instance);

        $this->assertTrue($this->container->has('test'));
        $this->assertSame($instance, $this->container->get('test'));
    }

    /**
     * Test alias resolves to the original binding.
     */
    public function testAliasResolution(): void
    {
        $this->container->singleton('original', fn() => new stdClass());
        $this->container->alias('alias', 'original');

        $original = $this->container->get('original');
        $aliased = $this->container->get('alias');

        $this->assertSame($original, $aliased, 'Alias should resolve to the same instance as original');
    }

    /**
     * Test chained aliases.
     */
    public function testChainedAliases(): void
    {
        $this->container->singleton('original', fn() => new stdClass());
        $this->container->alias('alias1', 'original');
        $this->container->alias('alias2', 'alias1');
        $this->container->alias('alias3', 'alias2');

        $original = $this->container->get('original');
        $alias1 = $this->container->get('alias1');
        $alias2 = $this->container->get('alias2');
        $alias3 = $this->container->get('alias3');

        $this->assertSame($original, $alias1);
        $this->assertSame($original, $alias2);
        $this->assertSame($original, $alias3);
    }

    /**
     * Test has() returns true for aliases.
     */
    public function testHasReturnsTrueForAlias(): void
    {
        $this->container->bind('original', fn() => new stdClass());
        $this->container->alias('alias', 'original');

        $this->assertTrue($this->container->has('alias'));
        $this->assertTrue($this->container->has('original'));
    }

    /**
     * Test alias with factory binding creates new instances.
     */
    public function testAliasWithFactoryBinding(): void
    {
        $this->container->bind('original', fn() => new stdClass());
        $this->container->alias('alias', 'original');

        $instance1 = $this->container->get('alias');
        $instance2 = $this->container->get('alias');

        $this->assertNotSame($instance1, $instance2, 'Factory binding through alias should create new instances');
    }

    /**
     * Test tagged services can be registered and retrieved.
     */
    public function testTaggedServices(): void
    {
        $this->container->bind('service1', fn() => (object)['name' => 'service1'], ['tags' => ['group1']]);
        $this->container->bind('service2', fn() => (object)['name' => 'service2'], ['tags' => ['group1']]);
        $this->container->bind('service3', fn() => (object)['name' => 'service3'], ['tags' => ['group2']]);

        $group1Services = $this->container->tagged('group1');
        $group2Services = $this->container->tagged('group2');

        $this->assertCount(2, $group1Services);
        $this->assertCount(1, $group2Services);
        $this->assertEquals('service1', $group1Services[0]->name);
        $this->assertEquals('service2', $group1Services[1]->name);
        $this->assertEquals('service3', $group2Services[0]->name);
    }

    /**
     * Test tagged returns empty array for non-existent tag.
     */
    public function testTaggedReturnsEmptyArrayForNonExistentTag(): void
    {
        $tagged = $this->container->tagged('nonexistent');

        $this->assertIsArray($tagged);
        $this->assertEmpty($tagged);
    }

    /**
     * Test service can have multiple tags.
     */
    public function testServiceWithMultipleTags(): void
    {
        $this->container->bind('service', fn() => new stdClass(), ['tags' => ['tag1', 'tag2', 'tag3']]);

        $tag1Services = $this->container->tagged('tag1');
        $tag2Services = $this->container->tagged('tag2');
        $tag3Services = $this->container->tagged('tag3');

        $this->assertCount(1, $tag1Services);
        $this->assertCount(1, $tag2Services);
        $this->assertCount(1, $tag3Services);
    }

    /**
     * Test tagged services with singleton bindings return same instance.
     */
    public function testTaggedServicesWithSingletons(): void
    {
        // Note: singleton() doesn't support tags directly, so we use bind with singleton type
        // For this test, we'll bind as factory with tags, then verify behavior
        $counter = 0;
        $this->container->bind('counter', function() use (&$counter) {
            return (object)['value' => ++$counter];
        }, ['tags' => ['counters']]);

        $services1 = $this->container->tagged('counters');
        $services2 = $this->container->tagged('counters');

        // Factory bindings should create new instances each time
        $this->assertNotSame($services1[0], $services2[0]);
        $this->assertEquals(1, $services1[0]->value);
        $this->assertEquals(2, $services2[0]->value);
    }

    /**
     * Test tagged services are resolved at call time.
     */
    public function testTaggedServicesResolvedAtCallTime(): void
    {
        $this->container->bind('service1', fn() => new stdClass(), ['tags' => ['dynamic']]);
        
        $services1 = $this->container->tagged('dynamic');
        
        // Add another service with the same tag
        $this->container->bind('service2', fn() => new stdClass(), ['tags' => ['dynamic']]);
        
        $services2 = $this->container->tagged('dynamic');

        $this->assertCount(1, $services1);
        $this->assertCount(2, $services2);
    }

    /**
     * Test circular dependency detection with direct cycle.
     */
    public function testCircularDependencyDetectionDirectCycle(): void
    {
        $this->expectException(CircularDependencyException::class);
        $this->expectExceptionMessage('Circular dependency detected: serviceA -> serviceA');

        // Service A depends on itself
        $this->container->bind('serviceA', function($container) {
            return $container->get('serviceA');
        });

        $this->container->get('serviceA');
    }

    /**
     * Test circular dependency detection with two-service cycle.
     */
    public function testCircularDependencyDetectionTwoServiceCycle(): void
    {
        $this->expectException(CircularDependencyException::class);
        $this->expectExceptionMessage('Circular dependency detected: serviceA -> serviceB -> serviceA');

        // Service A depends on B, B depends on A
        $this->container->bind('serviceA', function($container) {
            return $container->get('serviceB');
        });

        $this->container->bind('serviceB', function($container) {
            return $container->get('serviceA');
        });

        $this->container->get('serviceA');
    }

    /**
     * Test circular dependency detection with three-service cycle.
     */
    public function testCircularDependencyDetectionThreeServiceCycle(): void
    {
        $this->expectException(CircularDependencyException::class);
        $this->expectExceptionMessage('Circular dependency detected: serviceA -> serviceB -> serviceC -> serviceA');

        // Service A -> B -> C -> A
        $this->container->bind('serviceA', function($container) {
            return $container->get('serviceB');
        });

        $this->container->bind('serviceB', function($container) {
            return $container->get('serviceC');
        });

        $this->container->bind('serviceC', function($container) {
            return $container->get('serviceA');
        });

        $this->container->get('serviceA');
    }

    /**
     * Test circular dependency detection with singleton bindings.
     */
    public function testCircularDependencyDetectionWithSingletons(): void
    {
        $this->expectException(CircularDependencyException::class);
        $this->expectExceptionMessage('Circular dependency detected: serviceA -> serviceB -> serviceA');

        // Singletons with circular dependency
        $this->container->singleton('serviceA', function($container) {
            return $container->get('serviceB');
        });

        $this->container->singleton('serviceB', function($container) {
            return $container->get('serviceA');
        });

        $this->container->get('serviceA');
    }

    /**
     * Test that resolution stack is properly cleaned up after successful resolution.
     */
    public function testResolutionStackCleanupAfterSuccess(): void
    {
        // Service A depends on B, B is independent
        $this->container->bind('serviceA', function($container) {
            return (object)['dependency' => $container->get('serviceB')];
        });

        $this->container->bind('serviceB', function() {
            return (object)['name' => 'B'];
        });

        // First resolution should succeed
        $instance1 = $this->container->get('serviceA');
        $this->assertInstanceOf(\stdClass::class, $instance1);

        // Second resolution should also succeed (stack was cleaned up)
        $instance2 = $this->container->get('serviceA');
        $this->assertInstanceOf(\stdClass::class, $instance2);
    }

    /**
     * Test that non-circular dependencies work correctly.
     */
    public function testNonCircularDependenciesWork(): void
    {
        // Service A depends on B and C, B depends on C
        $this->container->bind('serviceC', function() {
            return (object)['name' => 'C'];
        });

        $this->container->bind('serviceB', function($container) {
            return (object)['name' => 'B', 'dependency' => $container->get('serviceC')];
        });

        $this->container->bind('serviceA', function($container) {
            return (object)[
                'name' => 'A',
                'b' => $container->get('serviceB'),
                'c' => $container->get('serviceC')
            ];
        });

        $instance = $this->container->get('serviceA');
        
        $this->assertEquals('A', $instance->name);
        $this->assertEquals('B', $instance->b->name);
        $this->assertEquals('C', $instance->c->name);
    }

    /**
     * Test auto-wiring with no constructor.
     */
    public function testAutoWiringWithNoConstructor(): void
    {
        $instance = $this->container->get(AutoWireTestClassNoConstructor::class);
        
        $this->assertInstanceOf(AutoWireTestClassNoConstructor::class, $instance);
    }

    /**
     * Test auto-wiring with type-hinted dependencies.
     */
    public function testAutoWiringWithTypeHintedDependencies(): void
    {
        // Register dependencies
        $this->container->singleton(AutoWireTestDependency::class, fn() => new AutoWireTestDependency());
        
        // Auto-wire class with dependency
        $instance = $this->container->get(AutoWireTestClassWithDependency::class);
        
        $this->assertInstanceOf(AutoWireTestClassWithDependency::class, $instance);
        $this->assertInstanceOf(AutoWireTestDependency::class, $instance->dependency);
    }

    /**
     * Test auto-wiring with nested dependencies.
     */
    public function testAutoWiringWithNestedDependencies(): void
    {
        // Register base dependency
        $this->container->singleton(AutoWireTestDependency::class, fn() => new AutoWireTestDependency());
        
        // Auto-wire nested dependencies
        $instance = $this->container->get(AutoWireTestClassWithNestedDependency::class);
        
        $this->assertInstanceOf(AutoWireTestClassWithNestedDependency::class, $instance);
        $this->assertInstanceOf(AutoWireTestClassWithDependency::class, $instance->nested);
        $this->assertInstanceOf(AutoWireTestDependency::class, $instance->nested->dependency);
    }

    /**
     * Test auto-wiring with optional parameters.
     */
    public function testAutoWiringWithOptionalParameters(): void
    {
        $instance = $this->container->get(AutoWireTestClassWithOptionalParam::class);
        
        $this->assertInstanceOf(AutoWireTestClassWithOptionalParam::class, $instance);
        $this->assertEquals('default', $instance->value);
    }

    /**
     * Test auto-wiring with nullable parameters.
     */
    public function testAutoWiringWithNullableParameters(): void
    {
        $instance = $this->container->get(AutoWireTestClassWithNullableParam::class);
        
        $this->assertInstanceOf(AutoWireTestClassWithNullableParam::class, $instance);
        $this->assertNull($instance->dependency);
    }

    /**
     * Test auto-wiring throws exception for unresolvable parameter.
     */
    public function testAutoWiringThrowsExceptionForUnresolvableParameter(): void
    {
        $this->expectException(\Viraloka\Core\Container\Exceptions\ContainerException::class);
        $this->expectExceptionMessage("Cannot auto-wire");
        
        $this->container->get(AutoWireTestClassWithUnresolvableDependency::class);
    }

    /**
     * Test auto-wiring throws exception for built-in type without default.
     */
    public function testAutoWiringThrowsExceptionForBuiltInTypeWithoutDefault(): void
    {
        $this->expectException(\Viraloka\Core\Container\Exceptions\ContainerException::class);
        $this->expectExceptionMessage("built-in type");
        
        $this->container->get(AutoWireTestClassWithBuiltInType::class);
    }

    /**
     * Test auto-wiring with built-in type with default value.
     */
    public function testAutoWiringWithBuiltInTypeWithDefault(): void
    {
        $instance = $this->container->get(AutoWireTestClassWithBuiltInTypeDefault::class);
        
        $this->assertInstanceOf(AutoWireTestClassWithBuiltInTypeDefault::class, $instance);
        $this->assertEquals(42, $instance->value);
    }

    /**
     * Test auto-wiring without explicit binding.
     */
    public function testAutoWiringWithoutExplicitBinding(): void
    {
        // Don't bind the class, just try to resolve it
        $instance = $this->container->get(AutoWireTestClassNoConstructor::class);
        
        $this->assertInstanceOf(AutoWireTestClassNoConstructor::class, $instance);
    }

    /**
     * Test auto-wiring respects circular dependency detection.
     */
    public function testAutoWiringRespectsCircularDependencyDetection(): void
    {
        $this->expectException(CircularDependencyException::class);
        
        // These classes have circular dependencies
        $this->container->get(AutoWireTestCircularA::class);
    }
}

// Test classes for auto-wiring

class AutoWireTestClassNoConstructor
{
    public string $name = 'test';
}

class AutoWireTestDependency
{
    public string $name = 'dependency';
}

class AutoWireTestClassWithDependency
{
    public function __construct(public AutoWireTestDependency $dependency)
    {
    }
}

class AutoWireTestClassWithNestedDependency
{
    public function __construct(public AutoWireTestClassWithDependency $nested)
    {
    }
}

class AutoWireTestClassWithOptionalParam
{
    public function __construct(public string $value = 'default')
    {
    }
}

class AutoWireTestClassWithNullableParam
{
    public function __construct(public ?AutoWireTestDependency $dependency = null)
    {
    }
}

class AutoWireTestClassWithUnresolvableDependency
{
    public function __construct(public AutoWireTestDependency $dependency)
    {
    }
}

class AutoWireTestClassWithBuiltInType
{
    public function __construct(public int $value)
    {
    }
}

class AutoWireTestClassWithBuiltInTypeDefault
{
    public function __construct(public int $value = 42)
    {
    }
}

class AutoWireTestCircularA
{
    public function __construct(public AutoWireTestCircularB $b)
    {
    }
}

class AutoWireTestCircularB
{
    public function __construct(public AutoWireTestCircularA $a)
    {
    }
}


/**
 * Tests for context-aware resolution.
 */
class ContainerContextAwareTest extends TestCase
{
    private Container $container;
    private MockContextResolver $contextResolver;
    private MockWorkspaceResolver $workspaceResolver;

    protected function setUp(): void
    {
        $this->contextResolver = new MockContextResolver();
        $this->workspaceResolver = new MockWorkspaceResolver();
        $this->container = new Container($this->contextResolver, $this->workspaceResolver);
    }

    /**
     * Test context-specific binding registration.
     */
    public function testContextSpecificBinding(): void
    {
        // Register global binding
        $this->container->bind('service', fn() => (object)['type' => 'global']);
        
        // Register context-specific binding
        $this->container->bindForContext('admin', 'service', fn() => (object)['type' => 'admin']);

        // Set context to 'default'
        $this->contextResolver->setContext('default');
        $instance1 = $this->container->get('service');
        $this->assertEquals('global', $instance1->type);

        // Set context to 'admin'
        $this->contextResolver->setContext('admin');
        $instance2 = $this->container->get('service');
        $this->assertEquals('admin', $instance2->type);
    }

    /**
     * Test workspace-specific binding registration.
     */
    public function testWorkspaceSpecificBinding(): void
    {
        // Register global binding
        $this->container->bind('service', fn() => (object)['type' => 'global']);
        
        // Register workspace-specific binding
        $this->container->bindForWorkspace('admin', 'workspace1', 'service', fn() => (object)['type' => 'workspace1']);

        // Set context to 'admin' but no workspace
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace(null);
        $instance1 = $this->container->get('service');
        $this->assertEquals('global', $instance1->type);

        // Set workspace to 'workspace1'
        $this->workspaceResolver->setWorkspace('workspace1');
        $instance2 = $this->container->get('service');
        $this->assertEquals('workspace1', $instance2->type);
    }

    /**
     * Test resolution order precedence: workspace > context > global.
     */
    public function testResolutionOrderPrecedence(): void
    {
        // Register at all three levels
        $this->container->bind('service', fn() => (object)['level' => 'global']);
        $this->container->bindForContext('admin', 'service', fn() => (object)['level' => 'context']);
        $this->container->bindForWorkspace('admin', 'ws1', 'service', fn() => (object)['level' => 'workspace']);

        // Test global (no context/workspace)
        $this->contextResolver->setContext('default');
        $this->workspaceResolver->setWorkspace(null);
        $this->assertEquals('global', $this->container->get('service')->level);

        // Test context (context but no workspace)
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace(null);
        $this->assertEquals('context', $this->container->get('service')->level);

        // Test workspace (both context and workspace)
        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('ws1');
        $this->assertEquals('workspace', $this->container->get('service')->level);

        // Test different workspace falls back to context
        $this->workspaceResolver->setWorkspace('ws2');
        $this->assertEquals('context', $this->container->get('service')->level);
    }

    /**
     * Test has() method respects context-aware bindings.
     */
    public function testHasRespectsContextAwareBindings(): void
    {
        // Register only context-specific binding
        $this->container->bindForContext('admin', 'service', fn() => new stdClass());

        // Should not be found in default context
        $this->contextResolver->setContext('default');
        $this->assertFalse($this->container->has('service'));

        // Should be found in admin context
        $this->contextResolver->setContext('admin');
        $this->assertTrue($this->container->has('service'));
    }

    /**
     * Test context-specific singleton bindings.
     */
    public function testContextSpecificSingletons(): void
    {
        // Register context-specific singleton
        $this->container->bindForContext('admin', 'service', fn() => new stdClass(), ['type' => BindingType::SINGLETON]);

        $this->contextResolver->setContext('admin');
        
        $instance1 = $this->container->get('service');
        $instance2 = $this->container->get('service');

        $this->assertSame($instance1, $instance2, 'Context-specific singleton should return same instance');
    }

    /**
     * Test workspace-specific factory bindings.
     */
    public function testWorkspaceSpecificFactories(): void
    {
        // Register workspace-specific factory
        $this->container->bindForWorkspace('admin', 'ws1', 'service', fn() => new stdClass());

        $this->contextResolver->setContext('admin');
        $this->workspaceResolver->setWorkspace('ws1');
        
        $instance1 = $this->container->get('service');
        $instance2 = $this->container->get('service');

        $this->assertNotSame($instance1, $instance2, 'Workspace-specific factory should return different instances');
    }

    /**
     * Test context-aware bindings with tags.
     */
    public function testContextAwareBindingsWithTags(): void
    {
        $this->container->bindForContext('admin', 'service1', fn() => (object)['name' => 'service1'], ['tags' => ['group1']]);
        $this->container->bindForContext('admin', 'service2', fn() => (object)['name' => 'service2'], ['tags' => ['group1']]);

        $this->contextResolver->setContext('admin');
        
        $services = $this->container->tagged('group1');
        
        $this->assertCount(2, $services);
        $this->assertEquals('service1', $services[0]->name);
        $this->assertEquals('service2', $services[1]->name);
    }

    /**
     * Test container works without resolvers (null resolvers).
     */
    public function testContainerWorksWithoutResolvers(): void
    {
        $container = new Container();
        
        $container->bind('service', fn() => (object)['type' => 'global']);
        
        $instance = $container->get('service');
        $this->assertEquals('global', $instance->type);
    }
}

/**
 * Mock context resolver for testing.
 */
class MockContextResolver implements \Viraloka\Core\Container\Contracts\ContextResolverInterface
{
    private string $context = 'default';

    public function setContext(string $context): void
    {
        $this->context = $context;
    }

    public function getCurrentContext(): string
    {
        return $this->context;
    }
}

/**
 * Mock workspace resolver for testing.
 */
class MockWorkspaceResolver implements \Viraloka\Core\Container\Contracts\WorkspaceResolverInterface
{
    private ?string $workspace = null;

    public function setWorkspace(?string $workspace): void
    {
        $this->workspace = $workspace;
    }

    public function getCurrentWorkspace(): ?string
    {
        return $this->workspace;
    }
}

/**
 * Tests for Service Provider support.
 */
class ContainerServiceProviderTest extends TestCase
{
    private Container $container;

    protected function setUp(): void
    {
        $this->container = new Container();
    }

    /**
     * Test provider registration calls register() immediately.
     */
    public function testProviderRegistrationCallsRegisterImmediately(): void
    {
        $provider = new TestServiceProvider();
        
        $this->container->registerProvider($provider);
        
        // Verify that register() was called by checking if the service was bound
        $this->assertTrue($this->container->has('test-service'));
        $instance = $this->container->get('test-service');
        $this->assertEquals('registered', $instance->status);
    }

    /**
     * Test bootProviders() calls boot() on all providers in order.
     */
    public function testBootProvidersCallsBootInOrder(): void
    {
        $provider1 = new TestServiceProvider();
        $provider2 = new TestServiceProvider2();
        
        $this->container->registerProvider($provider1);
        $this->container->registerProvider($provider2);
        
        // Boot all providers
        $this->container->bootProviders();
        
        // Verify boot was called by checking the booted services
        $service1 = $this->container->get('test-service');
        $service2 = $this->container->get('test-service-2');
        
        $this->assertEquals('booted', $service1->status);
        $this->assertEquals('booted', $service2->status);
    }

    /**
     * Test boot() is called after all register() calls.
     */
    public function testBootCalledAfterAllRegisterCalls(): void
    {
        $tracker = new ProviderCallTracker();
        
        $provider1 = new TrackingServiceProvider($tracker, 'provider1');
        $provider2 = new TrackingServiceProvider($tracker, 'provider2');
        
        $this->container->registerProvider($provider1);
        $this->container->registerProvider($provider2);
        
        // At this point, both register() should have been called
        $this->assertEquals(['provider1:register', 'provider2:register'], $tracker->getCalls());
        
        // Now boot all providers
        $this->container->bootProviders();
        
        // Boot should be called in order after all register calls
        $this->assertEquals([
            'provider1:register',
            'provider2:register',
            'provider1:boot',
            'provider2:boot'
        ], $tracker->getCalls());
    }

    /**
     * Test providers can register services that depend on each other.
     */
    public function testProvidersCanRegisterDependentServices(): void
    {
        $provider1 = new DependencyProviderA();
        $provider2 = new DependencyProviderB();
        
        // Register both providers
        $this->container->registerProvider($provider1);
        $this->container->registerProvider($provider2);
        
        // Boot providers
        $this->container->bootProviders();
        
        // ServiceB depends on ServiceA
        $serviceB = $this->container->get('serviceB');
        $this->assertInstanceOf(TestServiceB::class, $serviceB);
        $this->assertInstanceOf(TestServiceA::class, $serviceB->serviceA);
    }

    /**
     * Test providers can use boot() to perform initialization.
     */
    public function testProvidersCanUseBootForInitialization(): void
    {
        $provider = new InitializingServiceProvider();
        
        $this->container->registerProvider($provider);
        
        // Before boot, service should not be initialized
        $service = $this->container->get('initializable-service');
        $this->assertFalse($service->initialized);
        
        // After boot, service should be initialized
        $this->container->bootProviders();
        $this->assertTrue($service->initialized);
    }

    /**
     * Test multiple calls to bootProviders() only boot once.
     */
    public function testMultipleBootCallsOnlyBootOnce(): void
    {
        $tracker = new ProviderCallTracker();
        $provider = new TrackingServiceProvider($tracker, 'provider');
        
        $this->container->registerProvider($provider);
        
        // Call boot multiple times
        $this->container->bootProviders();
        $this->container->bootProviders();
        $this->container->bootProviders();
        
        // Boot should be called three times (once per bootProviders call)
        // This is expected behavior - the container doesn't prevent multiple boots
        $calls = $tracker->getCalls();
        $bootCalls = array_filter($calls, fn($call) => str_contains($call, ':boot'));
        $this->assertCount(3, $bootCalls);
    }

    /**
     * Test that the container registers itself as a service.
     */
    public function testContainerSelfRegistration(): void
    {
        // Container should be available via ContainerInterface
        $this->assertTrue($this->container->has(\Viraloka\Core\Container\Contracts\ContainerInterface::class));
        
        $containerViaInterface = $this->container->get(\Viraloka\Core\Container\Contracts\ContainerInterface::class);
        $this->assertSame($this->container, $containerViaInterface);
        
        // Container should also be available via its concrete class
        $this->assertTrue($this->container->has(\Viraloka\Core\Container\Container::class));
        
        $containerViaClass = $this->container->get(\Viraloka\Core\Container\Container::class);
        $this->assertSame($this->container, $containerViaClass);
    }

    /**
     * Test that the container can be injected into other services.
     */
    public function testContainerInjection(): void
    {
        // Create a service that depends on the container
        $this->container->bind('service-with-container', function($container) {
            return new class($container) {
                public function __construct(
                    public readonly \Viraloka\Core\Container\Contracts\ContainerInterface $container
                ) {}
            };
        });

        $service = $this->container->get('service-with-container');
        
        $this->assertSame($this->container, $service->container);
    }
}

/**
 * Test service provider that registers a simple service.
 */
class TestServiceProvider implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $container->bind('test-service', fn() => (object)['status' => 'registered']);
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $service = $container->get('test-service');
        $service->status = 'booted';
    }
}

/**
 * Second test service provider.
 */
class TestServiceProvider2 implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $container->bind('test-service-2', fn() => (object)['status' => 'registered']);
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $service = $container->get('test-service-2');
        $service->status = 'booted';
    }
}

/**
 * Helper class to track provider method calls.
 */
class ProviderCallTracker
{
    private array $calls = [];

    public function track(string $call): void
    {
        $this->calls[] = $call;
    }

    public function getCalls(): array
    {
        return $this->calls;
    }
}

/**
 * Service provider that tracks its method calls.
 */
class TrackingServiceProvider implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function __construct(
        private ProviderCallTracker $tracker,
        private string $name
    ) {}

    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $this->tracker->track("{$this->name}:register");
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $this->tracker->track("{$this->name}:boot");
    }
}

/**
 * Test service classes for dependency testing.
 */
class TestServiceA
{
    public string $name = 'ServiceA';
}

class TestServiceB
{
    public function __construct(public TestServiceA $serviceA)
    {
    }
}

/**
 * Provider that registers ServiceA.
 */
class DependencyProviderA implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $container->singleton('serviceA', fn() => new TestServiceA());
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        // No boot logic needed
    }
}

/**
 * Provider that registers ServiceB which depends on ServiceA.
 */
class DependencyProviderB implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $container->singleton('serviceB', fn($c) => new TestServiceB($c->get('serviceA')));
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        // No boot logic needed
    }
}

/**
 * Service that can be initialized.
 */
class InitializableService
{
    public bool $initialized = false;

    public function initialize(): void
    {
        $this->initialized = true;
    }
}

/**
 * Provider that uses boot() to initialize services.
 */
class InitializingServiceProvider implements \Viraloka\Core\Container\Contracts\ServiceProviderInterface
{
    public function register(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $container->singleton('initializable-service', fn() => new InitializableService());
    }

    public function boot(\Viraloka\Core\Container\Contracts\ContainerInterface $container): void
    {
        $service = $container->get('initializable-service');
        $service->initialize();
    }
}
