<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Modules\ModuleAdminUI;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\ModuleRecommender;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\Manifest;
use Viraloka\Core\Modules\InvalidModule;
use Viraloka\Core\Modules\ResolutionResult;
use Viraloka\Core\Modules\VisibilityConfig;

/**
 * Module Admin UI Tests
 * 
 * Tests for the ModuleAdminUI class that renders module management interface.
 */
class ModuleAdminUITest extends TestCase
{
    protected ModuleRegistry $registry;
    protected ModuleRecommender $recommender;
    protected ContextResolver $contextResolver;
    protected ModuleAdminUI $adminUI;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        $this->registry = new ModuleRegistry();
        $this->contextResolver = new ContextResolver();
        $this->recommender = new ModuleRecommender($this->contextResolver, $this->registry);
        $this->adminUI = new ModuleAdminUI($this->registry, $this->recommender, $this->contextResolver);
        
        // Mock WordPress functions
        if (!function_exists('esc_html')) {
            function esc_html($text) {
                return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
            }
        }
    }
    
    /**
     * Test rendering active modules with visibility filtering
     */
    public function testRenderActiveModulesRespectsVisibility(): void
    {
        // Create a public module
        $publicManifest = $this->createManifest('public-module', true);
        $publicModule = new Module($publicManifest, new ResolutionResult(true, [], [], [], []));
        $this->registry->register($publicModule);
        
        // Create a private module
        $privateManifest = $this->createManifest('private-module', false);
        $privateModule = new Module($privateManifest, new ResolutionResult(true, [], [], [], []));
        $this->registry->register($privateModule);
        
        ob_start();
        $this->adminUI->renderActiveModules();
        $output = ob_get_clean();
        
        // Public module should be visible
        $this->assertStringContainsString('public-module', $output);
        
        // Private module should not be visible
        $this->assertStringNotContainsString('private-module', $output);
    }
    
    /**
     * Test rendering invalid modules with error details
     */
    public function testRenderInvalidModulesShowsErrors(): void
    {
        $invalidModule = new InvalidModule(
            '/path/to/invalid/module',
            'Missing required field: namespace',
            'invalid-module'
        );
        
        $this->registry->registerInvalid($invalidModule);
        
        ob_start();
        $this->adminUI->renderInvalidModules();
        $output = ob_get_clean();
        
        // Should show module ID
        $this->assertStringContainsString('invalid-module', $output);
        
        // Should show path
        $this->assertStringContainsString('/path/to/invalid/module', $output);
        
        // Should show error message
        $this->assertStringContainsString('Missing required field: namespace', $output);
    }
    
    /**
     * Test rendering invalid modules without module ID
     */
    public function testRenderInvalidModulesWithoutModuleId(): void
    {
        $invalidModule = new InvalidModule(
            '/path/to/invalid/module',
            'Malformed JSON',
            null // No module ID
        );
        
        $this->registry->registerInvalid($invalidModule);
        
        ob_start();
        $this->adminUI->renderInvalidModules();
        $output = ob_get_clean();
        
        // Should show "Unknown" for missing module ID
        $this->assertStringContainsString('Unknown', $output);
        
        // Should show error message
        $this->assertStringContainsString('Malformed JSON', $output);
    }
    
    /**
     * Test rendering recommended modules with installation status
     */
    public function testRenderRecommendedModulesShowsInstallationStatus(): void
    {
        // Create a module that recommends others
        $manifest = $this->createManifestWithRecommendations(
            'source-module',
            ['recommended-installed', 'recommended-not-installed']
        );
        $module = new Module($manifest, new ResolutionResult(true, [], [], [], []));
        $this->registry->register($module);
        
        // Create the installed recommended module
        $installedManifest = $this->createManifest('recommended-installed', true);
        $installedModule = new Module($installedManifest, new ResolutionResult(true, [], [], [], []));
        $this->registry->register($installedModule);
        
        // Store recommendations
        $this->recommender->storeRecommendations($module);
        
        ob_start();
        $this->adminUI->renderRecommendedModules('creator');
        $output = ob_get_clean();
        
        // Should show both recommended modules
        $this->assertStringContainsString('recommended-installed', $output);
        $this->assertStringContainsString('recommended-not-installed', $output);
        
        // Should show installation status
        $this->assertStringContainsString('Installed', $output);
        $this->assertStringContainsString('Not Installed', $output);
    }
    
    /**
     * Test rendering empty active modules list
     */
    public function testRenderActiveModulesWhenEmpty(): void
    {
        ob_start();
        $this->adminUI->renderActiveModules();
        $output = ob_get_clean();
        
        $this->assertStringContainsString('No active modules found', $output);
    }
    
    /**
     * Test rendering empty invalid modules list
     */
    public function testRenderInvalidModulesWhenEmpty(): void
    {
        ob_start();
        $this->adminUI->renderInvalidModules();
        $output = ob_get_clean();
        
        $this->assertStringContainsString('No invalid modules found', $output);
    }
    
    /**
     * Helper to create a manifest with visibility settings
     */
    protected function createManifest(string $id, bool $public): Manifest
    {
        $data = [
            'id' => $id,
            'name' => ucfirst($id),
            'description' => 'Test Description',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'visibility' => [
                'public' => $public,
                'marketplace' => true,
            ],
        ];
        
        return new Manifest($data, '/path/to/module');
    }
    
    /**
     * Helper to create a manifest with recommendations
     */
    protected function createManifestWithRecommendations(string $id, array $recommendedModules): Manifest
    {
        $data = [
            'id' => $id,
            'name' => ucfirst($id),
            'description' => 'Test Description',
            'version' => '1.0.0',
            'author' => 'Test Author',
            'namespace' => 'Test\\Module',
            'recommendations' => [
                'modules' => $recommendedModules,
                'integrations' => [],
            ],
        ];
        
        return new Manifest($data, '/path/to/module');
    }
}
