<?php

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Events\EventDispatcher;

/**
 * Property-Based Tests for Event Dispatcher
 * 
 * Tests universal properties of the Event Dispatcher including:
 * - Listener execution order (Property 31)
 * - Non-blocking listener execution (Property 32)
 */
class EventDispatcherPropertyTest extends TestCase
{
    /**
     * Property 31: Event Listener Execution Order
     * 
     * For any set of event listeners registered for the same event,
     * the Event Dispatcher SHALL execute them in registration order.
     * 
     * Validates: Requirements 14.4
     * 
     * Feature: core-bootstrap-flow, Property 31: Event Listener Execution Order
     */
    public function testProperty31EventListenerExecutionOrder(): void
    {
        // Run multiple iterations with different numbers of listeners
        for ($iteration = 0; $iteration < 100; $iteration++) {
            $dispatcher = new EventDispatcher();
            
            // Generate random number of listeners (2-10)
            $numListeners = rand(2, 10);
            
            // Track execution order
            $executionOrder = [];
            
            // Register listeners in a specific order
            for ($i = 0; $i < $numListeners; $i++) {
                $listenerId = $i;
                $dispatcher->listen('test.event', function () use ($listenerId, &$executionOrder) {
                    $executionOrder[] = $listenerId;
                });
            }
            
            // Dispatch the event
            $dispatcher->dispatch('test.event');
            
            // Verify listeners executed in registration order
            $expectedOrder = range(0, $numListeners - 1);
            $this->assertEquals($expectedOrder, $executionOrder, 
                "Iteration {$iteration}: Listeners should execute in registration order");
        }
    }
    
    /**
     * Property 31 (with priorities): Event Listener Execution Order with Priorities
     * 
     * For any set of event listeners with different priorities,
     * the Event Dispatcher SHALL execute them by priority first,
     * then by registration order within each priority level.
     * 
     * Validates: Requirements 14.4
     * 
     * Feature: core-bootstrap-flow, Property 31: Event Listener Execution Order
     */
    public function testProperty31EventListenerExecutionOrderWithPriorities(): void
    {
        // Run multiple iterations
        for ($iteration = 0; $iteration < 100; $iteration++) {
            $dispatcher = new EventDispatcher();
            
            // Track execution order
            $executionOrder = [];
            
            // Register listeners with different priorities in random order
            // Priority 20 (later)
            $dispatcher->listen('test.event', function () use (&$executionOrder) {
                $executionOrder[] = 'priority20-first';
            }, 20);
            
            // Priority 10 (earlier)
            $dispatcher->listen('test.event', function () use (&$executionOrder) {
                $executionOrder[] = 'priority10-first';
            }, 10);
            
            // Priority 10 (earlier, but registered second)
            $dispatcher->listen('test.event', function () use (&$executionOrder) {
                $executionOrder[] = 'priority10-second';
            }, 10);
            
            // Priority 5 (earliest)
            $dispatcher->listen('test.event', function () use (&$executionOrder) {
                $executionOrder[] = 'priority5-first';
            }, 5);
            
            // Dispatch the event
            $dispatcher->dispatch('test.event');
            
            // Verify execution order: priority 5, then priority 10 (in registration order), then priority 20
            $expectedOrder = [
                'priority5-first',
                'priority10-first',
                'priority10-second',
                'priority20-first'
            ];
            
            $this->assertEquals($expectedOrder, $executionOrder,
                "Iteration {$iteration}: Listeners should execute by priority, then registration order");
        }
    }
    
    /**
     * Property 32: Non-Blocking Event Listeners
     * 
     * For any event listener that throws an exception,
     * the Event Dispatcher SHALL prevent it from blocking
     * the execution of subsequent listeners.
     * 
     * Validates: Requirements 14.5
     * 
     * Feature: core-bootstrap-flow, Property 32: Non-Blocking Event Listeners
     */
    public function testProperty32NonBlockingEventListeners(): void
    {
        // Run multiple iterations
        for ($iteration = 0; $iteration < 100; $iteration++) {
            $dispatcher = new EventDispatcher();
            
            // Generate random number of listeners (3-10)
            $numListeners = rand(3, 10);
            
            // Randomly choose which listener will throw an exception (not first or last)
            $failingListenerIndex = rand(1, $numListeners - 2);
            
            // Track execution
            $executedListeners = [];
            
            // Register listeners
            for ($i = 0; $i < $numListeners; $i++) {
                $listenerId = $i;
                
                if ($i === $failingListenerIndex) {
                    // This listener throws an exception
                    $dispatcher->listen('test.event', function () use ($listenerId) {
                        throw new \RuntimeException("Listener {$listenerId} failed");
                    });
                } else {
                    // Normal listener
                    $dispatcher->listen('test.event', function () use ($listenerId, &$executedListeners) {
                        $executedListeners[] = $listenerId;
                    });
                }
            }
            
            // Dispatch the event (should not throw)
            $dispatcher->dispatch('test.event');
            
            // Verify all non-failing listeners executed
            $expectedExecuted = array_values(array_filter(
                range(0, $numListeners - 1),
                fn($i) => $i !== $failingListenerIndex
            ));
            
            $this->assertEquals($expectedExecuted, $executedListeners,
                "Iteration {$iteration}: All non-failing listeners should execute despite exception in listener {$failingListenerIndex}");
        }
    }
    
    /**
     * Property 32 (multiple failures): Non-Blocking with Multiple Failures
     * 
     * For any event with multiple failing listeners,
     * the Event Dispatcher SHALL continue executing all listeners
     * regardless of how many fail.
     * 
     * Validates: Requirements 14.5
     * 
     * Feature: core-bootstrap-flow, Property 32: Non-Blocking Event Listeners
     */
    public function testProperty32NonBlockingEventListenersWithMultipleFailures(): void
    {
        // Run multiple iterations
        for ($iteration = 0; $iteration < 100; $iteration++) {
            $dispatcher = new EventDispatcher();
            
            // Generate random number of listeners (5-10)
            $numListeners = rand(5, 10);
            
            // Randomly choose 2-3 listeners to fail
            $numFailures = rand(2, 3);
            $failingIndices = array_rand(range(0, $numListeners - 1), $numFailures);
            if (!is_array($failingIndices)) {
                $failingIndices = [$failingIndices];
            }
            
            // Track execution
            $executedListeners = [];
            
            // Register listeners
            for ($i = 0; $i < $numListeners; $i++) {
                $listenerId = $i;
                
                if (in_array($i, $failingIndices)) {
                    // This listener throws an exception
                    $dispatcher->listen('test.event', function () use ($listenerId) {
                        throw new \RuntimeException("Listener {$listenerId} failed");
                    });
                } else {
                    // Normal listener
                    $dispatcher->listen('test.event', function () use ($listenerId, &$executedListeners) {
                        $executedListeners[] = $listenerId;
                    });
                }
            }
            
            // Dispatch the event (should not throw)
            $dispatcher->dispatch('test.event');
            
            // Verify all non-failing listeners executed
            $expectedExecuted = array_values(array_filter(
                range(0, $numListeners - 1),
                fn($i) => !in_array($i, $failingIndices)
            ));
            
            $this->assertEquals($expectedExecuted, $executedListeners,
                "Iteration {$iteration}: All non-failing listeners should execute despite {$numFailures} failures");
        }
    }
}
