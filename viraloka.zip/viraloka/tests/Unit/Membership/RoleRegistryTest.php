<?php

declare(strict_types=1);

namespace Tests\Unit\Membership;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Membership\RoleRegistry;
use Viraloka\Core\Membership\Membership;

/**
 * Unit tests for RoleRegistry
 * 
 * Tests role registration, capability management, and default roles.
 */
class RoleRegistryTest extends TestCase
{
    private RoleRegistry $registry;

    protected function setUp(): void
    {
        $this->registry = new RoleRegistry();
    }

    public function testDefaultRolesAreInitialized(): void
    {
        // Act
        $roles = $this->registry->getAllRoles();
        
        // Assert
        $this->assertContains(Membership::ROLE_OWNER, $roles);
        $this->assertContains(Membership::ROLE_ADMIN, $roles);
        $this->assertContains(Membership::ROLE_MEMBER, $roles);
    }

    public function testOwnerRoleHasFullCapabilities(): void
    {
        // Act
        $capabilities = $this->registry->getCapabilities(Membership::ROLE_OWNER);
        
        // Assert
        $this->assertContains('workspace.manage', $capabilities);
        $this->assertContains('workspace.delete', $capabilities);
        $this->assertContains('membership.manage', $capabilities);
        $this->assertContains('billing.manage', $capabilities);
        $this->assertContains('content.create', $capabilities);
        $this->assertContains('content.edit', $capabilities);
        $this->assertContains('content.delete', $capabilities);
    }

    public function testAdminRoleHasManagementCapabilities(): void
    {
        // Act
        $capabilities = $this->registry->getCapabilities(Membership::ROLE_ADMIN);
        
        // Assert
        $this->assertContains('workspace.manage', $capabilities);
        $this->assertContains('membership.invite', $capabilities);
        $this->assertContains('content.create', $capabilities);
        $this->assertContains('content.edit', $capabilities);
        $this->assertContains('content.delete', $capabilities);
        
        // Admin should not have billing access
        $this->assertNotContains('billing.manage', $capabilities);
        $this->assertNotContains('workspace.delete', $capabilities);
    }

    public function testMemberRoleHasBasicCapabilities(): void
    {
        // Act
        $capabilities = $this->registry->getCapabilities(Membership::ROLE_MEMBER);
        
        // Assert
        $this->assertContains('content.create', $capabilities);
        $this->assertContains('content.edit', $capabilities);
        $this->assertContains('content.view', $capabilities);
        
        // Member should not have management capabilities
        $this->assertNotContains('workspace.manage', $capabilities);
        $this->assertNotContains('membership.manage', $capabilities);
        $this->assertNotContains('billing.manage', $capabilities);
    }

    public function testRegisterCustomRole(): void
    {
        // Arrange
        $customRole = 'editor';
        $capabilities = ['content.create', 'content.edit', 'content.view'];
        
        // Act
        $this->registry->registerRole($customRole, $capabilities);
        
        // Assert
        $roles = $this->registry->getAllRoles();
        $this->assertContains($customRole, $roles);
        
        $retrievedCapabilities = $this->registry->getCapabilities($customRole);
        $this->assertEquals($capabilities, $retrievedCapabilities);
    }

    public function testRoleHasCapabilityReturnsTrue(): void
    {
        // Act & Assert
        $this->assertTrue($this->registry->roleHasCapability(Membership::ROLE_OWNER, 'workspace.manage'));
        $this->assertTrue($this->registry->roleHasCapability(Membership::ROLE_ADMIN, 'content.edit'));
        $this->assertTrue($this->registry->roleHasCapability(Membership::ROLE_MEMBER, 'content.create'));
    }

    public function testRoleHasCapabilityReturnsFalse(): void
    {
        // Act & Assert
        $this->assertFalse($this->registry->roleHasCapability(Membership::ROLE_MEMBER, 'billing.manage'));
        $this->assertFalse($this->registry->roleHasCapability(Membership::ROLE_ADMIN, 'workspace.delete'));
        $this->assertFalse($this->registry->roleHasCapability('nonexistent-role', 'any.capability'));
    }

    public function testGetCapabilitiesForNonexistentRoleReturnsEmptyArray(): void
    {
        // Act
        $capabilities = $this->registry->getCapabilities('nonexistent-role');
        
        // Assert
        $this->assertIsArray($capabilities);
        $this->assertEmpty($capabilities);
    }

    public function testRegisterRoleOverwritesExistingRole(): void
    {
        // Arrange
        $role = 'custom-role';
        $initialCapabilities = ['capability1', 'capability2'];
        $newCapabilities = ['capability3', 'capability4'];
        
        // Act
        $this->registry->registerRole($role, $initialCapabilities);
        $this->registry->registerRole($role, $newCapabilities);
        
        // Assert
        $capabilities = $this->registry->getCapabilities($role);
        $this->assertEquals($newCapabilities, $capabilities);
        $this->assertNotContains('capability1', $capabilities);
    }

    public function testCustomRoleWithEmptyCapabilities(): void
    {
        // Arrange
        $role = 'viewer';
        $capabilities = [];
        
        // Act
        $this->registry->registerRole($role, $capabilities);
        
        // Assert
        $retrievedCapabilities = $this->registry->getCapabilities($role);
        $this->assertIsArray($retrievedCapabilities);
        $this->assertEmpty($retrievedCapabilities);
        $this->assertFalse($this->registry->roleHasCapability($role, 'any.capability'));
    }
}
