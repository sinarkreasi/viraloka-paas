<?php

declare(strict_types=1);

namespace Tests\Unit\Membership;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Membership\Repositories\MembershipRepository;
use Viraloka\Core\Membership\Membership;
use Viraloka\Core\Adapter\Testing\InMemoryStorageAdapter;

/**
 * Unit tests for MembershipRepository
 * 
 * Tests persistence operations using InMemoryStorageAdapter.
 */
class MembershipRepositoryTest extends TestCase
{
    private InMemoryStorageAdapter $storageAdapter;
    private MembershipRepository $repository;

    protected function setUp(): void
    {
        $this->storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new MembershipRepository($this->storageAdapter);
    }

    public function testCreateMembership(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_ADMIN,
            Membership::STATUS_ACTIVE
        );
        
        // Act
        $result = $this->repository->create($membership);
        
        // Assert
        $this->assertSame($membership, $result);
        
        // Verify it can be retrieved
        $retrieved = $this->repository->findById('membership-123');
        $this->assertNotNull($retrieved);
        $this->assertEquals('membership-123', $retrieved->membershipId);
        $this->assertEquals('identity-456', $retrieved->identityId);
        $this->assertEquals('workspace-789', $retrieved->workspaceId);
    }

    public function testCreateThrowsExceptionWhenMembershipExists(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_ADMIN
        );
        
        $this->repository->create($membership);
        
        // Assert
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Membership already exists');
        
        // Act - try to create again
        $this->repository->create($membership);
    }

    public function testFindById(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_MEMBER
        );
        
        $this->repository->create($membership);
        
        // Act
        $result = $this->repository->findById('membership-123');
        
        // Assert
        $this->assertNotNull($result);
        $this->assertEquals('membership-123', $result->membershipId);
        $this->assertEquals('identity-456', $result->identityId);
        $this->assertEquals('workspace-789', $result->workspaceId);
        $this->assertEquals(Membership::ROLE_MEMBER, $result->role);
    }

    public function testFindByIdReturnsNullWhenNotFound(): void
    {
        // Act
        $result = $this->repository->findById('nonexistent');
        
        // Assert
        $this->assertNull($result);
    }

    public function testFindByIdentityAndWorkspace(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_ADMIN
        );
        
        $this->repository->create($membership);
        
        // Act
        $result = $this->repository->findByIdentityAndWorkspace('identity-456', 'workspace-789');
        
        // Assert
        $this->assertNotNull($result);
        $this->assertEquals('membership-123', $result->membershipId);
    }

    public function testFindByIdentityAndWorkspaceReturnsNullWhenNotFound(): void
    {
        // Act
        $result = $this->repository->findByIdentityAndWorkspace('identity-456', 'workspace-789');
        
        // Assert
        $this->assertNull($result);
    }

    public function testFindByIdentity(): void
    {
        // Arrange
        $membership1 = new Membership('membership-1', 'identity-123', 'workspace-1', Membership::ROLE_OWNER);
        $membership2 = new Membership('membership-2', 'identity-123', 'workspace-2', Membership::ROLE_MEMBER);
        $membership3 = new Membership('membership-3', 'identity-456', 'workspace-1', Membership::ROLE_ADMIN);
        
        $this->repository->create($membership1);
        $this->repository->create($membership2);
        $this->repository->create($membership3);
        
        // Act
        $result = $this->repository->findByIdentity('identity-123');
        
        // Assert
        $this->assertCount(2, $result);
        $this->assertEquals('membership-1', $result[0]->membershipId);
        $this->assertEquals('membership-2', $result[1]->membershipId);
    }

    public function testFindByWorkspace(): void
    {
        // Arrange
        $membership1 = new Membership('membership-1', 'identity-1', 'workspace-123', Membership::ROLE_OWNER);
        $membership2 = new Membership('membership-2', 'identity-2', 'workspace-123', Membership::ROLE_MEMBER);
        $membership3 = new Membership('membership-3', 'identity-3', 'workspace-456', Membership::ROLE_ADMIN);
        
        $this->repository->create($membership1);
        $this->repository->create($membership2);
        $this->repository->create($membership3);
        
        // Act
        $result = $this->repository->findByWorkspace('workspace-123');
        
        // Assert
        $this->assertCount(2, $result);
        $this->assertEquals('membership-1', $result[0]->membershipId);
        $this->assertEquals('membership-2', $result[1]->membershipId);
    }

    public function testUpdateMembership(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_MEMBER,
            Membership::STATUS_ACTIVE
        );
        
        $this->repository->create($membership);
        
        // Modify membership
        $membership->role = Membership::ROLE_ADMIN;
        
        // Act
        $result = $this->repository->update($membership);
        
        // Assert
        $this->assertSame($membership, $result);
        
        // Verify changes persisted
        $retrieved = $this->repository->findById('membership-123');
        $this->assertEquals(Membership::ROLE_ADMIN, $retrieved->role);
    }

    public function testUpdateThrowsExceptionWhenMembershipNotFound(): void
    {
        // Arrange
        $membership = new Membership(
            'nonexistent',
            'identity-456',
            'workspace-789',
            Membership::ROLE_MEMBER
        );
        
        // Assert
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Membership not found');
        
        // Act
        $this->repository->update($membership);
    }

    public function testDeleteMembership(): void
    {
        // Arrange
        $membership = new Membership(
            'membership-123',
            'identity-456',
            'workspace-789',
            Membership::ROLE_MEMBER
        );
        
        $this->repository->create($membership);
        
        // Act
        $result = $this->repository->delete('membership-123');
        
        // Assert
        $this->assertTrue($result);
        
        // Verify it's deleted
        $retrieved = $this->repository->findById('membership-123');
        $this->assertNull($retrieved);
    }

    public function testDeleteReturnsFalseWhenNotFound(): void
    {
        // Act
        $result = $this->repository->delete('nonexistent');
        
        // Assert
        $this->assertFalse($result);
    }

    public function testCountOwnersByWorkspace(): void
    {
        // Arrange
        $membership1 = new Membership('membership-1', 'identity-1', 'workspace-123', Membership::ROLE_OWNER, Membership::STATUS_ACTIVE);
        $membership2 = new Membership('membership-2', 'identity-2', 'workspace-123', Membership::ROLE_OWNER, Membership::STATUS_ACTIVE);
        $membership3 = new Membership('membership-3', 'identity-3', 'workspace-123', Membership::ROLE_ADMIN, Membership::STATUS_ACTIVE);
        $membership4 = new Membership('membership-4', 'identity-4', 'workspace-123', Membership::ROLE_OWNER, Membership::STATUS_REVOKED);
        
        $this->repository->create($membership1);
        $this->repository->create($membership2);
        $this->repository->create($membership3);
        $this->repository->create($membership4);
        
        // Act
        $count = $this->repository->countOwnersByWorkspace('workspace-123');
        
        // Assert
        $this->assertEquals(2, $count); // Only active owners
    }

    public function testCountOwnersReturnsZeroForWorkspaceWithNoOwners(): void
    {
        // Arrange
        $membership = new Membership('membership-1', 'identity-1', 'workspace-123', Membership::ROLE_MEMBER);
        $this->repository->create($membership);
        
        // Act
        $count = $this->repository->countOwnersByWorkspace('workspace-123');
        
        // Assert
        $this->assertEquals(0, $count);
    }
}
