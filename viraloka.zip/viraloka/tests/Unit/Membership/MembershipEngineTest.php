<?php

declare(strict_types=1);

namespace Tests\Unit\Membership;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Membership\MembershipEngine;
use Viraloka\Core\Membership\Membership;
use Viraloka\Core\Membership\Contracts\MembershipRepositoryInterface;
use Viraloka\Core\Membership\Contracts\RoleRegistryInterface;
use Viraloka\Core\Membership\Exceptions\MembershipExistsException;
use Viraloka\Core\Membership\Exceptions\MembershipNotFoundException;
use Viraloka\Core\Membership\Exceptions\MembershipNotPendingException;
use Viraloka\Core\Membership\Exceptions\LastOwnerException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Membership\Events\MembershipAttachedEvent;
use Viraloka\Core\Membership\Events\MembershipRequestedEvent;
use Viraloka\Core\Membership\Events\MembershipApprovedEvent;
use Viraloka\Core\Membership\Events\MembershipRevokedEvent;

/**
 * Unit tests for MembershipEngine
 * 
 * Tests the core functionality of membership lifecycle management.
 */
class MembershipEngineTest extends TestCase
{
    private MembershipRepositoryInterface $repository;
    private EventDispatcher $eventDispatcher;
    private RoleRegistryInterface $roleRegistry;
    private MembershipEngine $engine;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        // Create mock repository
        $this->repository = $this->createMock(MembershipRepositoryInterface::class);
        
        // Create mock role registry
        $this->roleRegistry = $this->createMock(RoleRegistryInterface::class);
        
        // Create event dispatcher with event capture
        $this->eventDispatcher = new EventDispatcher();
        $this->dispatchedEvents = [];
        
        // Capture dispatched events
        $this->eventDispatcher->listen('membership.attached', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.attached', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.requested', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.requested', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.approved', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.approved', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('membership.revoked', function($event) {
            $this->dispatchedEvents[] = ['name' => 'membership.revoked', 'event' => $event];
        });
        
        // Create engine
        $this->engine = new MembershipEngine($this->repository, $this->eventDispatcher, $this->roleRegistry);
    }

    public function testAttachCreatesActiveMembership(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = Membership::ROLE_ADMIN;
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn(null);
        
        $this->repository->expects($this->once())
            ->method('create')
            ->willReturnCallback(function($membership) {
                return $membership;
            });
        
        // Act
        $membership = $this->engine->attach($identityId, $workspaceId, $role);
        
        // Assert
        $this->assertInstanceOf(Membership::class, $membership);
        $this->assertEquals($identityId, $membership->identityId);
        $this->assertEquals($workspaceId, $membership->workspaceId);
        $this->assertEquals($role, $membership->role);
        $this->assertEquals(Membership::STATUS_ACTIVE, $membership->status);
        $this->assertNotEmpty($membership->membershipId);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.attached', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(MembershipAttachedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testAttachThrowsExceptionWhenMembershipExists(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $existingMembership = new Membership('existing-id', $identityId, $workspaceId, Membership::ROLE_MEMBER);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($existingMembership);
        
        // Assert
        $this->expectException(MembershipExistsException::class);
        
        // Act
        $this->engine->attach($identityId, $workspaceId, Membership::ROLE_ADMIN);
    }

    public function testRequestCreatesPendingMembership(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn(null);
        
        $this->repository->expects($this->once())
            ->method('create')
            ->willReturnCallback(function($membership) {
                return $membership;
            });
        
        // Act
        $membership = $this->engine->request($identityId, $workspaceId);
        
        // Assert
        $this->assertInstanceOf(Membership::class, $membership);
        $this->assertEquals($identityId, $membership->identityId);
        $this->assertEquals($workspaceId, $membership->workspaceId);
        $this->assertEquals(Membership::STATUS_PENDING, $membership->status);
        $this->assertEquals(Membership::ROLE_MEMBER, $membership->role);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.requested', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(MembershipRequestedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testApproveChangesPendingToActive(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = Membership::ROLE_ADMIN;
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_MEMBER, Membership::STATUS_PENDING);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturnCallback(function($membership) {
                return $membership;
            });
        
        // Act
        $result = $this->engine->approve($identityId, $workspaceId, $role);
        
        // Assert
        $this->assertInstanceOf(Membership::class, $result);
        $this->assertEquals(Membership::STATUS_ACTIVE, $result->status);
        $this->assertEquals($role, $result->role);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.approved', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(MembershipApprovedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testApproveThrowsExceptionWhenNotPending(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_MEMBER, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        // Assert
        $this->expectException(MembershipNotPendingException::class);
        
        // Act
        $this->engine->approve($identityId, $workspaceId, Membership::ROLE_ADMIN);
    }

    public function testApproveThrowsExceptionWhenMembershipNotFound(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn(null);
        
        // Assert
        $this->expectException(MembershipNotFoundException::class);
        
        // Act
        $this->engine->approve($identityId, $workspaceId, Membership::ROLE_ADMIN);
    }

    public function testRevokeChangesStatusToRevoked(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_MEMBER, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturn($membership);
        
        // Act
        $result = $this->engine->revoke($identityId, $workspaceId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Membership::STATUS_REVOKED, $membership->status);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('membership.revoked', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(MembershipRevokedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testRevokeThrowsExceptionForLastOwner(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_OWNER, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->repository->expects($this->once())
            ->method('countOwnersByWorkspace')
            ->with($workspaceId)
            ->willReturn(1);
        
        // Assert
        $this->expectException(LastOwnerException::class);
        
        // Act
        $this->engine->revoke($identityId, $workspaceId);
    }

    public function testRevokeAllowsWhenMultipleOwnersExist(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_OWNER, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->repository->expects($this->once())
            ->method('countOwnersByWorkspace')
            ->with($workspaceId)
            ->willReturn(2);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturn($membership);
        
        // Act
        $result = $this->engine->revoke($identityId, $workspaceId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Membership::STATUS_REVOKED, $membership->status);
    }

    public function testGetMembership(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_MEMBER);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        // Act
        $result = $this->engine->getMembership($identityId, $workspaceId);
        
        // Assert
        $this->assertSame($membership, $result);
    }

    public function testGetMembershipsForIdentity(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $memberships = [
            new Membership('membership-1', $identityId, 'workspace-1', Membership::ROLE_OWNER),
            new Membership('membership-2', $identityId, 'workspace-2', Membership::ROLE_MEMBER),
        ];
        
        $this->repository->expects($this->once())
            ->method('findByIdentity')
            ->with($identityId)
            ->willReturn($memberships);
        
        // Act
        $result = $this->engine->getMembershipsForIdentity($identityId);
        
        // Assert
        $this->assertCount(2, $result);
        $this->assertSame($memberships, $result);
    }

    public function testGetMembershipsForWorkspace(): void
    {
        // Arrange
        $workspaceId = 'workspace-456';
        $memberships = [
            new Membership('membership-1', 'identity-1', $workspaceId, Membership::ROLE_OWNER),
            new Membership('membership-2', 'identity-2', $workspaceId, Membership::ROLE_MEMBER),
        ];
        
        $this->repository->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($memberships);
        
        // Act
        $result = $this->engine->getMembershipsForWorkspace($workspaceId);
        
        // Assert
        $this->assertCount(2, $result);
        $this->assertSame($memberships, $result);
    }

    public function testHasPermissionReturnsTrueWhenRoleHasCapability(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $capability = 'content.edit';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_ADMIN, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->roleRegistry->expects($this->once())
            ->method('roleHasCapability')
            ->with(Membership::ROLE_ADMIN, $capability)
            ->willReturn(true);
        
        // Act
        $result = $this->engine->hasPermission($identityId, $workspaceId, $capability);
        
        // Assert
        $this->assertTrue($result);
    }

    public function testHasPermissionReturnsFalseWhenRoleDoesNotHaveCapability(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $capability = 'billing.manage';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_MEMBER, Membership::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        $this->roleRegistry->expects($this->once())
            ->method('roleHasCapability')
            ->with(Membership::ROLE_MEMBER, $capability)
            ->willReturn(false);
        
        // Act
        $result = $this->engine->hasPermission($identityId, $workspaceId, $capability);
        
        // Assert
        $this->assertFalse($result);
    }

    public function testHasPermissionReturnsFalseWhenMembershipNotFound(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $capability = 'content.edit';
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn(null);
        
        // Act
        $result = $this->engine->hasPermission($identityId, $workspaceId, $capability);
        
        // Assert
        $this->assertFalse($result);
    }

    public function testHasPermissionReturnsFalseWhenMembershipNotActive(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $capability = 'content.edit';
        $membership = new Membership('membership-id', $identityId, $workspaceId, Membership::ROLE_ADMIN, Membership::STATUS_REVOKED);
        
        $this->repository->expects($this->once())
            ->method('findByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($membership);
        
        // Act
        $result = $this->engine->hasPermission($identityId, $workspaceId, $capability);
        
        // Assert
        $this->assertFalse($result);
    }
}
