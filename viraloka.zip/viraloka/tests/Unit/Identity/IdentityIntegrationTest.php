<?php

declare(strict_types=1);

namespace Tests\Unit\Identity;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Identity\IdentityEngine;
use Viraloka\Core\Identity\Repositories\IdentityRepository;
use Viraloka\Core\Identity\Identity;
use Viraloka\Core\Identity\Exceptions\IdentityExistsException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Adapter\Testing\InMemoryStorageAdapter;

/**
 * Integration tests for Identity system
 * 
 * Tests the complete flow from engine through repository to storage.
 */
class IdentityIntegrationTest extends TestCase
{
    private IdentityEngine $engine;
    private IdentityRepository $repository;
    private EventDispatcher $eventDispatcher;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        $storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new IdentityRepository($storageAdapter);
        $this->eventDispatcher = new EventDispatcher();
        
        // Capture events
        $this->dispatchedEvents = [];
        $this->eventDispatcher->listen('identity.created', function($event) {
            $this->dispatchedEvents[] = ['name' => 'identity.created', 'event' => $event];
        });
        $this->eventDispatcher->listen('identity.suspended', function($event) {
            $this->dispatchedEvents[] = ['name' => 'identity.suspended', 'event' => $event];
        });
        
        $this->engine = new IdentityEngine($this->repository, $this->eventDispatcher);
    }

    public function testCompleteIdentityLifecycle(): void
    {
        // Create identity
        $identity = $this->engine->create([
            'email' => 'user@example.com',
            'metadata' => ['name' => 'Test User']
        ]);
        
        $this->assertNotNull($identity);
        $this->assertEquals('user@example.com', $identity->email);
        $this->assertEquals(Identity::STATUS_ACTIVE, $identity->status);
        $this->assertCount(1, $this->dispatchedEvents);
        
        // Resolve by email
        $resolved = $this->engine->resolve('user@example.com');
        $this->assertNotNull($resolved);
        $this->assertEquals($identity->identityId, $resolved->identityId);
        
        // Find by ID
        $found = $this->engine->findById($identity->identityId);
        $this->assertNotNull($found);
        $this->assertEquals($identity->identityId, $found->identityId);
        
        // Suspend identity
        $suspended = $this->engine->suspend($identity->identityId);
        $this->assertTrue($suspended);
        $this->assertCount(2, $this->dispatchedEvents);
        
        // Verify suspended
        $suspendedIdentity = $this->engine->findById($identity->identityId);
        $this->assertEquals(Identity::STATUS_SUSPENDED, $suspendedIdentity->status);
        
        // Activate identity
        $activated = $this->engine->activate($identity->identityId);
        $this->assertTrue($activated);
        
        // Verify activated
        $activeIdentity = $this->engine->findById($identity->identityId);
        $this->assertEquals(Identity::STATUS_ACTIVE, $activeIdentity->status);
    }

    public function testEmailUniquenessEnforcement(): void
    {
        // Create first identity
        $identity1 = $this->engine->create([
            'email' => 'unique@example.com'
        ]);
        
        $this->assertNotNull($identity1);
        
        // Attempt to create second identity with same email
        $this->expectException(IdentityExistsException::class);
        $this->engine->create([
            'email' => 'unique@example.com'
        ]);
    }

    public function testSuspendIsIdempotent(): void
    {
        // Create identity
        $identity = $this->engine->create([
            'email' => 'test@example.com'
        ]);
        
        // Clear events
        $this->dispatchedEvents = [];
        
        // Suspend once
        $this->engine->suspend($identity->identityId);
        $this->assertCount(1, $this->dispatchedEvents);
        
        // Suspend again (idempotent)
        $this->engine->suspend($identity->identityId);
        $this->assertCount(1, $this->dispatchedEvents); // No new event
        
        // Verify still suspended
        $found = $this->engine->findById($identity->identityId);
        $this->assertEquals(Identity::STATUS_SUSPENDED, $found->status);
    }

    public function testActivateIsIdempotent(): void
    {
        // Create identity (already active)
        $identity = $this->engine->create([
            'email' => 'test@example.com'
        ]);
        
        // Activate (idempotent - already active)
        $this->engine->activate($identity->identityId);
        
        // Verify still active
        $found = $this->engine->findById($identity->identityId);
        $this->assertEquals(Identity::STATUS_ACTIVE, $found->status);
    }

    public function testResolveReturnsNullForNonExistent(): void
    {
        $result = $this->engine->resolve('nonexistent@example.com');
        $this->assertNull($result);
    }

    public function testFindByIdReturnsNullForNonExistent(): void
    {
        $result = $this->engine->findById('non-existent-id');
        $this->assertNull($result);
    }

    public function testSuspendReturnsFalseForNonExistent(): void
    {
        $result = $this->engine->suspend('non-existent-id');
        $this->assertFalse($result);
    }

    public function testActivateReturnsFalseForNonExistent(): void
    {
        $result = $this->engine->activate('non-existent-id');
        $this->assertFalse($result);
    }

    public function testMetadataIsPersisted(): void
    {
        // Create identity with metadata
        $metadata = [
            'name' => 'John Doe',
            'phone' => '+1234567890',
            'preferences' => ['theme' => 'dark']
        ];
        
        $identity = $this->engine->create([
            'email' => 'john@example.com',
            'metadata' => $metadata
        ]);
        
        // Retrieve and verify metadata
        $found = $this->engine->findById($identity->identityId);
        $this->assertEquals($metadata, $found->metadata);
    }
}
