<?php

declare(strict_types=1);

namespace Tests\Unit\Identity;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Identity\IdentityEngine;
use Viraloka\Core\Identity\Identity;
use Viraloka\Core\Identity\Contracts\IdentityRepositoryInterface;
use Viraloka\Core\Identity\Exceptions\IdentityExistsException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Identity\Events\IdentityCreatedEvent;
use Viraloka\Core\Identity\Events\IdentitySuspendedEvent;

/**
 * Unit tests for IdentityEngine
 * 
 * Tests the core functionality of identity lifecycle management.
 */
class IdentityEngineTest extends TestCase
{
    private IdentityRepositoryInterface $repository;
    private EventDispatcher $eventDispatcher;
    private IdentityEngine $engine;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        // Create mock repository
        $this->repository = $this->createMock(IdentityRepositoryInterface::class);
        
        // Create event dispatcher with event capture
        $this->eventDispatcher = new EventDispatcher();
        $this->dispatchedEvents = [];
        
        // Capture dispatched events
        $this->eventDispatcher->listen('identity.created', function($event) {
            $this->dispatchedEvents[] = ['name' => 'identity.created', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('identity.suspended', function($event) {
            $this->dispatchedEvents[] = ['name' => 'identity.suspended', 'event' => $event];
        });
        
        // Create engine
        $this->engine = new IdentityEngine($this->repository, $this->eventDispatcher);
    }

    public function testCreateIdentityWithValidEmail(): void
    {
        // Arrange
        $email = 'test@example.com';
        $metadata = ['name' => 'Test User'];
        
        $this->repository->expects($this->once())
            ->method('emailExists')
            ->with($email)
            ->willReturn(false);
        
        $this->repository->expects($this->once())
            ->method('save')
            ->willReturn(true);
        
        // Act
        $identity = $this->engine->create([
            'email' => $email,
            'metadata' => $metadata
        ]);
        
        // Assert
        $this->assertInstanceOf(Identity::class, $identity);
        $this->assertEquals($email, $identity->email);
        $this->assertEquals(Identity::STATUS_ACTIVE, $identity->status);
        $this->assertEquals($metadata, $identity->metadata);
        $this->assertNotEmpty($identity->identityId);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('identity.created', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(IdentityCreatedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testCreateIdentityThrowsExceptionWhenEmailExists(): void
    {
        // Arrange
        $email = 'existing@example.com';
        
        $this->repository->expects($this->once())
            ->method('emailExists')
            ->with($email)
            ->willReturn(true);
        
        // Assert
        $this->expectException(IdentityExistsException::class);
        
        // Act
        $this->engine->create(['email' => $email]);
    }

    public function testCreateIdentityThrowsExceptionForInvalidEmail(): void
    {
        // Assert
        $this->expectException(\InvalidArgumentException::class);
        
        // Act
        $this->engine->create(['email' => 'invalid-email']);
    }

    public function testResolveIdentityByEmail(): void
    {
        // Arrange
        $email = 'test@example.com';
        $identity = new Identity('test-id', $email);
        
        $this->repository->expects($this->once())
            ->method('findByEmail')
            ->with($email)
            ->willReturn($identity);
        
        // Act
        $result = $this->engine->resolve($email);
        
        // Assert
        $this->assertSame($identity, $result);
    }

    public function testResolveReturnsNullForNonExistentEmail(): void
    {
        // Arrange
        $this->repository->expects($this->once())
            ->method('findByEmail')
            ->willReturn(null);
        
        // Act
        $result = $this->engine->resolve('nonexistent@example.com');
        
        // Assert
        $this->assertNull($result);
    }

    public function testSuspendIdentity(): void
    {
        // Arrange
        $identityId = 'test-id';
        $identity = new Identity($identityId, 'test@example.com', Identity::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($identityId)
            ->willReturn($identity);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturn(true);
        
        // Act
        $result = $this->engine->suspend($identityId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Identity::STATUS_SUSPENDED, $identity->status);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('identity.suspended', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(IdentitySuspendedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testSuspendIsIdempotent(): void
    {
        // Arrange
        $identityId = 'test-id';
        $identity = new Identity($identityId, 'test@example.com', Identity::STATUS_SUSPENDED);
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($identityId)
            ->willReturn($identity);
        
        // update should not be called since already suspended
        $this->repository->expects($this->never())
            ->method('update');
        
        // Act
        $result = $this->engine->suspend($identityId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Identity::STATUS_SUSPENDED, $identity->status);
        
        // No event should be dispatched for idempotent operation
        $this->assertCount(0, $this->dispatchedEvents);
    }

    public function testActivateIdentity(): void
    {
        // Arrange
        $identityId = 'test-id';
        $identity = new Identity($identityId, 'test@example.com', Identity::STATUS_SUSPENDED);
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($identityId)
            ->willReturn($identity);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturn(true);
        
        // Act
        $result = $this->engine->activate($identityId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Identity::STATUS_ACTIVE, $identity->status);
    }

    public function testActivateIsIdempotent(): void
    {
        // Arrange
        $identityId = 'test-id';
        $identity = new Identity($identityId, 'test@example.com', Identity::STATUS_ACTIVE);
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($identityId)
            ->willReturn($identity);
        
        // update should not be called since already active
        $this->repository->expects($this->never())
            ->method('update');
        
        // Act
        $result = $this->engine->activate($identityId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Identity::STATUS_ACTIVE, $identity->status);
    }

    public function testFindById(): void
    {
        // Arrange
        $identityId = 'test-id';
        $identity = new Identity($identityId, 'test@example.com');
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($identityId)
            ->willReturn($identity);
        
        // Act
        $result = $this->engine->findById($identityId);
        
        // Assert
        $this->assertSame($identity, $result);
    }
}
