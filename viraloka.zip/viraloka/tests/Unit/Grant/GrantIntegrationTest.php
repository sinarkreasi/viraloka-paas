<?php

declare(strict_types=1);

namespace Tests\Unit\Grant;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Grant\GrantEngine;
use Viraloka\Core\Grant\Repositories\GrantRepository;
use Viraloka\Adapter\Testing\InMemoryStorageAdapter;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Grant\Exceptions\NoConstraintException;
use Viraloka\Core\Grant\Exceptions\GrantExhaustedException;
use DateTimeImmutable;

/**
 * Integration tests for Grant system
 * 
 * Tests the complete workflow of grant lifecycle management.
 */
class GrantIntegrationTest extends TestCase
{
    private GrantEngine $engine;
    private GrantRepository $repository;
    private EventDispatcher $eventDispatcher;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        $storageAdapter = new InMemoryStorageAdapter();
        $this->repository = new GrantRepository($storageAdapter);
        $this->eventDispatcher = new EventDispatcher();
        
        // Capture all grant events
        $this->dispatchedEvents = [];
        
        $this->eventDispatcher->listen('grant.issued', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.issued', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.consumed', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.consumed', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.revoked', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.revoked', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.exhausted', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.exhausted', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.expired', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.expired', 'event' => $event];
        });
        
        $this->engine = new GrantEngine($this->repository, $this->eventDispatcher);
    }

    public function testCompleteGrantLifecycleWithTimeConstraint(): void
    {
        // Issue grant with time constraint
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['expires_at' => new DateTimeImmutable('+1 hour')]
        );

        // Verify grant was created
        $this->assertNotNull($grant);
        $this->assertEquals('identity-123', $grant->identityId);
        
        // Verify grant is valid
        $this->assertTrue($this->engine->validate($grant->grantId));
        
        // Revoke grant
        $this->assertTrue($this->engine->revoke($grant->grantId));
        
        // Verify grant is no longer valid
        $this->assertFalse($this->engine->validate($grant->grantId));
        
        // Verify events
        $this->assertCount(2, $this->dispatchedEvents);
        $this->assertEquals('grant.issued', $this->dispatchedEvents[0]['name']);
        $this->assertEquals('grant.revoked', $this->dispatchedEvents[1]['name']);
    }

    public function testCompleteGrantLifecycleWithUsageConstraint(): void
    {
        // Issue grant with usage constraint
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['max_usage' => 3]
        );

        // Consume grant 3 times
        $this->assertTrue($this->engine->consume($grant->grantId));
        $this->assertTrue($this->engine->consume($grant->grantId));
        $this->assertTrue($this->engine->consume($grant->grantId));
        
        // Verify grant is exhausted
        $this->assertFalse($this->engine->validate($grant->grantId));
        
        // Verify attempting to consume exhausted grant throws exception
        $this->expectException(GrantExhaustedException::class);
        $this->engine->consume($grant->grantId);
    }

    public function testGrantWithScopeConstraint(): void
    {
        // Issue grant with scope constraint
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['allowed_actions' => ['read', 'write']]
        );

        // Verify allowed actions
        $this->assertTrue($grant->isActionAllowed('read'));
        $this->assertTrue($grant->isActionAllowed('write'));
        $this->assertFalse($grant->isActionAllowed('delete'));
    }

    public function testGrantWithMultipleConstraints(): void
    {
        // Issue grant with multiple constraints
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'admin',
            [
                'expires_at' => new DateTimeImmutable('+1 hour'),
                'max_usage' => 5,
                'allowed_actions' => ['read', 'write', 'delete']
            ],
            ['purpose' => 'temporary admin access']
        );

        // Verify all constraints
        $this->assertNotNull($grant->expiresAt);
        $this->assertEquals(5, $grant->maxUsage);
        $this->assertEquals(['read', 'write', 'delete'], $grant->allowedActions);
        $this->assertEquals(['purpose' => 'temporary admin access'], $grant->metadata);
        
        // Verify grant is valid
        $this->assertTrue($this->engine->validate($grant->grantId));
    }

    public function testGetActiveGrants(): void
    {
        // Issue multiple grants
        $grant1 = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['expires_at' => new DateTimeImmutable('+1 hour')]
        );
        
        $grant2 = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'admin',
            ['max_usage' => 5]
        );
        
        $grant3 = $this->engine->issue(
            'identity-123',
            'workspace-789', // Different workspace
            'member',
            ['expires_at' => new DateTimeImmutable('+1 hour')]
        );

        // Get active grants for identity-123 in workspace-456
        $activeGrants = $this->engine->getActiveGrants('identity-123', 'workspace-456');
        
        // Verify only grants for the specific workspace are returned
        $this->assertCount(2, $activeGrants);
        
        $grantIds = array_map(fn($g) => $g->grantId, $activeGrants);
        $this->assertContains($grant1->grantId, $grantIds);
        $this->assertContains($grant2->grantId, $grantIds);
        $this->assertNotContains($grant3->grantId, $grantIds);
    }

    public function testGrantWithoutConstraintsThrowsException(): void
    {
        // Verify exception is thrown when no constraints provided
        $this->expectException(NoConstraintException::class);
        
        $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            [] // No constraints
        );
    }

    public function testExpiredGrantValidation(): void
    {
        // Issue grant that expires in the past
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['expires_at' => new DateTimeImmutable('-1 hour')]
        );

        // Validate should return false and emit expired event
        $this->assertFalse($this->engine->validate($grant->grantId));
        
        // Verify expired event was dispatched
        $eventNames = array_map(fn($e) => $e['name'], $this->dispatchedEvents);
        $this->assertContains('grant.expired', $eventNames);
    }

    public function testGrantPersistenceAcrossEngineInstances(): void
    {
        // Issue grant
        $grant = $this->engine->issue(
            'identity-123',
            'workspace-456',
            'member',
            ['max_usage' => 5]
        );

        // Create new engine instance with same repository
        $newEngine = new GrantEngine($this->repository, $this->eventDispatcher);
        
        // Verify grant can be found
        $foundGrant = $newEngine->findById($grant->grantId);
        $this->assertNotNull($foundGrant);
        $this->assertEquals($grant->grantId, $foundGrant->grantId);
        
        // Consume grant with new engine
        $this->assertTrue($newEngine->consume($grant->grantId));
        
        // Verify consumption persisted
        $foundGrant = $newEngine->findById($grant->grantId);
        $this->assertEquals(1, $foundGrant->currentUsage);
    }
}
