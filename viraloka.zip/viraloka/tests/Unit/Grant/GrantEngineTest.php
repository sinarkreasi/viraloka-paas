<?php

declare(strict_types=1);

namespace Tests\Unit\Grant;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Grant\GrantEngine;
use Viraloka\Core\Grant\Grant;
use Viraloka\Core\Grant\Contracts\GrantRepositoryInterface;
use Viraloka\Core\Grant\Exceptions\NoConstraintException;
use Viraloka\Core\Grant\Exceptions\GrantNotFoundException;
use Viraloka\Core\Grant\Exceptions\GrantExhaustedException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Grant\Events\GrantIssuedEvent;
use Viraloka\Core\Grant\Events\GrantConsumedEvent;
use Viraloka\Core\Grant\Events\GrantRevokedEvent;
use Viraloka\Core\Grant\Events\GrantExhaustedEvent;
use DateTimeImmutable;

/**
 * Unit tests for GrantEngine
 * 
 * Tests the core functionality of grant lifecycle management.
 */
class GrantEngineTest extends TestCase
{
    private GrantRepositoryInterface $repository;
    private EventDispatcher $eventDispatcher;
    private GrantEngine $engine;
    private array $dispatchedEvents = [];

    protected function setUp(): void
    {
        // Create mock repository
        $this->repository = $this->createMock(GrantRepositoryInterface::class);
        
        // Create event dispatcher with event capture
        $this->eventDispatcher = new EventDispatcher();
        $this->dispatchedEvents = [];
        
        // Capture dispatched events
        $this->eventDispatcher->listen('grant.issued', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.issued', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.consumed', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.consumed', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.revoked', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.revoked', 'event' => $event];
        });
        
        $this->eventDispatcher->listen('grant.exhausted', function($event) {
            $this->dispatchedEvents[] = ['name' => 'grant.exhausted', 'event' => $event];
        });
        
        // Create engine
        $this->engine = new GrantEngine($this->repository, $this->eventDispatcher);
    }

    public function testIssueGrantWithTimeConstraint(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = 'member';
        $expiresAt = new DateTimeImmutable('+1 hour');
        $constraints = ['expires_at' => $expiresAt];
        
        $this->repository->expects($this->once())
            ->method('create')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act
        $grant = $this->engine->issue($identityId, $workspaceId, $role, $constraints);
        
        // Assert
        $this->assertInstanceOf(Grant::class, $grant);
        $this->assertEquals($identityId, $grant->identityId);
        $this->assertEquals($workspaceId, $grant->workspaceId);
        $this->assertEquals($role, $grant->role);
        $this->assertEquals($expiresAt, $grant->expiresAt);
        $this->assertEquals(Grant::STATUS_ACTIVE, $grant->status);
        $this->assertNotEmpty($grant->grantId);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('grant.issued', $this->dispatchedEvents[0]['name']);
        $this->assertInstanceOf(GrantIssuedEvent::class, $this->dispatchedEvents[0]['event']);
    }

    public function testIssueGrantWithUsageConstraint(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = 'member';
        $maxUsage = 5;
        $constraints = ['max_usage' => $maxUsage];
        
        $this->repository->expects($this->once())
            ->method('create')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act
        $grant = $this->engine->issue($identityId, $workspaceId, $role, $constraints);
        
        // Assert
        $this->assertEquals($maxUsage, $grant->maxUsage);
        $this->assertEquals(0, $grant->currentUsage);
    }

    public function testIssueGrantWithScopeConstraint(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = 'member';
        $allowedActions = ['read', 'write'];
        $constraints = ['allowed_actions' => $allowedActions];
        
        $this->repository->expects($this->once())
            ->method('create')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act
        $grant = $this->engine->issue($identityId, $workspaceId, $role, $constraints);
        
        // Assert
        $this->assertEquals($allowedActions, $grant->allowedActions);
    }

    public function testIssueGrantThrowsExceptionWithoutConstraints(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $role = 'member';
        $constraints = []; // No constraints
        
        // Assert
        $this->expectException(NoConstraintException::class);
        
        // Act
        $this->engine->issue($identityId, $workspaceId, $role, $constraints);
    }

    public function testRevokeGrant(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            new DateTimeImmutable('+1 hour')
        );
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act
        $result = $this->engine->revoke($grantId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(Grant::STATUS_REVOKED, $grant->status);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('grant.revoked', $this->dispatchedEvents[0]['name']);
    }

    public function testValidateActiveGrant(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            new DateTimeImmutable('+1 hour')
        );
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        // Act
        $result = $this->engine->validate($grantId);
        
        // Assert
        $this->assertTrue($result);
    }

    public function testValidateExpiredGrant(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            new DateTimeImmutable('-1 hour') // Expired
        );
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        $this->repository->expects($this->once())
            ->method('update');
        
        // Act
        $result = $this->engine->validate($grantId);
        
        // Assert
        $this->assertFalse($result);
    }

    public function testConsumeGrant(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            null,
            5 // max_usage
        );
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act
        $result = $this->engine->consume($grantId);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(1, $grant->currentUsage);
        
        // Verify event was dispatched
        $this->assertCount(1, $this->dispatchedEvents);
        $this->assertEquals('grant.consumed', $this->dispatchedEvents[0]['name']);
    }

    public function testConsumeGrantUntilExhausted(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            null,
            2 // max_usage = 2
        );
        
        $this->repository->expects($this->exactly(2))
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        $this->repository->expects($this->exactly(2))
            ->method('update')
            ->willReturnCallback(function($grant) {
                return $grant;
            });
        
        // Act - First consumption
        $result1 = $this->engine->consume($grantId);
        
        // Assert first consumption
        $this->assertTrue($result1);
        $this->assertEquals(1, $grant->currentUsage);
        $this->assertEquals(Grant::STATUS_ACTIVE, $grant->status);
        
        // Act - Second consumption (should exhaust)
        $result2 = $this->engine->consume($grantId);
        
        // Assert second consumption
        $this->assertTrue($result2);
        $this->assertEquals(2, $grant->currentUsage);
        $this->assertEquals(Grant::STATUS_EXHAUSTED, $grant->status);
        
        // Verify events were dispatched (2 consumed + 1 exhausted)
        $this->assertCount(3, $this->dispatchedEvents);
        $this->assertEquals('grant.consumed', $this->dispatchedEvents[0]['name']);
        $this->assertEquals('grant.consumed', $this->dispatchedEvents[1]['name']);
        $this->assertEquals('grant.exhausted', $this->dispatchedEvents[2]['name']);
    }

    public function testConsumeExhaustedGrantThrowsException(): void
    {
        // Arrange
        $grantId = 'grant-123';
        $grant = new Grant(
            $grantId,
            'identity-123',
            'workspace-456',
            'member',
            null,
            1 // max_usage = 1
        );
        $grant->consume(); // Exhaust it
        
        $this->repository->expects($this->once())
            ->method('findById')
            ->with($grantId)
            ->willReturn($grant);
        
        // Assert
        $this->expectException(GrantExhaustedException::class);
        
        // Act
        $this->engine->consume($grantId);
    }

    public function testGetActiveGrants(): void
    {
        // Arrange
        $identityId = 'identity-123';
        $workspaceId = 'workspace-456';
        $grants = [
            new Grant('grant-1', $identityId, $workspaceId, 'member', new DateTimeImmutable('+1 hour')),
            new Grant('grant-2', $identityId, $workspaceId, 'admin', null, 5),
        ];
        
        $this->repository->expects($this->once())
            ->method('findActiveByIdentityAndWorkspace')
            ->with($identityId, $workspaceId)
            ->willReturn($grants);
        
        // Act
        $result = $this->engine->getActiveGrants($identityId, $workspaceId);
        
        // Assert
        $this->assertCount(2, $result);
        $this->assertEquals($grants, $result);
    }
}
