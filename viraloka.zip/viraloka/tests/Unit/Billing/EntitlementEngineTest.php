<?php

declare(strict_types=1);

namespace Viraloka\Tests\Unit\Billing;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Billing\EntitlementEngine;
use Viraloka\Core\Billing\Entitlement;
use Viraloka\Core\Billing\Plan;
use Viraloka\Core\Billing\Repositories\EntitlementRepository;
use Viraloka\Core\Events\EventDispatcher;
use DateTimeImmutable;

/**
 * Entitlement Engine Unit Tests
 * 
 * Tests core functionality of the EntitlementEngine.
 */
class EntitlementEngineTest extends TestCase
{
    private EntitlementEngine $engine;
    private EntitlementRepository $repository;
    private EventDispatcher $eventDispatcher;
    
    protected function setUp(): void
    {
        parent::setUp();
        
        // Create mock repository
        $this->repository = $this->createMock(EntitlementRepository::class);
        
        // Create real event dispatcher
        $this->eventDispatcher = new EventDispatcher();
        
        // Create engine
        $this->engine = new EntitlementEngine($this->repository, $this->eventDispatcher);
    }
    
    public function test_check_returns_false_for_non_existent_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'shortlink.max_links';
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn(null);
        
        // Act
        $result = $this->engine->check($workspaceId, $key);
        
        // Assert
        $this->assertFalse($result);
    }
    
    public function test_check_returns_true_for_boolean_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_BOOLEAN,
            true
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        // Act
        $result = $this->engine->check($workspaceId, $key);
        
        // Assert
        $this->assertTrue($result);
    }
    
    public function test_check_returns_false_for_expired_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        $expiresAt = new DateTimeImmutable('-1 day');
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_BOOLEAN,
            true,
            null,
            $expiresAt
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        // Act
        $result = $this->engine->check($workspaceId, $key);
        
        // Assert
        $this->assertFalse($result);
    }
    
    public function test_consume_throws_exception_for_boolean_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_BOOLEAN,
            true
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        // Assert
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('Cannot consume quota on boolean entitlement');
        
        // Act
        $this->engine->consume($workspaceId, $key, 1);
    }
    
    public function test_consume_decrements_quota_for_numeric_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'shortlink.max_links';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_NUMERIC,
            100,
            0
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->with($entitlement);
        
        // Act
        $result = $this->engine->consume($workspaceId, $key, 10);
        
        // Assert
        $this->assertTrue($result);
        $this->assertEquals(10, $entitlement->currentUsage);
    }
    
    public function test_consume_returns_false_when_quota_exceeded(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'shortlink.max_links';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_NUMERIC,
            100,
            95
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        // Track event emission
        $eventEmitted = false;
        $this->eventDispatcher->listen('entitlement.exceeded', function() use (&$eventEmitted) {
            $eventEmitted = true;
        });
        
        // Act
        $result = $this->engine->consume($workspaceId, $key, 10);
        
        // Assert
        $this->assertFalse($result);
        $this->assertTrue($eventEmitted);
    }
    
    public function test_grant_creates_new_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        $value = true;
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn(null);
        
        $newEntitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_BOOLEAN,
            $value
        );
        
        $this->repository->expects($this->once())
            ->method('create')
            ->with($workspaceId, $key, Entitlement::TYPE_BOOLEAN, $value, null)
            ->willReturn($newEntitlement);
        
        // Track event emission
        $eventEmitted = false;
        $this->eventDispatcher->listen('entitlement.granted', function() use (&$eventEmitted) {
            $eventEmitted = true;
        });
        
        // Act
        $result = $this->engine->grant($workspaceId, $key, $value);
        
        // Assert
        $this->assertInstanceOf(Entitlement::class, $result);
        $this->assertEquals($workspaceId, $result->workspaceId);
        $this->assertEquals($key, $result->key);
        $this->assertTrue($eventEmitted);
    }
    
    public function test_grant_updates_existing_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'shortlink.max_links';
        $oldValue = 100;
        $newValue = 200;
        
        $existingEntitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_NUMERIC,
            $oldValue,
            50
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($existingEntitlement);
        
        $this->repository->expects($this->once())
            ->method('update')
            ->with($existingEntitlement);
        
        // Act
        $result = $this->engine->grant($workspaceId, $key, $newValue);
        
        // Assert
        $this->assertEquals($newValue, $result->value);
        $this->assertEquals(0, $result->currentUsage); // Reset on value change
    }
    
    public function test_revoke_deletes_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_BOOLEAN,
            true
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        $this->repository->expects($this->once())
            ->method('delete')
            ->with('entitlement-123')
            ->willReturn(true);
        
        // Track event emission
        $eventEmitted = false;
        $this->eventDispatcher->listen('entitlement.revoked', function() use (&$eventEmitted) {
            $eventEmitted = true;
        });
        
        // Act
        $result = $this->engine->revoke($workspaceId, $key);
        
        // Assert
        $this->assertTrue($result);
        $this->assertTrue($eventEmitted);
    }
    
    public function test_revoke_is_idempotent_for_non_existent_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn(null);
        
        // Act
        $result = $this->engine->revoke($workspaceId, $key);
        
        // Assert
        $this->assertTrue($result);
    }
    
    public function test_current_returns_null_for_non_existent_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'analytics.enabled';
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn(null);
        
        // Act
        $result = $this->engine->current($workspaceId, $key);
        
        // Assert
        $this->assertNull($result);
    }
    
    public function test_current_returns_remaining_quota_for_numeric_entitlement(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $key = 'shortlink.max_links';
        
        $entitlement = new Entitlement(
            'entitlement-123',
            $workspaceId,
            $key,
            Entitlement::TYPE_NUMERIC,
            100,
            30
        );
        
        $this->repository->expects($this->once())
            ->method('findByWorkspaceAndKey')
            ->with($workspaceId, $key)
            ->willReturn($entitlement);
        
        // Act
        $result = $this->engine->current($workspaceId, $key);
        
        // Assert
        $this->assertEquals(70, $result); // 100 - 30
    }
    
    public function test_grantPlanEntitlements_grants_all_plan_entitlements(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $plan = new Plan(
            'pro',
            'Pro Plan',
            'monthly',
            [
                'shortlink.max_links' => 1000,
                'analytics.enabled' => true,
                'api.rate_limit' => 10000
            ]
        );
        
        $this->repository->expects($this->exactly(3))
            ->method('findByWorkspaceAndKey')
            ->willReturn(null);
        
        $this->repository->expects($this->exactly(3))
            ->method('create')
            ->willReturnCallback(function($workspaceId, $key, $type, $value, $currentUsage) {
                return new Entitlement(
                    'entitlement-' . uniqid(),
                    $workspaceId,
                    $key,
                    $type,
                    $value,
                    $currentUsage
                );
            });
        
        // Act
        $this->engine->grantPlanEntitlements($workspaceId, $plan);
        
        // Assert - if we get here without exceptions, the test passes
        $this->assertTrue(true);
    }
    
    public function test_revokePlanEntitlements_revokes_all_plan_entitlements(): void
    {
        // Arrange
        $workspaceId = 'workspace-123';
        $plan = new Plan(
            'pro',
            'Pro Plan',
            'monthly',
            [
                'shortlink.max_links' => 1000,
                'analytics.enabled' => true
            ]
        );
        
        $this->repository->expects($this->exactly(2))
            ->method('findByWorkspaceAndKey')
            ->willReturnCallback(function($workspaceId, $key) {
                return new Entitlement(
                    'entitlement-' . uniqid(),
                    $workspaceId,
                    $key,
                    Entitlement::TYPE_BOOLEAN,
                    true
                );
            });
        
        $this->repository->expects($this->exactly(2))
            ->method('delete')
            ->willReturn(true);
        
        // Act
        $this->engine->revokePlanEntitlements($workspaceId, $plan);
        
        // Assert - if we get here without exceptions, the test passes
        $this->assertTrue(true);
    }
}
