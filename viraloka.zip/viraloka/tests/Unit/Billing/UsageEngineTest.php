<?php

declare(strict_types=1);

namespace Viraloka\Tests\Unit\Billing;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Billing\UsageEngine;
use Viraloka\Core\Billing\Repositories\UsageRepository;
use Viraloka\Core\Billing\Repositories\SubscriptionRepository;
use Viraloka\Core\Billing\UsageRecord;
use Viraloka\Core\Billing\Subscription;
use DateTimeImmutable;

/**
 * Usage Engine Test
 * 
 * Tests the UsageEngine implementation for feature consumption tracking.
 */
class UsageEngineTest extends TestCase
{
    private UsageEngine $usageEngine;
    private UsageRepository $usageRepository;
    private SubscriptionRepository $subscriptionRepository;
    
    protected function setUp(): void
    {
        $this->usageRepository = $this->createMock(UsageRepository::class);
        $this->subscriptionRepository = $this->createMock(SubscriptionRepository::class);
        $this->usageEngine = new UsageEngine($this->usageRepository, $this->subscriptionRepository);
    }
    
    public function test_record_creates_usage_record(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        $amount = 10;
        $metadata = ['source' => 'api'];
        
        $expectedRecord = new UsageRecord(
            'usage-123',
            $workspaceId,
            $key,
            $amount,
            $metadata,
            new DateTimeImmutable()
        );
        
        $this->usageRepository
            ->expects($this->once())
            ->method('create')
            ->with($workspaceId, $key, $amount, $metadata)
            ->willReturn($expectedRecord);
        
        $result = $this->usageEngine->record($workspaceId, $key, $amount, $metadata);
        
        $this->assertSame($expectedRecord, $result);
    }
    
    public function test_record_throws_exception_for_negative_amount(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Usage amount cannot be negative');
        
        $this->usageEngine->record('workspace-123', 'shortlink.clicks', -5);
    }
    
    public function test_record_throws_exception_for_invalid_key_format(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('Usage key must follow dot notation format');
        
        $this->usageEngine->record('workspace-123', 'invalidkey', 10);
    }
    
    public function test_record_accepts_zero_amount(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        $amount = 0;
        
        $expectedRecord = new UsageRecord(
            'usage-123',
            $workspaceId,
            $key,
            $amount,
            [],
            new DateTimeImmutable()
        );
        
        $this->usageRepository
            ->expects($this->once())
            ->method('create')
            ->with($workspaceId, $key, $amount, [])
            ->willReturn($expectedRecord);
        
        $result = $this->usageEngine->record($workspaceId, $key, $amount);
        
        $this->assertSame($expectedRecord, $result);
    }
    
    public function test_current_returns_zero_for_workspace_without_subscription(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn(null);
        
        $result = $this->usageEngine->current($workspaceId, $key);
        
        $this->assertEquals(0, $result);
    }
    
    public function test_current_returns_billing_period_usage(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        $startedAt = new DateTimeImmutable('2024-01-01');
        
        $subscription = new Subscription(
            'sub-123',
            $workspaceId,
            'plan-pro',
            Subscription::STATUS_ACTIVE,
            Subscription::PERIOD_MONTHLY,
            $startedAt
        );
        
        $this->subscriptionRepository
            ->expects($this->once())
            ->method('findByWorkspace')
            ->with($workspaceId)
            ->willReturn($subscription);
        
        $this->usageRepository
            ->expects($this->once())
            ->method('aggregateByTimeRange')
            ->willReturn(150);
        
        $result = $this->usageEngine->current($workspaceId, $key);
        
        $this->assertEquals(150, $result);
    }
    
    public function test_total_returns_all_time_usage(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        
        $this->usageRepository
            ->expects($this->once())
            ->method('aggregateTotal')
            ->with($workspaceId, $key)
            ->willReturn(5000);
        
        $result = $this->usageEngine->total($workspaceId, $key);
        
        $this->assertEquals(5000, $result);
    }
    
    public function test_range_returns_usage_within_time_range(): void
    {
        $workspaceId = 'workspace-123';
        $key = 'shortlink.clicks';
        $start = new DateTimeImmutable('2024-01-01');
        $end = new DateTimeImmutable('2024-01-31');
        
        $this->usageRepository
            ->expects($this->once())
            ->method('aggregateByTimeRange')
            ->with($workspaceId, $key, $start, $end)
            ->willReturn(300);
        
        $result = $this->usageEngine->range($workspaceId, $key, $start, $end);
        
        $this->assertEquals(300, $result);
    }
    
    public function test_range_throws_exception_for_invalid_date_range(): void
    {
        $this->expectException(\InvalidArgumentException::class);
        $this->expectExceptionMessage('End date must be after start date');
        
        $start = new DateTimeImmutable('2024-01-31');
        $end = new DateTimeImmutable('2024-01-01');
        
        $this->usageEngine->range('workspace-123', 'shortlink.clicks', $start, $end);
    }
    
    public function test_getUsageBreakdown_returns_usage_by_key(): void
    {
        $workspaceId = 'workspace-123';
        $start = new DateTimeImmutable('2024-01-01');
        $end = new DateTimeImmutable('2024-01-31');
        
        $expectedBreakdown = [
            'shortlink.clicks' => 300,
            'shortlink.creates' => 50,
            'api.calls' => 1000,
        ];
        
        $this->usageRepository
            ->expects($this->once())
            ->method('getUsageBreakdown')
            ->with($workspaceId, $start, $end)
            ->willReturn($expectedBreakdown);
        
        $result = $this->usageEngine->getUsageBreakdown($workspaceId, $start, $end);
        
        $this->assertEquals($expectedBreakdown, $result);
    }
    
    public function test_resetBillingPeriod_is_noop(): void
    {
        // This method is a no-op because usage records are never deleted
        // Historical data is always preserved
        $this->usageEngine->resetBillingPeriod('workspace-123');
        
        // No assertions needed - just verify it doesn't throw
        $this->assertTrue(true);
    }
}
