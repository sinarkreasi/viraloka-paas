<?php

namespace Viraloka\Tests\Unit\Payment;

use PHPUnit\Framework\TestCase;
use Viraloka\Core\Adapter\AdapterRegistry;
use Viraloka\Core\Adapter\Contracts\PaymentAdapterInterface;
use Viraloka\Core\Billing\PaymentResult;
use Viraloka\Core\Billing\Events\PaymentSucceededEvent;
use Viraloka\Core\Billing\Events\PaymentFailedEvent;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Adapter\Payment\StripeAdapter;

class PaymentAdapterTest extends TestCase
{
    private EventDispatcher $eventDispatcher;
    private AdapterRegistry $adapterRegistry;
    
    protected function setUp(): void
    {
        $this->eventDispatcher = new EventDispatcher();
        $this->adapterRegistry = new AdapterRegistry();
    }
    
    public function test_stripe_adapter_implements_interface(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $this->assertInstanceOf(PaymentAdapterInterface::class, $adapter);
    }
    
    public function test_stripe_adapter_returns_gateway_name(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $this->assertEquals('stripe', $adapter->getName());
    }
    
    public function test_stripe_adapter_charge_returns_payment_result(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $result = $adapter->charge('workspace-123', 1000, 'USD', ['test' => 'data']);
        
        $this->assertInstanceOf(PaymentResult::class, $result);
        $this->assertEquals(1000, $result->amount);
        $this->assertEquals('USD', $result->currency);
        $this->assertTrue($result->isSucceeded());
    }
    
    public function test_stripe_adapter_charge_emits_success_event(): void
    {
        $eventEmitted = false;
        $emittedEvent = null;
        
        $this->eventDispatcher->listen('payment.succeeded', function ($event) use (&$eventEmitted, &$emittedEvent) {
            $eventEmitted = true;
            $emittedEvent = $event;
        });
        
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        $adapter->charge('workspace-123', 1000, 'USD');
        
        $this->assertTrue($eventEmitted);
        $this->assertInstanceOf(PaymentSucceededEvent::class, $emittedEvent);
        $this->assertEquals('workspace-123', $emittedEvent->workspaceId);
        $this->assertEquals(1000, $emittedEvent->amount);
        $this->assertEquals('USD', $emittedEvent->currency);
        $this->assertEquals('stripe', $emittedEvent->gateway);
    }
    
    public function test_adapter_registry_can_register_payment_adapter(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $this->adapterRegistry->registerPayment($adapter);
        
        $this->assertTrue($this->adapterRegistry->hasPaymentAdapter('stripe'));
    }
    
    public function test_adapter_registry_can_retrieve_payment_adapter(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $this->adapterRegistry->registerPayment($adapter);
        
        $retrieved = $this->adapterRegistry->payment('stripe');
        
        $this->assertSame($adapter, $retrieved);
    }
    
    public function test_adapter_registry_throws_exception_for_unregistered_adapter(): void
    {
        $this->expectException(\Viraloka\Core\Adapter\Exceptions\AdapterNotRegisteredException::class);
        
        $this->adapterRegistry->payment('nonexistent');
    }
    
    public function test_adapter_registry_can_get_all_payment_adapters(): void
    {
        $adapter1 = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $this->adapterRegistry->registerPayment($adapter1);
        
        $adapters = $this->adapterRegistry->getAllPaymentAdapters();
        
        $this->assertCount(1, $adapters);
        $this->assertArrayHasKey('stripe', $adapters);
    }
    
    public function test_stripe_webhook_handles_payment_succeeded(): void
    {
        $eventEmitted = false;
        $emittedEvent = null;
        
        $this->eventDispatcher->listen('payment.succeeded', function ($event) use (&$eventEmitted, &$emittedEvent) {
            $eventEmitted = true;
            $emittedEvent = $event;
        });
        
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $webhookPayload = [
            'type' => 'charge.succeeded',
            'data' => [
                'object' => [
                    'id' => 'ch_test123',
                    'amount' => 2000,
                    'currency' => 'usd',
                    'metadata' => [
                        'workspace_id' => 'workspace-456'
                    ]
                ]
            ]
        ];
        
        $adapter->handleWebhook($webhookPayload);
        
        $this->assertTrue($eventEmitted);
        $this->assertInstanceOf(PaymentSucceededEvent::class, $emittedEvent);
        $this->assertEquals('ch_test123', $emittedEvent->transactionId);
        $this->assertEquals('workspace-456', $emittedEvent->workspaceId);
        $this->assertEquals(2000, $emittedEvent->amount);
    }
    
    public function test_stripe_webhook_handles_payment_failed(): void
    {
        $eventEmitted = false;
        $emittedEvent = null;
        
        $this->eventDispatcher->listen('payment.failed', function ($event) use (&$eventEmitted, &$emittedEvent) {
            $eventEmitted = true;
            $emittedEvent = $event;
        });
        
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $webhookPayload = [
            'type' => 'charge.failed',
            'data' => [
                'object' => [
                    'id' => 'ch_test456',
                    'amount' => 1500,
                    'currency' => 'usd',
                    'metadata' => [
                        'workspace_id' => 'workspace-789'
                    ],
                    'failure_message' => 'Insufficient funds'
                ]
            ]
        ];
        
        $adapter->handleWebhook($webhookPayload);
        
        $this->assertTrue($eventEmitted);
        $this->assertInstanceOf(PaymentFailedEvent::class, $emittedEvent);
        $this->assertEquals('ch_test456', $emittedEvent->transactionId);
        $this->assertEquals('workspace-789', $emittedEvent->workspaceId);
        $this->assertEquals('Insufficient funds', $emittedEvent->reason);
    }
    
    public function test_stripe_webhook_validates_signature(): void
    {
        $adapter = new StripeAdapter($this->eventDispatcher, 'test_key', 'test_secret');
        
        $payload = ['type' => 'charge.succeeded'];
        
        // Valid signature
        $this->assertTrue($adapter->validateWebhookSignature($payload, 'valid_signature'));
        
        // Invalid signature (empty)
        $this->assertFalse($adapter->validateWebhookSignature($payload, ''));
    }
}
