# Link In Bio Module

A comprehensive link-in-bio solution for creators to showcase multiple links, social profiles, and content in a single customizable landing page.

## Features

- Custom link page post type
- Shortcode support for embedding link pages
- Theme customization capabilities
- Analytics integration (optional)
- WooCommerce integration (optional)

## Module Structure

```
linkinbio/
├── module.json                          # Module manifest
├── README.md                            # This file
└── src/
    └── LinkInBioServiceProvider.php    # Service provider
```

## PSR-4 Autoloading

This module follows PSR-4 autoloading standards:
- Namespace: `Viraloka\Modules\LinkInBio`
- Directory: `viraloka-modules/linkinbio/src/`

## Capabilities

The module declares the following capabilities:
- `manage_linkinbio` - Manage Link In Bio settings
- `edit_linkinbio_pages` - Create and edit link pages
- `view_linkinbio_analytics` - View analytics data
- `customize_linkinbio_theme` - Customize page themes

## Dependencies

### Required
- Core: >= 1.0.0

### Optional
- Module: `viraloka.analytics` >= 1.0.0 (for analytics features)
- Plugin: WooCommerce (for product integration)

## Context Support

This module is optimized for the following contexts:
- **Primary**: link-in-bio
- **Supported**: creator, digital

Priority: 80 (high priority for recommendations)

## Usage

Once loaded, the module registers:
1. Custom post type: `linkinbio_page`
2. Shortcode: `[linkinbio id="123" theme="default"]`

## Admin Menu

The module adds an admin menu item:
- Title: "Link In Bio"
- Icon: dashicons-admin-links
- Order: 30
