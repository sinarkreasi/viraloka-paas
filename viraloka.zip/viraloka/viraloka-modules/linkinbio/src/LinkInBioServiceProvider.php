<?php

namespace Viraloka\Modules\LinkInBio;

use Viraloka\Core\Providers\ServiceProvider;

/**
 * Link In Bio Service Provider
 * 
 * Registers and bootstraps the Link In Bio module services.
 * This module provides a comprehensive link-in-bio solution for creators.
 */
class LinkInBioServiceProvider extends ServiceProvider
{
    /**
     * Register services in the container
     * 
     * @return void
     */
    public function register(): void
    {
        // Register Link In Bio services
        // Example: Bind page manager, theme customizer, analytics tracker
        
        // For demonstration purposes, we'll just log that registration occurred
        if (function_exists('error_log')) {
            error_log('[LinkInBio Module] Services registered');
        }
    }
    
    /**
     * Bootstrap module services
     * 
     * @return void
     */
    public function boot(): void
    {
        // Bootstrap Link In Bio functionality
        // Example: Register post types, taxonomies, REST API endpoints
        
        // Register custom post type for link pages
        $this->registerLinkPagePostType();
        
        // Register shortcodes
        $this->registerShortcodes();
        
        // For demonstration purposes, log that boot occurred
        if (function_exists('error_log')) {
            error_log('[LinkInBio Module] Module booted successfully');
        }
    }
    
    /**
     * Register the link page custom post type
     * 
     * @return void
     */
    protected function registerLinkPagePostType(): void
    {
        if (!function_exists('register_post_type')) {
            return;
        }
        
        register_post_type('linkinbio_page', [
            'labels' => [
                'name' => 'Link Pages',
                'singular_name' => 'Link Page',
            ],
            'public' => true,
            'has_archive' => false,
            'supports' => ['title', 'editor', 'thumbnail'],
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-admin-links',
        ]);
    }
    
    /**
     * Register module shortcodes
     * 
     * @return void
     */
    protected function registerShortcodes(): void
    {
        if (!function_exists('add_shortcode')) {
            return;
        }
        
        // Register [linkinbio] shortcode
        add_shortcode('linkinbio', function ($atts) {
            $atts = shortcode_atts([
                'id' => null,
                'theme' => 'default',
            ], $atts);
            
            return sprintf(
                '<div class="linkinbio-container" data-page-id="%s" data-theme="%s">Link In Bio Page</div>',
                esc_attr($atts['id']),
                esc_attr($atts['theme'])
            );
        });
    }
}
