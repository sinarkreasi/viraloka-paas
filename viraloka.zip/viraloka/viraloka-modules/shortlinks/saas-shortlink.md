# 1. Shortlink Module – Technical Spec (shortlink-module-spec.md)
Purpose

Module Shortlink menyediakan fitur URL shortener berbasis workspace, aman, scalable, dan sesuai kontrak Viraloka (Identity, Membership, Grant).

Module ini bukan auth system, bukan analytics engine umum, dan tidak mengurus user lifecycle.

Core Responsibilities

Create / update / delete shortlink

Resolve shortlink → redirect

Track click event

Enforce expiry & status

Respect workspace boundary

Non-Responsibilities

User registration / login

Permission enforcement logic (delegated ke core)

Token / magic-link generation (optional, via Grant)

Domain Entity
Shortlink
Shortlink
- id
- workspace_id
- slug
- target_url
- status (active | inactive | expired)
- expires_at (nullable)
- created_at
- updated_at
- metadata (json)


Catatan:

identity_id tidak disimpan di entity

Ownership & access diturunkan dari workspace + membership

Permission Model (Module-level)
Permissions

shortlink.create

shortlink.edit

shortlink.delete

shortlink.view_analytics

Role Mapping (contoh)

owner → all

editor → create, edit

viewer → view only

Enforcement tetap di core (Policy / Permission Contract)

Request Flow
Create Shortlink (Admin)
Auth → Resolve Workspace
→ Permission check
→ Create Shortlink
→ Emit event: shortlink.created

Redirect Flow (Public)
Request /s/{slug}
→ Resolve Shortlink
→ Check status & expires_at
→ Emit event: shortlink.clicked
→ HTTP redirect (302 / 301)


Redirect tidak butuh login.

Analytics

Minimal tracking:

timestamp

referrer

user_agent

shortlink_id

Event-based:

shortlink.clicked

Integration Points

Identity & Membership Contract

Temporary Grant (optional, for analytics sharing)

Context Resolver (marketing / growth)

Out of Scope (Explicit)

Custom domain management

Advanced fraud detection

Rate limiting (host / infra concern)

# 2. Shortlink – Database Schema & Migration (shortlink-schema.md)
Storage Strategy

Module boleh punya tabel sendiri karena ini business object, bukan identity.

Semua data tetap di-scope oleh workspace_id.

Table: viraloka_shortlinks
CREATE TABLE viraloka_shortlinks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  workspace_id BIGINT UNSIGNED NOT NULL,
  slug VARCHAR(64) NOT NULL,
  target_url TEXT NOT NULL,
  status VARCHAR(20) DEFAULT 'active',
  expires_at DATETIME NULL,
  metadata JSON NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY unique_slug (slug),
  KEY idx_workspace (workspace_id),
  KEY idx_status (status)
);

Table: viraloka_shortlink_clicks
CREATE TABLE viraloka_shortlink_clicks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  shortlink_id BIGINT UNSIGNED NOT NULL,
  clicked_at DATETIME NOT NULL,
  referrer TEXT NULL,
  user_agent TEXT NULL,
  ip_address VARCHAR(45) NULL,
  KEY idx_shortlink (shortlink_id),
  KEY idx_clicked_at (clicked_at)
);

Migration Rules

Migration dijalankan saat module activation

Tidak boleh menyentuh tabel core

Tidak boleh assume engine WordPress (pakai abstraction layer)

Data Isolation Rules

Semua query wajib filter workspace_id

Tidak ada cross-workspace access

Analytics aggregation dilakukan di service layer

Retention (Optional)

Click logs bisa:

dipurge by date

dipindah ke external storage (future)

Kenapa desain ini aman?

Identity tidak diduplikasi

Workspace jadi boundary

Public access tetap terkendali

Bisa dipindah engine (Laravel, dll)