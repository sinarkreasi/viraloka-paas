# Sample Module

A minimal example module demonstrating the Viraloka module manifest system.

## Purpose

This module serves as a template and reference implementation for creating new Viraloka modules. It demonstrates:

- Proper module manifest structure (`module.json`)
- Service provider implementation
- Context support configuration
- Capability registration
- Admin UI integration
- Lifecycle management

## Structure

```
sample-module/
├── module.json                    # Module manifest
├── README.md                      # This file
└── src/
    └── SampleServiceProvider.php  # Service provider
```

## Module Manifest

The `module.json` file defines:

- **ID**: `viraloka.sample`
- **Namespace**: `Viraloka\Modules\Sample`
- **Contexts**: Supports `default` and `creator` contexts
- **Capabilities**: `manage_sample`, `view_sample`
- **UI**: Admin menu integration enabled
- **Lifecycle**: Uses `SampleServiceProvider` for bootstrapping

## Service Provider

The `SampleServiceProvider` class extends `Viraloka\Core\Providers\ServiceProvider` and implements:

- `register()`: Register services into the container
- `boot()`: Perform bootstrapping actions (hooks, assets, etc.)

## Usage

This module is automatically discovered and loaded by the Viraloka Core bootstrap system. No manual activation is required.

### Extending This Module

To create a new module based on this template:

1. Copy the `sample-module` directory
2. Update `module.json` with your module details
3. Rename the namespace in `SampleServiceProvider.php`
4. Implement your module's functionality in the service provider
5. Add additional classes as needed in the `src/` directory

## Development

### Adding Services

Register services in the `register()` method:

```php
public function register(): void
{
    $this->app->singleton(MyService::class, function($app) {
        return new MyService();
    });
}
```

### Adding WordPress Hooks

Register hooks in the `boot()` method:

```php
public function boot(): void
{
    add_action('init', [$this, 'initialize']);
    add_filter('the_content', [$this, 'filterContent']);
}
```

### Adding Admin Pages

The admin menu is automatically created based on the manifest. To add custom admin pages:

```php
public function registerAdminMenu(): void
{
    add_submenu_page(
        'viraloka-sample',
        'Settings',
        'Settings',
        'manage_sample',
        'sample-settings',
        [$this, 'renderSettingsPage']
    );
}
```

## Testing

This module is used in integration tests to verify:

- Module discovery
- Manifest parsing
- Service provider instantiation
- Lifecycle execution
- Error handling

## License

Proprietary - Viraloka Team
