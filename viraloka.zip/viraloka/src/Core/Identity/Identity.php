<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity;

use DateTimeImmutable;

/**
 * Identity Entity
 * 
 * Represents a global entity for one individual or system user across the platform.
 * Identity does not know about SaaS, default workspace, or built-in roles.
 */
class Identity
{
    public const STATUS_ACTIVE = 'active';
    public const STATUS_SUSPENDED = 'suspended';

    public readonly string $identityId;
    public readonly string $email;
    public string $status;
    public array $metadata;
    public readonly DateTimeImmutable $createdAt;

    public function __construct(
        string $identityId,
        string $email,
        string $status = self::STATUS_ACTIVE,
        array $metadata = [],
        ?DateTimeImmutable $createdAt = null
    ) {
        $this->identityId = $identityId;
        $this->email = $email;
        $this->status = $status;
        $this->metadata = $metadata;
        $this->createdAt = $createdAt ?? new DateTimeImmutable();
    }

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function suspend(): void
    {
        $this->status = self::STATUS_SUSPENDED;
    }

    public function activate(): void
    {
        $this->status = self::STATUS_ACTIVE;
    }
}
