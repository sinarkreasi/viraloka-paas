<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Exceptions;

use Exception;

/**
 * Identity Exists Exception
 * 
 * Thrown when attempting to create an identity with an email that already exists.
 */
class IdentityExistsException extends Exception
{
    public function __construct(string $email, int $code = 0, ?\Throwable $previous = null)
    {
        $message = sprintf('Identity with email "%s" already exists', $email);
        parent::__construct($message, $code, $previous);
    }
}
