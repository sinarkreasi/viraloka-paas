<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Exceptions;

use Exception;

/**
 * Identity Not Found Exception
 * 
 * Thrown when an identity cannot be found by ID.
 */
class IdentityNotFoundException extends Exception
{
    public function __construct(string $identityId, int $code = 0, ?\Throwable $previous = null)
    {
        $message = sprintf('Identity with ID "%s" not found', $identityId);
        parent::__construct($message, $code, $previous);
    }
}
