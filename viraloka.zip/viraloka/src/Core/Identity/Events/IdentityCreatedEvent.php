<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Events;

use DateTimeImmutable;

/**
 * Identity Created Event
 * 
 * Emitted when a new identity is created.
 */
class IdentityCreatedEvent
{
    public function __construct(
        public readonly string $identityId,
        public readonly string $email,
        public readonly DateTimeImmutable $createdAt
    ) {}
}
