<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity\Contracts;

use Viraloka\Core\Identity\Identity;
use Viraloka\Core\Identity\Exceptions\IdentityExistsException;

/**
 * Identity Engine Interface
 * 
 * Defines the contract for identity lifecycle operations.
 */
interface IdentityEngineInterface
{
    /**
     * Create a new identity
     * 
     * @param array $payload ['email' => string, 'metadata' => array]
     * @return Identity
     * @throws IdentityExistsException If email already registered
     */
    public function create(array $payload): Identity;

    /**
     * Resolve identity by email identifier
     * 
     * @param string $identifier Email address
     * @return Identity|null
     */
    public function resolve(string $identifier): ?Identity;

    /**
     * Suspend an identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function suspend(string $identityId): bool;

    /**
     * Activate a suspended identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function activate(string $identityId): bool;

    /**
     * Get identity by ID
     * 
     * @param string $identityId UUID
     * @return Identity|null
     */
    public function findById(string $identityId): ?Identity;
}
