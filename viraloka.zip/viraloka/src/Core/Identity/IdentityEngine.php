<?php

declare(strict_types=1);

namespace Viraloka\Core\Identity;

use Viraloka\Core\Application;
use Viraloka\Core\Identity\Contracts\IdentityEngineInterface;
use Viraloka\Core\Identity\Contracts\IdentityRepositoryInterface;
use Viraloka\Core\Identity\Repositories\IdentityRepository;
use Viraloka\Core\Identity\Events\IdentityCreatedEvent;
use Viraloka\Core\Identity\Events\IdentitySuspendedEvent;
use Viraloka\Core\Identity\Exceptions\IdentityExistsException;
use Viraloka\Core\Identity\Exceptions\IdentityNotFoundException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use DateTimeImmutable;

/**
 * Identity Engine
 * 
 * Manages the lifecycle of Identity entities including creation, resolution,
 * suspension, and activation. Integrates with EventDispatcher for lifecycle events.
 * Uses AdapterRegistry for StorageAdapter access.
 * 
 * Requirements: 1.1-1.10, 2.1-2.7, 11.4, 11.5
 */
class IdentityEngine implements IdentityEngineInterface
{
    private readonly IdentityRepositoryInterface $repository;
    private readonly EventDispatcher $eventDispatcher;

    /**
     * Create a new IdentityEngine instance
     * 
     * @param Application $app
     */
    public function __construct(private readonly Application $app)
    {
        // Resolve dependencies from container (Requirement 11.4, 11.5)
        $adapters = $this->app->make(AdapterRegistryInterface::class);
        
        // Create repository with StorageAdapter
        $this->repository = new IdentityRepository($adapters->storage());
        
        // Get EventDispatcher from Kernel
        $kernel = $this->app->make(\Viraloka\Core\Bootstrap\Kernel::class);
        $this->eventDispatcher = $kernel->getEventDispatcher();
    }

    /**
     * Create a new identity
     * 
     * @param array $payload ['email' => string, 'metadata' => array]
     * @return Identity
     * @throws IdentityExistsException If email already registered
     */
    public function create(array $payload): Identity
    {
        $email = $payload['email'] ?? '';
        $metadata = $payload['metadata'] ?? [];

        // Validate email
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('Valid email is required');
        }

        // Check if email already exists (Requirement 2.5)
        if ($this->repository->emailExists($email)) {
            throw new IdentityExistsException($email);
        }

        // Generate UUID for identity_id (Requirement 1.1)
        $identityId = $this->generateUuid();

        // Create identity with active status (Requirement 1.4)
        $identity = new Identity(
            $identityId,
            $email,
            Identity::STATUS_ACTIVE,
            $metadata,
            new DateTimeImmutable()
        );

        // Persist identity
        if (!$this->repository->save($identity)) {
            throw new \RuntimeException('Failed to save identity');
        }

        // Emit identity.created event (Requirement 1.9)
        $this->eventDispatcher->dispatch(
            'identity.created',
            new IdentityCreatedEvent(
                $identity->identityId,
                $identity->email,
                $identity->createdAt
            )
        );

        return $identity;
    }

    /**
     * Resolve identity by email identifier
     * 
     * @param string $identifier Email address
     * @return Identity|null
     */
    public function resolve(string $identifier): ?Identity
    {
        // Lookup by email (Requirement 1.7, 2.2)
        return $this->repository->findByEmail($identifier);
    }

    /**
     * Suspend an identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function suspend(string $identityId): bool
    {
        // Find identity
        $identity = $this->repository->findById($identityId);
        
        if ($identity === null) {
            return false;
        }

        // Suspend identity (Requirement 1.8, 2.7 - idempotent)
        if ($identity->status !== Identity::STATUS_SUSPENDED) {
            $identity->suspend();
            
            // Persist changes
            if (!$this->repository->update($identity)) {
                return false;
            }

            // Emit identity.suspended event (Requirement 1.10)
            $this->eventDispatcher->dispatch(
                'identity.suspended',
                new IdentitySuspendedEvent(
                    $identity->identityId,
                    $identity->email,
                    new DateTimeImmutable()
                )
            );
        }

        return true;
    }

    /**
     * Activate a suspended identity
     * 
     * @param string $identityId UUID
     * @return bool
     */
    public function activate(string $identityId): bool
    {
        // Find identity
        $identity = $this->repository->findById($identityId);
        
        if ($identity === null) {
            return false;
        }

        // Activate identity (Requirement 2.4, 2.7 - idempotent)
        if ($identity->status !== Identity::STATUS_ACTIVE) {
            $identity->activate();
            
            // Persist changes
            if (!$this->repository->update($identity)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Get identity by ID
     * 
     * @param string $identityId UUID
     * @return Identity|null
     */
    public function findById(string $identityId): ?Identity
    {
        return $this->repository->findById($identityId);
    }

    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
