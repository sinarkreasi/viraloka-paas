<?php

namespace Viraloka\Core\Billing;

use DateTimeImmutable;

/**
 * Usage Record Entity
 * 
 * Represents a measurement of feature consumption.
 */
class UsageRecord
{
    public function __construct(
        public readonly string $usageId,
        public readonly string $workspaceId,
        public readonly string $key,
        public readonly int $amount,
        public array $metadata = [],
        public readonly ?DateTimeImmutable $recordedAt = null
    ) {
        $this->recordedAt = $recordedAt ?? new DateTimeImmutable();
    }
}
