<?php

namespace Viraloka\Core\Billing;

use DateTimeImmutable;
use Viraloka\Core\Billing\Exceptions\InvalidStatusException;

/**
 * Subscription Entity
 * 
 * Represents a billing relationship between a workspace and the platform.
 */
class Subscription
{
    public const STATUS_ACTIVE = 'active';
    public const STATUS_TRIAL = 'trial';
    public const STATUS_PAUSED = 'paused';
    public const STATUS_EXPIRED = 'expired';
    public const STATUS_CANCELLED = 'cancelled';
    
    public const PERIOD_MONTHLY = 'monthly';
    public const PERIOD_YEARLY = 'yearly';
    public const PERIOD_CUSTOM = 'custom';
    
    public function __construct(
        public readonly string $subscriptionId,
        public readonly string $workspaceId,
        public string $planId,
        public string $status,
        public string $billingPeriod,
        public readonly DateTimeImmutable $startedAt,
        public ?DateTimeImmutable $endsAt = null,
        public array $metadata = [],
        public readonly ?DateTimeImmutable $createdAt = null
    ) {
        $this->createdAt = $createdAt ?? new DateTimeImmutable();
    }
    
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }
    
    public function isTrial(): bool
    {
        return $this->status === self::STATUS_TRIAL;
    }
    
    public function isPaused(): bool
    {
        return $this->status === self::STATUS_PAUSED;
    }
    
    public function isExpired(): bool
    {
        if ($this->status === self::STATUS_EXPIRED) {
            return true;
        }
        
        if ($this->endsAt !== null && $this->endsAt < new DateTimeImmutable()) {
            return true;
        }
        
        return false;
    }
    
    public function pause(): void
    {
        if (!$this->isActive()) {
            throw new InvalidStatusException(
                "Cannot pause non-active subscription",
                $this->status,
                [self::STATUS_ACTIVE]
            );
        }
        $this->status = self::STATUS_PAUSED;
    }
    
    public function resume(): void
    {
        if (!$this->isPaused()) {
            throw new InvalidStatusException(
                "Cannot resume non-paused subscription",
                $this->status,
                [self::STATUS_PAUSED]
            );
        }
        $this->status = self::STATUS_ACTIVE;
    }
    
    public function cancel(): void
    {
        $this->status = self::STATUS_CANCELLED;
        $this->endsAt = new DateTimeImmutable();
    }
    
    public function changePlan(string $newPlanId): void
    {
        $this->planId = $newPlanId;
    }
}
