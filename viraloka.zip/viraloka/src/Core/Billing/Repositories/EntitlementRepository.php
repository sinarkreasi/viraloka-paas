<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Repositories;

use Viraloka\Core\Billing\Entitlement;
use DateTimeImmutable;

/**
 * Entitlement Repository
 * 
 * Handles persistence of Entitlement entities using WordPress wpdb.
 * Enforces key format validation and workspace-key uniqueness.
 * 
 * Requirements: 3.5, 3.8, 3.10
 */
class EntitlementRepository
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_entitlements';
    }
    
    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * Validate entitlement key format (dot notation)
     * 
     * @param string $key Entitlement key
     * @return bool
     */
    private function validateKeyFormat(string $key): bool
    {
        // Key must contain at least one dot (Requirement 3.8)
        return strpos($key, '.') !== false;
    }
    
    /**
     * Create a new entitlement
     * 
     * @param string $workspaceId UUID
     * @param string $key Entitlement key (dot notation)
     * @param string $type Entitlement type (boolean, numeric, metered)
     * @param mixed $value Entitlement value
     * @param int|null $currentUsage Current usage for numeric types
     * @param DateTimeImmutable|null $expiresAt Expiration timestamp
     * @return Entitlement
     * @throws \RuntimeException If key format is invalid or entitlement already exists
     */
    public function create(
        string $workspaceId,
        string $key,
        string $type,
        mixed $value,
        ?int $currentUsage = null,
        ?DateTimeImmutable $expiresAt = null
    ): Entitlement {
        // Validate key format (Requirement 3.8)
        if (!$this->validateKeyFormat($key)) {
            throw new \RuntimeException("Invalid entitlement key format. Key must use dot notation (e.g., 'module.feature')");
        }
        
        // Check if entitlement already exists for this workspace and key
        $existing = $this->findByWorkspaceAndKey($workspaceId, $key);
        if ($existing !== null) {
            throw new \RuntimeException("Entitlement already exists for workspace and key");
        }
        
        $entitlementId = $this->generateUuid();
        $createdAt = new DateTimeImmutable();
        
        // Serialize value based on type
        $serializedValue = $this->serializeValue($value, $type);
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'entitlement_id' => $entitlementId,
                'workspace_id' => $workspaceId,
                'key' => $key,
                'type' => $type,
                'value' => $serializedValue,
                'current_usage' => $currentUsage,
                'expires_at' => $expiresAt ? $expiresAt->format('Y-m-d H:i:s') : null,
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create entitlement: ' . $this->wpdb->last_error);
        }
        
        return new Entitlement(
            $entitlementId,
            $workspaceId,
            $key,
            $type,
            $value,
            $currentUsage,
            $expiresAt,
            $createdAt
        );
    }

    
    /**
     * Find entitlement by workspace and key
     * 
     * @param string $workspaceId UUID
     * @param string $key Entitlement key
     * @return Entitlement|null
     */
    public function findByWorkspaceAndKey(string $workspaceId, string $key): ?Entitlement
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s AND `key` = %s",
                $workspaceId,
                $key
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find all entitlements for a workspace
     * 
     * @param string $workspaceId UUID
     * @return Entitlement[]
     */
    public function findAllByWorkspace(string $workspaceId): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s ORDER BY created_at DESC",
                $workspaceId
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Update an existing entitlement
     * 
     * @param Entitlement $entitlement
     * @return bool
     */
    public function update(Entitlement $entitlement): bool
    {
        $serializedValue = $this->serializeValue($entitlement->value, $entitlement->type);
        
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'type' => $entitlement->type,
                'value' => $serializedValue,
                'current_usage' => $entitlement->currentUsage,
                'expires_at' => $entitlement->expiresAt ? $entitlement->expiresAt->format('Y-m-d H:i:s') : null,
                'updated_at' => (new DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['entitlement_id' => $entitlement->entitlementId],
            ['%s', '%s', '%d', '%s', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Delete an entitlement
     * 
     * @param string $entitlementId UUID
     * @return bool
     */
    public function delete(string $entitlementId): bool
    {
        $result = $this->wpdb->delete(
            $this->tableName,
            ['entitlement_id' => $entitlementId],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Find all expired entitlements
     * 
     * Requirements: 3.9, 10.4
     * 
     * @return Entitlement[]
     */
    public function findExpired(): array
    {
        $now = (new DateTimeImmutable())->format('Y-m-d H:i:s');
        
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE expires_at IS NOT NULL AND expires_at < %s",
                $now
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Serialize value based on type
     * 
     * @param mixed $value
     * @param string $type
     * @return string
     */
    private function serializeValue(mixed $value, string $type): string
    {
        if ($type === Entitlement::TYPE_BOOLEAN) {
            return $value ? '1' : '0';
        }
        
        if ($type === Entitlement::TYPE_NUMERIC) {
            return (string) $value;
        }
        
        if ($type === Entitlement::TYPE_METERED) {
            return json_encode($value);
        }
        
        return (string) $value;
    }
    
    /**
     * Deserialize value based on type
     * 
     * @param string $value
     * @param string $type
     * @return mixed
     */
    private function deserializeValue(string $value, string $type): mixed
    {
        if ($type === Entitlement::TYPE_BOOLEAN) {
            return $value === '1';
        }
        
        if ($type === Entitlement::TYPE_NUMERIC) {
            return (int) $value;
        }
        
        if ($type === Entitlement::TYPE_METERED) {
            return json_decode($value, true);
        }
        
        return $value;
    }
    
    /**
     * Convert database row to Entitlement entity
     * 
     * @param array $row Database row
     * @return Entitlement
     */
    private function rowToEntity(array $row): Entitlement
    {
        $value = $this->deserializeValue($row['value'], $row['type']);
        
        return new Entitlement(
            $row['entitlement_id'],
            $row['workspace_id'],
            $row['key'],
            $row['type'],
            $value,
            $row['current_usage'] !== null ? (int) $row['current_usage'] : null,
            $row['expires_at'] ? new DateTimeImmutable($row['expires_at']) : null,
            new DateTimeImmutable($row['created_at'])
        );
    }
}
