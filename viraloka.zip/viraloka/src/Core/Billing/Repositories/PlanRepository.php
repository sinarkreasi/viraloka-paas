<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Repositories;

use Viraloka\Core\Billing\Plan;
use DateTimeImmutable;

/**
 * Plan Repository
 * 
 * Handles persistence of Plan entities using WordPress wpdb.
 * Validates plan deletion constraints (no active subscriptions).
 * 
 * Requirements: 7.8, 7.9
 */
class PlanRepository
{
    private \wpdb $wpdb;
    private string $tableName;
    private string $subscriptionsTableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_plans';
        $this->subscriptionsTableName = $wpdb->prefix . 'viraloka_subscriptions';
    }
    
    /**
     * Create or update a plan
     * 
     * @param Plan $plan
     * @return Plan
     * @throws \RuntimeException If save fails
     */
    public function save(Plan $plan): Plan
    {
        $existing = $this->findById($plan->planId);
        
        if ($existing === null) {
            return $this->create($plan);
        } else {
            $this->update($plan);
            return $plan;
        }
    }
    
    /**
     * Create a new plan
     * 
     * @param Plan $plan
     * @return Plan
     * @throws \RuntimeException If creation fails
     */
    private function create(Plan $plan): Plan
    {
        $createdAt = $plan->createdAt ?? new DateTimeImmutable();
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'plan_id' => $plan->planId,
                'name' => $plan->name,
                'billing_period' => $plan->billingPeriod,
                'entitlements' => json_encode($plan->entitlements),
                'trial_period_days' => $plan->trialPeriodDays,
                'is_active' => $plan->isActive ? 1 : 0,
                'metadata' => json_encode($plan->metadata),
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create plan: ' . $this->wpdb->last_error);
        }
        
        return $plan;
    }
    
    /**
     * Update an existing plan
     * 
     * @param Plan $plan
     * @return bool
     */
    private function update(Plan $plan): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'name' => $plan->name,
                'billing_period' => $plan->billingPeriod,
                'entitlements' => json_encode($plan->entitlements),
                'trial_period_days' => $plan->trialPeriodDays,
                'is_active' => $plan->isActive ? 1 : 0,
                'metadata' => json_encode($plan->metadata),
                'updated_at' => (new DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['plan_id' => $plan->planId],
            ['%s', '%s', '%s', '%d', '%d', '%s', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Find plan by ID
     * 
     * @param string $planId Plan identifier
     * @return Plan|null
     */
    public function findById(string $planId): ?Plan
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE plan_id = %s",
                $planId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }

    
    /**
     * Get all active plans
     * 
     * @return Plan[]
     */
    public function getAllActive(): array
    {
        $rows = $this->wpdb->get_results(
            "SELECT * FROM {$this->tableName} WHERE is_active = 1 ORDER BY created_at DESC",
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Archive a plan (soft delete)
     * 
     * @param string $planId Plan identifier
     * @return bool
     */
    public function archive(string $planId): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'is_active' => 0,
                'updated_at' => (new DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['plan_id' => $planId],
            ['%d', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Delete a plan (hard delete)
     * 
     * @param string $planId Plan identifier
     * @return bool
     * @throws \RuntimeException If plan has active subscriptions (Requirement 7.9)
     */
    public function delete(string $planId): bool
    {
        // Check for active subscriptions (Requirement 7.9)
        if ($this->hasActiveSubscriptions($planId)) {
            throw new \RuntimeException("Cannot delete plan with active subscriptions. Archive the plan instead.");
        }
        
        $result = $this->wpdb->delete(
            $this->tableName,
            ['plan_id' => $planId],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Check if plan has active subscriptions
     * 
     * @param string $planId Plan identifier
     * @return bool
     */
    private function hasActiveSubscriptions(string $planId): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->subscriptionsTableName} 
                WHERE plan_id = %s AND status IN ('active', 'trial', 'paused')",
                $planId
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Convert database row to Plan entity
     * 
     * @param array $row Database row
     * @return Plan
     */
    private function rowToEntity(array $row): Plan
    {
        $entitlements = !empty($row['entitlements']) ? json_decode($row['entitlements'], true) : [];
        $metadata = !empty($row['metadata']) ? json_decode($row['metadata'], true) : [];
        
        return new Plan(
            $row['plan_id'],
            $row['name'],
            $row['billing_period'],
            $entitlements,
            $row['trial_period_days'] !== null ? (int) $row['trial_period_days'] : null,
            (bool) $row['is_active'],
            $metadata,
            new DateTimeImmutable($row['created_at'])
        );
    }
}
