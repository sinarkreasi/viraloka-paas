<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Repositories;

use Viraloka\Core\Billing\UsageRecord;
use DateTimeImmutable;
use DateTimeInterface;

/**
 * Usage Repository
 * 
 * Handles persistence of UsageRecord entities using WordPress wpdb.
 * Provides efficient time-based aggregation queries.
 * 
 * Requirements: 5.2, 5.3, 5.7, 5.8
 */
class UsageRepository
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_usage_records';
    }
    
    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * Create a new usage record
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key (dot notation)
     * @param int $amount Amount to record
     * @param array $metadata Optional metadata
     * @param DateTimeImmutable|null $recordedAt Recording timestamp
     * @return UsageRecord
     * @throws \RuntimeException If creation fails
     */
    public function create(
        string $workspaceId,
        string $key,
        int $amount,
        array $metadata = [],
        ?DateTimeImmutable $recordedAt = null
    ): UsageRecord {
        $usageId = $this->generateUuid();
        $recordedAt = $recordedAt ?? new DateTimeImmutable();
        $createdAt = new DateTimeImmutable();
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'usage_id' => $usageId,
                'workspace_id' => $workspaceId,
                'key' => $key,
                'amount' => $amount,
                'metadata' => json_encode($metadata),
                'recorded_at' => $recordedAt->format('Y-m-d H:i:s'),
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%s', '%d', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create usage record: ' . $this->wpdb->last_error);
        }
        
        return new UsageRecord(
            $usageId,
            $workspaceId,
            $key,
            $amount,
            $metadata,
            $recordedAt
        );
    }
    
    /**
     * Find usage records by workspace and key
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return UsageRecord[]
     */
    public function findByWorkspaceAndKey(string $workspaceId, string $key): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s AND `key` = %s ORDER BY recorded_at DESC",
                $workspaceId,
                $key
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }

    
    /**
     * Aggregate usage by time range
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @param DateTimeInterface $start Start date
     * @param DateTimeInterface $end End date
     * @return int Total usage amount
     */
    public function aggregateByTimeRange(
        string $workspaceId,
        string $key,
        DateTimeInterface $start,
        DateTimeInterface $end
    ): int {
        $result = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COALESCE(SUM(amount), 0) FROM {$this->tableName} 
                WHERE workspace_id = %s AND `key` = %s 
                AND recorded_at >= %s AND recorded_at <= %s",
                $workspaceId,
                $key,
                $start->format('Y-m-d H:i:s'),
                $end->format('Y-m-d H:i:s')
            )
        );
        
        return (int) $result;
    }
    
    /**
     * Aggregate all usage for workspace and key
     * 
     * @param string $workspaceId UUID
     * @param string $key Usage key
     * @return int Total usage amount
     */
    public function aggregateTotal(string $workspaceId, string $key): int
    {
        $result = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COALESCE(SUM(amount), 0) FROM {$this->tableName} 
                WHERE workspace_id = %s AND `key` = %s",
                $workspaceId,
                $key
            )
        );
        
        return (int) $result;
    }
    
    /**
     * Get usage breakdown by key for workspace
     * 
     * @param string $workspaceId UUID
     * @param DateTimeInterface|null $start Optional start date
     * @param DateTimeInterface|null $end Optional end date
     * @return array<string, int> Key => usage amount
     */
    public function getUsageBreakdown(
        string $workspaceId,
        ?DateTimeInterface $start = null,
        ?DateTimeInterface $end = null
    ): array {
        $sql = "SELECT `key`, SUM(amount) as total FROM {$this->tableName} WHERE workspace_id = %s";
        $params = [$workspaceId];
        
        if ($start !== null) {
            $sql .= " AND recorded_at >= %s";
            $params[] = $start->format('Y-m-d H:i:s');
        }
        
        if ($end !== null) {
            $sql .= " AND recorded_at <= %s";
            $params[] = $end->format('Y-m-d H:i:s');
        }
        
        $sql .= " GROUP BY `key`";
        
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare($sql, ...$params),
            ARRAY_A
        );
        
        $breakdown = [];
        foreach ($rows as $row) {
            $breakdown[$row['key']] = (int) $row['total'];
        }
        
        return $breakdown;
    }
    
    /**
     * Convert database row to UsageRecord entity
     * 
     * @param array $row Database row
     * @return UsageRecord
     */
    private function rowToEntity(array $row): UsageRecord
    {
        $metadata = !empty($row['metadata']) ? json_decode($row['metadata'], true) : [];
        
        return new UsageRecord(
            $row['usage_id'],
            $row['workspace_id'],
            $row['key'],
            (int) $row['amount'],
            $metadata,
            new DateTimeImmutable($row['recorded_at'])
        );
    }
}
