<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Invalid Entitlement Type Exception
 * 
 * Thrown when an operation is not supported for the entitlement type.
 */
class InvalidEntitlementTypeException extends \RuntimeException
{
    public function __construct(string $type, string $operation)
    {
        parent::__construct(
            "Operation '{$operation}' is not supported for entitlement type '{$type}'"
        );
    }
}
