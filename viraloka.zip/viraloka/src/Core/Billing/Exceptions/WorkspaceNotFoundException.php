<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Workspace Not Found Exception
 * 
 * Thrown when a workspace does not exist.
 */
class WorkspaceNotFoundException extends \RuntimeException
{
    public function __construct(string $workspaceId)
    {
        parent::__construct(
            "Workspace not found: {$workspaceId}"
        );
    }
}
