<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Subscription Not Found Exception
 * 
 * Thrown when a subscription cannot be found for a workspace.
 */
class SubscriptionNotFoundException extends \RuntimeException
{
    public function __construct(string $workspaceId)
    {
        parent::__construct(
            "No subscription found for workspace: {$workspaceId}"
        );
    }
}
