<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Plan Not Found Exception
 * 
 * Thrown when a plan cannot be found by its ID.
 */
class PlanNotFoundException extends \RuntimeException
{
    public function __construct(string $planId)
    {
        parent::__construct(
            "Plan not found: {$planId}"
        );
    }
}
