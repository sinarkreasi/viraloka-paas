<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Subscription Exists Exception
 * 
 * Thrown when attempting to create a subscription for a workspace that already has an active subscription.
 */
class SubscriptionExistsException extends \RuntimeException
{
    public function __construct(string $workspaceId, string $existingSubscriptionId)
    {
        parent::__construct(
            "Workspace {$workspaceId} already has an active subscription: {$existingSubscriptionId}"
        );
    }
}
