<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

use Exception;

/**
 * Invalid Status Exception
 * 
 * Thrown when an operation is attempted on a subscription with an invalid status.
 */
class InvalidStatusException extends Exception
{
    public function __construct(string $message, string $currentStatus = '', array $allowedStatuses = [])
    {
        $contextMessage = $message;
        
        if (!empty($currentStatus)) {
            $contextMessage .= " Current status: {$currentStatus}.";
        }
        
        if (!empty($allowedStatuses)) {
            $contextMessage .= " Allowed statuses: " . implode(', ', $allowedStatuses) . ".";
        }
        
        parent::__construct($contextMessage);
    }
}
