<?php

declare(strict_types=1);

namespace Viraloka\Core\Billing\Exceptions;

/**
 * Invalid Amount Exception
 * 
 * Thrown when an amount value is invalid (e.g., negative).
 */
class InvalidAmountException extends \RuntimeException
{
    public function __construct(int $amount)
    {
        parent::__construct(
            "Invalid amount: {$amount}. Amount must be non-negative."
        );
    }
}
