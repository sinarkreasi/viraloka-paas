<?php

namespace Viraloka\Core\Billing;

use DateTimeImmutable;

/**
 * Payment Result Value Object
 * 
 * Represents the result of a payment operation.
 */
class PaymentResult
{
    public const STATUS_SUCCEEDED = 'succeeded';
    public const STATUS_FAILED = 'failed';
    public const STATUS_PENDING = 'pending';
    
    public function __construct(
        public readonly string $transactionId,
        public readonly string $status,
        public readonly int $amount,
        public readonly string $currency,
        public array $metadata = [],
        public readonly ?DateTimeImmutable $processedAt = null
    ) {
        $this->processedAt = $processedAt ?? new DateTimeImmutable();
    }
    
    public function isSucceeded(): bool
    {
        return $this->status === self::STATUS_SUCCEEDED;
    }
    
    public function isFailed(): bool
    {
        return $this->status === self::STATUS_FAILED;
    }
    
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }
}
