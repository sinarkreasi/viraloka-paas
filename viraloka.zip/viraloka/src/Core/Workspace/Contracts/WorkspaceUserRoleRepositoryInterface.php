<?php

namespace Viraloka\Core\Workspace\Contracts;

use Viraloka\Core\Workspace\WorkspaceUserRole;

/**
 * Workspace User Role Repository Contract
 * 
 * Defines the interface for workspace user role data access operations.
 * Implementations must handle role assignment, querying, and validation
 * of user-workspace relationships.
 * 
 * @package Viraloka\Core\Workspace\Contracts
 */
interface WorkspaceUserRoleRepositoryInterface
{
    /**
     * Assign a role to a user in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $role The role to assign (owner, admin, member, viewer)
     * @return WorkspaceUserRole The created role assignment
     */
    public function assignRole(string $workspaceId, int $userId, string $role): WorkspaceUserRole;
    
    /**
     * Get a user's role in a specific workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return WorkspaceUserRole|null The role assignment if found, null otherwise
     */
    public function getUserRole(string $workspaceId, int $userId): ?WorkspaceUserRole;
    
    /**
     * Get all workspaces a user has access to
     * 
     * @param int $userId The WordPress user ID
     * @return WorkspaceUserRole[] Array of role assignments for the user
     */
    public function getUserWorkspaces(int $userId): array;
    
    /**
     * Get all users with roles in a specific workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @return WorkspaceUserRole[] Array of role assignments for the workspace
     */
    public function getWorkspaceUsers(string $workspaceId): array;
    
    /**
     * Update a user's role in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $newRole The new role to assign
     * @return bool True if update was successful, false otherwise
     */
    public function updateRole(string $workspaceId, int $userId, string $newRole): bool;
    
    /**
     * Remove a user's role from a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return bool True if removal was successful, false otherwise
     */
    public function removeRole(string $workspaceId, int $userId): bool;
    
    /**
     * Check if a user has access to a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return bool True if user has access, false otherwise
     */
    public function hasAccess(string $workspaceId, int $userId): bool;
    
    /**
     * Check if a user has a specific role in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $role The role to check
     * @return bool True if user has the specified role, false otherwise
     */
    public function hasRole(string $workspaceId, int $userId, string $role): bool;
    
    /**
     * Get the workspace owner's user ID
     * 
     * @param string $workspaceId The workspace UUID
     * @return int|null The owner's user ID if found, null otherwise
     */
    public function getWorkspaceOwner(string $workspaceId): ?int;
}
