<?php

namespace Viraloka\Core\Workspace\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Domain Resolver Contract
 * 
 * Responsible for resolving workspace from incoming request.
 */
interface DomainResolverInterface
{
    /**
     * Resolve workspace from current request
     * 
     * @return Workspace The resolved workspace
     */
    public function resolve(): Workspace;
    
    /**
     * Get the resolution method used (domain, subdomain, path, default)
     * 
     * @return string The resolution method
     */
    public function getResolutionMethod(): string;
    
    /**
     * Check if resolution used fallback
     * 
     * @return bool True if fallback was used, false otherwise
     */
    public function usedFallback(): bool;
}
