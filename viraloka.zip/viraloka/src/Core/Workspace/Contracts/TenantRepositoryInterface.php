<?php

namespace Viraloka\Core\Workspace\Contracts;

use Viraloka\Core\Workspace\Tenant;

/**
 * Tenant Repository Contract
 * 
 * Defines the interface for tenant data access operations.
 * Implementations must handle UUID generation, CRUD operations,
 * and status management for tenant entities.
 * 
 * @package Viraloka\Core\Workspace\Contracts
 */
interface TenantRepositoryInterface
{
    /**
     * Create a new tenant
     * 
     * @param string $name The tenant name
     * @param int $ownerUserId The WordPress user ID of the tenant owner
     * @return Tenant The created tenant with generated UUID
     */
    public function create(string $name, int $ownerUserId): Tenant;
    
    /**
     * Find a tenant by its UUID
     * 
     * @param string $tenantId The tenant UUID
     * @return Tenant|null The tenant if found, null otherwise
     */
    public function findById(string $tenantId): ?Tenant;
    
    /**
     * Find all tenants owned by a specific user
     * 
     * @param int $userId The WordPress user ID
     * @return Tenant[] Array of tenants owned by the user
     */
    public function findByOwner(int $userId): array;
    
    /**
     * Update an existing tenant
     * 
     * @param Tenant $tenant The tenant entity with updated values
     * @return bool True if update was successful, false otherwise
     */
    public function update(Tenant $tenant): bool;
    
    /**
     * Suspend a tenant (soft delete)
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if suspension was successful, false otherwise
     */
    public function suspend(string $tenantId): bool;
    
    /**
     * Activate a suspended tenant
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if activation was successful, false otherwise
     */
    public function activate(string $tenantId): bool;
    
    /**
     * Delete a tenant (soft delete via status change)
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if deletion was successful, false otherwise
     */
    public function delete(string $tenantId): bool;
}
