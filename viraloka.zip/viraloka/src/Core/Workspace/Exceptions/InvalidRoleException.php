<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when an invalid role is assigned
 */
class InvalidRoleException extends WorkspaceException
{
}
