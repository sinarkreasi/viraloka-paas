<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when a tenant cannot be found
 */
class TenantNotFoundException extends WorkspaceException
{
}
