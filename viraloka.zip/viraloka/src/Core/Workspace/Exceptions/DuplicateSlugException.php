<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when attempting to create a workspace with a duplicate slug
 */
class DuplicateSlugException extends WorkspaceException
{
}
