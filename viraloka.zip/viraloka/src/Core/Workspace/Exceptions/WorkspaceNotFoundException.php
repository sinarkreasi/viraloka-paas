<?php

namespace Viraloka\Core\Workspace\Exceptions;

/**
 * Exception thrown when a workspace cannot be found
 */
class WorkspaceNotFoundException extends WorkspaceException
{
}
