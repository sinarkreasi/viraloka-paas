<?php

namespace Viraloka\Core\Workspace\Repositories;

use Viraloka\Core\Workspace\Contracts\TenantRepositoryInterface;
use Viraloka\Core\Workspace\Tenant;
use Viraloka\Core\Workspace\Exceptions\TenantNotFoundException;

/**
 * Tenant Repository
 * 
 * Implements data access operations for tenant entities.
 * Uses WordPress wpdb for database operations and UUID for primary keys.
 */
class TenantRepository implements TenantRepositoryInterface
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_tenants';
    }
    
    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
    
    /**
     * Create a new tenant
     * 
     * @param string $name The tenant name
     * @param int $ownerUserId The WordPress user ID of the tenant owner
     * @return Tenant The created tenant with generated UUID
     */
    public function create(string $name, int $ownerUserId): Tenant
    {
        $tenantId = $this->generateUuid();
        $createdAt = new \DateTimeImmutable();
        
        $result = $this->wpdb->insert(
            $this->tableName,
            [
                'tenant_id' => $tenantId,
                'name' => $name,
                'owner_user_id' => $ownerUserId,
                'status' => Tenant::STATUS_ACTIVE,
                'created_at' => $createdAt->format('Y-m-d H:i:s'),
                'updated_at' => $createdAt->format('Y-m-d H:i:s'),
            ],
            ['%s', '%s', '%d', '%s', '%s', '%s']
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to create tenant: ' . $this->wpdb->last_error);
        }
        
        return new Tenant(
            $tenantId,
            $name,
            $ownerUserId,
            Tenant::STATUS_ACTIVE,
            $createdAt
        );
    }
    
    /**
     * Find a tenant by its UUID
     * 
     * @param string $tenantId The tenant UUID
     * @return Tenant|null The tenant if found, null otherwise
     */
    public function findById(string $tenantId): ?Tenant
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE tenant_id = %s",
                $tenantId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Find all tenants owned by a specific user
     * 
     * @param int $userId The WordPress user ID
     * @return Tenant[] Array of tenants owned by the user
     */
    public function findByOwner(int $userId): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE owner_user_id = %d ORDER BY created_at DESC",
                $userId
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Update an existing tenant
     * 
     * @param Tenant $tenant The tenant entity with updated values
     * @return bool True if update was successful, false otherwise
     */
    public function update(Tenant $tenant): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'name' => $tenant->name,
                'status' => $tenant->status,
                'updated_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['tenant_id' => $tenant->tenantId],
            ['%s', '%s', '%s'],
            ['%s']
        );
        
        return $result !== false;
    }
    
    /**
     * Suspend a tenant (soft delete)
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if suspension was successful, false otherwise
     */
    public function suspend(string $tenantId): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'status' => Tenant::STATUS_SUSPENDED,
                'updated_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['tenant_id' => $tenantId],
            ['%s', '%s'],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Activate a suspended tenant
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if activation was successful, false otherwise
     */
    public function activate(string $tenantId): bool
    {
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'status' => Tenant::STATUS_ACTIVE,
                'updated_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            ['tenant_id' => $tenantId],
            ['%s', '%s'],
            ['%s']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Delete a tenant (soft delete via status change)
     * 
     * @param string $tenantId The tenant UUID
     * @return bool True if deletion was successful, false otherwise
     */
    public function delete(string $tenantId): bool
    {
        // Soft delete by suspending
        return $this->suspend($tenantId);
    }
    
    /**
     * Convert database row to Tenant entity
     * 
     * @param array $row Database row
     * @return Tenant
     */
    private function rowToEntity(array $row): Tenant
    {
        return new Tenant(
            $row['tenant_id'],
            $row['name'],
            (int) $row['owner_user_id'],
            $row['status'],
            new \DateTimeImmutable($row['created_at'])
        );
    }
}
