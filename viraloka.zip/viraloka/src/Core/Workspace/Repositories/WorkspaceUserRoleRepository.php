<?php

namespace Viraloka\Core\Workspace\Repositories;

use Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface;
use Viraloka\Core\Workspace\WorkspaceUserRole;
use Viraloka\Core\Workspace\Exceptions\InvalidRoleException;

/**
 * Workspace User Role Repository
 * 
 * Implements data access operations for workspace user role assignments.
 * Uses WordPress wpdb for database operations.
 * Enforces role validation and tenant owner constraints.
 */
class WorkspaceUserRoleRepository implements WorkspaceUserRoleRepositoryInterface
{
    private \wpdb $wpdb;
    private string $tableName;
    
    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->tableName = $wpdb->prefix . 'viraloka_workspace_user_roles';
    }
    
    /**
     * Assign a role to a user in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $role The role to assign (owner, admin, member, viewer)
     * @return WorkspaceUserRole The created role assignment
     * @throws InvalidRoleException If role is invalid
     */
    public function assignRole(string $workspaceId, int $userId, string $role): WorkspaceUserRole
    {
        // Validate role through entity constructor
        $workspaceUserRole = new WorkspaceUserRole($workspaceId, $userId, $role);
        
        $createdAt = new \DateTimeImmutable();
        
        // Use INSERT ... ON DUPLICATE KEY UPDATE to handle existing assignments
        $result = $this->wpdb->query(
            $this->wpdb->prepare(
                "INSERT INTO {$this->tableName} 
                (workspace_id, user_id, role, created_at, updated_at) 
                VALUES (%s, %d, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                role = VALUES(role), 
                updated_at = VALUES(updated_at)",
                $workspaceId,
                $userId,
                $role,
                $createdAt->format('Y-m-d H:i:s'),
                $createdAt->format('Y-m-d H:i:s')
            )
        );
        
        if ($result === false) {
            throw new \RuntimeException('Failed to assign role: ' . $this->wpdb->last_error);
        }
        
        return $workspaceUserRole;
    }
    
    /**
     * Get a user's role in a specific workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return WorkspaceUserRole|null The role assignment if found, null otherwise
     */
    public function getUserRole(string $workspaceId, int $userId): ?WorkspaceUserRole
    {
        $row = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s AND user_id = %d",
                $workspaceId,
                $userId
            ),
            ARRAY_A
        );
        
        if ($row === null) {
            return null;
        }
        
        return $this->rowToEntity($row);
    }
    
    /**
     * Get all workspaces a user has access to
     * 
     * @param int $userId The WordPress user ID
     * @return WorkspaceUserRole[] Array of role assignments for the user
     */
    public function getUserWorkspaces(int $userId): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE user_id = %d ORDER BY created_at DESC",
                $userId
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Get all users with roles in a specific workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @return WorkspaceUserRole[] Array of role assignments for the workspace
     */
    public function getWorkspaceUsers(string $workspaceId): array
    {
        $rows = $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->tableName} WHERE workspace_id = %s ORDER BY created_at ASC",
                $workspaceId
            ),
            ARRAY_A
        );
        
        if (empty($rows)) {
            return [];
        }
        
        return array_map([$this, 'rowToEntity'], $rows);
    }
    
    /**
     * Update a user's role in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $newRole The new role to assign
     * @return bool True if update was successful, false otherwise
     * @throws InvalidRoleException If role is invalid
     */
    public function updateRole(string $workspaceId, int $userId, string $newRole): bool
    {
        // Validate role
        if (!in_array($newRole, WorkspaceUserRole::VALID_ROLES, true)) {
            throw new InvalidRoleException("Invalid role: {$newRole}");
        }
        
        $result = $this->wpdb->update(
            $this->tableName,
            [
                'role' => $newRole,
                'updated_at' => (new \DateTimeImmutable())->format('Y-m-d H:i:s'),
            ],
            [
                'workspace_id' => $workspaceId,
                'user_id' => $userId,
            ],
            ['%s', '%s'],
            ['%s', '%d']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Remove a user's role from a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return bool True if removal was successful, false otherwise
     */
    public function removeRole(string $workspaceId, int $userId): bool
    {
        $result = $this->wpdb->delete(
            $this->tableName,
            [
                'workspace_id' => $workspaceId,
                'user_id' => $userId,
            ],
            ['%s', '%d']
        );
        
        return $result !== false && $result > 0;
    }
    
    /**
     * Check if a user has access to a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @return bool True if user has access, false otherwise
     */
    public function hasAccess(string $workspaceId, int $userId): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tableName} WHERE workspace_id = %s AND user_id = %d",
                $workspaceId,
                $userId
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Check if a user has a specific role in a workspace
     * 
     * @param string $workspaceId The workspace UUID
     * @param int $userId The WordPress user ID
     * @param string $role The role to check
     * @return bool True if user has the specified role, false otherwise
     */
    public function hasRole(string $workspaceId, int $userId, string $role): bool
    {
        $count = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->tableName} WHERE workspace_id = %s AND user_id = %d AND role = %s",
                $workspaceId,
                $userId,
                $role
            )
        );
        
        return $count > 0;
    }
    
    /**
     * Get the workspace owner's user ID
     * 
     * @param string $workspaceId The workspace UUID
     * @return int|null The owner's user ID if found, null otherwise
     */
    public function getWorkspaceOwner(string $workspaceId): ?int
    {
        $userId = $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT user_id FROM {$this->tableName} WHERE workspace_id = %s AND role = %s LIMIT 1",
                $workspaceId,
                WorkspaceUserRole::ROLE_OWNER
            )
        );
        
        return $userId !== null ? (int) $userId : null;
    }
    
    /**
     * Convert database row to WorkspaceUserRole entity
     * 
     * @param array $row Database row
     * @return WorkspaceUserRole
     */
    private function rowToEntity(array $row): WorkspaceUserRole
    {
        return new WorkspaceUserRole(
            $row['workspace_id'],
            (int) $row['user_id'],
            $row['role']
        );
    }
}
