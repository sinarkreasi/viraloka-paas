<?php

namespace Viraloka\Core\Workspace\Providers;

use Viraloka\Core\Container\Contracts\ContainerInterface;
use Viraloka\Core\Container\Contracts\ServiceProviderInterface;
use Viraloka\Core\Workspace\Contracts\TenantRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\DomainResolverInterface;
use Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface;
use Viraloka\Core\Workspace\Repositories\TenantRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceRepository;
use Viraloka\Core\Workspace\Repositories\WorkspaceUserRoleRepository;
use Viraloka\Core\Workspace\EnhancedWorkspaceResolver;
use Viraloka\Core\Workspace\PermissionBoundary;
use Viraloka\Core\Container\Contracts\WorkspaceResolverInterface;
use Viraloka\Core\Workspace\Workspace;

/**
 * Workspace & Tenant Service Provider
 * 
 * Registers all workspace and tenant system services in the container.
 * This includes repositories, resolvers, and permission boundaries.
 * 
 * Requirements: 5.3, 5.4
 */
class WorkspaceTenantServiceProvider implements ServiceProviderInterface
{
    /**
     * Register bindings in the container.
     * 
     * This method registers all repository interfaces, the workspace resolver,
     * and the permission boundary as singletons in the container.
     * 
     * @param ContainerInterface $container The container instance
     * @return void
     */
    public function register(ContainerInterface $container): void
    {
        // Register TenantRepository
        $container->singleton(
            TenantRepositoryInterface::class,
            fn($c) => new TenantRepository()
        );

        // Register WorkspaceRepository
        $container->singleton(
            WorkspaceRepositoryInterface::class,
            fn($c) => new WorkspaceRepository()
        );

        // Register WorkspaceUserRoleRepository
        $container->singleton(
            WorkspaceUserRoleRepositoryInterface::class,
            fn($c) => new WorkspaceUserRoleRepository()
        );

        // Register EnhancedWorkspaceResolver as singleton
        // This implements both DomainResolverInterface and WorkspaceResolverInterface
        $container->singleton(
            EnhancedWorkspaceResolver::class,
            function($c) {
                $repository = $c->get(WorkspaceRepositoryInterface::class);
                
                // Get RequestAdapter from AdapterRegistry
                $registry = $c->get(\Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface::class);
                $requestAdapter = $registry->request();
                
                $logger = null;
                
                // Try to get logger if available
                if ($c->has('logger')) {
                    $logger = $c->get('logger');
                }
                
                return new EnhancedWorkspaceResolver($repository, $requestAdapter, $logger);
            }
        );

        // Alias DomainResolverInterface to EnhancedWorkspaceResolver
        $container->singleton(
            DomainResolverInterface::class,
            fn($c) => $c->get(EnhancedWorkspaceResolver::class)
        );

        // Alias WorkspaceResolverInterface to EnhancedWorkspaceResolver
        $container->singleton(
            WorkspaceResolverInterface::class,
            fn($c) => $c->get(EnhancedWorkspaceResolver::class)
        );

        // Register PermissionBoundary as singleton
        $container->singleton(
            PermissionBoundaryInterface::class,
            function($c) {
                $workspaceUserRoleRepo = $c->get(WorkspaceUserRoleRepositoryInterface::class);
                $tenantRepo = $c->get(TenantRepositoryInterface::class);
                $logger = null;
                
                // Try to get logger if available
                if ($c->has('logger')) {
                    $logger = $c->get('logger');
                }
                
                return new PermissionBoundary($workspaceUserRoleRepo, $tenantRepo, $logger);
            }
        );
    }

    /**
     * Bootstrap services after all providers are registered.
     * 
     * This method resolves the current workspace and injects it into the container
     * so that it's available for all services that need workspace context.
     * 
     * @param ContainerInterface $container The container instance
     * @return void
     */
    public function boot(ContainerInterface $container): void
    {
        // Resolve the current workspace and inject it into the container
        try {
            $resolver = $container->get(DomainResolverInterface::class);
            $workspace = $resolver->resolve();
            
            // Register the resolved workspace as an instance in the container
            $container->instance(Workspace::class, $workspace);
            
            // Also register under a simple 'workspace' key for convenience
            $container->instance('workspace', $workspace);
            
        } catch (\Throwable $e) {
            // If workspace resolution fails during boot, log it but don't fail
            // The system should still be able to function with a default workspace
            if ($container->has('logger')) {
                $logger = $container->get('logger');
                $logger->warning('Failed to resolve workspace during boot: ' . $e->getMessage());
            }
        }
    }
}
