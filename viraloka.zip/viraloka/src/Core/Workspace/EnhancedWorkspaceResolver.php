<?php

namespace Viraloka\Core\Workspace;

use Viraloka\Core\Workspace\Contracts\DomainResolverInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Container\Contracts\WorkspaceResolverInterface;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Adapter\Contracts\RequestAdapterInterface;

/**
 * Enhanced Workspace Resolver
 * 
 * Implements both DomainResolverInterface and WorkspaceResolverInterface
 * for full integration with the container and context systems.
 * Uses RequestAdapter for host-agnostic request data access.
 * 
 * Resolution priority:
 * 1. Custom Domain (e.g., app.client.com)
 * 2. Subdomain (e.g., workspace.viraloka.app)
 * 3. Path (e.g., viraloka.app/workspace-slug)
 * 4. Default Workspace (fallback)
 */
class EnhancedWorkspaceResolver implements DomainResolverInterface, WorkspaceResolverInterface
{
    private WorkspaceRepositoryInterface $repository;
    private Logger $logger;
    private RequestAdapterInterface $requestAdapter;
    private ?Workspace $resolvedWorkspace = null;
    private string $resolutionMethod = 'none';
    private bool $usedFallback = false;
    
    public function __construct(
        WorkspaceRepositoryInterface $repository,
        RequestAdapterInterface $requestAdapter,
        ?Logger $logger = null
    ) {
        $this->repository = $repository;
        $this->requestAdapter = $requestAdapter;
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Resolve workspace from current request
     * 
     * Uses priority-based resolution:
     * 1. Custom domain
     * 2. Subdomain
     * 3. Path
     * 4. Default workspace (fallback)
     * 
     * @return Workspace The resolved workspace
     */
    public function resolve(): Workspace
    {
        // Return cached workspace if already resolved
        if ($this->resolvedWorkspace !== null) {
            return $this->resolvedWorkspace;
        }
        
        // Priority 1: Custom Domain
        $workspace = $this->resolveByDomain();
        if ($workspace !== null) {
            $this->resolutionMethod = 'domain';
            $this->resolvedWorkspace = $workspace;
            return $workspace;
        }
        
        // Priority 2: Subdomain
        $workspace = $this->resolveBySubdomain();
        if ($workspace !== null) {
            $this->resolutionMethod = 'subdomain';
            $this->resolvedWorkspace = $workspace;
            return $workspace;
        }
        
        // Priority 3: Path
        $workspace = $this->resolveByPath();
        if ($workspace !== null) {
            $this->resolutionMethod = 'path';
            $this->resolvedWorkspace = $workspace;
            return $workspace;
        }
        
        // Priority 4: Default Workspace (Fallback)
        $this->usedFallback = true;
        $this->resolutionMethod = 'default';
        $workspace = $this->repository->getDefault();
        
        if ($workspace === null) {
            $this->logger->warning('No default workspace found, creating system default');
            $workspace = $this->createSystemDefault();
        }
        
        $this->resolvedWorkspace = $workspace;
        return $workspace;
    }
    
    /**
     * Get the current workspace identifier
     * 
     * Implements WorkspaceResolverInterface for container integration.
     * 
     * @return string|null The current workspace ID
     */
    public function getCurrentWorkspace(): ?string
    {
        $workspace = $this->resolve();
        return $workspace->workspaceId;
    }
    
    /**
     * Get the resolution method used
     * 
     * @return string One of: 'domain', 'subdomain', 'path', 'default', 'none'
     */
    public function getResolutionMethod(): string
    {
        return $this->resolutionMethod;
    }
    
    /**
     * Check if resolution used fallback
     * 
     * @return bool True if fallback to default workspace was used
     */
    public function usedFallback(): bool
    {
        return $this->usedFallback;
    }
    
    /**
     * Resolve workspace by custom domain
     * 
     * @return Workspace|null The workspace if found, null otherwise
     */
    private function resolveByDomain(): ?Workspace
    {
        $domain = $this->getCurrentDomain();
        if (empty($domain)) {
            return null;
        }
        
        return $this->repository->findByDomain($domain);
    }
    
    /**
     * Resolve workspace by subdomain
     * 
     * Extracts subdomain from the current domain and looks up workspace.
     * 
     * @return Workspace|null The workspace if found, null otherwise
     */
    private function resolveBySubdomain(): ?Workspace
    {
        $domain = $this->getCurrentDomain();
        if (empty($domain)) {
            return null;
        }
        
        $parts = explode('.', $domain);
        if (count($parts) < 3) {
            return null;
        }
        
        $subdomain = $parts[0];
        return $this->repository->findBySubdomain($subdomain);
    }
    
    /**
     * Resolve workspace by path
     * 
     * Extracts the first path segment and looks up workspace by slug.
     * 
     * @return Workspace|null The workspace if found, null otherwise
     */
    private function resolveByPath(): ?Workspace
    {
        $path = $this->getCurrentPath();
        if (empty($path)) {
            return null;
        }
        
        $segments = explode('/', trim($path, '/'));
        if (empty($segments[0])) {
            return null;
        }
        
        return $this->repository->findBySlug($segments[0]);
    }
    
    /**
     * Get the current domain from the request
     * 
     * @return string The current domain (lowercase)
     */
    private function getCurrentDomain(): string
    {
        // Use RequestAdapter to get Host header
        $host = $this->requestAdapter->getHeader('Host');
        return strtolower($host ?? '');
    }
    
    /**
     * Get the current path from the request
     * 
     * @return string The current path
     */
    private function getCurrentPath(): string
    {
        // Use RequestAdapter to get path
        return $this->requestAdapter->getPath();
    }
    
    /**
     * Create a system default workspace
     * 
     * This is a fallback for when no default workspace exists in the database.
     * 
     * @return Workspace The system default workspace
     */
    private function createSystemDefault(): Workspace
    {
        return new Workspace(
            workspaceId: 'system-default',
            tenantId: 'system',
            name: 'Default Workspace',
            slug: 'default',
            status: Workspace::STATUS_ACTIVE,
            activeContext: 'default'
        );
    }
}
