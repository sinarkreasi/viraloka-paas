<?php

namespace Viraloka\Core\Workspace;

/**
 * Workspace Entity
 * 
 * Represents an isolated operational unit within a tenant.
 * Each workspace has its own context, configuration, and domain routing.
 */
class Workspace
{
    public readonly string $workspaceId;
    public readonly string $tenantId;
    public string $name;
    public string $slug;
    public string $status;
    public string $activeContext;
    public readonly \DateTimeImmutable $createdAt;
    
    // Domain configuration
    public ?string $customDomain = null;
    public ?string $subdomain = null;
    public bool $isDefault = false;
    
    // Legacy properties for backward compatibility
    public array $config = [];
    public array $enabledModules = [];
    
    public const STATUS_ACTIVE = 'active';
    public const STATUS_SUSPENDED = 'suspended';
    public const STATUS_ARCHIVED = 'archived';
    
    public function __construct(
        string $workspaceId,
        string $tenantId,
        string $name,
        string $slug,
        string $status = self::STATUS_ACTIVE,
        string $activeContext = 'default',
        ?\DateTimeImmutable $createdAt = null
    ) {
        $this->workspaceId = $workspaceId;
        $this->tenantId = $tenantId;
        $this->name = $name;
        $this->slug = $slug;
        $this->status = $status;
        $this->activeContext = $activeContext;
        $this->createdAt = $createdAt ?? new \DateTimeImmutable();
    }
    
    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }
    
    public function setCustomDomain(?string $domain): void
    {
        $this->customDomain = $domain;
    }
    
    public function setSubdomain(?string $subdomain): void
    {
        $this->subdomain = $subdomain;
    }
    
    public function setIsDefault(bool $isDefault): void
    {
        $this->isDefault = $isDefault;
    }
    
    public function suspend(): void
    {
        $this->status = self::STATUS_SUSPENDED;
    }
    
    public function activate(): void
    {
        $this->status = self::STATUS_ACTIVE;
    }
    
    public function archive(): void
    {
        $this->status = self::STATUS_ARCHIVED;
    }
}
