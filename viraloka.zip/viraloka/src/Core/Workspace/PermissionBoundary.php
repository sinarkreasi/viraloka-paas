<?php

namespace Viraloka\Core\Workspace;

use Viraloka\Core\Workspace\Contracts\PermissionBoundaryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceUserRoleRepositoryInterface;
use Viraloka\Core\Workspace\Contracts\WorkspaceRepositoryInterface;
use Viraloka\Core\Modules\Logger;

/**
 * Permission Boundary
 * 
 * Implements workspace-level permission checks and role-based access control.
 * Prevents cross-workspace data access by validating user access and logging violations.
 * Enforces the security boundary between workspaces.
 */
class PermissionBoundary implements PermissionBoundaryInterface
{
    private WorkspaceUserRoleRepositoryInterface $roleRepository;
    private WorkspaceRepositoryInterface $workspaceRepository;
    private Logger $logger;
    private ?string $currentWorkspaceId = null;
    
    /**
     * Action permission mappings
     * 
     * Defines which roles can perform which actions.
     */
    private const ACTION_PERMISSIONS = [
        'view' => [
            WorkspaceUserRole::ROLE_OWNER,
            WorkspaceUserRole::ROLE_ADMIN,
            WorkspaceUserRole::ROLE_MEMBER,
            WorkspaceUserRole::ROLE_VIEWER,
        ],
        'edit' => [
            WorkspaceUserRole::ROLE_OWNER,
            WorkspaceUserRole::ROLE_ADMIN,
            WorkspaceUserRole::ROLE_MEMBER,
        ],
        'delete' => [
            WorkspaceUserRole::ROLE_OWNER,
            WorkspaceUserRole::ROLE_ADMIN,
        ],
        'manage' => [
            WorkspaceUserRole::ROLE_OWNER,
            WorkspaceUserRole::ROLE_ADMIN,
        ],
        'configure' => [
            WorkspaceUserRole::ROLE_OWNER,
        ],
    ];
    
    public function __construct(
        WorkspaceUserRoleRepositoryInterface $roleRepository,
        WorkspaceRepositoryInterface $workspaceRepository,
        ?Logger $logger = null
    ) {
        $this->roleRepository = $roleRepository;
        $this->workspaceRepository = $workspaceRepository;
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Set the current workspace context
     * 
     * @param string $workspaceId The workspace UUID
     * @return void
     */
    public function setCurrentWorkspace(string $workspaceId): void
    {
        $this->currentWorkspaceId = $workspaceId;
    }
    
    /**
     * Get the current workspace context
     * 
     * @return string|null The current workspace UUID or null if not set
     */
    public function getCurrentWorkspace(): ?string
    {
        return $this->currentWorkspaceId;
    }
    
    /**
     * Check if user has access to workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @return bool True if user has access, false otherwise
     */
    public function canAccess(int $userId, string $workspaceId): bool
    {
        // Check if workspace exists and is active
        $workspace = $this->workspaceRepository->findById($workspaceId);
        if ($workspace === null || !$workspace->isActive()) {
            return false;
        }
        
        // Check if user has any role in the workspace
        $hasAccess = $this->roleRepository->hasAccess($workspaceId, $userId);
        
        // Log cross-workspace access attempts
        if (!$hasAccess && $this->currentWorkspaceId !== null && $this->currentWorkspaceId !== $workspaceId) {
            $this->logger->warning(
                "Cross-workspace access attempt: User {$userId} tried to access workspace {$workspaceId} from workspace {$this->currentWorkspaceId}"
            );
        }
        
        return $hasAccess;
    }
    
    /**
     * Check if user has specific role in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @param string $role The role to check (owner, admin, member, viewer)
     * @return bool True if user has the specified role, false otherwise
     */
    public function hasRole(int $userId, string $workspaceId, string $role): bool
    {
        // Validate role
        if (!in_array($role, WorkspaceUserRole::VALID_ROLES, true)) {
            $this->logger->warning("Invalid role check attempted: {$role}");
            return false;
        }
        
        return $this->roleRepository->hasRole($workspaceId, $userId, $role);
    }
    
    /**
     * Check if user can perform action in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @param string $action The action to check (e.g., 'edit', 'delete', 'manage')
     * @return bool True if user can perform the action, false otherwise
     */
    public function canPerform(int $userId, string $workspaceId, string $action): bool
    {
        // Check if user has access to the workspace first
        if (!$this->canAccess($userId, $workspaceId)) {
            $this->logger->warning(
                "Permission denied: User {$userId} attempted action '{$action}' in workspace {$workspaceId} without access"
            );
            return false;
        }
        
        // Get user's role
        $userRole = $this->getUserRole($userId, $workspaceId);
        if ($userRole === null) {
            return false;
        }
        
        // Check if action is defined in permissions
        if (!isset(self::ACTION_PERMISSIONS[$action])) {
            // Unknown action - default to deny
            $this->logger->warning("Unknown action permission check: {$action}");
            return false;
        }
        
        // Check if user's role is allowed for this action
        $allowed = in_array($userRole, self::ACTION_PERMISSIONS[$action], true);
        
        if (!$allowed) {
            $this->logger->warning(
                "Permission denied: User {$userId} with role '{$userRole}' attempted action '{$action}' in workspace {$workspaceId}"
            );
        }
        
        return $allowed;
    }
    
    /**
     * Get user's role in workspace
     * 
     * @param int $userId The WordPress user ID
     * @param string $workspaceId The workspace UUID
     * @return string|null The user's role if found, null otherwise
     */
    public function getUserRole(int $userId, string $workspaceId): ?string
    {
        $roleAssignment = $this->roleRepository->getUserRole($workspaceId, $userId);
        
        if ($roleAssignment === null) {
            return null;
        }
        
        return $roleAssignment->role;
    }
    
    /**
     * Validate workspace context for data access
     * 
     * Ensures that the current operation is within the correct workspace context.
     * Prevents cross-workspace data access by comparing the requested workspace
     * with the current workspace context.
     * 
     * @param string $workspaceId The workspace UUID to validate
     * @return bool True if workspace context is valid, false otherwise
     */
    public function validateWorkspaceContext(string $workspaceId): bool
    {
        // If no current workspace is set, validation passes
        // (this allows for system-level operations)
        if ($this->currentWorkspaceId === null) {
            return true;
        }
        
        // Check if requested workspace matches current workspace
        $isValid = $this->currentWorkspaceId === $workspaceId;
        
        // Log cross-workspace access attempts
        if (!$isValid) {
            $this->logger->warning(
                "Cross-workspace context violation: Attempted to access workspace {$workspaceId} while in workspace {$this->currentWorkspaceId}"
            );
        }
        
        return $isValid;
    }
}
