<?php

namespace Viraloka\Core\Workspace;

/**
 * Workspace User Role
 * 
 * Represents the many-to-many relationship between users and workspaces,
 * including the role assignment.
 */
class WorkspaceUserRole
{
    public readonly string $workspaceId;
    public readonly int $userId;
    public string $role;
    
    public const ROLE_OWNER = 'owner';
    public const ROLE_ADMIN = 'admin';
    public const ROLE_MEMBER = 'member';
    public const ROLE_VIEWER = 'viewer';
    
    public const VALID_ROLES = [
        self::ROLE_OWNER,
        self::ROLE_ADMIN,
        self::ROLE_MEMBER,
        self::ROLE_VIEWER,
    ];
    
    public function __construct(
        string $workspaceId,
        int $userId,
        string $role
    ) {
        if (!in_array($role, self::VALID_ROLES, true)) {
            throw new \InvalidArgumentException("Invalid role: {$role}");
        }
        
        $this->workspaceId = $workspaceId;
        $this->userId = $userId;
        $this->role = $role;
    }
    
    public function canManageWorkspace(): bool
    {
        return in_array($this->role, [self::ROLE_OWNER, self::ROLE_ADMIN], true);
    }
    
    public function canEditContent(): bool
    {
        return in_array($this->role, [self::ROLE_OWNER, self::ROLE_ADMIN, self::ROLE_MEMBER], true);
    }
    
    public function isOwner(): bool
    {
        return $this->role === self::ROLE_OWNER;
    }
}
