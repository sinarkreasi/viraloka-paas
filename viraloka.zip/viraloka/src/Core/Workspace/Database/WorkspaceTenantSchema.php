<?php

namespace Viraloka\Core\Workspace\Database;

use Viraloka\Adapter\WordPress\Database\WordPressWorkspaceTenantSchema;

/**
 * Workspace Tenant Schema
 * 
 * @deprecated Use Viraloka\Adapter\WordPress\Database\WordPressWorkspaceTenantSchema instead
 * 
 * This class is deprecated and maintained only for backward compatibility.
 * Database schema management is now handled by host-specific adapters.
 * 
 * For WordPress: Use WordPressWorkspaceTenantSchema
 * For other hosts: Implement your own schema management
 */
class WorkspaceTenantSchema
{
    private WordPressWorkspaceTenantSchema $implementation;
    
    public function __construct()
    {
        $this->implementation = new WordPressWorkspaceTenantSchema();
    }
    
    /**
     * Create all required database tables
     * 
     * @deprecated Use WordPressWorkspaceTenantSchema::createTables() instead
     * @return void
     */
    public function createTables(): void
    {
        $this->implementation->createTables();
    }
    
    /**
     * Drop all tables (for rollback)
     * 
     * @deprecated Use WordPressWorkspaceTenantSchema::dropTables() instead
     * @return void
     */
    public function dropTables(): void
    {
        $this->implementation->dropTables();
    }
    
    /**
     * Check if all tables exist
     * 
     * @deprecated Use WordPressWorkspaceTenantSchema::tablesExist() instead
     * @return bool
     */
    public function tablesExist(): bool
    {
        return $this->implementation->tablesExist();
    }
    
    /**
     * Run migration (create tables if they don't exist)
     * 
     * @deprecated Use WordPressWorkspaceTenantSchema::migrate() instead
     * @return bool True if migration was successful
     */
    public function migrate(): bool
    {
        return $this->implementation->migrate();
    }
    
    /**
     * Run rollback (drop all tables)
     * 
     * @deprecated Use WordPressWorkspaceTenantSchema::rollback() instead
     * @return bool True if rollback was successful
     */
    public function rollback(): bool
    {
        return $this->implementation->rollback();
    }
}
