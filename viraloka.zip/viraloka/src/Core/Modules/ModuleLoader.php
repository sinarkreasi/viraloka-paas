<?php

namespace Viraloka\Core\Modules;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Contracts\ModuleLoaderContract;
use Viraloka\Core\Modules\Contracts\ManifestParserContract;
use Viraloka\Core\Modules\Contracts\DependencyResolverContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Viraloka\Core\Modules\Contracts\ManifestCacheContract;
use Viraloka\Core\Context\Contracts\ContextResolverContract;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

/**
 * Module Loader
 * 
 * Orchestrates the module discovery and loading process.
 * 
 * Implementation Details:
 * - Scans the /viraloka-modules/ directory for subdirectories
 * - Checks for module.json in each subdirectory
 * - Delegates to ManifestParser for file parsing
 * - Maintains separate collections for valid and invalid modules
 * - Uses ManifestCache to avoid redundant parsing
 */
class ModuleLoader implements ModuleLoaderContract
{
    /**
     * Manifest parser instance
     * 
     * @var ManifestParserContract
     */
    protected ManifestParserContract $parser;
    
    /**
     * Dependency resolver instance
     * 
     * @var DependencyResolverContract
     */
    protected DependencyResolverContract $dependencyResolver;
    
    /**
     * Module registry instance
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $registry;
    
    /**
     * Context resolver instance
     * 
     * @var ContextResolverContract
     */
    protected ContextResolverContract $contextResolver;
    
    /**
     * Manifest cache instance
     * 
     * @var ManifestCacheContract|null
     */
    protected ?ManifestCacheContract $cache;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Base modules directory path
     * 
     * @var string
     */
    protected string $modulesPath;
    
    /**
     * Collection of invalid modules
     * 
     * @var Collection<InvalidModule>
     */
    protected Collection $invalidModules;
    
    /**
     * Create a new module loader instance
     * 
     * @param ManifestParserContract $parser
     * @param DependencyResolverContract $dependencyResolver
     * @param ModuleRegistryContract $registry
     * @param ContextResolverContract $contextResolver
     * @param string $modulesPath
     * @param ManifestCacheContract|null $cache
     * @param Logger|null $logger
     */
    public function __construct(
        ManifestParserContract $parser,
        DependencyResolverContract $dependencyResolver,
        ModuleRegistryContract $registry,
        ContextResolverContract $contextResolver,
        string $modulesPath,
        ?ManifestCacheContract $cache = null,
        ?Logger $logger = null
    ) {
        $this->parser = $parser;
        $this->dependencyResolver = $dependencyResolver;
        $this->registry = $registry;
        $this->contextResolver = $contextResolver;
        $this->modulesPath = rtrim($modulesPath, '/\\');
        $this->cache = $cache;
        $this->logger = $logger ?? new Logger();
        $this->invalidModules = new Collection();
    }
    
    /**
     * Discover and load all valid modules
     * 
     * Scans module directories, parses manifests, resolves dependencies,
     * checks context compatibility, and filters by tenant enablement.
     * 
     * @return Collection<Module>
     */
    public function loadModules(): Collection
    {
        // Reset invalid modules collection
        $this->invalidModules = new Collection();
        
        // Scan for module.json files
        $manifestFiles = $this->scanModuleDirectories();
        
        // Get current context for filtering
        $currentContext = $this->contextResolver->getCurrentContext();
        
        // Process each manifest file
        foreach ($manifestFiles as $manifestPath) {
            $this->loadModuleFromManifest($manifestPath, $currentContext);
        }
        
        // Return all successfully loaded modules
        return $this->registry->all();
    }
    
    /**
     * Load a specific module by ID
     * 
     * @param string $moduleId
     * @return Module|null
     */
    public function loadModule(string $moduleId): ?Module
    {
        // Check if module is already loaded
        if ($this->registry->has($moduleId)) {
            return $this->registry->get($moduleId);
        }
        
        // Scan for the specific module
        $manifestFiles = $this->scanModuleDirectories();
        $currentContext = $this->contextResolver->getCurrentContext();
        
        foreach ($manifestFiles as $manifestPath) {
            $parseResult = $this->parser->parse($manifestPath);
            
            if ($parseResult->success && $parseResult->manifest->id === $moduleId) {
                return $this->loadModuleFromManifest($manifestPath, $currentContext);
            }
        }
        
        return null;
    }
    
    /**
     * Get all invalid modules with error details
     * 
     * @return Collection<InvalidModule>
     */
    public function getInvalidModules(): Collection
    {
        return $this->invalidModules;
    }
    
    /**
     * Scan module directories for module.json files
     * 
     * Recursively scans subdirectories in the modules folder.
     * Returns array of absolute paths to module.json files.
     * 
     * @return array<string>
     */
    protected function scanModuleDirectories(): array
    {
        $manifestFiles = [];
        
        // Check if modules directory exists
        if (!is_dir($this->modulesPath)) {
            $this->logger->error("Modules directory not found: {$this->modulesPath}");
            return $manifestFiles;
        }
        
        try {
            // Create recursive directory iterator
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $this->modulesPath,
                    RecursiveDirectoryIterator::SKIP_DOTS
                ),
                RecursiveIteratorIterator::SELF_FIRST
            );
            
            // Find all module.json files
            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getFilename() === 'module.json') {
                    $manifestFiles[] = $file->getPathname();
                }
            }
        } catch (\Exception $e) {
            $this->logger->error("Error scanning modules directory: {$e->getMessage()}");
        }
        
        return $manifestFiles;
    }
    
    /**
     * Load a module from a manifest file path
     * 
     * Parses the manifest, validates it, resolves dependencies,
     * checks context compatibility, and registers the module.
     * Uses cache to avoid redundant parsing.
     * 
     * @param string $manifestPath
     * @param string $currentContext
     * @return Module|null
     */
    protected function loadModuleFromManifest(string $manifestPath, string $currentContext): ?Module
    {
        $modulePath = dirname($manifestPath);
        $manifest = null;
        
        // Try to get from cache first
        if ($this->cache !== null) {
            // We need to parse once to get the module ID for cache lookup
            // Or we could use a different cache key strategy
            // For now, we'll parse first to get the ID, then check cache
            $parseResult = $this->parser->parse($manifestPath);
            
            if ($parseResult->success) {
                $moduleId = $parseResult->manifest->id;
                $cachedManifest = $this->cache->get($moduleId);
                
                if ($cachedManifest !== null) {
                    // Use cached manifest
                    $manifest = $cachedManifest;
                    
                    // Log warnings from original parse if any
                    if (!empty($parseResult->warnings)) {
                        foreach ($parseResult->warnings as $warning) {
                            $this->logger->warning($warning, $manifest->id);
                        }
                    }
                } else {
                    // Cache miss, use parsed manifest and cache it
                    $manifest = $parseResult->manifest;
                    $this->cache->put($moduleId, $manifest);
                }
            } else {
                // Parse failed
                $this->registerInvalidModule($modulePath, $parseResult->error);
                $this->logger->error("Module parse error at {$modulePath}: {$parseResult->error}");
                return null;
            }
        } else {
            // No cache, parse directly
            $parseResult = $this->parser->parse($manifestPath);
            
            // Handle parse failure
            if (!$parseResult->success) {
                $this->registerInvalidModule($modulePath, $parseResult->error);
                $this->logger->error("Module parse error at {$modulePath}: {$parseResult->error}");
                return null;
            }
            
            $manifest = $parseResult->manifest;
            
            // Log warnings if any
            if (!empty($parseResult->warnings)) {
                foreach ($parseResult->warnings as $warning) {
                    $this->logger->warning($warning, $manifest->id);
                }
            }
        }
        
        // Resolve dependencies
        $resolutionResult = $this->dependencyResolver->resolve($manifest);
        
        // Check if core version is compatible
        if (!$resolutionResult->coreVersionSatisfied) {
            $error = "Incompatible core version. Required: {$manifest->dependencies->core}";
            $this->registerInvalidModule($modulePath, $error, $manifest->id);
            $this->logger->error($error, $manifest->id, 'Version Mismatch');
            return null;
        }
        
        // Log warnings for missing optional dependencies (already logged by DependencyResolver)
        // No need to duplicate logging here
        
        // Check context compatibility
        if (!$this->contextResolver->supportsContext($manifest, $currentContext)) {
            // Module doesn't support current context - skip silently
            return null;
        }
        
        // Check tenant enablement (placeholder - always enabled for now)
        if (!$this->isEnabledForCurrentTenant($manifest->id)) {
            // Module not enabled for current tenant - skip silently
            return null;
        }
        
        // Create module instance
        $module = new Module($manifest, $resolutionResult);
        
        // Register module
        try {
            $this->registry->register($module);
        } catch (Exceptions\DuplicateModuleException $e) {
            $error = "Duplicate module ID: {$manifest->id}";
            $this->registerInvalidModule($modulePath, $error, $manifest->id);
            // Conflict error already logged by ModuleRegistry
            return null;
        }
        
        return $module;
    }
    
    /**
     * Register an invalid module
     * 
     * @param string $path
     * @param string $error
     * @param string|null $moduleId
     * @return void
     */
    protected function registerInvalidModule(string $path, string $error, ?string $moduleId = null): void
    {
        $invalidModule = new InvalidModule($path, $error, $moduleId);
        $this->invalidModules->push($invalidModule);
        $this->registry->registerInvalid($invalidModule);
    }
    
    /**
     * Check if module is enabled for current tenant
     * 
     * Placeholder implementation - always returns true.
     * Will be implemented in later tasks with proper tenant management.
     * 
     * @param string $moduleId
     * @return bool
     */
    protected function isEnabledForCurrentTenant(string $moduleId): bool
    {
        // Placeholder: always enabled
        // In production, this would check tenant-specific module enablement
        return true;
    }
}
