<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\SchemaValidatorContract;

/**
 * Schema Validator
 * 
 * Validates manifest data against the defined schema.
 */
class SchemaValidator implements SchemaValidatorContract
{
    /**
     * Schema definition with all field rules
     * 
     * @var array
     */
    private array $schema;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    private Logger $logger;
    
    /**
     * Create a new schema validator instance
     * 
     * @param Logger|null $logger
     */
    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger ?? new Logger();
        $this->schema = [
            'id' => [
                'type' => 'string',
                'required' => true,
                'pattern' => '/^[a-z0-9\-\.]+$/'
            ],
            'name' => [
                'type' => 'string',
                'required' => true
            ],
            'description' => [
                'type' => 'string',
                'required' => true
            ],
            'version' => [
                'type' => 'string',
                'required' => true,
                'pattern' => '/^\d+\.\d+\.\d+$/'
            ],
            'author' => [
                'type' => 'string',
                'required' => true
            ],
            'namespace' => [
                'type' => 'string',
                'required' => true,
                'pattern' => '/^[A-Z][a-zA-Z0-9\\\\]+$/'
            ],
            'contexts' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'supported' => ['type' => 'array', 'items' => 'string'],
                    'primary' => ['type' => 'string'],
                    'priority' => ['type' => 'integer', 'min' => 0, 'max' => 100]
                ]
            ],
            'dependencies' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'core' => ['type' => 'string', 'pattern' => '/^[><=!]+\d+\.\d+\.\d+$/'],
                    'modules' => ['type' => 'array', 'items' => 'object'],
                    'plugins' => ['type' => 'array', 'items' => 'object']
                ]
            ],
            'capabilities' => [
                'type' => 'array',
                'required' => false,
                'items' => 'string'
            ],
            'ui' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'admin_menu' => ['type' => 'boolean'],
                    'menu_title' => ['type' => 'string'],
                    'icon' => ['type' => 'string'],
                    'order' => ['type' => 'integer']
                ]
            ],
            'lifecycle' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'provider' => ['type' => 'string'],
                    'boot' => ['type' => 'boolean']
                ]
            ],
            'recommendations' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'modules' => ['type' => 'array', 'items' => 'string'],
                    'integrations' => ['type' => 'array', 'items' => 'string']
                ]
            ],
            'visibility' => [
                'type' => 'object',
                'required' => false,
                'properties' => [
                    'public' => ['type' => 'boolean', 'default' => true],
                    'marketplace' => ['type' => 'boolean', 'default' => true]
                ]
            ]
        ];
    }
    
    /**
     * Validate manifest data against schema
     * 
     * @param array $data
     * @return ValidationResult
     */
    public function validate(array $data): ValidationResult
    {
        $errors = [];
        $warnings = [];
        
        // Extract module ID for logging context
        $moduleId = $data['id'] ?? null;
        
        // Validate required fields
        foreach ($this->schema as $field => $rules) {
            if (isset($rules['required']) && $rules['required']) {
                if (!isset($data[$field])) {
                    $errors[] = "Missing required field: {$field}";
                }
            }
        }
        
        // Validate field types and patterns
        foreach ($data as $field => $value) {
            if (!isset($this->schema[$field])) {
                // Additional fields are allowed (schema extensibility)
                continue;
            }
            
            $rules = $this->schema[$field];
            
            // Type validation
            $typeError = $this->validateType($field, $value, $rules);
            if ($typeError !== null) {
                $errors[] = $typeError;
                continue; // Skip further validation if type is wrong
            }
            
            // Pattern validation
            if (isset($rules['pattern']) && is_string($value)) {
                if (!preg_match($rules['pattern'], $value)) {
                    $errors[] = $this->getPatternErrorMessage($field, $rules['pattern']);
                }
            }
            
            // Nested object validation
            if ($rules['type'] === 'object' && isset($rules['properties'])) {
                $nestedErrors = $this->validateObject($field, $value, $rules['properties']);
                $errors = array_merge($errors, $nestedErrors);
            }
            
            // Array validation
            if ($rules['type'] === 'array' && isset($rules['items'])) {
                $arrayErrors = $this->validateArray($field, $value, $rules['items']);
                $errors = array_merge($errors, $arrayErrors);
            }
        }
        
        $valid = empty($errors);
        
        // Log validation errors
        if (!$valid) {
            $this->logger->validationError($errors, $moduleId);
        }
        
        return new ValidationResult($valid, $errors, $warnings);
    }
    
    /**
     * Validate field type
     * 
     * @param string $field
     * @param mixed $value
     * @param array $rules
     * @return string|null Error message or null if valid
     */
    private function validateType(string $field, $value, array $rules): ?string
    {
        $expectedType = $rules['type'];
        
        switch ($expectedType) {
            case 'string':
                if (!is_string($value)) {
                    return "Field '{$field}' must be a string, " . gettype($value) . " given";
                }
                break;
                
            case 'integer':
                if (!is_int($value)) {
                    return "Field '{$field}' must be an integer, " . gettype($value) . " given";
                }
                
                // Check min/max constraints
                if (isset($rules['min']) && $value < $rules['min']) {
                    return "Field '{$field}' must be at least {$rules['min']}";
                }
                if (isset($rules['max']) && $value > $rules['max']) {
                    return "Field '{$field}' must be at most {$rules['max']}";
                }
                break;
                
            case 'boolean':
                if (!is_bool($value)) {
                    return "Field '{$field}' must be a boolean, " . gettype($value) . " given";
                }
                break;
                
            case 'array':
                if (!is_array($value)) {
                    return "Field '{$field}' must be an array, " . gettype($value) . " given";
                }
                break;
                
            case 'object':
                if (!is_array($value)) {
                    return "Field '{$field}' must be an object, " . gettype($value) . " given";
                }
                break;
        }
        
        return null;
    }
    
    /**
     * Validate nested object properties
     * 
     * @param string $parentField
     * @param array $value
     * @param array $properties
     * @return array Array of error messages
     */
    private function validateObject(string $parentField, array $value, array $properties): array
    {
        $errors = [];
        
        foreach ($value as $key => $val) {
            if (!isset($properties[$key])) {
                // Additional properties are allowed
                continue;
            }
            
            $rules = $properties[$key];
            $fieldPath = "{$parentField}.{$key}";
            
            // Type validation
            $typeError = $this->validateType($fieldPath, $val, $rules);
            if ($typeError !== null) {
                $errors[] = $typeError;
                continue;
            }
            
            // Pattern validation
            if (isset($rules['pattern']) && is_string($val)) {
                if (!preg_match($rules['pattern'], $val)) {
                    $errors[] = $this->getPatternErrorMessage($fieldPath, $rules['pattern']);
                }
            }
            
            // Nested array validation
            if ($rules['type'] === 'array' && isset($rules['items'])) {
                $arrayErrors = $this->validateArray($fieldPath, $val, $rules['items']);
                $errors = array_merge($errors, $arrayErrors);
            }
        }
        
        return $errors;
    }
    
    /**
     * Validate array items
     * 
     * @param string $field
     * @param array $value
     * @param string $itemType
     * @return array Array of error messages
     */
    private function validateArray(string $field, array $value, string $itemType): array
    {
        $errors = [];
        
        foreach ($value as $index => $item) {
            $itemPath = "{$field}[{$index}]";
            
            switch ($itemType) {
                case 'string':
                    if (!is_string($item)) {
                        $errors[] = "Array item '{$itemPath}' must be a string, " . gettype($item) . " given";
                    }
                    break;
                    
                case 'object':
                    if (!is_array($item)) {
                        $errors[] = "Array item '{$itemPath}' must be an object, " . gettype($item) . " given";
                    }
                    break;
            }
        }
        
        return $errors;
    }
    
    /**
     * Get human-readable error message for pattern validation
     * 
     * @param string $field
     * @param string $pattern
     * @return string
     */
    private function getPatternErrorMessage(string $field, string $pattern): string
    {
        // Provide specific error messages for known patterns
        if ($pattern === '/^[a-z0-9\-\.]+$/') {
            return "Field '{$field}' must contain only lowercase letters, numbers, hyphens, and dots";
        }
        
        if ($pattern === '/^\d+\.\d+\.\d+$/') {
            return "Field '{$field}' must follow semantic versioning format (MAJOR.MINOR.PATCH)";
        }
        
        if ($pattern === '/^[A-Z][a-zA-Z0-9\\\\]+$/') {
            return "Field '{$field}' must follow PSR-4 namespace pattern (start with uppercase letter, contain only alphanumeric characters and backslashes)";
        }
        
        if ($pattern === '/^[><=!]+\d+\.\d+\.\d+$/') {
            return "Field '{$field}' must be a valid version constraint (e.g., >=1.0.0, <2.0.0)";
        }
        
        return "Field '{$field}' does not match the required pattern: {$pattern}";
    }
    
    /**
     * Get schema definition
     * 
     * @return array
     */
    public function getSchema(): array
    {
        return $this->schema;
    }
}
