<?php

namespace Viraloka\Core\Modules;

/**
 * Context Configuration
 * 
 * Value object for context-related manifest configuration.
 */
class ContextConfig
{
    public array $supported;
    public ?string $primary;
    public int $priority;
    
    /**
     * Create a new context config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->supported = $data['supported'] ?? [];
        $this->primary = $data['primary'] ?? null;
        $this->priority = $data['priority'] ?? 50;
    }
}
