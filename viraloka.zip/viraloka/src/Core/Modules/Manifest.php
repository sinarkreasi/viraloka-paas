<?php

namespace Viraloka\Core\Modules;

/**
 * Manifest
 * 
 * The core data structure representing a parsed and validated module manifest.
 */
class Manifest
{
    public string $id;
    public string $name;
    public string $description;
    public string $version;
    public string $author;
    public string $namespace;
    public ?ContextConfig $contexts;
    public ?DependencyConfig $dependencies;
    public array $capabilities;
    public ?UIConfig $ui;
    public ?LifecycleConfig $lifecycle;
    public ?RecommendationConfig $recommendations;
    public VisibilityConfig $visibility;
    
    private string $path;
    
    /**
     * Create a new manifest instance
     * 
     * @param array $data
     * @param string $path
     */
    public function __construct(array $data, string $path)
    {
        $this->id = $data['id'];
        $this->name = $data['name'];
        $this->description = $data['description'];
        $this->version = $data['version'];
        $this->author = $data['author'];
        $this->namespace = $data['namespace'];
        $this->path = $path;
        
        $this->contexts = isset($data['contexts']) ? new ContextConfig($data['contexts']) : null;
        $this->dependencies = isset($data['dependencies']) ? new DependencyConfig($data['dependencies']) : null;
        $this->capabilities = $data['capabilities'] ?? [];
        $this->ui = isset($data['ui']) ? new UIConfig($data['ui']) : null;
        $this->lifecycle = isset($data['lifecycle']) ? new LifecycleConfig($data['lifecycle']) : null;
        $this->recommendations = isset($data['recommendations']) ? new RecommendationConfig($data['recommendations']) : null;
        $this->visibility = isset($data['visibility']) ? new VisibilityConfig($data['visibility']) : new VisibilityConfig([]);
    }
    
    /**
     * Get the module's directory path
     * 
     * @return string
     */
    public function getPath(): string
    {
        return $this->path;
    }
    
    /**
     * Check if module supports a context
     * 
     * @param string $context
     * @return bool
     */
    public function supportsContext(string $context): bool
    {
        if ($this->contexts === null) {
            return true; // Context-agnostic
        }
        
        return in_array($context, $this->contexts->supported);
    }
    
    /**
     * Get the service provider class name
     * 
     * @return string
     */
    public function getProviderClass(): string
    {
        return $this->lifecycle?->provider ?? '';
    }
}
