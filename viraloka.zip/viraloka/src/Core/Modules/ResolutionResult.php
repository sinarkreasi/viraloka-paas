<?php

namespace Viraloka\Core\Modules;

/**
 * Resolution Result
 * 
 * Result object from dependency resolution.
 */
class ResolutionResult
{
    public bool $coreVersionSatisfied;
    public array $availableModules;
    public array $missingModules;
    public array $availablePlugins;
    public array $missingPlugins;
    
    /**
     * Create a new resolution result instance
     * 
     * @param bool $coreVersionSatisfied
     * @param array $availableModules
     * @param array $missingModules
     * @param array $availablePlugins
     * @param array $missingPlugins
     */
    public function __construct(
        bool $coreVersionSatisfied,
        array $availableModules = [],
        array $missingModules = [],
        array $availablePlugins = [],
        array $missingPlugins = []
    ) {
        $this->coreVersionSatisfied = $coreVersionSatisfied;
        $this->availableModules = $availableModules;
        $this->missingModules = $missingModules;
        $this->availablePlugins = $availablePlugins;
        $this->missingPlugins = $missingPlugins;
    }
    
    /**
     * Check if all dependencies are satisfied
     * 
     * @return bool
     */
    public function allDependenciesSatisfied(): bool
    {
        return $this->coreVersionSatisfied 
            && empty($this->missingModules) 
            && empty($this->missingPlugins);
    }
    
    /**
     * Get all missing dependencies
     * 
     * @return array
     */
    public function getMissingDependencies(): array
    {
        return array_merge($this->missingModules, $this->missingPlugins);
    }
}
