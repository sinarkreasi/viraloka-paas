<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Providers\ServiceProvider;

/**
 * Module
 * 
 * Represents a loaded module with its manifest and runtime state.
 */
class Module
{
    public Manifest $manifest;
    public bool $isBootstrapped = false;
    public ?ServiceProvider $provider = null;
    public ResolutionResult $dependencies;
    
    /**
     * Create a new module instance
     * 
     * @param Manifest $manifest
     * @param ResolutionResult $dependencies
     */
    public function __construct(Manifest $manifest, ResolutionResult $dependencies)
    {
        $this->manifest = $manifest;
        $this->dependencies = $dependencies;
    }
    
    /**
     * Get module ID
     * 
     * @return string
     */
    public function getId(): string
    {
        return $this->manifest->id;
    }
    
    /**
     * Check if module is enabled for tenant
     * 
     * @param string $tenantId
     * @return bool
     */
    public function isEnabledForTenant(string $tenantId): bool
    {
        // To be implemented in later tasks
        return true;
    }
    
    /**
     * Get module capabilities
     * 
     * @return array
     */
    public function getCapabilities(): array
    {
        return $this->manifest->capabilities;
    }
}
