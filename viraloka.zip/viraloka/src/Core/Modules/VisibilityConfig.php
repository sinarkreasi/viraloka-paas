<?php

namespace Viraloka\Core\Modules;

/**
 * Visibility Configuration
 * 
 * Value object for visibility-related manifest configuration.
 */
class VisibilityConfig
{
    public bool $public;
    public bool $marketplace;
    
    /**
     * Create a new visibility config instance
     * 
     * @param array $data
     */
    public function __construct(array $data)
    {
        $this->public = $data['public'] ?? true;
        $this->marketplace = $data['marketplace'] ?? true;
    }
}
