<?php

namespace Viraloka\Core\Modules;

/**
 * Parse Result
 * 
 * Result object from manifest parsing operation.
 */
class ParseResult
{
    public bool $success;
    public ?Manifest $manifest;
    public ?string $error;
    public array $warnings;
    
    /**
     * Create a new parse result instance
     * 
     * @param bool $success
     * @param Manifest|null $manifest
     * @param string|null $error
     * @param array $warnings
     */
    private function __construct(bool $success, ?Manifest $manifest, ?string $error, array $warnings)
    {
        $this->success = $success;
        $this->manifest = $manifest;
        $this->error = $error;
        $this->warnings = $warnings;
    }
    
    /**
     * Create a successful parse result
     * 
     * @param Manifest $manifest
     * @param array $warnings
     * @return self
     */
    public static function success(Manifest $manifest, array $warnings = []): self
    {
        return new self(true, $manifest, null, $warnings);
    }
    
    /**
     * Create a failed parse result
     * 
     * @param string $error
     * @return self
     */
    public static function failure(string $error): self
    {
        return new self(false, null, $error, []);
    }
}
