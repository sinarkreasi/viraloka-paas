<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Modules\Contracts\DependencyResolverContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Composer\Semver\Semver;

/**
 * Dependency Resolver
 * 
 * Checks module dependencies and determines if they are satisfied.
 * Uses Composer's semantic version comparison for core version checking.
 * Queries ModuleRegistry for module availability.
 * Uses WordPress is_plugin_active() for plugin checks.
 * All dependencies are soft - missing dependencies don't block loading.
 */
class DependencyResolver implements DependencyResolverContract
{
    /**
     * Core version constant
     */
    private const CORE_VERSION = '1.0.0';
    
    /**
     * Module registry instance
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $registry;
    
    /**
     * Logger instance
     * 
     * @var Logger
     */
    protected Logger $logger;
    
    /**
     * Create a new dependency resolver instance
     * 
     * @param ModuleRegistryContract $registry
     * @param Logger|null $logger
     */
    public function __construct(ModuleRegistryContract $registry, ?Logger $logger = null)
    {
        $this->registry = $registry;
        $this->logger = $logger ?? new Logger();
    }
    
    /**
     * Resolve dependencies for a manifest
     * 
     * Checks all dependencies (core version, modules, plugins) and returns
     * a ResolutionResult with availability status for each.
     * 
     * @param Manifest $manifest
     * @return ResolutionResult
     */
    public function resolve(Manifest $manifest): ResolutionResult
    {
        $coreVersionSatisfied = true;
        $availableModules = [];
        $missingModules = [];
        $availablePlugins = [];
        $missingPlugins = [];
        
        $moduleId = $manifest->id;
        
        // Check core version requirement
        if ($manifest->dependencies !== null && $manifest->dependencies->core !== null) {
            $coreVersionSatisfied = $this->checkCoreVersion($manifest->dependencies->core);
            
            // Log warning if core version is incompatible
            if (!$coreVersionSatisfied) {
                $this->logger->warning(
                    "Incompatible core version. Required: {$manifest->dependencies->core}, Current: " . self::CORE_VERSION,
                    $moduleId
                );
            }
        }
        
        // Check module dependencies
        if ($manifest->dependencies !== null && !empty($manifest->dependencies->modules)) {
            foreach ($manifest->dependencies->modules as $moduleDep) {
                $depModuleId = is_array($moduleDep) ? ($moduleDep['id'] ?? '') : $moduleDep;
                
                if ($this->checkModule($depModuleId)) {
                    $availableModules[] = $depModuleId;
                } else {
                    $missingModules[] = $depModuleId;
                }
            }
            
            // Optional dependency warnings disabled for production (only log errors)
            // if (!empty($missingModules)) {
            //     $this->logger->dependencyWarning($moduleId, $missingModules, 'module');
            // }
        }
        
        // Check plugin dependencies
        if ($manifest->dependencies !== null && !empty($manifest->dependencies->plugins)) {
            foreach ($manifest->dependencies->plugins as $pluginDep) {
                $pluginSlug = is_array($pluginDep) ? ($pluginDep['slug'] ?? '') : $pluginDep;
                
                if ($this->checkPlugin($pluginSlug)) {
                    $availablePlugins[] = $pluginSlug;
                } else {
                    $missingPlugins[] = $pluginSlug;
                }
            }
            
            // Optional dependency warnings disabled for production (only log errors)
            // if (!empty($missingPlugins)) {
            //     $this->logger->dependencyWarning($moduleId, $missingPlugins, 'plugin');
            // }
        }
        
        return new ResolutionResult(
            $coreVersionSatisfied,
            $availableModules,
            $missingModules,
            $availablePlugins,
            $missingPlugins
        );
    }
    
    /**
     * Check if core version satisfies requirement
     * 
     * Uses Composer's semantic version comparison to validate
     * the current Core version satisfies the constraint.
     * 
     * @param string $requirement Version constraint (e.g., ">=1.0.0", "<2.0.0")
     * @return bool
     */
    public function checkCoreVersion(string $requirement): bool
    {
        try {
            return Semver::satisfies(self::CORE_VERSION, $requirement);
        } catch (\Exception $e) {
            // Invalid version constraint format
            return false;
        }
    }
    
    /**
     * Check if module is available
     * 
     * Queries ModuleRegistry to determine if the module is registered.
     * 
     * @param string $moduleId
     * @return bool
     */
    public function checkModule(string $moduleId): bool
    {
        return $this->registry->has($moduleId);
    }
    
    /**
     * Check if WordPress plugin is active
     * 
     * Uses WordPress is_plugin_active() function to check plugin status.
     * Returns false if WordPress function is not available.
     * 
     * @param string $pluginSlug Plugin slug (e.g., "woocommerce/woocommerce.php")
     * @return bool
     */
    public function checkPlugin(string $pluginSlug): bool
    {
        if (!function_exists('is_plugin_active')) {
            // WordPress function not available (e.g., in tests)
            return false;
        }
        
        return is_plugin_active($pluginSlug);
    }
}
