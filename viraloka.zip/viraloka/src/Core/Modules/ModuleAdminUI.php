<?php

namespace Viraloka\Core\Modules;

use Viraloka\Core\Context\Contracts\ContextResolverContract;
use Viraloka\Core\Modules\Contracts\ModuleAdminUIContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Viraloka\Core\Modules\Contracts\ModuleRecommenderContract;

/**
 * Module Admin UI
 * 
 * Renders module management interface in WordPress admin.
 * 
 * Features:
 * - Display list of active modules with visibility filtering
 * - Display list of invalid modules with error details
 * - Show installation status for recommended modules
 * - Respect visibility settings when rendering lists
 */
class ModuleAdminUI implements ModuleAdminUIContract
{
    /**
     * Module registry for accessing modules
     * 
     * @var ModuleRegistryContract
     */
    protected ModuleRegistryContract $moduleRegistry;
    
    /**
     * Module recommender for recommendations
     * 
     * @var ModuleRecommenderContract
     */
    protected ModuleRecommenderContract $moduleRecommender;
    
    /**
     * Context resolver for current context
     * 
     * @var ContextResolverContract
     */
    protected ContextResolverContract $contextResolver;
    
    /**
     * Create a new module admin UI instance
     * 
     * @param ModuleRegistryContract $moduleRegistry
     * @param ModuleRecommenderContract $moduleRecommender
     * @param ContextResolverContract $contextResolver
     */
    public function __construct(
        ModuleRegistryContract $moduleRegistry,
        ModuleRecommenderContract $moduleRecommender,
        ContextResolverContract $contextResolver
    ) {
        $this->moduleRegistry = $moduleRegistry;
        $this->moduleRecommender = $moduleRecommender;
        $this->contextResolver = $contextResolver;
    }
    
    /**
     * Render the module management page
     * 
     * Main entry point for the admin UI.
     * 
     * @return void
     */
    public function render(): void
    {
        $currentContext = $this->contextResolver->getCurrentContext();
        
        echo '<div class="wrap">';
        echo '<h1>Viraloka Modules</h1>';
        
        // Render active modules section
        echo '<h2>Active Modules</h2>';
        $this->renderActiveModules();
        
        // Render invalid modules section if any exist
        $invalidModules = $this->moduleRegistry->getInvalidModules();
        if ($invalidModules->isNotEmpty()) {
            echo '<h2>Invalid Modules</h2>';
            $this->renderInvalidModules();
        }
        
        // Render recommended modules section
        echo '<h2>Recommended Modules</h2>';
        $this->renderRecommendedModules($currentContext);
        
        echo '</div>';
    }
    
    /**
     * Render active modules list
     * 
     * Displays all active modules, respecting visibility settings.
     * Only shows modules with public visibility set to true.
     * 
     * @return void
     */
    public function renderActiveModules(): void
    {
        $modules = $this->moduleRegistry->all();
        
        // Filter modules by public visibility
        $publicModules = $modules->filter(function (Module $module) {
            return $module->manifest->visibility->public;
        });
        
        if ($publicModules->isEmpty()) {
            echo '<p>No active modules found.</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Name</th>';
        echo '<th>ID</th>';
        echo '<th>Version</th>';
        echo '<th>Author</th>';
        echo '<th>Description</th>';
        echo '<th>Status</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($publicModules as $module) {
            $manifest = $module->manifest;
            $bootstrapStatus = $module->isBootstrapped ? 'Bootstrapped' : 'Loaded';
            
            echo '<tr>';
            echo '<td><strong>' . esc_html($manifest->name) . '</strong></td>';
            echo '<td>' . esc_html($manifest->id) . '</td>';
            echo '<td>' . esc_html($manifest->version) . '</td>';
            echo '<td>' . esc_html($manifest->author) . '</td>';
            echo '<td>' . esc_html($manifest->description) . '</td>';
            echo '<td><span class="dashicons dashicons-yes-alt" style="color: green;"></span> ' . esc_html($bootstrapStatus) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
    }
    
    /**
     * Render invalid modules list
     * 
     * Displays all invalid modules with actionable error details.
     * Shows module ID (if available), path, and specific error message.
     * 
     * @return void
     */
    public function renderInvalidModules(): void
    {
        $invalidModules = $this->moduleRegistry->getInvalidModules();
        
        if ($invalidModules->isEmpty()) {
            echo '<p>No invalid modules found.</p>';
            return;
        }
        
        echo '<div class="notice notice-error">';
        echo '<p><strong>The following modules failed validation and were not loaded:</strong></p>';
        echo '</div>';
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Module ID</th>';
        echo '<th>Path</th>';
        echo '<th>Error</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($invalidModules as $invalidModule) {
            $moduleId = $invalidModule->moduleId ?? '<em>Unknown</em>';
            
            echo '<tr>';
            echo '<td>' . esc_html($moduleId) . '</td>';
            echo '<td><code>' . esc_html($invalidModule->path) . '</code></td>';
            echo '<td><span class="dashicons dashicons-warning" style="color: #d63638;"></span> ' . esc_html($invalidModule->error) . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
    }
    
    /**
     * Render recommended modules list
     * 
     * Displays recommended modules for the current context.
     * Shows installation status for each recommended module.
     * 
     * @param string $context
     * @return void
     */
    public function renderRecommendedModules(string $context): void
    {
        $recommendations = $this->moduleRecommender->getRecommendationsForContext($context);
        
        if ($recommendations->isEmpty()) {
            echo '<p>No module recommendations available for the current context.</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Recommended Module</th>';
        echo '<th>Recommended By</th>';
        echo '<th>Installation Status</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($recommendations as $recommendation) {
            $moduleId = $recommendation['recommended_module_id'];
            $sourceName = $recommendation['source_module_name'];
            $installed = $recommendation['installed'];
            
            $statusIcon = $installed 
                ? '<span class="dashicons dashicons-yes-alt" style="color: green;"></span> Installed'
                : '<span class="dashicons dashicons-download" style="color: #2271b1;"></span> Not Installed';
            
            echo '<tr>';
            echo '<td><strong>' . esc_html($moduleId) . '</strong></td>';
            echo '<td>' . esc_html($sourceName) . '</td>';
            echo '<td>' . $statusIcon . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
    }
}
