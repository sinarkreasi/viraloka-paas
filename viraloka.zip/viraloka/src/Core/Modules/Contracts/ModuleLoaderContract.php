<?php

namespace Viraloka\Core\Modules\Contracts;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Module;
use Viraloka\Core\Modules\InvalidModule;

/**
 * Module Loader Contract
 * 
 * Orchestrates the module discovery and loading process.
 */
interface ModuleLoaderContract
{
    /**
     * Discover and load all valid modules
     * 
     * @return Collection<Module>
     */
    public function loadModules(): Collection;
    
    /**
     * Load a specific module by ID
     * 
     * @param string $moduleId
     * @return Module|null
     */
    public function loadModule(string $moduleId): ?Module;
    
    /**
     * Get all invalid modules with error details
     * 
     * @return Collection<InvalidModule>
     */
    public function getInvalidModules(): Collection;
}
