<?php

namespace Viraloka\Core\Modules\Contracts;

use Illuminate\Support\Collection;

/**
 * Distribution Manager Contract
 * 
 * Manages module distribution and marketplace visibility.
 */
interface DistributionManagerContract
{
    /**
     * Get modules available for marketplace distribution
     * 
     * Filters modules based on visibility.marketplace setting.
     * 
     * @return Collection
     */
    public function getMarketplaceModules(): Collection;
}
