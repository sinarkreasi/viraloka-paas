<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\Module;

/**
 * Admin Menu Builder Contract
 * 
 * Interface for building WordPress admin menus from module UI hints.
 */
interface AdminMenuBuilderContract
{
    /**
     * Build admin menu for a module
     * 
     * @param Module $module
     * @return void
     */
    public function buildMenu(Module $module): void;
    
    /**
     * Build admin menus for multiple modules
     * 
     * @param array $modules
     * @return void
     */
    public function buildMenus(array $modules): void;
}
