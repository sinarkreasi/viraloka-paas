<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\Manifest;

/**
 * Capability Registry Contract
 * 
 * Manages module-declared capabilities for permission system.
 */
interface CapabilityRegistryContract
{
    /**
     * Register capabilities from manifest
     * 
     * @param Manifest $manifest
     * @return void
     */
    public function registerCapabilities(Manifest $manifest): void;
    
    /**
     * Get all capabilities for a module
     * 
     * @param string $moduleId
     * @return array
     */
    public function getModuleCapabilities(string $moduleId): array;
    
    /**
     * Remove capabilities when module is disabled
     * 
     * @param string $moduleId
     * @return void
     */
    public function unregisterCapabilities(string $moduleId): void;
}
