<?php

namespace Viraloka\Core\Modules\Contracts;

use Viraloka\Core\Modules\ParseResult;
use Viraloka\Core\Modules\ValidationResult;

/**
 * Manifest Parser Contract
 * 
 * Parses and validates module.json files into Manifest objects.
 */
interface ManifestParserContract
{
    /**
     * Parse a manifest file
     * 
     * @param string $filePath
     * @return ParseResult
     */
    public function parse(string $filePath): ParseResult;
    
    /**
     * Validate manifest structure
     * 
     * @param array $data
     * @return ValidationResult
     */
    public function validate(array $data): ValidationResult;
}
