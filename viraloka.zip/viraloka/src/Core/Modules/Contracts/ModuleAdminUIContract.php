<?php

namespace Viraloka\Core\Modules\Contracts;

/**
 * Module Admin UI Contract
 * 
 * Interface for rendering module management UI in WordPress admin.
 */
interface ModuleAdminUIContract
{
    /**
     * Render the module management page
     * 
     * @return void
     */
    public function render(): void;
    
    /**
     * Render active modules list
     * 
     * @return void
     */
    public function renderActiveModules(): void;
    
    /**
     * Render invalid modules list
     * 
     * @return void
     */
    public function renderInvalidModules(): void;
    
    /**
     * Render recommended modules list
     * 
     * @param string $context
     * @return void
     */
    public function renderRecommendedModules(string $context): void;
}
