<?php

namespace Viraloka\Core\Modules\Contracts;

use Illuminate\Support\Collection;
use Viraloka\Core\Modules\Module;

/**
 * Module Recommender Contract
 * 
 * Manages module recommendations and provides context-aware ranking.
 */
interface ModuleRecommenderContract
{
    /**
     * Store recommendations from a module's manifest
     * 
     * @param Module $module
     * @return void
     */
    public function storeRecommendations(Module $module): void;
    
    /**
     * Get recommended modules for a given context
     * 
     * Returns modules ranked by context relevance and priority.
     * 
     * @param string $context
     * @return Collection<array> Array of recommendations with module info and metadata
     */
    public function getRecommendationsForContext(string $context): Collection;
    
    /**
     * Get all recommendations from a specific module
     * 
     * @param string $moduleId
     * @return array
     */
    public function getModuleRecommendations(string $moduleId): array;
    
    /**
     * Check if a recommended module is installed
     * 
     * @param string $moduleId
     * @return bool
     */
    public function isModuleInstalled(string $moduleId): bool;
    
    /**
     * Get recommendations for physical marketplace use-case
     * 
     * @return array
     */
    public function getPhysicalMarketplaceRecommendations(): array;
    
    /**
     * Get all out-of-scope recommendations
     * 
     * @return array
     */
    public function getOutOfScopeRecommendations(): array;
}
