<?php

namespace Viraloka\Core\Adapter\Exceptions;

/**
 * Exception thrown when runtime adapter operations fail.
 */
class RuntimeAdapterException extends AdapterException
{
}
