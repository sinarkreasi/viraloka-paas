<?php

namespace Viraloka\Core\Adapter\Exceptions;

/**
 * Exception thrown when response adapter operations fail.
 */
class ResponseAdapterException extends AdapterException
{
}
