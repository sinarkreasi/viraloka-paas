<?php

namespace Viraloka\Core\Subscription\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Subscription Engine Contract
 * 
 * Defines the interface for subscription management and tier-based entitlements.
 * The SubscriptionEngine manages subscription status, tier limits, and entitlements
 * within workspace boundaries.
 */
interface SubscriptionEngineContract
{
    /**
     * Get subscription tier for a user in a workspace
     * 
     * Returns the subscription tier identifier (e.g., 'free', 'pro', 'enterprise').
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return string Subscription tier identifier
     */
    public function getTier(string $userId, Workspace $workspace): string;
    
    /**
     * Check if a subscription tier has a specific entitlement
     * 
     * Verifies that a subscription tier includes the requested entitlement.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $entitlement Entitlement identifier
     * @return bool True if tier has the entitlement, false otherwise
     */
    public function hasEntitlement(string $tier, string $entitlement): bool;
    
    /**
     * Check if a limit is within the subscription tier's allowance
     * 
     * Verifies that a requested amount is within the tier's limit for a specific resource.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $limitType Limit type (e.g., 'api_calls', 'storage', 'users')
     * @param int $amount Amount to check
     * @return bool True if within limit, false if exceeds limit
     */
    public function checkLimit(string $tier, string $limitType, int $amount): bool;
    
    /**
     * Check if a subscription is active
     * 
     * Verifies that the subscription is in an active state (not expired or cancelled).
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return bool True if subscription is active, false otherwise
     */
    public function isActive(string $userId, Workspace $workspace): bool;
    
    /**
     * Get subscription status
     * 
     * Returns the current subscription status (active, expired, cancelled, trial).
     * 
     * @param string $userId User ID
     * @param Workspace $workspace Workspace context
     * @return string Subscription status
     */
    public function getStatus(string $userId, Workspace $workspace): string;
    
    /**
     * Get limit value for a subscription tier
     * 
     * Returns the numeric limit for a specific resource type in a tier.
     * Returns -1 for unlimited.
     * 
     * @param string $tier Subscription tier identifier
     * @param string $limitType Limit type (e.g., 'api_calls', 'storage', 'users')
     * @return int Limit value, or -1 for unlimited
     */
    public function getLimit(string $tier, string $limitType): int;
}
