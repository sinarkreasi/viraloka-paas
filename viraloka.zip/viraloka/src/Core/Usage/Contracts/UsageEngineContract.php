<?php

namespace Viraloka\Core\Usage\Contracts;

use Viraloka\Core\Workspace\Workspace;

/**
 * Usage Engine Contract
 * 
 * Defines the interface for credit-based usage metering and enforcement.
 * The UsageEngine records usage against workspaces, enforces limits based on
 * subscription tiers, and tracks usage history.
 */
interface UsageEngineContract
{
    /**
     * Record usage for a user in a workspace
     * 
     * Records a usage event and deducts from available quota.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param int $amount Amount of usage to record
     * @param Workspace $workspace Workspace context
     * @param array $metadata Optional metadata about the usage event
     * @return bool True on success, false on failure
     */
    public function recordUsage(string $userId, string $resourceType, int $amount, Workspace $workspace, array $metadata = []): bool;
    
    /**
     * Check if usage is within limit
     * 
     * Verifies that recording the specified amount would not exceed the subscription tier's limit.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param int $amount Amount to check
     * @param Workspace $workspace Workspace context
     * @return bool True if within limit, false if would exceed limit
     */
    public function checkLimit(string $userId, string $resourceType, int $amount, Workspace $workspace): bool;
    
    /**
     * Get current usage for a user in a workspace
     * 
     * Returns the current usage amount for a specific resource type.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return int Current usage amount
     */
    public function getUsage(string $userId, string $resourceType, Workspace $workspace): int;
    
    /**
     * Get usage history for a user in a workspace
     * 
     * Returns historical usage records for a specific resource type.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @param int $limit Maximum number of records to return
     * @return array Array of usage records
     */
    public function getUsageHistory(string $userId, string $resourceType, Workspace $workspace, int $limit = 100): array;
    
    /**
     * Reset usage for a user in a workspace
     * 
     * Resets usage counters for a specific resource type (typically used for monthly resets).
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return bool True on success, false on failure
     */
    public function resetUsage(string $userId, string $resourceType, Workspace $workspace): bool;
    
    /**
     * Get remaining quota for a user in a workspace
     * 
     * Returns the remaining quota available for a specific resource type.
     * Returns -1 for unlimited.
     * 
     * @param string $userId User ID
     * @param string $resourceType Resource type (e.g., 'api_calls', 'storage', 'compute_time')
     * @param Workspace $workspace Workspace context
     * @return int Remaining quota, or -1 for unlimited
     */
    public function getRemainingQuota(string $userId, string $resourceType, Workspace $workspace): int;
}
