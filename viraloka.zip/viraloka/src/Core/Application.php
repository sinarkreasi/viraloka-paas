<?php

namespace Viraloka\Core;

use Viraloka\Core\Modules\ModuleLoader;
use Viraloka\Core\Modules\ManifestParser;
use Viraloka\Core\Modules\SchemaValidator;
use Viraloka\Core\Modules\DependencyResolver;
use Viraloka\Core\Modules\ModuleRegistry;
use Viraloka\Core\Modules\ModuleBootstrapper;
use Viraloka\Core\Modules\ManifestCache;
use Viraloka\Core\Modules\Logger;
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Modules\Contracts\ModuleLoaderContract;
use Viraloka\Core\Modules\Contracts\ModuleRegistryContract;
use Viraloka\Core\Modules\Contracts\ModuleBootstrapperContract;
use Illuminate\Support\Collection;

/**
 * Application
 * 
 * Core application container and bootstrap coordinator.
 * Manages the module lifecycle: discovery, loading, and bootstrapping.
 */
class Application
{
    /**
     * The application's service container
     * 
     * @var array
     */
    protected array $bindings = [];
    
    /**
     * The application's singleton instances
     * 
     * @var array
     */
    protected array $instances = [];
    
    /**
     * Services marked for lazy loading
     * 
     * @var array
     */
    protected array $lazyServices = [];
    
    /**
     * Indicates if the application has been bootstrapped
     * 
     * @var bool
     */
    protected bool $bootstrapped = false;
    
    /**
     * The base path for the application
     * 
     * @var string
     */
    protected string $basePath;
    
    /**
     * The modules path
     * 
     * @var string
     */
    protected string $modulesPath;
    
    /**
     * Create a new application instance
     * 
     * @param string $basePath
     */
    public function __construct(string $basePath)
    {
        $this->basePath = rtrim($basePath, '/\\');
        $this->modulesPath = $this->basePath . '/viraloka-modules';
        
        // Register the application instance
        $this->instance(self::class, $this);
        $this->instance('app', $this);
    }
    
    /**
     * Bootstrap the application
     * 
     * Delegates to the Kernel class for the complete bootstrap sequence.
     * 
     * @return void
     */
    public function bootstrap(): void
    {
        if ($this->bootstrapped) {
            return;
        }
        
        // Create and bootstrap the Kernel
        $kernel = new \Viraloka\Core\Bootstrap\Kernel($this);
        $kernel->bootstrap();
        
        $this->bootstrapped = true;
    }
    
    /**
     * Register core services in the container
     * 
     * Note: Service registration is now handled by the Kernel class.
     * This method is kept for backward compatibility.
     * 
     * @return void
     * @deprecated Use Kernel for service registration
     */
    protected function registerCoreServices(): void
    {
        // Service registration is now handled by Kernel
        // This method is kept for backward compatibility
    }
    
    /**
     * Bind a service into the container
     * 
     * @param string $abstract
     * @param mixed $concrete
     * @return void
     */
    public function bind(string $abstract, $concrete): void
    {
        $this->bindings[$abstract] = $concrete;
    }
    
    /**
     * Register a singleton binding in the container
     * 
     * @param string $abstract
     * @param mixed $concrete
     * @return void
     */
    public function singleton(string $abstract, $concrete): void
    {
        $this->bind($abstract, function ($app) use ($concrete, $abstract) {
            if (isset($this->instances[$abstract])) {
                return $this->instances[$abstract];
            }
            
            $instance = is_callable($concrete) ? $concrete($app) : $concrete;
            $this->instances[$abstract] = $instance;
            
            return $instance;
        });
    }
    
    /**
     * Mark a service for lazy loading
     * 
     * The service will not be instantiated until first requested via make()
     * 
     * @param string $abstract
     * @param mixed $concrete
     * @return void
     */
    public function lazy(string $abstract, $concrete): void
    {
        $this->lazyServices[$abstract] = true;
        $this->bind($abstract, $concrete);
    }
    
    /**
     * Register an existing instance as a singleton
     * 
     * @param string $abstract
     * @param mixed $instance
     * @return void
     */
    public function instance(string $abstract, $instance): void
    {
        $this->instances[$abstract] = $instance;
    }
    
    /**
     * Resolve a service from the container
     * 
     * @param string $abstract
     * @return mixed
     * @throws \RuntimeException When lazy service instantiation fails
     */
    public function make(string $abstract)
    {
        // Check if we have a singleton instance
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }
        
        // Check if we have a binding
        if (isset($this->bindings[$abstract])) {
            $concrete = $this->bindings[$abstract];
            
            try {
                if (is_callable($concrete)) {
                    $instance = $concrete($this);
                } else {
                    $instance = $concrete;
                }
                
                // Cache lazy service instances after first instantiation
                if (isset($this->lazyServices[$abstract])) {
                    $this->instances[$abstract] = $instance;
                }
                
                return $instance;
            } catch (\Throwable $e) {
                // Provide descriptive exception for lazy service instantiation failures
                if (isset($this->lazyServices[$abstract])) {
                    throw new \RuntimeException(
                        "Failed to instantiate lazy service [{$abstract}]: {$e->getMessage()}",
                        0,
                        $e
                    );
                }
                throw $e;
            }
        }
        
        // Try to auto-resolve the class
        if (class_exists($abstract)) {
            return new $abstract();
        }
        
        return null;
    }
    
    /**
     * Check if a service is bound
     * 
     * @param string $abstract
     * @return bool
     */
    public function bound(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) || isset($this->instances[$abstract]);
    }
    
    /**
     * Get the base path of the application
     * 
     * @return string
     */
    public function basePath(): string
    {
        return $this->basePath;
    }
    
    /**
     * Get the modules path
     * 
     * @return string
     */
    public function modulesPath(): string
    {
        return $this->modulesPath;
    }
    
    /**
     * Check if the application has been bootstrapped
     * 
     * @return bool
     */
    public function isBootstrapped(): bool
    {
        return $this->bootstrapped;
    }
    
    /**
     * Get all loaded modules
     * 
     * @return Collection
     */
    public function getModules(): Collection
    {
        $registry = $this->make(ModuleRegistryContract::class);
        return $registry->all();
    }
}
