<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Events;

use DateTimeImmutable;

/**
 * Membership Attached Event
 * 
 * Emitted when an identity is directly attached to a workspace with a role.
 * Requirement 4.5
 */
class MembershipAttachedEvent
{
    public function __construct(
        public readonly string $membershipId,
        public readonly string $identityId,
        public readonly string $workspaceId,
        public readonly string $role,
        public readonly DateTimeImmutable $attachedAt
    ) {}
}
