<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership;

use Viraloka\Core\Membership\Contracts\RoleRegistryInterface;

/**
 * Role Registry
 * 
 * Manages role definitions and capability mappings.
 * Provides default roles (owner, admin, member) with default capabilities.
 * Allows modules to register custom roles.
 * 
 * Requirements: 5.1, 5.2, 5.3, 5.4
 */
class RoleRegistry implements RoleRegistryInterface
{
    /**
     * @var array<string, array<string>> Role to capabilities mapping
     */
    private array $roles = [];

    public function __construct()
    {
        // Initialize default roles with default capabilities (Requirement 5.1, 5.2)
        $this->initializeDefaultRoles();
    }

    /**
     * Register a custom role with capabilities
     * 
     * @param string $role Role name
     * @param array $capabilities List of capabilities
     * @return void
     */
    public function registerRole(string $role, array $capabilities): void
    {
        // Requirement 5.3, 5.4
        $this->roles[$role] = $capabilities;
    }

    /**
     * Get capabilities for a role
     * 
     * @param string $role Role name
     * @return array List of capabilities
     */
    public function getCapabilities(string $role): array
    {
        // Requirement 5.3, 5.4
        return $this->roles[$role] ?? [];
    }

    /**
     * Check if role has capability
     * 
     * @param string $role Role name
     * @param string $capability Capability name
     * @return bool
     */
    public function roleHasCapability(string $role, string $capability): bool
    {
        // Requirement 5.3, 5.4
        $capabilities = $this->getCapabilities($role);
        return in_array($capability, $capabilities, true);
    }

    /**
     * Get all registered roles
     * 
     * @return array List of role names
     */
    public function getAllRoles(): array
    {
        // Requirement 5.3, 5.4
        return array_keys($this->roles);
    }

    /**
     * Initialize default roles with default capabilities
     * 
     * @return void
     */
    private function initializeDefaultRoles(): void
    {
        // Owner role - full access (Requirement 5.1, 5.2)
        $this->roles[Membership::ROLE_OWNER] = [
            'workspace.manage',
            'workspace.delete',
            'membership.manage',
            'membership.invite',
            'membership.remove',
            'content.create',
            'content.edit',
            'content.delete',
            'content.publish',
            'settings.manage',
            'billing.manage',
        ];

        // Admin role - management access without billing (Requirement 5.1, 5.2)
        $this->roles[Membership::ROLE_ADMIN] = [
            'workspace.manage',
            'membership.invite',
            'content.create',
            'content.edit',
            'content.delete',
            'content.publish',
            'settings.manage',
        ];

        // Member role - basic access (Requirement 5.1, 5.2)
        $this->roles[Membership::ROLE_MEMBER] = [
            'content.create',
            'content.edit',
            'content.view',
        ];
    }
}
