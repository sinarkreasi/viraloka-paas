<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership;

use Viraloka\Core\Application;
use Viraloka\Core\Membership\Contracts\MembershipEngineInterface;
use Viraloka\Core\Membership\Contracts\MembershipRepositoryInterface;
use Viraloka\Core\Membership\Contracts\RoleRegistryInterface;
use Viraloka\Core\Membership\Repositories\MembershipRepository;
use Viraloka\Core\Membership\Events\MembershipAttachedEvent;
use Viraloka\Core\Membership\Events\MembershipRequestedEvent;
use Viraloka\Core\Membership\Events\MembershipApprovedEvent;
use Viraloka\Core\Membership\Events\MembershipRevokedEvent;
use Viraloka\Core\Membership\Exceptions\MembershipExistsException;
use Viraloka\Core\Membership\Exceptions\MembershipNotFoundException;
use Viraloka\Core\Membership\Exceptions\MembershipNotPendingException;
use Viraloka\Core\Membership\Exceptions\LastOwnerException;
use Viraloka\Core\Events\EventDispatcher;
use Viraloka\Core\Adapter\Contracts\AdapterRegistryInterface;
use DateTimeImmutable;

/**
 * Membership Engine
 * 
 * Manages the lifecycle of Membership entities including attach, request, approve, and revoke.
 * Integrates with EventDispatcher for lifecycle events.
 * Enforces workspace owner protection rules.
 * Uses AdapterRegistry for StorageAdapter access.
 * 
 * Requirements: 3.1-3.10, 4.1-4.10, 11.4, 11.5
 */
class MembershipEngine implements MembershipEngineInterface
{
    private readonly MembershipRepositoryInterface $repository;
    private readonly EventDispatcher $eventDispatcher;
    private readonly RoleRegistryInterface $roleRegistry;

    /**
     * Create a new MembershipEngine instance
     * 
     * @param Application $app
     */
    public function __construct(private readonly Application $app)
    {
        // Resolve dependencies from container (Requirement 11.4, 11.5)
        $adapters = $this->app->make(AdapterRegistryInterface::class);
        
        // Create repository with StorageAdapter
        $this->repository = new MembershipRepository($adapters->storage());
        
        // Get EventDispatcher from Kernel
        $kernel = $this->app->make(\Viraloka\Core\Bootstrap\Kernel::class);
        $this->eventDispatcher = $kernel->getEventDispatcher();
        
        // Get RoleRegistry from container
        $this->roleRegistry = $this->app->make(RoleRegistryInterface::class);
    }

    /**
     * Attach identity to workspace with role (direct membership)
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $role owner|admin|member|custom
     * @return Membership
     * @throws MembershipExistsException
     */
    public function attach(string $identityId, string $workspaceId, string $role): Membership
    {
        // Check if membership already exists (Requirement 4.1)
        $existing = $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
        if ($existing !== null) {
            throw new MembershipExistsException($identityId, $workspaceId);
        }

        // Generate UUID for membership_id (Requirement 3.1)
        $membershipId = $this->generateUuid();

        // Create membership with active status (Requirement 3.3)
        $membership = new Membership(
            $membershipId,
            $identityId,
            $workspaceId,
            $role,
            Membership::STATUS_ACTIVE,
            new DateTimeImmutable()
        );

        // Persist membership
        $membership = $this->repository->create($membership);

        // Emit membership.attached event (Requirement 4.5)
        $this->eventDispatcher->dispatch(
            'membership.attached',
            new MembershipAttachedEvent(
                $membership->membershipId,
                $membership->identityId,
                $membership->workspaceId,
                $membership->role,
                $membership->createdAt
            )
        );

        return $membership;
    }

    /**
     * Request membership (pending approval)
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership
     */
    public function request(string $identityId, string $workspaceId): Membership
    {
        // Check if membership already exists
        $existing = $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
        if ($existing !== null) {
            throw new MembershipExistsException($identityId, $workspaceId);
        }

        // Generate UUID for membership_id
        $membershipId = $this->generateUuid();

        // Create membership with pending status (Requirement 3.4, 4.2)
        $membership = new Membership(
            $membershipId,
            $identityId,
            $workspaceId,
            Membership::ROLE_MEMBER, // Default role for requests
            Membership::STATUS_PENDING,
            new DateTimeImmutable()
        );

        // Persist membership
        $membership = $this->repository->create($membership);

        // Emit membership.requested event (Requirement 4.6)
        $this->eventDispatcher->dispatch(
            'membership.requested',
            new MembershipRequestedEvent(
                $membership->membershipId,
                $membership->identityId,
                $membership->workspaceId,
                $membership->createdAt
            )
        );

        return $membership;
    }

    /**
     * Approve pending membership request
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $role Role to assign
     * @return Membership
     * @throws MembershipNotPendingException
     */
    public function approve(string $identityId, string $workspaceId, string $role): Membership
    {
        // Find membership
        $membership = $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
        
        if ($membership === null) {
            throw new MembershipNotFoundException($identityId, $workspaceId);
        }

        // Validate membership is pending (Requirement 4.10)
        if (!$membership->isPending()) {
            throw new MembershipNotPendingException($membership->membershipId, $membership->status);
        }

        // Approve membership and assign role (Requirement 4.3)
        $membership->approve($role);

        // Persist changes
        $membership = $this->repository->update($membership);

        // Emit membership.approved event (Requirement 4.7)
        $this->eventDispatcher->dispatch(
            'membership.approved',
            new MembershipApprovedEvent(
                $membership->membershipId,
                $membership->identityId,
                $membership->workspaceId,
                $membership->role,
                new DateTimeImmutable()
            )
        );

        return $membership;
    }

    /**
     * Revoke membership
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return bool
     * @throws LastOwnerException
     */
    public function revoke(string $identityId, string $workspaceId): bool
    {
        // Find membership
        $membership = $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
        
        if ($membership === null) {
            throw new MembershipNotFoundException($identityId, $workspaceId);
        }

        // Check if this is the last owner (Requirement 3.7, 4.9)
        if ($membership->isOwner() && $membership->isActive()) {
            $ownerCount = $this->repository->countOwnersByWorkspace($workspaceId);
            if ($ownerCount <= 1) {
                throw new LastOwnerException($workspaceId);
            }
        }

        // Revoke membership (Requirement 4.4)
        $membership->revoke();

        // Persist changes
        $this->repository->update($membership);

        // Emit membership.revoked event (Requirement 4.8)
        $this->eventDispatcher->dispatch(
            'membership.revoked',
            new MembershipRevokedEvent(
                $membership->membershipId,
                $membership->identityId,
                $membership->workspaceId,
                new DateTimeImmutable()
            )
        );

        return true;
    }

    /**
     * Get membership for identity in workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership|null
     */
    public function getMembership(string $identityId, string $workspaceId): ?Membership
    {
        return $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
    }

    /**
     * List all memberships for an identity
     * 
     * @param string $identityId UUID
     * @return Membership[]
     */
    public function getMembershipsForIdentity(string $identityId): array
    {
        // Requirement 3.9
        return $this->repository->findByIdentity($identityId);
    }

    /**
     * List all memberships for a workspace
     * 
     * @param string $workspaceId UUID
     * @return Membership[]
     */
    public function getMembershipsForWorkspace(string $workspaceId): array
    {
        // Requirement 3.10
        return $this->repository->findByWorkspace($workspaceId);
    }

    /**
     * Check if identity has permission in workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @param string $capability Capability to check
     * @return bool
     */
    public function hasPermission(string $identityId, string $workspaceId, string $capability): bool
    {
        // Requirement 5.6, 5.7, 5.8, 11.1, 11.2, 11.3
        // Return false without exceptions on failure (Requirement 5.8)
        
        // Step 1: Resolve the membership for the identity in the workspace
        $membership = $this->repository->findByIdentityAndWorkspace($identityId, $workspaceId);
        
        if ($membership === null) {
            return false;
        }
        
        // Only check active memberships
        if (!$membership->isActive()) {
            return false;
        }
        
        // Step 2: Get the role from the membership
        $role = $membership->role;
        
        // Step 3: Check if role has the capability using RoleRegistry
        return $this->roleRegistry->roleHasCapability($role, $capability);
    }

    /**
     * Get current workspace from WorkspaceResolver
     * 
     * Helper method to access workspace context (Requirement 11.1, 11.2)
     * 
     * @return \Viraloka\Core\Workspace\Workspace|null
     */
    protected function getCurrentWorkspace(): ?\Viraloka\Core\Workspace\Workspace
    {
        try {
            $workspaceResolver = $this->app->make(\Viraloka\Core\Workspace\WorkspaceResolver::class);
            return $workspaceResolver->resolve();
        } catch (\Throwable $e) {
            // Return null if workspace cannot be resolved
            return null;
        }
    }

    /**
     * Get current context from ContextResolver
     * 
     * Helper method to access context information (Requirement 11.3)
     * 
     * @return string|null
     */
    protected function getCurrentContext(): ?string
    {
        try {
            $contextResolver = $this->app->make(\Viraloka\Core\Context\ContextResolver::class);
            return $contextResolver->getCurrentContext();
        } catch (\Throwable $e) {
            // Return null if context cannot be resolved
            return null;
        }
    }

    /**
     * Generate a UUID v4
     * 
     * @return string
     */
    private function generateUuid(): string
    {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}
