<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Exceptions;

use Exception;

/**
 * Last Owner Exception
 * 
 * Thrown when attempting to revoke the last owner of a workspace.
 * Requirement 4.9
 */
class LastOwnerException extends Exception
{
    public function __construct(string $workspaceId)
    {
        parent::__construct(
            "Cannot revoke the last owner of workspace {$workspaceId}. Each workspace must have at least one owner."
        );
    }
}
