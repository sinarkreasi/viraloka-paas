<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Exceptions;

use Exception;

/**
 * Membership Exists Exception
 * 
 * Thrown when attempting to create a membership that already exists.
 * Requirement 4.9
 */
class MembershipExistsException extends Exception
{
    public function __construct(string $identityId, string $workspaceId)
    {
        parent::__construct(
            "Membership already exists for identity {$identityId} in workspace {$workspaceId}"
        );
    }
}
