<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Contracts;

use Viraloka\Core\Membership\Membership;

/**
 * Membership Repository Interface
 * 
 * Defines the contract for membership persistence operations.
 * Handles CRUD operations and listing by identity and workspace.
 */
interface MembershipRepositoryInterface
{
    /**
     * Create a new membership
     * 
     * @param Membership $membership
     * @return Membership
     */
    public function create(Membership $membership): Membership;
    
    /**
     * Update an existing membership
     * 
     * @param Membership $membership
     * @return Membership
     */
    public function update(Membership $membership): Membership;
    
    /**
     * Delete a membership
     * 
     * @param string $membershipId UUID
     * @return bool
     */
    public function delete(string $membershipId): bool;
    
    /**
     * Find membership by ID
     * 
     * @param string $membershipId UUID
     * @return Membership|null
     */
    public function findById(string $membershipId): ?Membership;
    
    /**
     * Find membership by identity and workspace
     * 
     * @param string $identityId UUID
     * @param string $workspaceId UUID
     * @return Membership|null
     */
    public function findByIdentityAndWorkspace(string $identityId, string $workspaceId): ?Membership;
    
    /**
     * List all memberships for an identity
     * 
     * @param string $identityId UUID
     * @return Membership[]
     */
    public function findByIdentity(string $identityId): array;
    
    /**
     * List all memberships for a workspace
     * 
     * @param string $workspaceId UUID
     * @return Membership[]
     */
    public function findByWorkspace(string $workspaceId): array;
    
    /**
     * Count owners for a workspace
     * 
     * @param string $workspaceId UUID
     * @return int
     */
    public function countOwnersByWorkspace(string $workspaceId): int;
}
