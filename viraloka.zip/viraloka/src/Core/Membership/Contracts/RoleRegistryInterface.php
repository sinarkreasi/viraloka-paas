<?php

declare(strict_types=1);

namespace Viraloka\Core\Membership\Contracts;

/**
 * Role Registry Interface
 * 
 * Manages role definitions and capability mappings.
 * Allows modules to define custom roles and map them to capabilities.
 * 
 * Requirements: 5.3, 5.4
 */
interface RoleRegistryInterface
{
    /**
     * Register a custom role with capabilities
     * 
     * @param string $role Role name
     * @param array $capabilities List of capabilities
     * @return void
     */
    public function registerRole(string $role, array $capabilities): void;

    /**
     * Get capabilities for a role
     * 
     * @param string $role Role name
     * @return array List of capabilities
     */
    public function getCapabilities(string $role): array;

    /**
     * Check if role has capability
     * 
     * @param string $role Role name
     * @param string $capability Capability name
     * @return bool
     */
    public function roleHasCapability(string $role, string $capability): bool;

    /**
     * Get all registered roles
     * 
     * @return array List of role names
     */
    public function getAllRoles(): array;
}
