<?php

namespace Viraloka\Core\Providers;

use Viraloka\Core\Application;

/**
 * Base Service Provider
 * 
 * Abstract class that all module service providers must extend.
 * Provides hooks for registering and booting module services.
 */
abstract class ServiceProvider
{
    /**
     * The application instance
     * 
     * @var Application
     */
    protected Application $app;
    
    /**
     * Create a new service provider instance
     * 
     * @param Application $app
     */
    public function __construct(Application $app)
    {
        $this->app = $app;
    }
    
    /**
     * Register services in the container
     * 
     * This method is called during module loading and should be used
     * to bind services into the dependency injection container.
     * 
     * @return void
     */
    abstract public function register(): void;
    
    /**
     * Bootstrap module services
     * 
     * This method is called after all modules have been registered
     * and should be used for any initialization that depends on
     * other services being available.
     * 
     * @return void
     */
    public function boot(): void
    {
        // Optional boot method - modules can override if needed
    }
    
    /**
     * Get the application instance
     * 
     * @return Application
     */
    protected function getApp(): Application
    {
        return $this->app;
    }
}
