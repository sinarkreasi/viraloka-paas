# 2. Getting Started

## 2.1 Installation

### Minimum Requirements

**Server Requirements:**
- PHP 8.1 or higher
- WordPress 6.0 or higher
- MySQL 5.7+ or MariaDB 10.3+
- Composer (for development)

**PHP Extensions:**
- json
- mbstring
- pdo_mysql
- openssl

**Recommended:**
- PHP 8.3+
- OPcache enabled
- Memory limit: 256MB+

### Install Core Plugin

**Method 1: Manual Installation**

1. Download Viraloka core plugin
2. Extract ke `wp-content/plugins/viraloka/`
3. Activate via WordPress admin

**Method 2: Composer (Development)**

```bash
composer require viraloka/core
```

**Method 3: WP-CLI**

```bash
wp plugin install viraloka --activate
```

### What Viraloka Does on Activation

Saat plugin diaktifkan, Viraloka akan:

**1. Create Database Tables**
```sql
-- Workspace tables
wp_viraloka_workspaces
wp_viraloka_tenants
wp_viraloka_workspace_user_roles

-- Module tables
wp_viraloka_modules
wp_viraloka_module_dependencies
```

**2. Register Core Services**
- Service Container
- Context Resolver
- Module Registry
- Adapter Registry
- Event Dispatcher

**3. Initialize Default Context**
- System default context
- Admin context
- Public context

**4. Scan for Modules**
- Scan `viraloka-modules/` directory
- Parse module manifests
- Register discovered modules

**5. Setup Capabilities**
- `manage_viraloka` (admin)
- `manage_workspaces` (workspace admin)
- `access_workspace` (workspace member)

### Verification

Setelah aktivasi, verify installation:

**Via Admin UI:**
1. Navigate to **Viraloka → Dashboard**
2. Check system status
3. Verify core services loaded

**Via WP-CLI:**
```bash
wp viraloka status
```

Expected output:
```
✓ Core: Active
✓ Container: Initialized
✓ Modules: 0 loaded
✓ Adapters: WordPress
✓ Database: Tables created
```

## 2.2 First Boot

### Bootstrap Flow Explanation

Viraloka bootstrap terjadi dalam beberapa tahap:

**Phase 1: Kernel Initialization**
```php
// viraloka-core.php
$kernel = new Kernel($container, $adapterRegistry);
$kernel->boot();
```

**What happens:**
- Load configuration
- Register error handlers
- Initialize security guard
- Setup performance monitoring

**Phase 2: Service Registration**
```php
$container->singleton(ContextResolverInterface::class, ContextResolver::class);
$container->singleton(ModuleRegistryInterface::class, ModuleRegistry::class);
// ... more services
```

**What happens:**
- Register core contracts
- Bind implementations
- Setup service providers
- Configure lazy loading

**Phase 3: Adapter Registration**
```php
$adapterRegistry->register('auth', new WordPressAuthAdapter());
$adapterRegistry->register('storage', new WordPressStorageAdapter());
$adapterRegistry->register('event', new WordPressEventAdapter());
// ... more adapters
```

**What happens:**
- Detect host environment (WordPress)
- Register host-specific adapters
- Bind adapters to container
- Verify adapter contracts

**Phase 4: Module Discovery**
```php
$moduleLoader = $container->make(ModuleLoaderInterface::class);
$moduleLoader->discover('viraloka-modules/');
```

**What happens:**
- Scan module directories
- Parse `module.json` manifests
- Validate module structure
- Register modules in registry

**Phase 5: Context Resolution**
```php
$contextResolver = $container->make(ContextResolverInterface::class);
$context = $contextResolver->resolve();
```

**What happens:**
- Detect current workspace
- Resolve active context
- Filter modules by context
- Build execution plan

### Core Services Initialized

Setelah boot, services berikut tersedia:

**Container Services:**
- `ContainerInterface` - Dependency injection
- `ServiceProviderInterface` - Service registration

**Context Services:**
- `ContextResolverInterface` - Context resolution
- `WorkspaceResolverInterface` - Workspace detection

**Module Services:**
- `ModuleRegistryInterface` - Module management
- `ModuleLoaderInterface` - Module discovery
- `ModuleBootstrapperInterface` - Module initialization

**Adapter Services:**
- `AuthAdapterInterface` - Authentication
- `StorageAdapterInterface` - Data persistence
- `EventAdapterInterface` - Event system
- `RequestAdapterInterface` - HTTP requests
- `ResponseAdapterInterface` - HTTP responses
- `RuntimeAdapterInterface` - Environment info

**Workspace Services:**
- `WorkspaceRepositoryInterface` - Workspace CRUD
- `TenantRepositoryInterface` - Tenant management
- `PermissionBoundaryInterface` - Access control

### Default Context

Viraloka memiliki beberapa default context:

**System Default Context**
```php
[
    'id' => 'system',
    'type' => 'system',
    'priority' => 0,
    'modules' => ['core-admin', 'core-settings']
]
```

**Admin Context**
```php
[
    'id' => 'admin',
    'type' => 'admin',
    'priority' => 10,
    'modules' => ['dashboard', 'user-management']
]
```

**Public Context**
```php
[
    'id' => 'public',
    'type' => 'public',
    'priority' => 5,
    'modules' => [] // determined by workspace
]
```

## 2.3 Project Types

Viraloka mendukung berbagai tipe project:

### Single App SaaS

**Characteristics:**
- Satu aplikasi untuk semua user
- Shared database
- User-level isolation
- Simple setup

**Example: Link-in-Bio Tool**
```
Workspace: Default
├── User A → Profile A
├── User B → Profile B
└── User C → Profile C

All users share same app instance
```

**Configuration:**
```php
// module.json
{
    "id": "linkinbio",
    "type": "application",
    "multi_tenant": false,
    "context": {
        "provides": ["linkinbio"]
    }
}
```

**Use Cases:**
- Personal tools
- Simple SaaS apps
- Internal utilities

### Multi-Tenant SaaS

**Characteristics:**
- Multiple workspaces
- Data isolation per workspace
- Workspace-level customization
- Complex setup

**Example: Agency Platform**
```
Workspace: Agency A
├── Client 1 → Tenant 1
├── Client 2 → Tenant 2
└── Client 3 → Tenant 3

Workspace: Agency B
├── Client 1 → Tenant 1
└── Client 2 → Tenant 2

Complete isolation between workspaces
```

**Configuration:**
```php
// module.json
{
    "id": "agency-platform",
    "type": "application",
    "multi_tenant": true,
    "workspace_aware": true,
    "context": {
        "provides": ["agency", "client-management"]
    }
}
```

**Use Cases:**
- Agency platforms
- White-label SaaS
- Enterprise applications

### Internal Tools

**Characteristics:**
- Single workspace
- Team collaboration
- Role-based access
- Custom workflows

**Example: Company Dashboard**
```
Workspace: Company Internal
├── Department: Sales
├── Department: Marketing
└── Department: Support

Shared workspace, different permissions
```

**Configuration:**
```php
// module.json
{
    "id": "company-dashboard",
    "type": "internal",
    "multi_tenant": false,
    "workspace_aware": true,
    "context": {
        "provides": ["internal-tools"]
    }
}
```

**Use Cases:**
- Company dashboards
- Team tools
- Internal workflows

### Choosing Project Type

**Decision Matrix:**

| Requirement | Single App | Multi-Tenant | Internal |
|-------------|-----------|--------------|----------|
| Multiple customers | ❌ | ✅ | ❌ |
| Data isolation | User-level | Workspace-level | Role-level |
| Customization | Limited | High | Medium |
| Complexity | Low | High | Medium |
| Setup time | Fast | Slow | Medium |

**Recommendations:**

**Choose Single App if:**
- Building simple SaaS tool
- All users share same features
- No need for workspace isolation
- Quick time to market

**Choose Multi-Tenant if:**
- Building platform for multiple customers
- Need complete data isolation
- Customers need customization
- Scaling to many workspaces

**Choose Internal if:**
- Building for single organization
- Need team collaboration
- Role-based access sufficient
- Custom workflows required

---

## Next Steps

Now that Viraloka is installed, learn about the architecture:

→ [Architecture Overview](03-architecture-overview.md)

Or jump straight to building:

→ [Building Modules](05-building-modules.md)
