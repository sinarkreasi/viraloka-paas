# Viraloka Core Module Manifest System

A declarative, JSON-based module system for WordPress that enables dynamic module discovery, validation, and lazy loading with soft dependency resolution.

## Project Structure

```
viraloka-core/
├── src/
│   └── Core/
│       ├── Application.php                    # Core application container
│       ├── Context/
│       │   └── Contracts/
│       │       └── ContextResolverContract.php
│       ├── Modules/
│       │   ├── Contracts/                     # All module-related interfaces
│       │   │   ├── CapabilityRegistryContract.php
│       │   │   ├── DependencyResolverContract.php
│       │   │   ├── ManifestCacheContract.php
│       │   │   ├── ManifestParserContract.php
│       │   │   ├── ModuleBootstrapperContract.php
│       │   │   ├── ModuleLoaderContract.php
│       │   │   ├── ModuleRegistryContract.php
│       │   │   └── SchemaValidatorContract.php
│       │   ├── Exceptions/                    # Module exceptions
│       │   │   ├── BootstrapException.php
│       │   │   └── DuplicateModuleException.php
│       │   ├── ContextConfig.php              # Configuration value objects
│       │   ├── DependencyConfig.php
│       │   ├── InvalidModule.php
│       │   ├── LifecycleConfig.php
│       │   ├── Manifest.php                   # Core manifest data model
│       │   ├── Module.php                     # Module runtime representation
│       │   ├── ParseResult.php
│       │   ├── RecommendationConfig.php
│       │   ├── ResolutionResult.php
│       │   ├── UIConfig.php
│       │   ├── ValidationResult.php
│       │   └── VisibilityConfig.php
│       ├── Providers/
│       │   └── ServiceProvider.php            # Base service provider
│       └── Support/
│           └── Collection.php                 # Collection utility
├── viraloka-modules/                          # Module directory (PSR-4)
├── tests/                                     # Test directory
├── composer.json                              # Composer configuration
└── README.md
```

## PSR-4 Autoloading

The project follows PSR-4 autoloading standards:

- `Viraloka\Core\` → `src/Core/`
- `Viraloka\Modules\` → `viraloka-modules/`
- `Viraloka\Tests\` → `tests/`

## Core Contracts

### Module Loading
- **ModuleLoaderContract**: Orchestrates module discovery and loading
- **ManifestParserContract**: Parses module.json files
- **SchemaValidatorContract**: Validates manifest structure

### Dependency Management
- **DependencyResolverContract**: Checks module dependencies
- **ContextResolverContract**: Matches modules to contexts

### Module Lifecycle
- **ModuleBootstrapperContract**: Initializes service providers
- **ModuleRegistryContract**: Central module registry
- **CapabilityRegistryContract**: Manages module capabilities
- **ManifestCacheContract**: Caches parsed manifests

## Base Service Provider

All modules must extend `Viraloka\Core\Providers\ServiceProvider`:

```php
<?php

namespace Viraloka\Modules\MyModule;

use Viraloka\Core\Providers\ServiceProvider;

class MyModuleServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Bind services into the container
    }
    
    public function boot(): void
    {
        // Bootstrap module services
    }
}
```

## Installation

```bash
composer install
```

## Next Steps

This task has set up the foundational structure. Subsequent tasks will:

1. Implement data models and value objects
2. Implement schema validation
3. Implement manifest parsing
4. Implement module loading and bootstrapping
5. Add caching and performance optimizations

## Requirements

- PHP >= 8.0
- Composer

## License

Proprietary
