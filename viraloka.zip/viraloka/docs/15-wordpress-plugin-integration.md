# 15. External System Integration via Capabilities

## Overview

Viraloka integrates with external systems (WordPress plugins, Laravel packages, APIs, etc.) through a **capability-based adapter pattern**. This maintains the engine-agnostic architecture while enabling rich integrations.

**Critical Principle:** Core and your modules **never know** about WooCommerce, Contact Form 7, or any specific external system. They only know about **capabilities**.

## Integration Philosophy

**Key Principles:**

1. **Capability-First:** Define what you need (capability), not how to get it (implementation)
2. **Adapter as Module:** Each adapter is a full Viraloka module with its own lifecycle
3. **Core Agnostic:** Core never depends on external systems
4. **Multiple Implementations:** One capability can have many adapter implementations
5. **Fail-Safe:** If adapter fails, core and other modules continue working

**Architecture:**

```
┌─────────────────────────────────────┐
│     Your Viraloka Module            │
│  (depends on EcommerceCapability)   │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│   Capability Interface (Contract)   │  ← Engine-agnostic
│     (EcommerceCapability)           │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│   Adapter Module (Implementation)   │  ← Host-specific
│  (WooCommerce / Shopify / Custom)   │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│   External System (WooCommerce)     │
└─────────────────────────────────────┘
```

**What This Means:**
- Your module depends on `EcommerceCapability` interface
- Adapter provides the implementation
- Swap WooCommerce adapter with Shopify adapter → your module still works
- No WooCommerce code in your module

## Capability Definition

### What is a Capability?

A **capability** is an engine-agnostic contract that defines **what the system can do**, not **how it does it**.

**Examples:**
- `EcommerceCapability` - Product, cart, checkout operations
- `FormSubmissionCapability` - Form handling and submissions
- `PaymentCapability` - Payment processing
- `ForumCapability` - Forum, topics, replies
- `DesignSystemCapability` - Theme, layouts, design tokens

**Capabilities MUST NOT:**
- Contain business logic
- Assume any specific host (WordPress, Laravel, etc.)
- Reference external systems directly

### Capability Interface Example

```php
<?php

namespace Viraloka\Core\Capabilities;

/**
 * EcommerceCapability
 * 
 * Engine-agnostic interface for e-commerce operations.
 * Can be implemented by WooCommerce, Shopify, custom systems, etc.
 */
interface EcommerceCapability
{
    // Product operations
    public function getProduct(int $productId): ?Product;
    public function getProducts(ProductQuery $query): ProductCollection;
    public function createProduct(ProductData $data): Product;
    public function updateProduct(int $productId, ProductData $data): Product;
    public function deleteProduct(int $productId): bool;
    
    // Cart operations
    public function getCart(): Cart;
    public function addToCart(int $productId, int $quantity): CartItem;
    public function removeFromCart(string $cartItemId): bool;
    public function clearCart(): bool;
    
    // Order operations
    public function createOrder(OrderData $data): Order;
    public function getOrder(int $orderId): ?Order;
    public function updateOrderStatus(int $orderId, string $status): bool;
}
```

**Key Points:**
- Uses value objects (`Product`, `Cart`, `Order`) - not arrays
- No WordPress types (no `WC_Product`, no `$wpdb`)
- No Laravel types (no Eloquent models)
- Pure PHP interfaces

## Adapter Module Structure

### What is an Adapter Module?

An **adapter module** is a Viraloka module that implements a capability interface using a specific external system.

**Adapter Module Characteristics:**
- Full Viraloka module with `module.json`
- Implements one or more capability interfaces
- Handles environment detection
- Manages version compatibility
- Provides fail-safe behavior

### Adapter Module Structure

```
viraloka-modules/woocommerce-adapter/
├── module.json
├── src/
│   ├── WooCommerceAdapterProvider.php
│   ├── WooCommerceEcommerceAdapter.php  ← Implements EcommerceCapability
│   ├── ValueObjects/
│   │   ├── Product.php
│   │   ├── Cart.php
│   │   └── Order.php
│   └── Mappers/
│       ├── ProductMapper.php
│       └── OrderMapper.php
└── README.md
```

### Adapter Manifest

```json
{
  "id": "woocommerce-adapter",
  "name": "WooCommerce Adapter",
  "description": "Provides EcommerceCapability via WooCommerce",
  "version": "1.0.0",
  "type": "adapter",
  
  "provides": {
    "capabilities": ["ecommerce"]
  },
  
  "requires": {
    "viraloka-core": "^1.0",
    "host": "wordpress",
    "external": {
      "woocommerce": ">=8.0"
    }
  },
  
  "context": {
    "provides": ["ecommerce"]
  },
  
  "bootstrap": {
    "provider": "WooCommerceAdapter\\WooCommerceAdapterProvider"
  }
}
```

**Key Differences from Regular Module:**
- `type: "adapter"` - identifies as adapter
- `provides.capabilities` - declares which capabilities it implements
- `requires.external` - declares external system dependencies

## Example: WooCommerce Adapter

### Adapter Implementation

```php
<?php

namespace WooCommerceAdapter;

use Viraloka\Core\Capabilities\EcommerceCapability;
use Viraloka\Core\Capabilities\ValueObjects\Product;
use Viraloka\Core\Capabilities\ValueObjects\ProductQuery;
use Viraloka\Core\Capabilities\ValueObjects\ProductCollection;
use WooCommerceAdapter\Mappers\ProductMapper;

class WooCommerceEcommerceAdapter implements EcommerceCapability
{
    private ProductMapper $mapper;
    
    public function __construct()
    {
        $this->mapper = new ProductMapper();
    }
    
    public function getProduct(int $productId): ?Product
    {
        // Get WooCommerce product
        $wcProduct = wc_get_product($productId);
        
        if (!$wcProduct) {
            return null;
        }
        
        // Map to Viraloka Product value object
        return $this->mapper->toViraloka($wcProduct);
    }
    
    public function getProducts(ProductQuery $query): ProductCollection
    {
        // Translate Viraloka query to WooCommerce args
        $args = [
            'status' => 'publish',
            'limit' => $query->getLimit(),
            'offset' => $query->getOffset(),
        ];
        
        if ($query->hasCategory()) {
            $args['category'] = [$query->getCategory()];
        }
        
        if ($query->hasSearch()) {
            $args['s'] = $query->getSearch();
        }
        
        // Get WooCommerce products
        $wcProducts = wc_get_products($args);
        
        // Map to Viraloka Product collection
        $products = array_map(
            fn($wcProduct) => $this->mapper->toViraloka($wcProduct),
            $wcProducts
        );
        
        return new ProductCollection($products);
    }
    
    public function createProduct(ProductData $data): Product
    {
        // Create WooCommerce product
        $wcProduct = new \WC_Product_Simple();
        
        $wcProduct->set_name($data->getName());
        $wcProduct->set_regular_price($data->getPrice()->getAmount());
        $wcProduct->set_description($data->getDescription());
        $wcProduct->set_stock_quantity($data->getStock());
        $wcProduct->set_manage_stock(true);
        
        $wcProduct->save();
        
        // Return Viraloka Product
        return $this->mapper->toViraloka($wcProduct);
    }
    
    // ... other methods
}
```

### Product Mapper

```php
<?php

namespace WooCommerceAdapter\Mappers;

use Viraloka\Core\Capabilities\ValueObjects\Product;
use Viraloka\Core\Capabilities\ValueObjects\Money;
use WC_Product;

class ProductMapper
{
    /**
     * Map WooCommerce product to Viraloka Product value object
     */
    public function toViraloka(WC_Product $wcProduct): Product
    {
        return new Product(
            id: $wcProduct->get_id(),
            name: $wcProduct->get_name(),
            slug: $wcProduct->get_slug(),
            price: new Money(
                amount: (float) $wcProduct->get_regular_price(),
                currency: get_woocommerce_currency()
            ),
            description: $wcProduct->get_description(),
            stock: $wcProduct->get_stock_quantity() ?? 0,
            inStock: $wcProduct->is_in_stock(),
            imageUrl: wp_get_attachment_url($wcProduct->get_image_id()),
            permalink: $wcProduct->get_permalink()
        );
    }
    
    /**
     * Map Viraloka Product to WooCommerce product
     */
    public function toWooCommerce(Product $product): WC_Product
    {
        $wcProduct = wc_get_product($product->getId());
        
        if (!$wcProduct) {
            $wcProduct = new \WC_Product_Simple();
        }
        
        $wcProduct->set_name($product->getName());
        $wcProduct->set_regular_price($product->getPrice()->getAmount());
        $wcProduct->set_description($product->getDescription());
        $wcProduct->set_stock_quantity($product->getStock());
        
        return $wcProduct;
    }
}
```

### Service Provider (Adapter Registration)

```php
<?php

namespace WooCommerceAdapter;

use Viraloka\Container\Contracts\ServiceProviderInterface;
use Viraloka\Container\Contracts\ContainerInterface;
use Viraloka\Core\Capabilities\EcommerceCapability;

class WooCommerceAdapterProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // Check if WooCommerce is available
        if (!$this->isWooCommerceAvailable()) {
            // Log warning but don't fail
            error_log('WooCommerce not available, adapter will not bind');
            return;
        }
        
        // Bind capability to adapter implementation
        $container->singleton(
            EcommerceCapability::class,
            WooCommerceEcommerceAdapter::class
        );
    }
    
    public function boot(ContainerInterface $container): void
    {
        if (!$this->isWooCommerceAvailable()) {
            return;
        }
        
        // Register event bridge if needed
        $this->registerEventBridge($container);
    }
    
    private function isWooCommerceAvailable(): bool
    {
        return class_exists('WooCommerce');
    }
    
    private function registerEventBridge(ContainerInterface $container): void
    {
        // Bridge WooCommerce events to Viraloka events
        add_action('woocommerce_new_product', function($productId) use ($container) {
            $events = $container->make(EventAdapterInterface::class);
            $events->dispatch('ecommerce.product.created', [
                'product_id' => $productId
            ]);
        });
        
        // ... more event bridges
    }
}
```

## Using Capabilities in Your Module

### Your Module Code (Engine-Agnostic)

```php
<?php

namespace MyModule\Services;

use Viraloka\Core\Capabilities\EcommerceCapability;
use Viraloka\Core\Capabilities\ValueObjects\ProductQuery;

class ProductService
{
    public function __construct(
        private ?EcommerceCapability $ecommerce = null  // Optional dependency
    ) {}
    
    public function listProducts(int $limit = 10): array
    {
        // Check if ecommerce capability is available
        if (!$this->ecommerce) {
            // Fallback behavior
            return [];
        }
        
        // Use capability (works with WooCommerce, Shopify, or any adapter)
        $query = new ProductQuery(limit: $limit);
        $collection = $this->ecommerce->getProducts($query);
        
        return $collection->toArray();
    }
    
    public function getProduct(int $productId): ?array
    {
        if (!$this->ecommerce) {
            return null;
        }
        
        $product = $this->ecommerce->getProduct($productId);
        
        return $product?->toArray();
    }
}
```

**Key Points:**
- Your module depends on `EcommerceCapability` interface
- No WooCommerce code in your module
- No `class_exists('WooCommerce')` checks
- Works with any adapter (WooCommerce, Shopify, custom)
- Optional dependency with graceful fallback

### Module Manifest (Declares Capability Need)

```json
{
  "id": "my-product-module",
  "name": "My Product Module",
  "version": "1.0.0",
  "type": "feature",
  
  "requires": {
    "viraloka-core": "^1.0",
    "capabilities": {
      "ecommerce": "optional"
    }
  },
  
  "bootstrap": {
    "provider": "MyModule\\MyServiceProvider"
  }
}
```

**Capability Requirement Levels:**
- `"required"` - Module won't load without capability
- `"optional"` - Module loads but features may be limited
- `"recommended"` - Module suggests installing adapter

## Example: Form Submission Capability

### Capability Interface

```php
<?php

namespace Viraloka\Core\Capabilities;

interface FormSubmissionCapability
{
    public function getForm(int $formId): ?Form;
    public function getForms(): FormCollection;
    public function submitForm(int $formId, FormData $data): FormSubmission;
    public function getSubmissions(int $formId): SubmissionCollection;
}
```

### Contact Form 7 Adapter

```php
<?php

namespace CF7Adapter;

use Viraloka\Core\Capabilities\FormSubmissionCapability;
use Viraloka\Core\Capabilities\ValueObjects\Form;
use Viraloka\Core\Capabilities\ValueObjects\FormCollection;
use WPCF7_ContactForm;

class CF7FormAdapter implements FormSubmissionCapability
{
    public function getForm(int $formId): ?Form
    {
        $cf7Form = WPCF7_ContactForm::get_instance($formId);
        
        if (!$cf7Form) {
            return null;
        }
        
        return new Form(
            id: $cf7Form->id(),
            title: $cf7Form->title(),
            fields: $this->extractFields($cf7Form)
        );
    }
    
    public function getForms(): FormCollection
    {
        $cf7Forms = WPCF7_ContactForm::find();
        
        $forms = array_map(
            fn($cf7Form) => $this->getForm($cf7Form->id()),
            $cf7Forms
        );
        
        return new FormCollection($forms);
    }
    
    // ... other methods
}
```

## Example: Forum Capability

### Capability Interface

```php
<?php

namespace Viraloka\Core\Capabilities;

interface ForumCapability
{
    public function getForum(int $forumId): ?Forum;
    public function getForums(): ForumCollection;
    public function createTopic(int $forumId, TopicData $data): Topic;
    public function createReply(int $topicId, ReplyData $data): Reply;
}
```

### bbPress Adapter

```php
<?php

namespace bbPressAdapter;

use Viraloka\Core\Capabilities\ForumCapability;
use Viraloka\Core\Capabilities\ValueObjects\Forum;

class bbPressForumAdapter implements ForumCapability
{
    public function getForum(int $forumId): ?Forum
    {
        if (!function_exists('bbp_get_forum')) {
            return null;
        }
        
        $bbpForum = bbp_get_forum($forumId);
        
        if (!$bbpForum) {
            return null;
        }
        
        return new Forum(
            id: $forumId,
            title: bbp_get_forum_title($forumId),
            content: bbp_get_forum_content($forumId),
            topicCount: bbp_get_forum_topic_count($forumId),
            replyCount: bbp_get_forum_reply_count($forumId)
        );
    }
    
    // ... other methods
}
```

## Capability Binding Flow

### How Capabilities Get Bound

1. **Core defines capability interfaces** (engine-agnostic)
2. **Adapter module implements capability** (host-specific)
3. **Service container binds interface to implementation**
4. **Your module requests capability** (via dependency injection)
5. **Container resolves and injects** (if adapter available)

### Multiple Adapters for Same Capability

```php
// WooCommerce adapter binds
$container->singleton(EcommerceCapability::class, WooCommerceAdapter::class);

// Shopify adapter also wants to bind
$container->singleton(EcommerceCapability::class, ShopifyAdapter::class);

// Context resolver decides which one to use
$context = $contextResolver->resolve();

if (in_array('woocommerce', $context)) {
    // Use WooCommerce adapter
} elseif (in_array('shopify', $context)) {
    // Use Shopify adapter
}
```

### Adapter Priority

```json
{
  "id": "woocommerce-adapter",
  "provides": {
    "capabilities": ["ecommerce"],
    "priority": 10
  }
}

{
  "id": "shopify-adapter",
  "provides": {
    "capabilities": ["ecommerce"],
    "priority": 5
  }
}
```

Higher priority wins if both available.

## Best Practices

### 1. Always Use Value Objects

```php
// ❌ BAD: Using arrays
public function getProduct(int $id): ?array;

// ✅ GOOD: Using value objects
public function getProduct(int $id): ?Product;
```

### 2. Never Check for External Systems in Your Module

```php
// ❌ BAD: Checking for WooCommerce
if (class_exists('WooCommerce')) {
    // Use WooCommerce
}

// ✅ GOOD: Depend on capability
public function __construct(
    private ?EcommerceCapability $ecommerce = null
) {}
```

### 3. Make Capabilities Optional

```php
// ✅ GOOD: Optional dependency with fallback
public function __construct(
    private ?EcommerceCapability $ecommerce = null
) {}

public function getProducts(): array
{
    if (!$this->ecommerce) {
        return []; // Fallback
    }
    
    return $this->ecommerce->getProducts(new ProductQuery())->toArray();
}
```

### 4. Adapter Handles All External Logic

```php
// ✅ GOOD: Adapter handles WooCommerce specifics
class WooCommerceAdapter implements EcommerceCapability
{
    public function getProduct(int $id): ?Product
    {
        // All WooCommerce code here
        $wcProduct = wc_get_product($id);
        
        // Map to Viraloka value object
        return $this->mapper->toViraloka($wcProduct);
    }
}
```

### 5. Use Mappers for Translation

```php
// ✅ GOOD: Separate mapper class
class ProductMapper
{
    public function toViraloka(WC_Product $wcProduct): Product
    {
        return new Product(
            id: $wcProduct->get_id(),
            name: $wcProduct->get_name(),
            // ... mapping logic
        );
    }
    
    public function toWooCommerce(Product $product): WC_Product
    {
        // Reverse mapping
    }
}
```

### 6. Graceful Degradation

```php
public function register(ContainerInterface $container): void
{
    // Check availability
    if (!$this->isWooCommerceAvailable()) {
        error_log('WooCommerce not available');
        return; // Don't bind, don't fail
    }
    
    // Bind capability
    $container->singleton(
        EcommerceCapability::class,
        WooCommerceAdapter::class
    );
}
```

## Anti-Patterns to Avoid

### ❌ DON'T: Put External System Code in Your Module

```php
// ❌ BAD
class MyProductService
{
    public function getProducts(): array
    {
        // Direct WooCommerce code in your module
        return wc_get_products(['status' => 'publish']);
    }
}
```

### ❌ DON'T: Check for External Systems

```php
// ❌ BAD
if (class_exists('WooCommerce')) {
    $products = wc_get_products();
}
```

### ❌ DON'T: Return External System Types

```php
// ❌ BAD
public function getProduct(int $id): ?WC_Product;

// ✅ GOOD
public function getProduct(int $id): ?Product;
```

### ❌ DON'T: Use Arrays Instead of Value Objects

```php
// ❌ BAD
public function getProduct(int $id): ?array;

// ✅ GOOD
public function getProduct(int $id): ?Product;
```

### ❌ DON'T: Make Capabilities Required

```php
// ❌ BAD: Required dependency
public function __construct(
    private EcommerceCapability $ecommerce
) {}

// ✅ GOOD: Optional dependency
public function __construct(
    private ?EcommerceCapability $ecommerce = null
) {}
```

## Portability Benefits

### Swap Implementations Without Code Changes

**Scenario:** Migrate from WooCommerce to Shopify

**Your Module Code:** No changes needed!

```php
// This code works with both WooCommerce and Shopify
class ProductService
{
    public function __construct(
        private ?EcommerceCapability $ecommerce = null
    ) {}
    
    public function listProducts(): array
    {
        if (!$this->ecommerce) {
            return [];
        }
        
        $query = new ProductQuery(limit: 10);
        return $this->ecommerce->getProducts($query)->toArray();
    }
}
```

**What Changes:**
1. Disable WooCommerce adapter
2. Enable Shopify adapter
3. Done!

### Multi-Platform Support

**Same module works on:**
- WordPress + WooCommerce
- WordPress + Shopify
- Laravel + Custom E-commerce
- Symfony + Magento

**Your code:** Unchanged!

## Summary

**Key Takeaways:**

1. **Capabilities are contracts** - Define what, not how
2. **Adapters are implementations** - Handle host-specific code
3. **Your modules depend on capabilities** - Not on external systems
4. **Use value objects** - Not arrays or external types
5. **Make capabilities optional** - Graceful degradation
6. **Adapters are modules** - Full lifecycle management
7. **Portability guaranteed** - Swap adapters without code changes

**This architecture ensures:**
- ✅ Engine-agnostic core
- ✅ Portable modules
- ✅ Easy testing (mock capabilities)
- ✅ Future-proof (swap implementations)
- ✅ Clean separation of concerns

---

## Next Steps

Learn about building modules:

→ [Building Modules](05-building-modules.md)

Or explore the roadmap:

→ [Roadmap & Evolution](14-roadmap-evolution.md)
