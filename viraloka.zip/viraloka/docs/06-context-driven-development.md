# 6. Context-Driven Development

## 6.1 Declaring Context

Context is the foundation of Viraloka's adaptive behavior. Modules and themes declare contexts to coordinate functionality across the platform.

### Theme Context

Themes can declare contexts that affect the entire application.

**In `theme.json`:**

```json
{
  "name": "E-commerce Theme",
  "version": "1.0.0",
  "viraloka": {
    "context": {
      "provides": ["ecommerce", "shop"],
      "priority": 50
    }
  }
}
```

**In `functions.php`:**

```php
add_filter('viraloka_theme_context', function($context) {
    return array_merge($context, ['ecommerce', 'shop']);
});
```

**Theme Context Characteristics:**
- High priority (overrides module recommendations)
- Affects all pages using the theme
- Typically represents the primary application type
- Should be stable (not change frequently)

**Example Use Cases:**

**E-commerce Theme:**
```json
{
  "viraloka": {
    "context": {
      "provides": ["ecommerce", "shop", "catalog"]
    }
  }
}
```
Activates: Product modules, cart, checkout, payment

**Blog Theme:**
```json
{
  "viraloka": {
    "context": {
      "provides": ["blog", "content", "publishing"]
    }
  }
}
```
Activates: Post modules, comments, authors, categories

**Agency Dashboard Theme:**
```json
{
  "viraloka": {
    "context": {
      "provides": ["agency", "client-management", "dashboard"]
    }
  }
}
```
Activates: Client modules, project management, reporting

### Module Context

Modules declare contexts to indicate what they provide and what they need.

**Providing Context:**

```json
{
  "id": "product-catalog",
  "context": {
    "provides": ["ecommerce", "catalog", "products"]
  }
}
```

**Meaning:**
- This module enables "ecommerce" functionality
- Other modules can depend on "ecommerce" context
- Module contributes to the context stack

**Requiring Context:**

```json
{
  "id": "shopping-cart",
  "context": {
    "requires": ["ecommerce", "products"]
  }
}
```

**Meaning:**
- Module only loads if "ecommerce" AND "products" contexts exist
- Ensures dependencies are met
- Prevents loading in incompatible environments

**Recommending Context:**

```json
{
  "id": "payment-gateway",
  "context": {
    "recommends": ["checkout"]
  }
}
```

**Meaning:**
- Module works better with "checkout" context
- Not required, but beneficial
- Suggests related modules

**Complete Example:**

```json
{
  "id": "advanced-checkout",
  "name": "Advanced Checkout",
  "context": {
    "provides": ["checkout", "payment-processing"],
    "requires": ["ecommerce", "cart"],
    "recommends": ["shipping", "tax-calculation"]
  }
}
```

## 6.2 Context Resolution Flow

Context resolution happens in multiple phases with clear priority rules.

### Priority Rules

**Resolution Order (Highest to Lowest):**

```
1. Workspace Configuration (Priority: 100)
   ↓
2. Theme Declaration (Priority: 50)
   ↓
3. Module Recommendations (Priority: 10)
   ↓
4. System Defaults (Priority: 0)
```

**Phase 1: Workspace Configuration**

```php
// Workspace explicitly sets context
$workspace = $workspaceRepo->find($workspaceId);
$workspaceContext = $workspace->getSettings()['context'] ?? [];

// Result: ['ecommerce', 'b2b']
// Priority: 100 (highest)
```

**Phase 2: Theme Context**

```php
// Theme declares context
$themeContext = apply_filters('viraloka_theme_context', []);

// Result: ['shop', 'catalog']
// Priority: 50
```

**Phase 3: Module Recommendations**

```php
// Modules recommend contexts
$moduleRecommendations = $recommender->getRecommendations();

// Result: ['products', 'inventory']
// Priority: 10
```

**Phase 4: System Defaults**

```php
// Fallback to system defaults
$systemDefaults = ['public', 'system'];

// Priority: 0 (lowest)
```

**Final Context Stack:**

```php
$contextStack = [
    'ecommerce',  // from workspace
    'b2b',        // from workspace
    'shop',       // from theme
    'catalog',    // from theme
    'products',   // from module
    'inventory',  // from module
    'public',     // system default
    'system'      // system default
];
```

### Conflict Handling

**Scenario 1: Duplicate Contexts**

```php
// Workspace provides: ['ecommerce']
// Theme provides: ['ecommerce', 'shop']
// Module provides: ['ecommerce']

// Result: ['ecommerce', 'shop']
// Duplicates removed, order preserved
```

**Scenario 2: Conflicting Contexts**

```json
// Module A
{
  "context": {
    "provides": ["b2c"],
    "conflicts": ["b2b"]
  }
}

// Module B
{
  "context": {
    "provides": ["b2b"],
    "conflicts": ["b2c"]
  }
}
```

**Resolution:**
```php
// If workspace declares 'b2b':
// - Module B loads
// - Module A does NOT load (conflict detected)

// If workspace declares 'b2c':
// - Module A loads
// - Module B does NOT load (conflict detected)
```

**Scenario 3: Missing Required Context**

```json
{
  "id": "advanced-shipping",
  "context": {
    "requires": ["ecommerce", "checkout"]
  }
}
```

**Resolution:**
```php
// If context stack = ['ecommerce', 'shop', 'public']
// Missing: 'checkout'
// Result: Module does NOT load

// If context stack = ['ecommerce', 'checkout', 'public']
// All requirements met
// Result: Module loads
```

**Scenario 4: Priority Override**

```php
// Theme declares: ['blog']
// Workspace declares: ['ecommerce']

// Result: ['ecommerce', 'blog']
// Workspace has higher priority, but both included
```

### Resolution Algorithm

**Step-by-Step Process:**

```php
class ContextResolver
{
    public function resolve(): array
    {
        $stack = [];
        
        // 1. Add workspace context (highest priority)
        $stack = array_merge($stack, $this->getWorkspaceContext());
        
        // 2. Add theme context
        $stack = array_merge($stack, $this->getThemeContext());
        
        // 3. Add module recommendations
        $stack = array_merge($stack, $this->getModuleRecommendations());
        
        // 4. Add system defaults
        $stack = array_merge($stack, $this->getSystemDefaults());
        
        // 5. Remove duplicates (preserve order)
        $stack = array_unique($stack);
        
        // 6. Validate no conflicts
        $this->validateNoConflicts($stack);
        
        return $stack;
    }
    
    private function validateNoConflicts(array $stack): void
    {
        $conflicts = $this->getContextConflicts();
        
        foreach ($stack as $context) {
            if (isset($conflicts[$context])) {
                foreach ($conflicts[$context] as $conflicting) {
                    if (in_array($conflicting, $stack)) {
                        throw new ContextConflictException(
                            "Context '{$context}' conflicts with '{$conflicting}'"
                        );
                    }
                }
            }
        }
    }
}
```

## 6.3 Context-Aware UI

UI components adapt based on the current context.

### UI Behavior by Context

**Admin Menu Registration:**

```php
// Module: Product Catalog
{
  "ui": {
    "menu": {
      "title": "Products",
      "contexts": ["ecommerce", "catalog"]
    }
  }
}

// Only visible when 'ecommerce' OR 'catalog' in context stack
```

**Conditional UI Components:**

```php
class DashboardWidget
{
    public function __construct(
        private ContainerInterface $container
    ) {}
    
    public function render(): string
    {
        $context = $this->container->make('current.context');
        
        if (in_array('ecommerce', $context)) {
            return $this->renderEcommerceWidget();
        }
        
        if (in_array('blog', $context)) {
            return $this->renderBlogWidget();
        }
        
        return $this->renderDefaultWidget();
    }
}
```

**Context-Based Navigation:**

```php
class NavigationBuilder
{
    public function build(): array
    {
        $context = $this->getContext();
        $menu = [];
        
        // Always show
        $menu[] = ['title' => 'Dashboard', 'url' => '/dashboard'];
        
        // Context-specific items
        if (in_array('ecommerce', $context)) {
            $menu[] = ['title' => 'Products', 'url' => '/products'];
            $menu[] = ['title' => 'Orders', 'url' => '/orders'];
        }
        
        if (in_array('blog', $context)) {
            $menu[] = ['title' => 'Posts', 'url' => '/posts'];
            $menu[] = ['title' => 'Comments', 'url' => '/comments'];
        }
        
        return $menu;
    }
}
```

**Frontend Templates:**

```php
// In module service provider
public function boot(): void
{
    $this->eventAdapter->listen('template_redirect', function() {
        $context = $this->container->make('current.context');
        
        if (in_array('ecommerce', $context)) {
            // Load e-commerce templates
            $this->loadTemplate('ecommerce');
        } elseif (in_array('blog', $context)) {
            // Load blog templates
            $this->loadTemplate('blog');
        }
    });
}
```

**Dynamic Feature Flags:**

```php
class FeatureManager
{
    public function isEnabled(string $feature): bool
    {
        $context = $this->getContext();
        
        return match($feature) {
            'shopping-cart' => in_array('ecommerce', $context),
            'comments' => in_array('blog', $context),
            'client-portal' => in_array('agency', $context),
            default => false
        };
    }
}
```

**Context-Aware Permissions:**

```php
class PermissionChecker
{
    public function canAccess(string $resource): bool
    {
        $context = $this->getContext();
        $user = $this->authAdapter->currentUser();
        
        // Context-specific permission checks
        if ($resource === 'products') {
            return in_array('ecommerce', $context) 
                && $user->hasCapability('manage_products');
        }
        
        if ($resource === 'posts') {
            return in_array('blog', $context)
                && $user->hasCapability('edit_posts');
        }
        
        return false;
    }
}
```

### Best Practices

**DO:**

✅ **Use context for feature toggling**
```php
if (in_array('ecommerce', $context)) {
    $this->enableShoppingCart();
}
```

✅ **Declare contexts in manifest**
```json
{
  "context": {
    "provides": ["ecommerce"],
    "requires": ["public"]
  }
}
```

✅ **Check context before rendering UI**
```php
public function shouldRender(): bool
{
    return in_array('ecommerce', $this->getContext());
}
```

✅ **Use context for module coordination**
```php
// Module A provides 'payment'
// Module B requires 'payment'
// Platform ensures Module A loads before Module B
```

**DON'T:**

❌ **Don't hardcode context checks everywhere**
```php
// Bad: Scattered context checks
if (in_array('ecommerce', $context)) { /* ... */ }
if (in_array('ecommerce', $context)) { /* ... */ }
if (in_array('ecommerce', $context)) { /* ... */ }

// Good: Centralized feature flag
if ($this->features->isEnabled('shopping-cart')) { /* ... */ }
```

❌ **Don't use context for business logic**
```php
// Bad: Business logic based on context
if (in_array('b2b', $context)) {
    $price = $product->price * 0.9; // 10% discount
}

// Good: Business logic in domain layer
$price = $this->pricingService->calculatePrice($product, $customer);
```

❌ **Don't create too many contexts**
```php
// Bad: Too granular
['ecommerce', 'shop', 'products', 'catalog', 'inventory', 'pricing', ...]

// Good: High-level contexts
['ecommerce', 'shop']
```

❌ **Don't change context during request**
```php
// Bad: Mutating context
$context[] = 'new-context';

// Good: Context is immutable per request
// Use workspace configuration to change context
```

### Real-World Examples

**Example 1: Multi-Purpose Platform**

```php
// Workspace 1: E-commerce
Context: ['ecommerce', 'shop', 'b2c']
Modules: [product-catalog, shopping-cart, checkout, payment]
UI: Product management, orders, customers

// Workspace 2: Blog
Context: ['blog', 'publishing', 'content']
Modules: [post-management, comments, authors, seo]
UI: Posts, categories, comments, media

// Workspace 3: Agency
Context: ['agency', 'client-management', 'projects']
Modules: [client-portal, project-tracker, invoicing]
UI: Clients, projects, invoices, reports
```

**Example 2: Hybrid Platform**

```php
// Single workspace with multiple contexts
Context: ['ecommerce', 'blog', 'membership']

// E-commerce modules active
Modules: [products, cart, checkout]

// Blog modules active
Modules: [posts, comments]

// Membership modules active
Modules: [subscriptions, access-control]

// UI shows all features
// Navigation includes: Shop, Blog, Members
```

**Example 3: Context-Based Routing**

```php
class Router
{
    public function dispatch(string $path): void
    {
        $context = $this->getContext();
        
        // Route based on context
        if (str_starts_with($path, '/shop') && in_array('ecommerce', $context)) {
            $this->routeToEcommerce($path);
        } elseif (str_starts_with($path, '/blog') && in_array('blog', $context)) {
            $this->routeToBlog($path);
        } else {
            $this->routeToDefault($path);
        }
    }
}
```

---

## Next Steps

Learn about data persistence:

→ [Data & Persistence](07-data-persistence.md)

Or explore security:

→ [Security & Performance](08-security-performance.md)
