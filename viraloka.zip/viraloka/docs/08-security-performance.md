# 8. Security & Performance

## 8.1 Security Baseline

### Permissions

Viraloka implements a capability-based permission system that extends WordPress capabilities.

**Core Capabilities:**

```php
// System-level capabilities
'manage_viraloka'      // Full platform access
'manage_workspaces'    // Create/edit workspaces
'delete_workspaces'    // Delete workspaces

// Workspace-level capabilities
'access_workspace'     // Access workspace
'manage_workspace_users' // Manage workspace members
'edit_workspace_settings' // Edit workspace config

// Module-specific capabilities
'manage_products'      // Manage products (e-commerce)
'edit_posts'          // Edit posts (blog)
'view_reports'        // View reports (analytics)
```

**Capability Registration:**

```json
// In module.json
{
  "capabilities": [
    "manage_products",
    "edit_products",
    "delete_products",
    "view_product_reports"
  ]
}
```

**Automatic Registration:**

```php
// Platform automatically registers capabilities on module activation
class CapabilityRegistry
{
    public function registerModuleCapabilities(Module $module): void
    {
        $capabilities = $module->getManifest()->getCapabilities();
        
        foreach ($capabilities as $capability) {
            // Add to administrator role
            $admin = get_role('administrator');
            $admin->add_cap($capability);
            
            // Store in registry
            $this->storage->set("capability_{$capability}", [
                'module' => $module->getId(),
                'registered_at' => time()
            ]);
        }
    }
}
```

**Permission Checks:**

```php
class ProductController
{
    public function __construct(
        private AuthAdapterInterface $auth
    ) {}
    
    public function create(): void
    {
        // Check capability
        $user = $this->auth->currentUser();
        
        if (!$this->auth->hasCapability($user->id, 'manage_products')) {
            throw new PermissionDeniedException(
                'You do not have permission to manage products'
            );
        }
        
        // Proceed with creation
        $this->productService->create($data);
    }
}
```

**Workspace-Scoped Permissions:**

```php
class WorkspacePermissionChecker
{
    public function canAccessWorkspace(int $userId, int $workspaceId): bool
    {
        // Check if user has workspace role
        $role = $this->workspaceUserRoleRepo->findByUserAndWorkspace(
            $userId,
            $workspaceId
        );
        
        return $role !== null;
    }
    
    public function canManageWorkspace(int $userId, int $workspaceId): bool
    {
        $role = $this->workspaceUserRoleRepo->findByUserAndWorkspace(
            $userId,
            $workspaceId
        );
        
        return $role && in_array($role->getRole(), ['owner', 'admin']);
    }
}
```

### Capability Mapping

**Role Hierarchy:**

```php
// System roles
System Admin
├── Full platform access
├── All workspaces access
└── All capabilities

// Workspace roles
Workspace Owner
├── Full workspace access
├── Manage workspace users
├── All workspace capabilities
└── Cannot access other workspaces

Workspace Admin
├── Manage workspace content
├── Limited user management
└── Cannot delete workspace

Workspace Member
├── Access workspace
├── Limited capabilities
└── Cannot manage workspace
```

**Capability Mapping Example:**

```php
class CapabilityMapper
{
    private array $roleCapabilities = [
        'system_admin' => [
            'manage_viraloka',
            'manage_workspaces',
            'delete_workspaces',
            '*' // All capabilities
        ],
        'workspace_owner' => [
            'access_workspace',
            'manage_workspace_users',
            'edit_workspace_settings',
            'manage_products',
            'edit_products',
            'delete_products',
        ],
        'workspace_admin' => [
            'access_workspace',
            'manage_products',
            'edit_products',
        ],
        'workspace_member' => [
            'access_workspace',
            'edit_products',
        ],
    ];
    
    public function getRoleCapabilities(string $role): array
    {
        return $this->roleCapabilities[$role] ?? [];
    }
    
    public function hasCapability(string $role, string $capability): bool
    {
        $capabilities = $this->getRoleCapabilities($role);
        
        // Check for wildcard
        if (in_array('*', $capabilities)) {
            return true;
        }
        
        return in_array($capability, $capabilities);
    }
}
```

## 8.2 Isolation Rules

### Module Isolation

Modules must be isolated from each other to prevent conflicts and security issues.

**Namespace Isolation:**

```php
// ✅ Good: Each module has own namespace
namespace ProductCatalog\Controllers;
namespace ShoppingCart\Controllers;
namespace Checkout\Controllers;

// ❌ Bad: Shared namespace
namespace App\Controllers; // All modules in same namespace
```

**Service Isolation:**

```php
// ✅ Good: Module registers own services
class ProductServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        $container->singleton(
            ProductRepositoryInterface::class,
            ProductRepository::class
        );
    }
}

// ❌ Bad: Module modifies other module's services
class ProductServiceProvider implements ServiceProviderInterface
{
    public function register(ContainerInterface $container): void
    {
        // Don't override services from other modules
        $container->singleton(
            CartServiceInterface::class, // From another module
            MyCustomCartService::class
        );
    }
}
```

**Data Isolation:**

```php
// ✅ Good: Module uses own tables
CREATE TABLE wp_viraloka_products (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    workspace_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(255)
);

// ✅ Good: Module queries own tables
$products = $this->storage->query('viraloka_products', [
    'workspace_id' => $workspaceId
]);

// ❌ Bad: Module queries other module's tables
$orders = $this->storage->query('viraloka_orders', []); // From another module
```

**Event Isolation:**

```php
// ✅ Good: Module dispatches namespaced events
$this->events->dispatch('product.created', $data);
$this->events->dispatch('product.updated', $data);

// ✅ Good: Module listens to public events
$this->events->listen('order.completed', function($data) {
    // Update product stock
});

// ❌ Bad: Module listens to internal events of other modules
$this->events->listen('cart.internal.recalculate', function($data) {
    // Don't listen to internal events
});
```

### Tenant Isolation

**Data Access Rules:**

```php
class TenantIsolationGuard
{
    public function validateAccess(int $userId, int $tenantId): void
    {
        // Get user's workspace
        $userWorkspace = $this->getUserWorkspace($userId);
        
        // Get tenant's workspace
        $tenant = $this->tenantRepo->find($tenantId);
        $tenantWorkspace = $tenant->getWorkspaceId();
        
        // Verify same workspace
        if ($userWorkspace !== $tenantWorkspace) {
            throw new CrossWorkspaceAccessException(
                'Cannot access tenant from different workspace'
            );
        }
        
        // Verify user has access to tenant
        if (!$this->hasAccessToTenant($userId, $tenantId)) {
            throw new PermissionDeniedException(
                'You do not have access to this tenant'
            );
        }
    }
    
    private function hasAccessToTenant(int $userId, int $tenantId): bool
    {
        // Check if user is workspace admin (access all tenants)
        if ($this->isWorkspaceAdmin($userId)) {
            return true;
        }
        
        // Check if user is assigned to tenant
        return $this->tenantUserRepo->exists($tenantId, $userId);
    }
}
```

**Query Filtering:**

```php
class TenantAwareQuery
{
    public function applyTenantFilter(array $conditions): array
    {
        $tenantId = $this->getCurrentTenantId();
        
        if ($tenantId) {
            $conditions['tenant_id'] = $tenantId;
        }
        
        return $conditions;
    }
    
    public function findProducts(): array
    {
        $conditions = $this->applyTenantFilter([
            'status' => 'active'
        ]);
        
        return $this->storage->query('products', $conditions);
    }
}
```

**Cross-Tenant Prevention:**

```php
// ✅ Good: Tenant-scoped query
SELECT * FROM products 
WHERE workspace_id = ? AND tenant_id = ?

// ❌ Bad: Cross-tenant query
SELECT * FROM products 
WHERE workspace_id = ?
-- Missing tenant_id filter!
```

## 8.3 Performance Principles

### Lazy Loading

**Module Lazy Loading:**

```php
class ModuleBootstrapper
{
    public function bootstrap(Module $module): void
    {
        // Don't load module immediately
        // Register lazy loader instead
        
        $this->container->bind(
            $module->getServiceProviderClass(),
            function($container) use ($module) {
                // Only instantiate when needed
                return new ($module->getServiceProviderClass())();
            }
        );
    }
}
```

**Service Lazy Loading:**

```php
class Container
{
    public function singleton(string $abstract, $concrete): void
    {
        $this->bindings[$abstract] = [
            'concrete' => $concrete,
            'shared' => true,
            'instance' => null, // Not created yet
        ];
    }
    
    public function make(string $abstract)
    {
        $binding = $this->bindings[$abstract];
        
        // Return cached instance if exists
        if ($binding['instance'] !== null) {
            return $binding['instance'];
        }
        
        // Create instance only when first requested
        $instance = $this->build($binding['concrete']);
        
        if ($binding['shared']) {
            $this->bindings[$abstract]['instance'] = $instance;
        }
        
        return $instance;
    }
}
```

**Asset Lazy Loading:**

```php
class AssetManager
{
    public function enqueueConditional(string $handle, string $context): void
    {
        // Only load assets when context matches
        $this->events->listen('wp_enqueue_scripts', function() use ($handle, $context) {
            $currentContext = $this->container->make('current.context');
            
            if (in_array($context, $currentContext)) {
                wp_enqueue_script($handle);
            }
        });
    }
}
```

### No Global State

**Avoid Global Variables:**

```php
// ❌ Bad: Global state
global $viraloka_products;
$viraloka_products[] = $product;

// ✅ Good: Container-managed state
class ProductRegistry
{
    private array $products = [];
    
    public function register(Product $product): void
    {
        $this->products[] = $product;
    }
}

// Register as singleton
$container->singleton(ProductRegistry::class);
```

**Avoid Static State:**

```php
// ❌ Bad: Static state
class ProductManager
{
    private static array $products = [];
    
    public static function add(Product $product): void
    {
        self::$products[] = $product;
    }
}

// ✅ Good: Instance state
class ProductManager
{
    private array $products = [];
    
    public function add(Product $product): void
    {
        $this->products[] = $product;
    }
}
```

**Stateless Services:**

```php
// ✅ Good: Stateless service
class PriceCalculator
{
    public function calculate(Product $product, Customer $customer): Money
    {
        // No internal state
        // Pure function based on inputs
        
        $basePrice = $product->getPrice();
        $discount = $this->getCustomerDiscount($customer);
        
        return $basePrice->multiply(1 - $discount);
    }
}
```

**Performance Best Practices:**

✅ **DO:**

**Cache Expensive Operations:**
```php
class ContextResolver
{
    private ?array $cachedContext = null;
    
    public function resolve(): array
    {
        if ($this->cachedContext !== null) {
            return $this->cachedContext;
        }
        
        $this->cachedContext = $this->performResolution();
        return $this->cachedContext;
    }
}
```

**Use Database Indexes:**
```sql
CREATE INDEX idx_workspace_tenant ON products(workspace_id, tenant_id);
CREATE INDEX idx_status ON products(status);
CREATE INDEX idx_created_at ON products(created_at);
```

**Batch Operations:**
```php
// ✅ Good: Batch insert
$this->storage->insertBatch('products', $products);

// ❌ Bad: Individual inserts
foreach ($products as $product) {
    $this->storage->insert('products', $product);
}
```

**Eager Load Relations:**
```php
// ✅ Good: Eager load
$products = $this->productRepo->findAllWithCategories();

// ❌ Bad: N+1 queries
$products = $this->productRepo->findAll();
foreach ($products as $product) {
    $category = $this->categoryRepo->find($product->getCategoryId());
}
```

❌ **DON'T:**

**Don't Query in Loops:**
```php
// ❌ Bad
foreach ($productIds as $id) {
    $product = $this->storage->query('products', ['id' => $id]);
}

// ✅ Good
$products = $this->storage->query('products', [
    'id' => ['IN', $productIds]
]);
```

**Don't Load Unnecessary Data:**
```php
// ❌ Bad: Load all fields
SELECT * FROM products WHERE workspace_id = ?

// ✅ Good: Load only needed fields
SELECT id, name, price FROM products WHERE workspace_id = ?
```

**Don't Perform Heavy Operations on Every Request:**
```php
// ❌ Bad: Calculate on every request
public function getStats(): array
{
    return [
        'total_products' => $this->countProducts(),
        'total_orders' => $this->countOrders(),
        'revenue' => $this->calculateRevenue(),
    ];
}

// ✅ Good: Cache results
public function getStats(): array
{
    return $this->cache->remember('workspace_stats', 3600, function() {
        return [
            'total_products' => $this->countProducts(),
            'total_orders' => $this->countOrders(),
            'revenue' => $this->calculateRevenue(),
        ];
    });
}
```

---

## Next Steps

Explore canonical applications:

→ [Canonical Applications](09-canonical-applications.md)

Or learn about anti-patterns:

→ [Anti-Patterns & Common Mistakes](10-anti-patterns.md)
