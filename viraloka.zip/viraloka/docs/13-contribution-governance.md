# 13. Contribution & Governance

## 13.1 Contribution Rules

### PR Checklist

Before submitting a pull request, ensure all items are checked:

**Code Quality:**
- [ ] Code follows PSR-12 coding standards
- [ ] All classes have proper docblocks
- [ ] No unused imports or variables
- [ ] Proper type hints on all methods
- [ ] No mixed return types without documentation

**Testing:**
- [ ] Unit tests added for new functionality
- [ ] All existing tests pass
- [ ] Test coverage maintained or improved
- [ ] Integration tests added if applicable
- [ ] Property-based tests for core logic

**Documentation:**
- [ ] Public methods documented
- [ ] README updated if needed
- [ ] CHANGELOG updated
- [ ] Migration guide provided for breaking changes
- [ ] Examples added for new features

**Architecture:**
- [ ] No WordPress functions in core
- [ ] Adapters used for host integration
- [ ] Workspace filtering applied where needed
- [ ] Events used for module communication
- [ ] No global state or static properties

**Security:**
- [ ] Input validation implemented
- [ ] Output sanitization applied
- [ ] Capability checks in place
- [ ] SQL injection prevention
- [ ] XSS prevention

**Performance:**
- [ ] No N+1 query problems
- [ ] Database indexes added if needed
- [ ] Lazy loading used appropriately
- [ ] No unnecessary computations in loops
- [ ] Caching implemented for expensive operations

### Contract Enforcement

**Core Contract Validation:**

All contributions to core must pass contract validation:

```php
// Automated check in CI/CD
class CoreContractValidator
{
    public function validate(string $filePath): ValidationResult
    {
        $content = file_get_contents($filePath);
        $violations = [];
        
        // Check for WordPress functions
        if (preg_match('/\b(wp_|get_|add_|do_|apply_filters|add_filter)\b/', $content)) {
            $violations[] = 'WordPress functions found in core';
        }
        
        // Check for global variables
        if (preg_match('/global \$/', $content)) {
            $violations[] = 'Global variables found in core';
        }
        
        // Check for superglobals
        if (preg_match('/\$_(SERVER|POST|GET|REQUEST|COOKIE|SESSION)/', $content)) {
            $violations[] = 'Superglobals found in core';
        }
        
        // Check for direct database access
        if (preg_match('/\$wpdb|mysqli_|pg_/', $content)) {
            $violations[] = 'Direct database access found in core';
        }
        
        return new ValidationResult(
            isValid: empty($violations),
            violations: $violations
        );
    }
}
```

**Adapter Contract Validation:**

Adapters must implement all interface methods:

```php
class AdapterContractValidator
{
    public function validate(string $adapterClass, string $interfaceClass): ValidationResult
    {
        $reflection = new ReflectionClass($adapterClass);
        $interface = new ReflectionClass($interfaceClass);
        
        $violations = [];
        
        // Check if implements interface
        if (!$reflection->implementsInterface($interfaceClass)) {
            $violations[] = "Adapter does not implement {$interfaceClass}";
        }
        
        // Check all interface methods are implemented
        foreach ($interface->getMethods() as $method) {
            if (!$reflection->hasMethod($method->getName())) {
                $violations[] = "Missing method: {$method->getName()}";
            }
        }
        
        // Check method signatures match
        foreach ($interface->getMethods() as $interfaceMethod) {
            if ($reflection->hasMethod($interfaceMethod->getName())) {
                $adapterMethod = $reflection->getMethod($interfaceMethod->getName());
                
                if (!$this->signaturesMatch($interfaceMethod, $adapterMethod)) {
                    $violations[] = "Method signature mismatch: {$interfaceMethod->getName()}";
                }
            }
        }
        
        return new ValidationResult(
            isValid: empty($violations),
            violations: $violations
        );
    }
}
```

**Module Manifest Validation:**

All modules must have valid manifests:

```php
class ManifestValidator
{
    private array $requiredFields = [
        'id',
        'name',
        'version',
        'type',
        'bootstrap.provider'
    ];
    
    public function validate(array $manifest): ValidationResult
    {
        $violations = [];
        
        // Check required fields
        foreach ($this->requiredFields as $field) {
            if (!$this->hasField($manifest, $field)) {
                $violations[] = "Missing required field: {$field}";
            }
        }
        
        // Validate ID format
        if (isset($manifest['id']) && !preg_match('/^[a-z0-9-]+$/', $manifest['id'])) {
            $violations[] = 'ID must be kebab-case';
        }
        
        // Validate version format
        if (isset($manifest['version']) && !preg_match('/^\d+\.\d+\.\d+$/', $manifest['version'])) {
            $violations[] = 'Version must follow semver (x.y.z)';
        }
        
        // Validate type
        $validTypes = ['feature', 'application', 'integration', 'internal'];
        if (isset($manifest['type']) && !in_array($manifest['type'], $validTypes)) {
            $violations[] = 'Invalid type. Must be: ' . implode(', ', $validTypes);
        }
        
        // Validate dependencies
        if (isset($manifest['dependencies']['requires'])) {
            foreach ($manifest['dependencies']['requires'] as $module => $version) {
                if (!preg_match('/^[\^~]?\d+\.\d+(\.\d+)?$/', $version)) {
                    $violations[] = "Invalid version constraint for {$module}";
                }
            }
        }
        
        return new ValidationResult(
            isValid: empty($violations),
            violations: $violations
        );
    }
}
```

### Code Review Process

**1. Automated Checks (CI/CD):**

```yaml
# .github/workflows/pr-checks.yml
name: PR Checks

on: [pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Install dependencies
        run: composer install
      
      - name: Run PHPStan
        run: vendor/bin/phpstan analyse
      
      - name: Run PHP CS Fixer
        run: vendor/bin/php-cs-fixer fix --dry-run --diff
      
      - name: Run Core Contract Validator
        run: php scripts/validate-core-contracts.php
      
      - name: Run Tests
        run: vendor/bin/phpunit
      
      - name: Check Test Coverage
        run: vendor/bin/phpunit --coverage-text --coverage-clover=coverage.xml
```

**2. Manual Review:**

Reviewers check for:

- **Architecture Compliance:**
  - Core isolation maintained
  - Adapters used correctly
  - Module boundaries respected
  - Context system used appropriately

- **Code Quality:**
  - Clean, readable code
  - Proper abstractions
  - No code duplication
  - Appropriate design patterns

- **Security:**
  - No SQL injection vulnerabilities
  - No XSS vulnerabilities
  - Proper input validation
  - Capability checks in place

- **Performance:**
  - No obvious performance issues
  - Efficient database queries
  - Appropriate caching
  - No memory leaks

**3. Approval Requirements:**

- At least 2 approvals from core maintainers
- All automated checks passing
- No unresolved comments
- Documentation updated
- CHANGELOG updated

## 13.2 Versioning

### Core Versioning

Viraloka core follows semantic versioning (semver):

**Format:** `MAJOR.MINOR.PATCH`

**MAJOR version** (1.0.0 → 2.0.0):
- Breaking changes to public APIs
- Incompatible adapter interface changes
- Major architectural changes
- Requires module updates

**MINOR version** (1.0.0 → 1.1.0):
- New features added
- New adapter methods (with defaults)
- New events added
- Backward compatible changes

**PATCH version** (1.0.0 → 1.0.1):
- Bug fixes
- Security patches
- Performance improvements
- Documentation updates

**Examples:**

```
1.0.0 → 1.0.1: Bug fix in context resolver
1.0.1 → 1.1.0: Added new storage adapter method
1.1.0 → 2.0.0: Changed AuthAdapter interface (breaking)
```

### Module Compatibility

**Declaring Compatibility:**

```json
{
  "id": "my-module",
  "version": "2.1.0",
  "dependencies": {
    "requires": {
      "viraloka-core": "^1.0"
    }
  }
}
```

**Version Constraints:**

```
^1.0    = >=1.0.0 <2.0.0  (compatible with 1.x)
^1.2    = >=1.2.0 <2.0.0  (requires at least 1.2)
~1.2    = >=1.2.0 <1.3.0  (compatible with 1.2.x)
~1.2.3  = >=1.2.3 <1.3.0  (requires at least 1.2.3)
1.2.*   = >=1.2.0 <1.3.0  (any 1.2.x version)
>=1.2   = >=1.2.0         (at least 1.2)
```

**Compatibility Matrix:**

| Core Version | Module Version | Compatible? |
|--------------|----------------|-------------|
| 1.0.0        | ^1.0           | ✅ Yes      |
| 1.5.0        | ^1.0           | ✅ Yes      |
| 2.0.0        | ^1.0           | ❌ No       |
| 1.2.0        | ^1.3           | ❌ No       |
| 1.5.0        | ~1.2           | ✅ Yes      |

**Checking Compatibility:**

```php
class CompatibilityChecker
{
    public function isCompatible(string $moduleVersion, string $coreVersion): bool
    {
        $constraint = $this->parseConstraint($moduleVersion);
        return $this->satisfies($coreVersion, $constraint);
    }
    
    public function checkAllModules(): array
    {
        $incompatible = [];
        $coreVersion = $this->getCoreVersion();
        
        foreach ($this->getInstalledModules() as $module) {
            $required = $module->getManifest()->getRequiredCoreVersion();
            
            if (!$this->isCompatible($required, $coreVersion)) {
                $incompatible[] = [
                    'module' => $module->getId(),
                    'requires' => $required,
                    'current' => $coreVersion
                ];
            }
        }
        
        return $incompatible;
    }
}
```

### Deprecation Policy

**Deprecation Process:**

1. **Announce Deprecation** (Minor version):
   ```php
   /**
    * @deprecated since 1.5.0, use newMethod() instead
    * @see newMethod()
    */
   public function oldMethod(): void
   {
       trigger_error(
           'oldMethod() is deprecated, use newMethod() instead',
           E_USER_DEPRECATED
       );
       
       $this->newMethod();
   }
   ```

2. **Maintain for One Major Version:**
   - Deprecated in 1.5.0
   - Maintained through 1.x
   - Removed in 2.0.0

3. **Document in CHANGELOG:**
   ```markdown
   ## [1.5.0] - 2024-01-15
   
   ### Deprecated
   - `AuthAdapter::oldMethod()` - Use `AuthAdapter::newMethod()` instead
   - Will be removed in 2.0.0
   ```

4. **Provide Migration Guide:**
   ```markdown
   # Migration Guide: 1.x to 2.0
   
   ## AuthAdapter Changes
   
   ### Before (1.x):
   ```php
   $adapter->oldMethod();
   ```
   
   ### After (2.0):
   ```php
   $adapter->newMethod();
   ```
   ```

**Deprecation Timeline:**

```
Version 1.5.0: Feature deprecated, warning added
Version 1.6.0: Still available, warning remains
Version 1.9.0: Still available, warning remains
Version 2.0.0: Feature removed
```

### Release Process

**1. Prepare Release:**
- Update version in `composer.json`
- Update CHANGELOG.md
- Update documentation
- Run full test suite
- Check compatibility

**2. Create Release Branch:**
```bash
git checkout -b release/1.5.0
git push origin release/1.5.0
```

**3. Tag Release:**
```bash
git tag -a v1.5.0 -m "Release version 1.5.0"
git push origin v1.5.0
```

**4. Publish Release:**
- Create GitHub release
- Publish to Packagist
- Update documentation site
- Announce on community channels

**5. Post-Release:**
- Monitor for issues
- Prepare hotfix if needed
- Update roadmap
- Plan next release

---

## Next Steps

Explore the roadmap:

→ [Roadmap & Evolution](14-roadmap-evolution.md)

Or return to the beginning:

→ [Introduction](01-introduction.md)
