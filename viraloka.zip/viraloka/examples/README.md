# Context Resolver Examples

This directory contains practical examples demonstrating how to use the Context Resolver system in the Viraloka Core platform.

## Running the Examples

Each example is a standalone PHP script that can be run from the command line:

```bash
php examples/01-basic-context-resolution.php
php examples/02-registering-recommendations.php
php examples/03-container-integration.php
php examples/04-module-querying-context.php
php examples/05-workspace-hooks-usage.php
```

## Example Overview

### 01 - Basic Context Resolution

**File:** `01-basic-context-resolution.php`

Demonstrates the fundamental flow of context resolution:
- Setting up workspace and theme providers
- Creating a ContextResolver instance
- Resolving context from multiple sources
- Querying the context stack

**Key Concepts:**
- Context resolution flow
- Priority ordering (workspace > theme > default)
- Querying contexts by key

---

### 02 - Registering Recommendations

**File:** `02-registering-recommendations.php`

Shows how to use the RecommendationGraph to provide context-based hints:
- Registering recommendations for different contexts
- Querying recommended modules
- Querying optional integrations
- Accessing UI hints
- Handling non-existent contexts

**Key Concepts:**
- Recommendation graph structure
- Context-specific module suggestions
- Graceful handling of missing recommendations

---

### 03 - Container Integration

**File:** `03-container-integration.php`

Demonstrates context-aware dependency injection:
- Creating a ContextAwareContainer
- Binding context-specific service implementations
- Resolving services based on active context
- Fallback to default implementations

**Key Concepts:**
- Context-aware service binding
- Multiple implementations per interface
- Automatic context-based resolution

---

### 04 - Module Querying Context

**File:** `04-module-querying-context.php`

Shows how modules can adapt their behavior based on context:
- Querying the context stack from within a module
- Adapting functionality based on active contexts
- Accessing recommendations for the current context
- Context-aware feature toggling

**Key Concepts:**
- Module context awareness
- Behavioral adaptation without coupling
- Context-based feature configuration

---

### 05 - Workspace Hooks Usage

**File:** `05-workspace-hooks-usage.php`

Demonstrates the WorkspaceHooks system for resource limits and billing:
- Enforcing usage limits (API calls, storage, users)
- Controlling feature access based on workspace plan
- Recording usage for billing/metering
- Triggering billing events
- Integrating with external billing systems

**Key Concepts:**
- Usage limit enforcement
- Feature limit control
- Usage recording for billing
- Billing event triggers
- Multiple handler composition
- External system integration

## Common Patterns

### Creating a Context Resolver

```php
use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\RecommendationGraph;

$resolver = new ContextResolver(
    $workspaceResolver,
    $themeProvider,
    new ContextStackBuilder(),
    new RecommendationGraph()
);

$contextStack = $resolver->resolve();
```

### Querying Context

```php
// Get primary context
$primary = $resolver->getPrimaryContext();

// Check if specific context exists
if ($resolver->getContextStack()->hasContext('marketplace')) {
    // Do marketplace-specific logic
}

// Get all contexts
$allContexts = $resolver->getContextStack()->getAll();
```

### Registering Recommendations

```php
$graph = new RecommendationGraph();

$graph->register('marketplace', [
    'recommended_modules' => ['payment', 'inventory'],
    'optional_integrations' => ['analytics'],
    'ui_hints' => ['show_product_grid' => true]
]);
```

### Context-Aware Container Binding

```php
$container = new ContextAwareContainer($resolver, $baseContainer);

$container->bindContextual(
    ServiceInterface::class,
    [
        'context-a' => fn() => new ImplementationA(),
        'context-b' => fn() => new ImplementationB(),
    ],
    fn() => new DefaultImplementation()
);

$service = $container->resolve(ServiceInterface::class);
```

## Best Practices

1. **Don't couple to specific contexts**: Modules should query context but not assume specific values exist
2. **Always provide fallbacks**: Use default implementations when context-specific ones aren't available
3. **Keep contexts semantic**: Use use-case identifiers (e.g., 'marketplace') not technical names (e.g., 'module-x')
4. **Immutability**: Never attempt to modify the context stack after resolution
5. **Query, don't control**: Modules query context, they don't set or change it

## Further Reading

- See `docs/context-resolver.md` for architectural overview
- See `.kiro/specs/context-resolver/design.md` for detailed design documentation
- See `.kiro/specs/context-resolver/requirements.md` for requirements specification
