<?php

/**
 * Example 3: Container Integration
 * 
 * This example demonstrates how to use the ContextAwareContainer
 * to bind different service implementations based on context.
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\RecommendationGraph;
use Viraloka\Core\Context\ContextAwareContainer;
use Viraloka\Core\Context\WorkspaceContext;
use Viraloka\Container\Container;

// Define a service interface
interface PaymentGateway {
    public function processPayment(float $amount): string;
}

// Define context-specific implementations
class StripePaymentGateway implements PaymentGateway {
    public function processPayment(float $amount): string {
        return "Processing \${$amount} via Stripe";
    }
}

class PayPalPaymentGateway implements PaymentGateway {
    public function processPayment(float $amount): string {
        return "Processing \${$amount} via PayPal";
    }
}

class DefaultPaymentGateway implements PaymentGateway {
    public function processPayment(float $amount): string {
        return "Processing \${$amount} via default gateway";
    }
}

// Set up context resolver with a specific context
$workspaceResolver = new class implements \Viraloka\Container\Contracts\WorkspaceResolverInterface {
    public function resolve(): ?\Viraloka\Core\Workspace\Workspace {
        return new \Viraloka\Core\Workspace\Workspace(
            'ws_123',
            'My Store',
            ['context' => 'marketplace']
        );
    }
};

$themeProvider = new class {
    public function getCurrentTheme(): ?object {
        return null;
    }
};

$stackBuilder = new ContextStackBuilder();
$recommendationGraph = new RecommendationGraph();
$resolver = new ContextResolver(
    $workspaceResolver,
    $themeProvider,
    $stackBuilder,
    $recommendationGraph
);

// Resolve context
$resolver->resolve();

// Create context-aware container
$baseContainer = new Container();
$container = new ContextAwareContainer($resolver, $baseContainer);

// Bind context-specific implementations
$container->bindContextual(
    PaymentGateway::class,
    [
        'marketplace' => function() {
            return new StripePaymentGateway();
        },
        'subscription' => function() {
            return new PayPalPaymentGateway();
        }
    ],
    function() {
        return new DefaultPaymentGateway();
    }
);

// Resolve the service (will use Stripe because context is 'marketplace')
$paymentGateway = $container->resolve(PaymentGateway::class);

echo "Container Integration Example:\n";
echo "==============================\n\n";
echo "Current Context: " . $resolver->getPrimaryContext()->getKey() . "\n";
echo "Resolved Service: " . get_class($paymentGateway) . "\n";
echo "Payment Result: " . $paymentGateway->processPayment(99.99) . "\n\n";

// Example: Change context and resolve again
echo "Changing context to 'subscription'...\n";
$workspaceResolver2 = new class implements \Viraloka\Container\Contracts\WorkspaceResolverInterface {
    public function resolve(): ?\Viraloka\Core\Workspace\Workspace {
        return new \Viraloka\Core\Workspace\Workspace(
            'ws_456',
            'Subscription Service',
            ['context' => 'subscription']
        );
    }
};

$resolver2 = new ContextResolver(
    $workspaceResolver2,
    $themeProvider,
    $stackBuilder,
    $recommendationGraph
);
$resolver2->resolve();

$container2 = new ContextAwareContainer($resolver2, $baseContainer);
$container2->bindContextual(
    PaymentGateway::class,
    [
        'marketplace' => function() {
            return new StripePaymentGateway();
        },
        'subscription' => function() {
            return new PayPalPaymentGateway();
        }
    ],
    function() {
        return new DefaultPaymentGateway();
    }
);

$paymentGateway2 = $container2->resolve(PaymentGateway::class);
echo "New Context: " . $resolver2->getPrimaryContext()->getKey() . "\n";
echo "Resolved Service: " . get_class($paymentGateway2) . "\n";
echo "Payment Result: " . $paymentGateway2->processPayment(49.99) . "\n";
