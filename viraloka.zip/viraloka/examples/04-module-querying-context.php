<?php

/**
 * Example 4: Module Querying Context
 * 
 * This example shows how modules can query the context stack
 * to adapt their behavior without being coupled to specific contexts.
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\RecommendationGraph;

// Define a module that adapts based on context
class AnalyticsModule {
    private ContextResolver $contextResolver;
    
    public function __construct(ContextResolver $contextResolver) {
        $this->contextResolver = $contextResolver;
    }
    
    public function getTrackingEvents(): array {
        $contextStack = $this->contextResolver->getContextStack();
        $events = ['page_view']; // Always track page views
        
        // Adapt based on context
        if ($contextStack->hasContext('marketplace')) {
            $events[] = 'product_view';
            $events[] = 'add_to_cart';
            $events[] = 'purchase';
        }
        
        if ($contextStack->hasContext('ai-service')) {
            $events[] = 'api_call';
            $events[] = 'rate_limit_hit';
        }
        
        if ($contextStack->hasContext('link-in-bio')) {
            $events[] = 'link_click';
            $events[] = 'profile_view';
        }
        
        return $events;
    }
    
    public function getRecommendedIntegrations(): array {
        $primaryContext = $this->contextResolver->getPrimaryContext();
        
        if (!$primaryContext) {
            return [];
        }
        
        $recommendations = $this->contextResolver->getRecommendations();
        return $recommendations['optional_integrations'] ?? [];
    }
}

// Set up context resolver
$workspaceResolver = new class implements \Viraloka\Container\Contracts\WorkspaceResolverInterface {
    public function resolve(): ?\Viraloka\Core\Workspace\Workspace {
        return new \Viraloka\Core\Workspace\Workspace(
            'ws_123',
            'My Store',
            ['context' => 'marketplace']
        );
    }
};

$themeProvider = new class {
    public function getCurrentTheme(): ?object {
        return new class {
            public function getContext(): string {
                return 'digital';
            }
        };
    }
};

$stackBuilder = new ContextStackBuilder();
$recommendationGraph = new RecommendationGraph();

// Register recommendations
$recommendationGraph->register('marketplace', [
    'recommended_modules' => ['payment', 'inventory'],
    'optional_integrations' => ['analytics', 'email', 'shipping'],
    'ui_hints' => ['show_product_grid' => true]
]);

$resolver = new ContextResolver(
    $workspaceResolver,
    $themeProvider,
    $stackBuilder,
    $recommendationGraph
);

// Resolve context
$resolver->resolve();

// Create and use the module
$analyticsModule = new AnalyticsModule($resolver);

echo "Module Querying Context Example:\n";
echo "=================================\n\n";

echo "Current Context Stack:\n";
foreach ($resolver->getContextStack()->getAll() as $context) {
    echo "  - {$context->getKey()} (priority: {$context->getPriority()})\n";
}

echo "\nTracking Events (adapted to context):\n";
foreach ($analyticsModule->getTrackingEvents() as $event) {
    echo "  - {$event}\n";
}

echo "\nRecommended Integrations:\n";
$integrations = $analyticsModule->getRecommendedIntegrations();
if (empty($integrations)) {
    echo "  None\n";
} else {
    foreach ($integrations as $integration) {
        echo "  - {$integration}\n";
    }
}

// Example: Module behavior with different context
echo "\n\n--- Changing to AI Service Context ---\n\n";

$workspaceResolver2 = new class implements \Viraloka\Container\Contracts\WorkspaceResolverInterface {
    public function resolve(): ?\Viraloka\Core\Workspace\Workspace {
        return new \Viraloka\Core\Workspace\Workspace(
            'ws_456',
            'AI Platform',
            ['context' => 'ai-service']
        );
    }
};

$recommendationGraph2 = new RecommendationGraph();
$recommendationGraph2->register('ai-service', [
    'recommended_modules' => ['api', 'rate-limiter'],
    'optional_integrations' => ['monitoring', 'logging'],
    'ui_hints' => ['show_api_docs' => true]
]);

$resolver2 = new ContextResolver(
    $workspaceResolver2,
    $themeProvider,
    $stackBuilder,
    $recommendationGraph2
);

$resolver2->resolve();
$analyticsModule2 = new AnalyticsModule($resolver2);

echo "Current Context Stack:\n";
foreach ($resolver2->getContextStack()->getAll() as $context) {
    echo "  - {$context->getKey()} (priority: {$context->getPriority()})\n";
}

echo "\nTracking Events (adapted to new context):\n";
foreach ($analyticsModule2->getTrackingEvents() as $event) {
    echo "  - {$event}\n";
}

echo "\nRecommended Integrations:\n";
$integrations2 = $analyticsModule2->getRecommendedIntegrations();
if (empty($integrations2)) {
    echo "  None\n";
} else {
    foreach ($integrations2 as $integration) {
        echo "  - {$integration}\n";
    }
}
