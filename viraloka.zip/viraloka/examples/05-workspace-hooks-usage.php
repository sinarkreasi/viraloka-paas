<?php

/**
 * Example: Using Workspace Hooks for Resource Limits and Billing
 * 
 * This example demonstrates how to use the WorkspaceHooks system to:
 * 1. Enforce usage limits (e.g., API calls, storage)
 * 2. Control feature access (e.g., custom domains, advanced analytics)
 * 3. Record usage for billing/metering
 * 4. Trigger billing events
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Viraloka\Core\Workspace\WorkspaceHooks;
use Viraloka\Core\Workspace\Workspace;

// Create a workspace hooks instance
$hooks = new WorkspaceHooks();

// Register the hooks
$hooks->register();

// Create a test workspace
$workspace = new Workspace(
    workspaceId: 'workspace-123',
    tenantId: 'tenant-456',
    name: 'Acme Corp Workspace',
    slug: 'acme-corp',
    status: Workspace::STATUS_ACTIVE,
    activeContext: 'production'
);

echo "=== Workspace Hooks Example ===\n\n";

// ============================================================================
// Example 1: Usage Limit Enforcement
// ============================================================================

echo "1. Usage Limit Enforcement\n";
echo "----------------------------\n";

// Register a usage limit handler
$hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
    // Define limits per resource type
    $limits = [
        'api_calls' => 10000,
        'storage_mb' => 5000,
        'users' => 50,
    ];
    
    $limit = $limits[$resourceType] ?? PHP_FLOAT_MAX;
    
    // Return true if limit is exceeded
    return $currentUsage > $limit;
});

// Check if workspace has exceeded API call limit
$apiCallsUsage = 8500;
$isExceeded = $hooks->checkUsageLimit($workspace, 'api_calls', $apiCallsUsage);
echo "API Calls: {$apiCallsUsage} / 10000 - " . ($isExceeded ? "EXCEEDED" : "OK") . "\n";

$apiCallsUsage = 12000;
$isExceeded = $hooks->checkUsageLimit($workspace, 'api_calls', $apiCallsUsage);
echo "API Calls: {$apiCallsUsage} / 10000 - " . ($isExceeded ? "EXCEEDED" : "OK") . "\n";

echo "\n";

// ============================================================================
// Example 2: Feature Limit Control
// ============================================================================

echo "2. Feature Limit Control\n";
echo "-------------------------\n";

// Register a feature limit handler based on workspace plan
$hooks->onFeatureLimitCheck(function (Workspace $workspace, string $featureName): bool {
    // Simulate getting plan from database
    $workspacePlan = 'basic'; // Could be: basic, pro, enterprise
    
    // Define feature availability per plan
    $featureMatrix = [
        'basic' => ['api_access', 'basic_analytics'],
        'pro' => ['api_access', 'basic_analytics', 'custom_domain', 'advanced_analytics'],
        'enterprise' => ['api_access', 'basic_analytics', 'custom_domain', 'advanced_analytics', 'white_label', 'sso'],
    ];
    
    $availableFeatures = $featureMatrix[$workspacePlan] ?? [];
    
    // Return true if feature is available
    return in_array($featureName, $availableFeatures, true);
});

// Check feature availability
$features = ['api_access', 'custom_domain', 'white_label'];
foreach ($features as $feature) {
    $isAvailable = $hooks->checkFeatureLimit($workspace, $feature);
    echo "Feature '{$feature}': " . ($isAvailable ? "AVAILABLE" : "NOT AVAILABLE") . "\n";
}

echo "\n";

// ============================================================================
// Example 3: Usage Recording for Billing
// ============================================================================

echo "3. Usage Recording for Billing\n";
echo "-------------------------------\n";

// Register a usage recording handler
$usageLog = [];
$hooks->onRecordUsage(function (Workspace $workspace, string $resourceType, float $amount, array $metadata) use (&$usageLog) {
    // Store usage data for billing
    $usageLog[] = [
        'workspace_id' => $workspace->workspaceId,
        'resource_type' => $resourceType,
        'amount' => $amount,
        'timestamp' => $metadata['timestamp'],
        'metadata' => $metadata,
    ];
    
    echo "Recorded: {$resourceType} = {$amount} for workspace {$workspace->name}\n";
});

// Record various types of usage
$hooks->recordUsage($workspace, 'api_calls', 150, ['endpoint' => '/api/users', 'method' => 'GET']);
$hooks->recordUsage($workspace, 'storage_mb', 25, ['file_type' => 'image', 'operation' => 'upload']);
$hooks->recordUsage($workspace, 'email_sends', 100, ['campaign_id' => 'campaign-789']);

echo "\nTotal usage records: " . count($usageLog) . "\n";

echo "\n";

// ============================================================================
// Example 4: Billing Events
// ============================================================================

echo "4. Billing Events\n";
echo "------------------\n";

// Register a billing event handler
$billingEvents = [];
$hooks->onBillingEvent(function (Workspace $workspace, string $eventType, array $eventData) use (&$billingEvents) {
    // Send event to billing system
    $billingEvents[] = [
        'workspace_id' => $workspace->workspaceId,
        'event_type' => $eventType,
        'event_data' => $eventData,
        'timestamp' => $eventData['timestamp'],
    ];
    
    echo "Billing Event: {$eventType} for workspace {$workspace->name}\n";
});

// Trigger various billing events
$hooks->triggerBillingEvent($workspace, 'workspace_created', ['plan' => 'basic', 'trial_days' => 14]);
$hooks->triggerBillingEvent($workspace, 'plan_upgraded', ['from_plan' => 'basic', 'to_plan' => 'pro']);
$hooks->triggerBillingEvent($workspace, 'workspace_suspended', ['reason' => 'payment_failed']);

echo "\nTotal billing events: " . count($billingEvents) . "\n";

echo "\n";

// ============================================================================
// Example 5: Multiple Handlers
// ============================================================================

echo "5. Multiple Handlers (Composite Logic)\n";
echo "---------------------------------------\n";

// Clear previous handlers
$hooks->clearHandlers();

// Register multiple usage limit handlers for different checks
$hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
    // Check daily limit
    $dailyLimits = ['api_calls' => 1000];
    $dailyLimit = $dailyLimits[$resourceType] ?? PHP_FLOAT_MAX;
    
    if ($currentUsage > $dailyLimit) {
        echo "  - Daily limit check: EXCEEDED\n";
        return true;
    }
    
    echo "  - Daily limit check: OK\n";
    return false;
});

$hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
    // Check monthly limit
    $monthlyLimits = ['api_calls' => 10000];
    $monthlyLimit = $monthlyLimits[$resourceType] ?? PHP_FLOAT_MAX;
    
    if ($currentUsage > $monthlyLimit) {
        echo "  - Monthly limit check: EXCEEDED\n";
        return true;
    }
    
    echo "  - Monthly limit check: OK\n";
    return false;
});

echo "Checking API calls with 500 usage:\n";
$isExceeded = $hooks->checkUsageLimit($workspace, 'api_calls', 500);
echo "Result: " . ($isExceeded ? "EXCEEDED" : "OK") . "\n\n";

echo "Checking API calls with 1500 usage:\n";
$isExceeded = $hooks->checkUsageLimit($workspace, 'api_calls', 1500);
echo "Result: " . ($isExceeded ? "EXCEEDED" : "OK") . "\n";

echo "\n";

// ============================================================================
// Example 6: Integration with External Systems
// ============================================================================

echo "6. Integration with External Systems\n";
echo "-------------------------------------\n";

// Clear previous handlers
$hooks->clearHandlers();

// Simulate integration with external billing API
class BillingAPI {
    public static function checkQuota(string $workspaceId, string $resourceType): array {
        // Simulate API call
        return [
            'limit' => 10000,
            'used' => 8500,
            'remaining' => 1500,
        ];
    }
    
    public static function recordUsage(string $workspaceId, string $resourceType, float $amount): void {
        // Simulate API call
        echo "  - Sent to Billing API: {$resourceType} = {$amount}\n";
    }
}

// Register handler that calls external API
$hooks->onUsageLimitCheck(function (Workspace $workspace, string $resourceType, float $currentUsage): bool {
    $quota = BillingAPI::checkQuota($workspace->workspaceId, $resourceType);
    echo "  - Quota from Billing API: {$quota['used']} / {$quota['limit']}\n";
    return $quota['used'] >= $quota['limit'];
});

$hooks->onRecordUsage(function (Workspace $workspace, string $resourceType, float $amount, array $metadata) {
    BillingAPI::recordUsage($workspace->workspaceId, $resourceType, $amount);
});

echo "Checking usage limit with external API:\n";
$isExceeded = $hooks->checkUsageLimit($workspace, 'api_calls', 8500);
echo "Result: " . ($isExceeded ? "EXCEEDED" : "OK") . "\n\n";

echo "Recording usage with external API:\n";
$hooks->recordUsage($workspace, 'api_calls', 100);

echo "\n=== Example Complete ===\n";
