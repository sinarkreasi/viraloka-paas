<?php

/**
 * Example 1: Basic Context Resolution
 * 
 * This example demonstrates the basic flow of resolving context
 * from workspace, theme, and system default sources.
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Viraloka\Core\Context\ContextResolver;
use Viraloka\Core\Context\ContextStackBuilder;
use Viraloka\Core\Context\RecommendationGraph;
use Viraloka\Core\Workspace\WorkspaceResolver;

// Mock workspace resolver that returns a workspace with context
$workspaceResolver = new class implements \Viraloka\Container\Contracts\WorkspaceResolverInterface {
    public function resolve(): ?\Viraloka\Core\Workspace\Workspace {
        return new \Viraloka\Core\Workspace\Workspace(
            'ws_123',
            'My Marketplace',
            ['context' => 'marketplace']
        );
    }
};

// Mock theme provider that returns theme context
$themeProvider = new class {
    public function getCurrentTheme(): ?object {
        return new class {
            public function getContext(): string {
                return 'digital';
            }
        };
    }
};

// Create the context resolver
$stackBuilder = new ContextStackBuilder();
$recommendationGraph = new RecommendationGraph();
$resolver = new ContextResolver(
    $workspaceResolver,
    $themeProvider,
    $stackBuilder,
    $recommendationGraph
);

// Resolve the context
$contextStack = $resolver->resolve();

// Display the results
echo "Context Resolution Results:\n";
echo "===========================\n\n";

echo "Primary Context: " . $contextStack->getPrimary()->getKey() . "\n";
echo "Priority: " . $contextStack->getPrimary()->getPriority() . "\n\n";

echo "Full Context Stack:\n";
foreach ($contextStack->getAll() as $context) {
    echo "  - {$context->getKey()} (priority: {$context->getPriority()})\n";
}

echo "\n";
echo "Has 'marketplace' context: " . ($contextStack->hasContext('marketplace') ? 'Yes' : 'No') . "\n";
echo "Has 'digital' context: " . ($contextStack->hasContext('digital') ? 'Yes' : 'No') . "\n";
echo "Has 'default' context: " . ($contextStack->hasContext('default') ? 'Yes' : 'No') . "\n";
