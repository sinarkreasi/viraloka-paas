<?php

/**
 * Example 2: Registering Recommendations
 * 
 * This example shows how to register and query recommendations
 * for different contexts using the RecommendationGraph.
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Viraloka\Core\Context\RecommendationGraph;

// Create a recommendation graph
$graph = new RecommendationGraph();

// Register recommendations for 'marketplace' context
$graph->register('marketplace', [
    'recommended_modules' => ['payment', 'inventory', 'shipping'],
    'optional_integrations' => ['analytics', 'email'],
    'ui_hints' => [
        'show_product_grid' => true,
        'enable_cart' => true,
        'layout' => 'grid'
    ]
]);

// Register recommendations for 'ai-service' context
$graph->register('ai-service', [
    'recommended_modules' => ['api', 'rate-limiter', 'auth'],
    'optional_integrations' => ['monitoring', 'logging'],
    'ui_hints' => [
        'show_api_docs' => true,
        'layout' => 'minimal'
    ]
]);

// Register recommendations for 'link-in-bio' context
$graph->register('link-in-bio', [
    'recommended_modules' => ['social-links', 'analytics'],
    'optional_integrations' => ['custom-domains'],
    'ui_hints' => [
        'show_link_list' => true,
        'enable_themes' => true,
        'layout' => 'vertical'
    ]
]);

// Query recommendations for different contexts
echo "Recommendation Graph Examples:\n";
echo "==============================\n\n";

// Example 1: Get all recommendations for marketplace
echo "Marketplace Context:\n";
$marketplaceRecs = $graph->getRecommendations('marketplace');
echo "  Recommended Modules: " . implode(', ', $marketplaceRecs['recommended_modules'] ?? []) . "\n";
echo "  Optional Integrations: " . implode(', ', $marketplaceRecs['optional_integrations'] ?? []) . "\n";
echo "  UI Hints: " . json_encode($marketplaceRecs['ui_hints'] ?? []) . "\n\n";

// Example 2: Get specific recommendation types
echo "AI Service Context:\n";
echo "  Recommended Modules: " . implode(', ', $graph->getRecommendedModules('ai-service')) . "\n";
echo "  Optional Integrations: " . implode(', ', $graph->getOptionalIntegrations('ai-service')) . "\n";
echo "  UI Hints: " . json_encode($graph->getUIHints('ai-service')) . "\n\n";

// Example 3: Query non-existent context (returns empty arrays)
echo "Non-existent Context:\n";
$emptyRecs = $graph->getRecommendations('non-existent');
echo "  Recommended Modules: " . (empty($emptyRecs['recommended_modules']) ? 'None' : implode(', ', $emptyRecs['recommended_modules'])) . "\n";
echo "  Optional Integrations: " . (empty($emptyRecs['optional_integrations']) ? 'None' : implode(', ', $emptyRecs['optional_integrations'])) . "\n";
echo "  UI Hints: " . (empty($emptyRecs['ui_hints']) ? 'None' : json_encode($emptyRecs['ui_hints'])) . "\n";
